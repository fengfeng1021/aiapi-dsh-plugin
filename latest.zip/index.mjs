import { FEATURES, readFeatures } from './modules/features.mjs';
import { apply as models } from './modules/models/index.mjs';
import { apply as engineering } from './modules/engineering/index.mjs';
import { apply as communication } from './modules/communication/index.mjs';
import { apply as infiniteContext } from './modules/infinite-context/index.mjs';
import { apply as skills } from './modules/skills/index.mjs';
import { apply as fonts } from './modules/fonts/host.mjs';
import { trackLineage } from './modules/lineage.mjs';
import { guardSocketTypeOfService } from './modules/net-guard.mjs';

export { Config } from './modules/config.mjs';

export const name = 'aiapi-customizations';
export const inject = ['connection', 'settings', 'credentials', 'skills', 'systemPrompt'];

/**
 * Host contributions, one mount per switchable feature. Each entry receives the plugin context of
 * its own fiber, so disposing it retracts exactly that feature's tools, prompt sections and routes.
 * @type {ReadonlyMap<string, (ctx: any, config: any, lineage: any) => void>}
 */
const HOST_MODULES = new Map([
  ['models', (ctx, config) => models(ctx, config)],
  ['engineering', ctx => engineering(ctx)],
  ['communication', (ctx, config) => communication(ctx, config)],
  ['infinite-context', ctx => infiniteContext(ctx)],
  ['skills', ctx => skills(ctx)],
  ['fonts', ctx => fonts(ctx)],
]);

/**
 * One fiber owns every host contribution; each feature runs in its own child fiber so a switch can
 * mount or dispose it alone.
 *
 * `features` is volatile, so flipping a switch does not remount this entry: the loader commits the
 * new value into the running reference and emits `loader/volatile-update`, and this listener mounts
 * or disposes the one affected feature. A config without `features` (an older entry) keeps every
 * feature on.
 * @param ctx - the customization plugin context.
 * @param config - volatile feature switches, progress interval and deployment-owned overrides.
 * @returns after the enabled features are mounted.
 */
export function apply(ctx, config = {}) {
  // Before anything makes a request: a Node bug in this DSH runtime otherwise turns some requests into an
  // uncaught exception that never settles (see net-guard.mjs).
  ctx.effect(() => guardSocketTypeOfService(ctx.logger), 'aiapi socket QoS guard');
  const lineage = trackLineage(ctx);
  // Settings are edited on this plugin's own pages, never through an automatic form of internal fields.
  ctx.effect(() => ctx.settings.configure({ auto: false }), 'aiapi settings presentation');

  /** Feature id to the fiber currently serving it. */
  const mounted = new Map();

  const sync = () => {
    const flags = readFeatures(config);
    for (const feature of FEATURES) {
      const mount = HOST_MODULES.get(feature.id);
      if (mount === undefined) continue;
      const fiber = mounted.get(feature.id);
      if (flags[feature.id] === true) {
        if (fiber !== undefined) continue;
        mounted.set(feature.id, ctx.plugin({
          name: `aiapi-${feature.id}`,
          apply: child => mount(child, config, lineage),
        }));
        continue;
      }
      if (fiber === undefined) continue;
      mounted.delete(feature.id);
      void Promise.resolve(fiber.dispose()).catch(reason => ctx.logger.error(reason));
    }
  };

  ctx.on('loader/volatile-update', sync);
  sync();
}
