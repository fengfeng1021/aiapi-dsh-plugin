import { FEATURES, readFeatures } from './modules/features.mjs';
import { PLUGIN_VERSION } from './modules/version.js';
import { reportError } from './modules/features/reporter.js';
import { applyGeneralRows, applyPluginPageRow, applyUpdateNotice, getFeatureValues, setFeatureValues, subscribeFeatures } from './modules/features/client.jsx';
import { applyAccount } from './modules/account/client.jsx';
import { KIT_CSS, installStyle } from './modules/ui/kit.jsx';
import { apply as brand } from '../aiapi-brand/client.jsx';
import { apply as models } from './modules/models/client.jsx';
import { apply as opencodeTheme } from './modules/opencode/client.jsx';
import { apply as fonts } from './modules/fonts/client.jsx';
import { apply as skills } from './modules/skills/client.jsx';
import { apply as workspaceOrder } from './modules/workspaces/order.mjs';

/**
 * Browser contributions, one mount per switchable feature. Each module registers its slots inside
 * its own fiber, so disposing it restores the official component or page that it replaced.
 * @type {ReadonlyMap<string, (ctx: any) => void>}
 */
const CLIENT_MODULES = new Map([
  ['brand', brand],
  ['models', models],
  ['opencode', opencodeTheme],
  ['fonts', fonts],
  ['skills', skills],
  // The workspace remote is optional: wait for it, and stay silent when this build does not expose it.
  ['workspace-order', scope => {
    if (typeof scope.inject === 'function') scope.inject(['remote.workspace'], injected => workspaceOrder(injected));
    else workspaceOrder(scope);
  }],
]);

export const name = 'aiapi-customizations';
// `remote.pluginManager` is declared because the 推薦插件 rows install through DSH's own plugin manager;
// reading a remote namespace that was not injected throws 「cannot get property … without inject」.
// Only services every supported DSH build has belong here: a missing one keeps this whole interface plugin from
// loading, which empties the sidebar (2026-11-01). Optional ones are injected at mount time instead.
export const inject = ['slots', 'remote', 'remote.session', 'remote.settings', 'remote.credentials', 'remote.pluginManager'];

/**
 * Every UI feature belongs to the same client plugin, but each runs in its own fiber gated by its
 * switch, and the 功能開關 row publishes changes so a toggle takes effect without a reload.
 * @param ctx - client plugin context.
 * @param config - the plugin config; `features` may hold volatile references on the Host side.
 * @returns nothing.
 */
export { PLUGIN_VERSION } from './modules/version.js';

// 全域錯誤只記錄一次，方便使用者回報「載入了什麼、哪一步炸掉」。
if (typeof window !== 'undefined' && window.__aiapiErrorHook !== true) {
  window.__aiapiErrorHook = true;
  window.addEventListener('error', event => {
    console.warn('[aiapi] 未捕捉錯誤:', event?.message, event?.filename, event?.lineno);
    void reportError({ message: event?.message, stack: event?.error?.stack, where: `window:${event?.filename ?? ''}:${event?.lineno ?? ''}` }, globalThis.__aiapiReportingEnabled !== false);
  });
  window.addEventListener('unhandledrejection', event => {
    console.warn('[aiapi] 未處理的 Promise:', event?.reason);
    void reportError({ message: String(event?.reason?.message ?? event?.reason ?? ''), stack: event?.reason?.stack, where: 'unhandledrejection' }, globalThis.__aiapiReportingEnabled !== false);
  });
}

export function apply(ctx, config = {}) {
  setFeatureValues(readFeatures(config));

  /** Feature id to the fiber currently serving it. */
  const mounted = new Map();

  // A carrier without child fibers still loads every enabled feature; only live switching is lost.
  const gated = typeof ctx.plugin === 'function';

  const sync = () => {
    const flags = getFeatureValues();
    for (const feature of FEATURES) {
      const mount = CLIENT_MODULES.get(feature.id);
      if (mount === undefined) continue;
      const fiber = mounted.get(feature.id);
      if (flags[feature.id] !== false) {
        if (fiber !== undefined) continue;
        if (!gated) {
          mount(ctx);
          mounted.set(feature.id, undefined);
          continue;
        }
        mounted.set(feature.id, ctx.plugin({ name: `aiapi-client-${feature.id}`, apply: mount }));
        continue;
      }
      if (!mounted.has(feature.id)) continue;
      const held = mounted.get(feature.id);
      mounted.delete(feature.id);
      if (held === undefined) continue;
      void Promise.resolve(held.dispose()).catch(reason => ctx.logger.error(reason));
    }
  };

  ctx.effect(() => subscribeFeatures(sync), 'aiapi feature switches');
  sync();
  // 每個區塊獨立保護：一個註冊失敗不該拖垮整個插件的介面。
  const safe = (label, run) => {
    try { return run(); } catch (failure) { console.warn(`[aiapi] ${label} 掛載失敗:`, failure); return undefined; }
  };
  globalThis.__aiapiReportingEnabled = config?.errorReporting !== false;
  console.info('[aiapi] 客戶端版本', PLUGIN_VERSION, '| 錯誤回報', globalThis.__aiapiReportingEnabled ? 'on' : 'off');
  installStyle(ctx, 'kit', KIT_CSS);
  // 帳號與餘額在 DSH 自己的「账号与余额」頁裡；側邊欄餘額也由同一個模組提供。
  safe('account', () => applyAccount(ctx));
  safe('plugin page', () => applyPluginPageRow(ctx));
  safe('general rows', () => applyGeneralRows(ctx));
  safe('update notice', () => applyUpdateNotice(ctx));
}
