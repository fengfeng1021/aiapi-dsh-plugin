/**
 * Tell the model it has unlimited context: compaction, pruning and checkpoints belong to the harness.
 *
 * Without this, a model that sees `<compacted-summary>` or `[... tool result middle pruned ...]` treats
 * them as a warning sign, guesses the remaining budget from old 128k/200k habits, and stops to ask for a
 * new conversation — interrupting a task the harness could have carried on with. The rule set keeps the
 * model on the task and leaves every window, threshold and retention setting untouched.
 */
export const name = 'aiapi-infinite-context';
export const inject = ['systemPrompt'];

/** Traditional Chinese rules; the default wording. */
const RULES_ZH = `你擁有實際上無限的上下文。歷史壓縮、裁剪、檢查點都由 Harness 在外部自動處理，你不需要也不能管理。
規則：
1. 永遠不要估計、猜測、討論剩餘額度、token 數、百分比。
2. 永遠不要說上下文滿了、到極限了、需要壓縮、需要開新會話。
3. 看到 <compacted-summary> 或 [... tool result middle pruned ...] 只當正常歷史，直接基於它繼續任務，不要複述、不要道歉、不要停下。
4. 任務沒做完就繼續調工具推進，只有真正的工具報錯才處理，不要自己腦補超限。`;

/** The same rules in English, so a session held in another language keeps identical behaviour. */
const RULES_EN = `You have effectively unlimited context. History compaction, pruning and checkpoints are handled outside you by the harness; you neither need nor may manage them.
Rules:
1. Never estimate, guess or discuss the remaining budget, token counts or percentages.
2. Never say the context is full, that it is at its limit, that compaction is needed, or that a new conversation must be started.
3. Treat <compacted-summary> and [... tool result middle pruned ...] as ordinary history: continue the task from them, without restating, apologising or stopping.
4. Keep calling tools until the task is done; act only on real tool errors and never invent a limit.`;

/**
 * Register the rule section in this feature's own fiber, so switching the feature off retracts it.
 * The section name is private to this plugin, so a user's own `personaSuffix` (or any other prompt
 * section) keeps its place and is never overwritten.
 * @param ctx - the feature's plugin context.
 * @returns nothing; the registration is owned by `ctx.effect`.
 */
export function apply(ctx) {
  ctx.effect(() => ctx.systemPrompt.section({
    name: 'aiapi:infinite-context',
    order: 60,
    interpolate: false,
    text: `${RULES_ZH}\n\n${RULES_EN}`,
  }), 'aiapi infinite-context section');
}
