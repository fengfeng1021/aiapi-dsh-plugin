/**
 * Fonts in Settings → General: for conversation text, code and the terminal, pick a family this computer actually
 * has and set the size.
 *
 * The row takes the place of DSH's own font group (same id, lower priority) and writes through the same official
 * theme service (`setFontFamily`, `setFontSize`), so values persist in the user's settings exactly as DSH's own
 * fields would and switching the feature off brings DSH's group back with the same values. Nothing is applied on
 * load: the theme service already owns that.
 *
 * Cascadia Mono, Maple Mono CN and Noto Sans Mono ship with the plugin (OFL; served by modules/fonts/host.mjs), so
 * they work on every machine. Other families are offered only when the browser can render them. A chosen list is
 * placed ahead of DSH's built-in stack, so anything it does not cover still falls back to system fonts.
 */
import React, { useEffect, useMemo, useState } from 'react';
import { installStyle } from '../ui/kit.jsx';

/** Roles, their size ranges (DSH's own) and the families worth offering for each. */
const ROLES = [
  {
    id: 'text', title: '對話與介面', min: 10, max: 22, fallback: 14,
    sample: 'Aiapi 字型預覽 · 繁體 简体 0123',
    families: ['PingFang TC', 'PingFang SC', 'PingFang HK', 'Hiragino Sans', 'Hiragino Sans GB', 'Noto Sans TC', 'Noto Sans SC', 'Noto Sans CJK TC', 'Source Han Sans TC', 'Source Han Sans SC', 'Microsoft JhengHei UI', 'Microsoft JhengHei', 'Microsoft YaHei UI', 'Microsoft YaHei', 'LXGW WenKai TC', 'LXGW WenKai', 'Sarasa Gothic TC', 'Inter', 'Helvetica Neue', 'Segoe UI', 'Roboto', 'Maple Mono CN', 'Maple Mono NF CN', 'Cascadia Mono', 'JetBrains Mono'],
  },
  {
    id: 'code', title: '程式碼', min: 10, max: 16, fallback: 11,
    sample: 'const ok = 0x1F; // 程式碼 0Oo1lI',
    families: ['SF Mono', 'Menlo', 'Monaco', 'JetBrains Mono', 'Fira Code', 'Cascadia Code', 'Cascadia Mono', 'Consolas', 'Source Code Pro', 'IBM Plex Mono', 'Roboto Mono', 'Noto Sans Mono', 'Maple Mono', 'Maple Mono CN', 'Maple Mono NF CN', 'Sarasa Mono TC', 'Sarasa Mono SC', 'Hack', 'Iosevka', 'Ubuntu Mono', 'Courier New'],
  },
  {
    id: 'terminal', title: '終端機', min: 10, max: 20, fallback: 13,
    sample: '$ git status  # 終端機 0123',
    families: ['SF Mono', 'Menlo', 'Monaco', 'JetBrains Mono', 'Fira Code', 'Cascadia Code', 'Cascadia Mono', 'Consolas', 'Source Code Pro', 'IBM Plex Mono', 'Roboto Mono', 'Noto Sans Mono', 'Maple Mono', 'Maple Mono CN', 'Maple Mono NF CN', 'Sarasa Mono TC', 'Hack', 'Iosevka', 'Ubuntu Mono'],
  },
];

/** Where the bundled font files are served (relative, so a path-prefixed app still works). */
const FONT_ROUTE = 'api/aiapi/fonts/';

/** Faces for the bundled families. Maple Mono CN covers CJK only; Latin falls through to the Latin family. */
const FONT_FACES = `
@font-face{font-family:'Cascadia Mono';font-style:normal;font-weight:200 700;font-display:swap;src:url('${FONT_ROUTE}cascadia-mono.woff2') format('woff2')}
@font-face{font-family:'Cascadia Mono';font-style:italic;font-weight:200 700;font-display:swap;src:url('${FONT_ROUTE}cascadia-mono-italic.woff2') format('woff2')}
@font-face{font-family:'Noto Sans Mono';font-style:normal;font-weight:100 900;font-display:swap;src:url('${FONT_ROUTE}noto-sans-mono-latin-ext.woff2') format('woff2');unicode-range:U+0100-02BA,U+02BD-02C5,U+02C7-02CC,U+02CE-02D7,U+02DD-02FF,U+0304,U+0308,U+0329,U+1D00-1DBF,U+1E00-1E9F,U+1EF2-1EFF,U+2020,U+20A0-20AB,U+20AD-20C0,U+2113,U+2C60-2C7F,U+A720-A7FF}
@font-face{font-family:'Noto Sans Mono';font-style:normal;font-weight:100 900;font-display:swap;src:url('${FONT_ROUTE}noto-sans-mono-latin.woff2') format('woff2');unicode-range:U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+0304,U+0308,U+0329,U+2000-206F,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD}
${[[400, '400 500'], [700, '600 800']].map(([file, range]) => `@font-face{font-family:'Maple Mono CN';font-style:normal;font-weight:${range};font-display:swap;src:url('${FONT_ROUTE}maple-mono-cn-${file}.woff2') format('woff2');unicode-range:U+2E80-2EFF,U+2F00-2FDF,U+3000-303F,U+3040-309F,U+30A0-30FF,U+3100-312F,U+3130-318F,U+3190-319F,U+31A0-31FF,U+3200-32FF,U+3300-33FF,U+3400-4DBF,U+4E00-9FFF,U+A000-A48F,U+A490-A4CF,U+AC00-D7AF,U+D7B0-D7FF,U+F900-FAFF,U+FE10-FE1F,U+FE30-FE4F,U+FF00-FF60,U+FFE0-FFE6,U+20000-2EBEF,U+2F800-2FA1F,U+30000-323AF}`).join('\n')}
`;

/** Lists built only from bundled families; offered on every machine, first in each picker. */
const BUNDLED = [
  { value: '"Cascadia Mono", "Maple Mono CN"', label: 'Cascadia Mono + Maple Mono CN', roles: ['text', 'code', 'terminal'] },
  { value: '"Noto Sans Mono", "Maple Mono CN"', label: 'Noto Sans Mono + Maple Mono CN', roles: ['text', 'code', 'terminal'] },
  { value: '"Maple Mono CN"', label: 'Maple Mono CN', roles: ['text'] },
  { value: '"Cascadia Mono"', label: 'Cascadia Mono', roles: ['code', 'terminal'] },
  { value: '"Noto Sans Mono"', label: 'Noto Sans Mono', roles: ['code', 'terminal'] },
];

/** Families the plugin ships; never listed again as "installed". */
const BUNDLED_FAMILIES = new Set(['Cascadia Mono', 'Maple Mono CN', 'Noto Sans Mono']);

/** Compare font lists however they are quoted or spaced. */
const fontKey = list => String(list ?? '').replace(/["']/g, '').split(',').map(part => part.trim().toLowerCase()).filter(Boolean).join(',');

/**
 * Fallback chain appended after the user's own list and before DSH's built-in stack.
 *
 * DSH inserts the chosen list ahead of `--dsh-font-family-text-default`, whose first CJK family is
 * `"PingFang SC"` — a Simplified-first face. Any glyph the chosen font does not carry (a Latin-only
 * pick, a rare character, CJK punctuation inside a mono font) therefore rendered with Simplified
 * shapes, which reads as "some characters did not get the font". Putting Traditional-first families
 * between the two keeps Traditional text consistent and leaves Simplified text untouched.
 */
const TEXT_FALLBACKS = '"PingFang TC", "Hiragino Sans", "Microsoft JhengHei", "Noto Sans CJK TC", "Source Han Sans TC", "PingFang SC", "Microsoft YaHei"';
const CODE_FALLBACKS = '"Maple Mono CN", "Sarasa Mono TC", "Sarasa Mono SC", "PingFang TC", "Microsoft JhengHei"';
/** The terminal is measured by the emulator in JavaScript and never reads a CSS variable, so its CJK fallback
 *  has to travel inside the stored value; pickers compensate with `cleanFamilyList` so the label stays short. */
const TERMINAL_FALLBACKS = '"Maple Mono CN", "Sarasa Mono TC", "PingFang TC", "Microsoft JhengHei"';

/** Families that are purely ours, never a user's own choice. */
const FALLBACK_FAMILIES = new Set(['PingFang TC', 'Hiragino Sans', 'Microsoft JhengHei', 'Noto Sans CJK TC',
  'Source Han Sans TC', 'PingFang SC', 'Microsoft YaHei', 'Maple Mono CN', 'Sarasa Mono TC', 'Sarasa Mono SC']);

/** Every list the plugin uses for one role, so the sample and the real reply agree. */
const ROLE_FALLBACKS = { text: TEXT_FALLBACKS, code: CODE_FALLBACKS, terminal: TERMINAL_FALLBACKS };

/** The full stack a role actually renders with; used by the samples and by the terminal write. */
const stackFor = (roleId, value) => (value === '' || value === undefined ? '' : `${value}, ${ROLE_FALLBACKS[roleId] ?? ''}`);

/** Drop our own fallback families from a stored list, so the picker still shows the family the user chose. */
const cleanFamilyList = list => String(list ?? '').replace(/["']/g, '').split(',').map(part => part.trim())
  .filter(part => part !== '' && !FALLBACK_FAMILIES.has(part)).join(', ');

/** `html body` outranks DSH's own `body` rule, so our chain lands before the built-in default. */
const FONT_FALLBACK_CSS = `
html body{
  --dsw-font-family:var(--dsh-font-family-text,var(--dsh-font-family-text-default)), ${TEXT_FALLBACKS}, var(--dsh-font-family-text-default);
  --ds-font-family-code:var(--dsh-font-family-code,var(--dsh-font-family-code-default)), ${CODE_FALLBACKS}, var(--dsh-font-family-code-default);
  --dsh-font-family-terminal:var(--dsh-font-family-terminal,${TERMINAL_FALLBACKS}), ${TERMINAL_FALLBACKS};
}
`;

const FONTS_CSS = `
.aiapi-fonts{padding:16px 0;border-bottom:.5px solid var(--dsw-alias-border-l2)}
.aiapi-fonts-head{margin-bottom:12px}
.aiapi-fonts .aiapi-card{padding:4px 16px}
.aiapi-fonts .aiapi-row{min-height:56px}
.aiapi-fonts .aiapi-row-copy{flex:1 1 auto;min-width:0}
.aiapi-fonts-sample{font-size:12px;line-height:18px;color:var(--dsw-alias-label-tertiary);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.aiapi-fonts .aiapi-select{min-width:180px;width:180px}
/* 每個角色一列，比較清單掛在同一塊裡，跟著那一列走。 */
.aiapi-fonts-role+.aiapi-fonts-role{border-top:.5px solid var(--dsw-alias-border-l1)}
.aiapi-fonts-compare-toggle{border:none;background:transparent;color:var(--dsw-alias-link);font:inherit;font-size:12px;line-height:18px;padding:0;cursor:pointer;text-decoration:underline;text-underline-offset:2px;white-space:nowrap}
.aiapi-fonts-compare{padding:2px 0 12px;display:flex;flex-direction:column;gap:1px;max-height:264px;overflow:auto}
.aiapi-fonts-compare-item{display:flex;align-items:baseline;gap:12px;width:100%;padding:5px 8px;border:none;border-radius:8px;background:transparent;color:inherit;cursor:pointer;text-align:left;font:inherit}
.aiapi-fonts-compare-item:hover,.aiapi-fonts-compare-item[data-active='true']{background:var(--dsw-alias-interactive-bg-hover)}
.aiapi-fonts-compare-label{flex:none;width:150px;font-size:11px;line-height:16px;color:var(--dsw-alias-label-tertiary);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.aiapi-fonts-compare-sample{flex:1 1 auto;font-size:13px;line-height:20px;color:var(--dsw-alias-label-primary);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
/* 預覽用實際字級，看到的就是回覆那個大小。 */
.aiapi-fonts-preview{margin-top:12px;padding:14px 16px;border:.5px solid var(--dsw-alias-settings-card-stroke);border-radius:var(--dsw-radius-xl);background:var(--dsw-alias-settings-card-fill)}
.aiapi-fonts-preview-head{font-size:12px;line-height:18px;color:var(--dsw-alias-label-tertiary);margin-bottom:10px}
.aiapi-fonts-preview-row+.aiapi-fonts-preview-row{margin-top:10px;padding-top:10px;border-top:.5px solid var(--dsw-alias-border-l1)}
.aiapi-fonts-preview-label{font-size:11px;line-height:16px;color:var(--dsw-alias-label-tertiary);margin-bottom:2px}
.aiapi-fonts-preview-text{color:var(--dsw-alias-label-primary);line-height:1.6;word-break:break-word}
.aiapi-stepper{display:inline-flex;align-items:center;border:.5px solid var(--dsw-alias-border-l3);border-radius:var(--dsw-radius-md);height:32px;overflow:hidden}
.aiapi-stepper button{width:30px;height:100%;border:none;background:transparent;color:var(--dsw-alias-label-primary);font:inherit;font-size:15px;cursor:pointer}
.aiapi-stepper button:hover:not(:disabled){background:var(--dsw-alias-interactive-bg-hover)}
.aiapi-stepper button:disabled{color:var(--dsw-alias-label-dimmed);cursor:default}
.aiapi-stepper span{min-width:44px;text-align:center;font-size:13px;font-variant-numeric:tabular-nums}
`;

/**
 * Whether the browser renders a family: text measured in it differs from the generic fallback it names.
 * @param family - family name.
 * @returns true when installed (or otherwise available to the page).
 */
function renders(family) {
  const canvas = renders.canvas ??= document.createElement('canvas');
  const context = canvas.getContext('2d');
  if (context === null) return true;
  const sample = 'mmmmmmmmmmlli1WW@# 中文字型 0123';
  return ['monospace', 'sans-serif', 'serif'].some(base => {
    context.font = `48px ${base}`;
    const fallback = context.measureText(sample).width;
    context.font = `48px "${family}", ${base}`;
    return context.measureText(sample).width !== fallback;
  });
}

/** Read DSH's theme service, which may start after this plugin. */
const themeOf = ctx => { try { return ctx.get('theme'); } catch { return undefined; } };

/** The theme snapshot, re-read whenever the theme publishes. */
function useThemeSnapshot(ctx) {
  const [snapshot, setSnapshot] = useState(() => themeOf(ctx)?.getTheme?.());
  useEffect(() => {
    const read = () => setSnapshot(themeOf(ctx)?.getTheme?.());
    read();
    const off = typeof ctx.on === 'function' ? ctx.on('theme/change', read) : undefined;
    const timer = setInterval(read, 1500);
    return () => { off?.(); clearInterval(timer); };
  }, [ctx]);
  return snapshot;
}

/**
 * One role: family picker with a live sample, the size stepper, and an optional list that renders the same sample in
 * every available family so the choice can be compared instead of guessed.
 */
function RoleRow({ ctx, role, snapshot }) {
  const installed = useMemo(() => role.families.filter(family => !BUNDLED_FAMILIES.has(family)).filter(renders), [role]);
  const stored = snapshot?.fontFamilies?.[role.id] ?? '';
  const size = snapshot?.fontSizes?.[role.id] ?? role.fallback;
  const [error, setError] = useState('');
  const [compare, setCompare] = useState(false);
  const run = action => {
    try { action(themeOf(ctx)); setError(''); }
    catch (failure) { setError(failure?.message ?? String(failure)); }
  };
  const options = [
    ...BUNDLED.filter(option => option.roles.includes(role.id)).map(option => ({ value: option.value, label: `${option.label}（內建）` })),
    ...installed.map(family => ({ value: `"${family}"`, label: family })),
  ];
  const selected = options.find(option => fontKey(option.value) === fontKey(cleanFamilyList(stored)));
  const current = stored === '' ? '' : selected?.value ?? stored;
  if (stored !== '' && selected === undefined) options.unshift({ value: stored, label: `目前：${cleanFamilyList(stored)}` });
  return <div className="aiapi-fonts-role">
    <div className="aiapi-row">
      <div className="aiapi-row-copy">
        <span className="aiapi-row-title">{role.title}</span>
        <span className="aiapi-fonts-sample" style={{ fontFamily: stackFor(role.id, stored) || undefined }}>{role.sample}</span>
        {error === '' ? null : <span className="aiapi-row-caption aiapi-error-text">{error}</span>}
      </div>
      <div className="aiapi-row-actions">
        <select className="aiapi-select" aria-label={`${role.title}字型`} value={current} onChange={event => run(theme => theme.setFontFamily(role.id, role.id === 'terminal' ? stackFor('terminal', event.target.value) : event.target.value))}>
          <option value="">系統預設</option>
          {options.map(option => <option key={option.value} value={option.value}>{option.label}</option>)}
        </select>
        <span className="aiapi-stepper" role="group" aria-label={`${role.title}字級`}>
          <button type="button" aria-label="縮小" disabled={size <= role.min} onClick={() => run(theme => theme.setFontSize(role.id, size - 1))}>−</button>
          <span>{size} px</span>
          <button type="button" aria-label="放大" disabled={size >= role.max} onClick={() => run(theme => theme.setFontSize(role.id, size + 1))}>＋</button>
        </span>
        <button type="button" className="aiapi-fonts-compare-toggle" aria-expanded={compare} onClick={() => setCompare(value => !value)}>
          {compare ? '收起' : '比較字型'}
        </button>
      </div>
    </div>
    {compare ? <div className="aiapi-fonts-compare" role="listbox" aria-label={`${role.title}字型比較`}>
      {options.map(option => <button key={option.value} type="button" role="option" aria-selected={option.value === current}
        className="aiapi-fonts-compare-item" data-active={option.value === current ? 'true' : undefined}
        onClick={() => run(theme => theme.setFontFamily(role.id, option.value))}>
        <span className="aiapi-fonts-compare-label">{option.label}</span>
        <span className="aiapi-fonts-compare-sample" style={{ fontFamily: stackFor(role.id, option.value) || undefined }}>{role.sample}</span>
      </button>)}
    </div> : null}
  </div>;
}

/** The three roles at their real family and size — what the reply will actually look like. */
const PREVIEW_TEXT = {
  text: '今天的回覆會用這個字型與大小呈現：金額 $1,234.56、時間 15:24，繁體與简体都清楚。',
  code: 'const answer = 42; // 中文註解 · 0Oo1lI',
  terminal: '$ npm test -- --watch   # 終端機 0123',
};

/**
 * What the current choices look like at their real size.
 * @param root0 - theme snapshot.
 * @param root0.snapshot - font families and sizes DSH currently holds.
 * @returns the preview block.
 */
function FontPreview({ snapshot }) {
  return <div className="aiapi-fonts-preview">
    <div className="aiapi-fonts-preview-head">預覽：套用目前選擇的字型與大小（改動後立即反映）</div>
    {ROLES.map(role => {
      const family = snapshot?.fontFamilies?.[role.id] ?? '';
      const size = snapshot?.fontSizes?.[role.id] ?? role.fallback;
      return <div className="aiapi-fonts-preview-row" key={role.id}>
        <div className="aiapi-fonts-preview-label">{role.title} · {size} px</div>
        <div className="aiapi-fonts-preview-text" style={{ fontFamily: stackFor(role.id, family) || undefined, fontSize: `${size}px` }}>{PREVIEW_TEXT[role.id]}</div>
      </div>;
    })}
  </div>;
}

/** The whole group that takes the place of DSH's font settings. */
function FontSettings({ ctx }) {
  const snapshot = useThemeSnapshot(ctx);
  if (themeOf(ctx) === undefined) return null;
  return <div className="aiapi-fonts">
    <div className="aiapi-fonts-head">
      <div className="aiapi-general-title">字型與字級</div>
      <div className="aiapi-general-description">標示「內建」的字型隨插件附上，每台電腦都能用；其餘是這台電腦已安裝的字型</div>
    </div>
    <div className="aiapi-card">
      {ROLES.map(role => <RoleRow key={role.id} ctx={ctx} role={role} snapshot={snapshot} />)}
    </div>
    <FontPreview snapshot={snapshot} />
  </div>;
}

/**
 * Show the font group in place of DSH's own for this client plugin lifetime.
 * @param ctx - client plugin context.
 */
export function apply(ctx) {
  installStyle(ctx, 'font-faces', FONT_FACES);
  installStyle(ctx, 'fonts', FONTS_CSS);
  // 使用者選的字型沒有的字（含繁中字形差異）由這條後援鏈接手，避免掉回簡中字面。
  installStyle(ctx, 'font-fallbacks', FONT_FALLBACK_CSS);
  // A shared id: the lowest priority renders, and DSH's own font group registers at 0.
  ctx.slots.inject('settings.general.item', () => ctx.slots.register(
    { name: 'settings.general.item', id: 'font-size', priority: -1, order: 11 },
    () => <FontSettings ctx={ctx} />,
  ));
}
