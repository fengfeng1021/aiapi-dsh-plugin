import { readFileSync, readdirSync } from 'node:fs';
import { fileURLToPath } from 'node:url';

export const name = 'aiapi-engineering';
export const inject = ['skills', 'systemPrompt'];
/** Contributions belong to this plugin fiber, never to permanent user files. */
export function apply(ctx) {
  ctx.systemPrompt.context({ name: 'aiapi:engineering', order: 80, text: 'For software changes, load aiapi-engineering-rules. Follow the target repository instructions and its own test commands. Preserve user changes. Use DSH plugin extension points and disposable registrations. Validate changed behavior, review the final diff, and recheck fixes against the original issue. The aiapi-code-review skill provides focused review and verification guidance adapted from Codex; it does not replace the DSH engine or authorize external actions. Preview updates must remain isolated from stable; promotion requires explicit user confirmation.' });
  const root = new URL('./skills/', import.meta.url);
  for (const folder of readdirSync(root, { withFileTypes: true }).filter(entry => entry.isDirectory())) {
    const url = new URL(`${folder.name}/SKILL.md`, root);
    const raw = readFileSync(url, 'utf8');
    const match = /^---\r?\nname: ([^\r\n]+)\r?\ndescription: ([^\r\n]+)\r?\n---\r?\n([\s\S]*)$/.exec(raw);
    if (!match) throw new Error(`Invalid packaged skill: ${folder.name}`);
    ctx.skills.register({ name: match[1], description: match[2], content: match[3], source: 'bundled', provider: 'aiapi-engineering', path: fileURLToPath(url), resourceBase: { kind: 'directory', path: fileURLToPath(new URL('./', url)) } });
  }
}
