/** Bounded text for user-requested conversation handoffs; no model call is involved. */
import { renderLedger } from './ledger.mjs';
import { clipTokens, contentText, estimateTokens } from './text.mjs';

/** Demote headings inside quoted excerpts so they cannot read as sections of the handoff itself. */
const quoted = text => text.replace(/^#{1,6}[ \t]*/gm, '▸ ');

/**
 * Human prompts from the source conversation, oldest first, within a token budget.
 * The newest prompts are kept first when the budget is short; every omission names its recall ref.
 * @param prompts - `{ seq, text }` human prompts.
 * @param maxTokens - total budget.
 * @returns Markdown lines.
 */
export function promptLines(prompts, maxTokens) {
  const lines = [];
  let used = 0;
  for (const prompt of [...prompts].reverse()) {
    const room = Math.max(120, Math.min(1800, maxTokens - used));
    const text = clipTokens(prompt.text.trim(), room, `…（後略，完整原文用 context_recall 讀取 ref r${prompt.seq}）`);
    used += estimateTokens(text);
    lines.push(`- [r${prompt.seq}] ${text.replace(/\n+/g, '\n  ')}`);
    if (used >= maxTokens) {
      const rest = prompts.length - lines.length;
      if (rest > 0) lines.push(`- 另有 ${rest} 則較早的要求，請用 context_recall 依 ref 讀取：${prompts.slice(0, rest).map(item => `r${item.seq}`).join('、')}`);
      break;
    }
  }
  return lines.reverse();
}

/**
 * The final assistant reply of each selected human turn: decisions,
 * standards, and explanations that the requirements and the task state may not record.
 * The newest replies are kept first when the budget is short.
 * @param events - session events in order.
 * @param promptSeqs - seqs of the human prompts, in order.
 * @param hidden - whether to include an event seq in the handoff.
 * @param maxTokens - total budget.
 * @returns Markdown lines in conversation order.
 */
export function conclusionLines(events, promptSeqs, hidden, maxTokens) {
  const replies = [];
  promptSeqs.forEach((start, index) => {
    const end = promptSeqs[index + 1] ?? Infinity;
    let reply;
    for (const event of events) {
      if (event.seq <= start || event.seq >= end || event.type !== 'assistant/message') continue;
      if (event.surfaceOp && event.surfaceOp !== 'append') continue;
      const text = contentText(event.data.message.content.filter(block => block.type === 'text')).trim();
      if (text !== '') reply = { prompt: start, seq: event.seq, text };
    }
    if (reply !== undefined && hidden(reply.seq)) replies.push(reply);
  });
  const lines = [];
  let used = 0;
  for (const reply of replies.reverse()) {
    const room = Math.min(400, maxTokens - used);
    if (room < 80) break;
    const text = clipTokens(quoted(reply.text).replace(/\s+/g, ' '), room, `…（完整回覆用 context_recall 讀取 r${reply.seq}）`);
    used += estimateTokens(text);
    lines.push(`- [回覆 r${reply.prompt} 的 r${reply.seq}] ${text}`);
  }
  return lines.reverse();
}

/**
 * Text handed to a new conversation that continues the same work.
 * @param input - `{ cwd, fromTitle, fromSessionId, prompts, conclusions?, ledger, ledgerSeq, deliverables, files, finalReport, summary }`.
 * @returns bounded Markdown handoff.
 */
export function buildHandoff(input) {
  const lines = [
    '# 續做交接（由 AiApi Agent 自動整理）',
    `來源對話：${input.fromTitle || input.fromSessionId}（${input.fromSessionId}）`,
    `工作區：${input.cwd}`,
    '請先閱讀這份交接，確認需求、已完成成果與待辦，再繼續未完成的部分。不要重做已完成或已淘汰的項目；不確定時先讀取下方列出的成果檔案。',
  ];
  if (input.prompts.length > 0) lines.push('## 使用者的要求（原文）', ...promptLines(input.prompts, 3000));
  if (input.conclusions?.length > 0) lines.push('## 各輪結論（節錄，含已向使用者說明的決定與標準）', ...input.conclusions);
  if (input.ledgerSeq >= 0) lines.push('## 任務狀態', clipTokens(renderLedger(input.ledger, { maxItems: 60, finishedChars: 5000 }), 3500, '\n…（其餘項目請讀取來源對話或成果檔）'));
  const outputs = [...new Set([...input.deliverables, ...Object.keys(input.ledger.outputs)])];
  if (outputs.length > 0) lines.push('## 已交付或記錄的成果檔案', ...outputs.slice(0, 60).map(path => `- ${path}`));
  if (input.files.length > 0) lines.push('## 曾寫入或修改的檔案（最近）', ...input.files.slice(-30).map(path => `- ${path}`));
  if (input.summary) lines.push('## 先前的摘要（節錄）', clipTokens(quoted(input.summary), 1500, '…'));
  if (input.finalReport) lines.push('## 上一段對話最後的說明（節錄）', clipTokens(quoted(input.finalReport), 1200, '…'));
  return clipTokens(lines.join('\n'), 9000, '\n…（交接內容已達上限）');
}
