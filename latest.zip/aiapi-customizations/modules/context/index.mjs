/** Durable task state, original-log lookup, and user-requested conversation handoff. */
import { homedir } from 'node:os';
import { join } from 'node:path';
import { createContextTools, sessionEvents } from './tools.mjs';
import { handoffMessages, registerHandoffRoute } from './handoff.mjs';

export const name = 'aiapi-context';

const GUIDANCE = `For long or multi-step tasks, keep task_state current with the goal, user requirements, constraints, acceptance criteria, completed and pending items, evidence, output files, and next steps. This state supports the user's "continue in a new conversation" action. Save detailed results in files and consult completed items before repeating work. context_recall can read original logged messages by their r-reference.`;

/**
 * Register tools and a handoff route without changing existing model-visible history.
 * @param ctx - customization plugin context.
 * @returns after reversible contributions are registered.
 */
export function apply(ctx) {
  const home = process.env.DSH_HOME || join(homedir(), '.dsh');
  ctx.inject(['systemPrompt'], scope => {
    scope.systemPrompt.section({ name: 'aiapi:task-state', order: 60, text: GUIDANCE, interpolate: false });
  });
  ctx.inject(['tools'], async scope => {
    try {
      const { defineTool } = await import('@deepseek-ai/dsh-tools');
      for (const tool of createContextTools(defineTool)) scope.tools.register(tool);
    } catch (error) {
      scope.logger?.warn?.(`aiapi-context: task_state and context_recall are unavailable: ${error instanceof Error ? error.stack : error}`);
    }
  });
  ctx.on('agent/pre-step', async ({ agent }, next) => {
    const decision = await next();
    if (decision?.kind !== 'enter' || (agent.session.header?.delegationDepth ?? 0) > 0) return decision;
    try {
      const handoff = await handoffMessages(sessionEvents(agent.session), String(agent.session.id), decision.messages, home);
      return handoff.messages === decision.messages ? decision : { ...decision, messages: handoff.messages };
    } catch (error) {
      ctx.logger?.warn?.(`aiapi-context: handoff expansion skipped: ${error instanceof Error ? error.message : error}`);
      return decision;
    }
  });
  ctx.inject(['connection', 'sessionController', 'workspaceRegistry'], scope => registerHandoffRoute(scope, home));
}
