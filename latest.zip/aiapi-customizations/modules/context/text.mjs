/** Text measurement and bounded excerpts for task-state tools and handoffs. */

const WIDE = /[ᄀ-ᇿ⺀-鿿ꥠ-꥿가-퟿豈-﫿︰-﹏＀-￯]/g;

/**
 * Conservative token estimate: one token per CJK character, about 3.6 characters per token otherwise.
 * Matches observed provider usage on mixed Traditional Chinese and code within a few percent.
 * @param text - plain text.
 * @returns estimated tokens.
 */
export function estimateTokens(text) {
  if (!text) return 0;
  const wide = text.match(WIDE)?.length ?? 0;
  return Math.ceil(wide + (text.length - wide) / 3.6);
}

/**
 * Trim text to a token budget by keeping its head.
 * @param text - source text.
 * @param maxTokens - token budget.
 * @param suffix - appended when trimmed.
 * @returns text within the budget.
 */
export function clipTokens(text, maxTokens, suffix = '…') {
  if (estimateTokens(text) <= maxTokens) return text;
  let low = 0;
  let high = text.length;
  while (low < high) {
    const middle = Math.ceil((low + high) / 2);
    if (estimateTokens(text.slice(0, middle)) + estimateTokens(suffix) <= maxTokens) low = middle;
    else high = middle - 1;
  }
  return text.slice(0, low) + suffix;
}

/**
 * Plain text of message content; non-text blocks are summarized by type.
 * @param content - message content blocks.
 * @returns concatenated text.
 */
export function contentText(content) {
  return (Array.isArray(content) ? content : []).map(block => {
    if (block?.type === 'text') return block.text;
    if (block?.type === 'image') return `[圖片 ${block.attachment?.name ?? ''}]`;
    if (block?.type === 'file') return `[檔案 ${block.attachment?.name ?? ''}]`;
    return '';
  }).filter(Boolean).join('\n');
}
