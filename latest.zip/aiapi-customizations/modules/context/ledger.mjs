/**
 * Durable task state for long tasks, folded from logged `task_state` tool calls.
 * Pure data functions: the session log is the only store, so the same calls always rebuild the same state.
 */

/** Item lifecycle values accepted from the model. */
export const ITEM_STATUSES = ['pending', 'in_progress', 'done', 'rejected', 'blocked'];
/** Tool name whose successful calls form the task state. */
export const TASK_STATE_TOOL = 'task_state';
/** Injected handoff source that seeds a continued conversation's state. */
export const HANDOFF_SOURCE = 'aiapi-handoff';

const LIMITS = { list: 60, text: 1200, items: 3000, evidence: 12, outputs: 300, notes: 40, next: 20 };
const STATUS_LABEL = { pending: '待處理', in_progress: '進行中', done: '已完成', rejected: '已淘汰', blocked: '受阻' };

const clip = (value, max = LIMITS.text) => {
  const text = typeof value === 'string' ? value.trim() : '';
  return text.length > max ? `${text.slice(0, max - 1)}…` : text;
};
const list = (values, max = LIMITS.list) => (Array.isArray(values) ? values : [])
  .map(value => clip(value)).filter(Boolean).slice(0, max);

/** @returns an empty task state. */
export function emptyLedger() {
  return { goal: '', requirements: [], constraints: [], acceptance: [], items: {}, outputs: {}, nextSteps: [], notes: [], updates: 0 };
}

/**
 * Apply one validated `task_state` update without mutating the input.
 * Lists given in full replace the old list; items and outputs merge by id/path.
 * @param state - current task state.
 * @param args - model arguments of one `update` call.
 * @returns the next task state.
 * @throws when the update would exceed the hard item bound.
 */
export function applyLedgerUpdate(state, args) {
  const next = structuredClone(state);
  if (typeof args.goal === 'string') next.goal = clip(args.goal, 2000);
  for (const [key, field] of [['requirements', 'requirements'], ['constraints', 'constraints'], ['acceptance', 'acceptance'], ['next_steps', 'nextSteps']]) {
    if (Array.isArray(args[key])) next[field] = list(args[key], key === 'next_steps' ? LIMITS.next : LIMITS.list);
  }
  for (const id of list(args.remove_items, LIMITS.items)) delete next.items[id];
  for (const raw of Array.isArray(args.items) ? args.items : []) {
    const id = clip(raw?.id, 120);
    if (id === '') continue;
    const previous = next.items[id] ?? { id, title: '', status: 'pending', note: '', evidence: [] };
    const status = ITEM_STATUSES.includes(raw.status) ? raw.status : previous.status;
    next.items[id] = {
      id,
      title: typeof raw.title === 'string' ? clip(raw.title, 300) : previous.title,
      status,
      note: typeof raw.note === 'string' ? clip(raw.note, 600) : previous.note,
      evidence: Array.isArray(raw.evidence) ? list(raw.evidence, LIMITS.evidence) : previous.evidence,
    };
  }
  if (Object.keys(next.items).length > LIMITS.items) throw new Error(`task_state keeps at most ${LIMITS.items} items; record finished items in an output file and remove them`);
  for (const raw of Array.isArray(args.outputs) ? args.outputs : []) {
    const path = clip(raw?.path, 500);
    if (path === '') continue;
    next.outputs[path] = { path, description: clip(raw.description, 300) };
  }
  const outputPaths = Object.keys(next.outputs);
  for (const path of outputPaths.slice(0, Math.max(0, outputPaths.length - LIMITS.outputs))) delete next.outputs[path];
  if (typeof args.note === 'string' && args.note.trim() !== '') next.notes = [...next.notes, clip(args.note, 600)].slice(-LIMITS.notes);
  next.updates = state.updates + 1;
  return next;
}

/**
 * Whether a durable value is a task state written by this module (handoff seeds are wire data).
 * @param value - candidate state.
 * @returns true for a structurally usable state.
 */
export function isLedger(value) {
  return value !== null && typeof value === 'object' && typeof value.goal === 'string'
    && Array.isArray(value.requirements) && value.items !== null && typeof value.items === 'object'
    && value.outputs !== null && typeof value.outputs === 'object' && Array.isArray(value.nextSteps);
}

/**
 * Rebuild the task state from session events: the latest handoff seed, then every successful update after it.
 * @param events - session events in seq order (`tool/call`, `tool/result`, `user/message` are read).
 * @returns `{ state, seq }` where `seq` is the last update's call seq, or -1 without updates.
 */
export function foldLedger(events) {
  let state = emptyLedger();
  let seq = -1;
  const calls = new Map();
  for (const event of events) {
    if (event.type === 'user/message' && event.data?.source?.kind === HANDOFF_SOURCE && isLedger(event.data.source.ledger)) {
      state = { ...emptyLedger(), ...structuredClone(event.data.source.ledger) };
      seq = event.seq;
    } else if (event.type === 'tool/call' && event.data?.name === TASK_STATE_TOOL) {
      calls.set(event.data.callId, event);
    } else if (event.type === 'tool/result' && (!event.surfaceOp || event.surfaceOp === 'append')) {
      const call = calls.get(event.data?.message?.toolCallId);
      if (call === undefined) continue;
      calls.delete(event.data.message.toolCallId);
      if (event.data.message.isError === true) continue;
      let args;
      try { args = JSON.parse(call.data.arguments); } catch { continue; }
      if (args?.action !== 'update') continue;
      try {
        state = applyLedgerUpdate(state, args);
        seq = call.seq;
      } catch {
        // The original call reported this failure to the model; the state stays at its prior value.
      }
    }
  }
  return { state, seq };
}

/**
 * Bounded plain-text rendering for the model and the handoff.
 * Finished and rejected items are summarized by count unless requested.
 * @param state - task state.
 * @param options - `{ status, query, maxItems, finishedChars }`: list matching items in full; without a filter,
 *   active items are listed and finished items fill up to `finishedChars` characters, newest kept.
 * @returns Markdown text.
 */
export function renderLedger(state, options = {}) {
  const items = Object.values(state.items);
  const counts = Object.fromEntries(ITEM_STATUSES.map(status => [status, items.filter(item => item.status === status).length]));
  const lines = [];
  if (state.goal) lines.push(`目標：${state.goal}`);
  const section = (title, values) => { if (values.length > 0) lines.push(`${title}：`, ...values.map(value => `- ${value}`)); };
  section('需求（使用者原意）', state.requirements);
  section('限制', state.constraints);
  section('驗收標準', state.acceptance);
  if (items.length > 0) {
    lines.push(`項目：共 ${items.length}（${ITEM_STATUSES.filter(status => counts[status] > 0).map(status => `${STATUS_LABEL[status]} ${counts[status]}`).join('、')}）`);
    const query = typeof options.query === 'string' ? options.query.trim().toLowerCase() : '';
    const selected = items.filter(item => (options.status ? item.status === options.status
      : ['in_progress', 'pending', 'blocked'].includes(item.status))
      && (query === '' || `${item.id} ${item.title} ${item.note}`.toLowerCase().includes(query)));
    const max = options.maxItems ?? 40;
    const line = item => {
      const evidence = item.evidence.length > 0 ? `；證據：${item.evidence.join('、')}` : '';
      return `- [${STATUS_LABEL[item.status]}] ${item.id}${item.title ? ` ${item.title}` : ''}${item.note ? `：${item.note}` : ''}${evidence}`;
    };
    for (const item of selected.slice(0, max)) lines.push(line(item));
    if (selected.length > max) lines.push(`- …另有 ${selected.length - max} 項，請用 task_state get 加上 status 或 query 查詢。`);
    const finished = options.status || query !== '' ? [] : items.filter(item => item.status === 'done' || item.status === 'rejected');
    // Finished results are listed newest last within a character budget; the rest stay queryable.
    const budget = options.finishedChars ?? 0;
    let used = 0;
    const shown = [];
    for (const item of [...finished].reverse()) {
      const text = line(item);
      if (used + text.length > budget) break;
      used += text.length;
      shown.unshift(text);
    }
    if (shown.length > 0) lines.push('已完成與已淘汰（結果摘要）：', ...shown);
    if (finished.length > shown.length) lines.push(`（另有 ${finished.length - shown.length} 個已完成或已淘汰項目未列出；需要時用 task_state get 指定 status 查詢。）`);
  }
  section('成果檔案', Object.values(state.outputs).map(output => `${output.path}${output.description ? `：${output.description}` : ''}`));
  section('下一步', state.nextSteps);
  section('決策與備註', state.notes.slice(-10));
  return lines.join('\n') || '（尚未建立任務狀態）';
}
