/** Model tools for durable task state and original session-log lookup. */
import { applyLedgerUpdate, foldLedger, ITEM_STATUSES, renderLedger, TASK_STATE_TOOL } from './ledger.mjs';
import { clipTokens, contentText } from './text.mjs';

const RECALL_DEFAULT_CHARS = 12000;
const RECALL_MAX_CHARS = 40000;

/**
 * Read all events of a live session (the log is the only task-state store).
 * @param session - live session.
 * @returns events in seq order.
 */
export function sessionEvents(session) {
  return session.snapshotEvents();
}

/**
 * Original model-relevant text of one logged event, for `context_recall`.
 * @param event - any session event.
 * @returns readable text.
 */
export function recallText(event) {
  switch (event.type) {
    case 'tool/result': {
      const images = event.data.message.content.filter(block => block.type === 'image').map(block => block.attachment?.name ?? '圖片');
      return [`工具結果 r${event.seq}${event.data.message.isError ? '（錯誤）' : ''}`, contentText(event.data.message.content.filter(block => block.type === 'text')),
        ...(images.length > 0 ? [`（此結果含 ${images.length} 張圖片：${images.join('、')}；需要影像時請重新讀取原始圖片檔）`] : [])].join('\n');
    }
    case 'tool/call':
      return `工具呼叫 r${event.seq}：${event.data.name}\n${event.data.arguments}`;
    case 'assistant/message':
      return [`助理訊息 r${event.seq}`, ...event.data.message.content.map(block => (block.type === 'text' ? block.text
        : block.type === 'tool-call' ? `[呼叫 ${block.name}] ${block.arguments}` : '')).filter(Boolean)].join('\n');
    case 'user/message':
      return `${event.data.source?.kind === 'user' ? '使用者訊息' : `注入內容（${event.data.source?.kind ?? '未知'}）`} r${event.seq}\n${contentText(event.data.content)}`;
    default:
      return `${event.type} r${event.seq}\n${JSON.stringify(event.data, null, 1)}`;
  }
}

/**
 * Build the two tool definitions.
 * @param defineTool - the official `defineTool` from `@deepseek-ai/dsh-tools` (injected for testability).
 * @returns `[taskState, contextRecall]` registry-ready definitions.
 */
export function createContextTools(defineTool) {
  const taskState = defineTool({
    name: TASK_STATE_TOOL,
    description: 'Keep the durable state of a long or multi-step task for conversation handoff and progress lookup. '
      + 'Use action "update" early to record the goal, the user\'s requirements (faithful to their wording), constraints and acceptance criteria, '
      + 'then after each milestone record items (products, files, subtasks) with status pending|in_progress|done|rejected|blocked, a short note and evidence paths, '
      + 'output files, and the next steps. Lists you send replace the stored list; items and outputs merge by id/path. '
      + 'Use action "get" with status or query to look up items. Done and rejected items must not be redone unless the user asks.',
    parameters: {
      action: { type: 'string', required: true, enum: ['update', 'get'], description: 'update writes the given fields; get reads the state.' },
      goal: { type: 'string', description: 'One-sentence task goal.' },
      requirements: { type: 'array', items: { type: 'string' }, description: 'Complete list of user requirements; replaces the stored list.' },
      constraints: { type: 'array', items: { type: 'string' }, description: 'Complete list of constraints and preferences.' },
      acceptance: { type: 'array', items: { type: 'string' }, description: 'Complete list of acceptance criteria.' },
      items: {
        type: 'array',
        description: 'Items to add or update, merged by id.',
        items: {
          type: 'object',
          additionalProperties: false,
          properties: {
            id: { type: 'string', required: true, description: 'Stable short id, for example a product number.' },
            title: { type: 'string', description: 'Short human label.' },
            status: { type: 'string', enum: [...ITEM_STATUSES], description: 'pending | in_progress | done | rejected | blocked' },
            note: { type: 'string', description: 'Result, reason for rejection, or blocker, in one or two sentences.' },
            evidence: { type: 'array', items: { type: 'string' }, description: 'File paths or URLs proving the result.' },
          },
        },
      },
      remove_items: { type: 'array', items: { type: 'string' }, description: 'Item ids to delete from the state.' },
      outputs: {
        type: 'array',
        description: 'Output files to add or update, merged by path.',
        items: { type: 'object', additionalProperties: false, properties: { path: { type: 'string', required: true }, description: { type: 'string' } } },
      },
      next_steps: { type: 'array', items: { type: 'string' }, description: 'Complete ordered list of next steps.' },
      note: { type: 'string', description: 'Decision or important fact to append.' },
      status: { type: 'string', enum: [...ITEM_STATUSES], description: 'For get: list items with this status.' },
      query: { type: 'string', description: 'For get: match item id, title or note.' },
    },
    output: {
      schema: { type: 'object', additionalProperties: false, properties: { summary: { type: 'string', required: true } } },
      render: (_args, value) => [{ type: 'text', text: value.summary }],
    },
    isConcurrencySafe: args => args.action === 'get',
    async execute(args, exec) {
      if (!exec.agent) throw new Error('task_state requires an owning agent session');
      const { state } = foldLedger(sessionEvents(exec.agent.session));
      if (args.action === 'get') {
        return { summary: clipTokens(renderLedger(state, { status: args.status, query: args.query, maxItems: 200 }), 6000, '\n…（結果過長，請縮小 status 或 query）') };
      }
      const next = applyLedgerUpdate(state, args);
      return { summary: `已更新任務狀態。\n${clipTokens(renderLedger(next), 3000, '\n…')}` };
    },
    presentCall: args => ({ card: 'generic', title: args.action === 'get' ? '查看任務狀態' : '更新任務狀態', kind: 'other' }),
  });
  const contextRecall = defineTool({
    name: 'context_recall',
    description: 'Read the original logged content of an earlier message, tool call, or tool result. '
      + 'Pass an r-reference from this conversation (for example "r1234"), including references left by older builds. Long content is paged with offset.',
    parameters: {
      ref: { type: 'string', required: true, description: 'Reference such as r1234.' },
      offset: { type: 'integer', description: 'Character offset for paging; default 0.' },
      limit: { type: 'integer', description: `Characters to return; default ${RECALL_DEFAULT_CHARS}, at most ${RECALL_MAX_CHARS}.` },
    },
    output: {
      schema: { type: 'object', additionalProperties: false, properties: { text: { type: 'string', required: true } } },
      render: (_args, value) => [{ type: 'text', text: value.text }],
    },
    isConcurrencySafe: () => true,
    async execute(args, exec) {
      if (!exec.agent) throw new Error('context_recall requires an owning agent session');
      const seq = Number(String(args.ref).trim().replace(/^r/i, ''));
      const session = exec.agent.session;
      if (!Number.isSafeInteger(seq) || seq < 0 || seq >= session.seq) throw new Error(`unknown reference ${args.ref}; use an r-number from this conversation`);
      const text = recallText(session.eventAt(seq));
      const offset = Math.max(0, Math.trunc(args.offset ?? 0));
      const limit = Math.min(RECALL_MAX_CHARS, Math.max(500, Math.trunc(args.limit ?? RECALL_DEFAULT_CHARS)));
      const page = text.slice(offset, offset + limit);
      const rest = text.length - offset - page.length;
      return { text: rest > 0 ? `${page}\n…（還有 ${rest} 字元，請以 offset=${offset + page.length} 繼續讀取）` : page };
    },
    presentCall: args => ({ card: 'generic', title: `取回原始內容 ${args.ref}`, kind: 'read' }),
  });
  return [taskState, contextRecall];
}
