/** "Continue in a new conversation": a bounded handoff injected into a new session of the same workspace. */
import { randomUUID } from 'node:crypto';
import { mkdir, readFile, writeFile } from 'node:fs/promises';
import { isAbsolute, join, resolve } from 'node:path';
import { foldLedger, HANDOFF_SOURCE } from './ledger.mjs';
import { buildHandoff, conclusionLines } from './digest.mjs';
import { contentText } from './text.mjs';

const WRITE_TOOLS = new Set(['write', 'edit', 'str_replace_editor', 'apply_patch']);
const isAppend = event => event.surfaceOp === undefined || event.surfaceOp === 'append';

/**
 * Collect handoff facts from one session log.
 * @param events - complete source session events.
 * @param cwd - source working directory, used to absolutize delivered paths.
 * @returns `{ prompts, ledger, ledgerSeq, deliverables, files, summary, finalReport, title }`.
 */
export function handoffFacts(events, cwd) {
  const { state, seq } = foldLedger(events);
  const absolute = path => (isAbsolute(path) || !cwd ? path : resolve(cwd, path));
  const prompts = [];
  const deliverables = [];
  const files = [];
  let summary = '';
  let finalReport = '';
  let finalSeq = -1;
  let title = '';
  for (const event of events) {
    if (event.type === 'user/message' && isAppend(event) && event.data.source?.kind === 'user') {
      prompts.push({ seq: event.seq, text: contentText(event.data.content) });
    } else if (event.type === 'user/message' && isAppend(event) && event.data.source?.kind === HANDOFF_SOURCE) {
      prompts.push({ seq: event.seq, text: `（上一段對話的交接）\n${contentText(event.data.content)}` });
    } else if (event.type === 'deliverables/presented') {
      for (const file of event.data.files ?? []) if (typeof file.path === 'string') deliverables.push(absolute(file.path));
    } else if (event.type === 'tool/call' && WRITE_TOOLS.has(event.data.name)) {
      try {
        const args = JSON.parse(event.data.arguments);
        const path = args.path ?? args.file_path ?? args.filePath;
        if (typeof path === 'string') files.push(absolute(path));
      } catch {
        // Unparseable arguments simply do not name a file.
      }
    } else if (event.type === 'compaction/summary') {
      summary = contentText(event.data.summary);
    } else if (event.type === 'assistant/message' && isAppend(event)) {
      const text = contentText(event.data.message.content.filter(block => block.type === 'text')).trim();
      if (text !== '') { finalReport = text; finalSeq = event.seq; }
    } else if (event.type === 'session/title' && typeof event.data.title === 'string') {
      title = event.data.title;
    }
  }
  // The last reply is quoted separately as the final report.
  const conclusions = conclusionLines(events, prompts.map(prompt => prompt.seq), replySeq => replySeq !== finalSeq, 1500);
  return { prompts, conclusions, ledger: state, ledgerSeq: seq, deliverables: [...new Set(deliverables)], files: [...new Set(files)], summary, finalReport, title };
}

const HANDOFF_FILE = '續做交接.md';
const HANDOFF_META = 'handoff.json';
const handoffDirectory = (home, sessionId) => join(home, 'aiapi-handoffs', sessionId);
const comparable = text => text.replaceAll('/', '\\').toLowerCase();

/**
 * Messages entering one root step, with the handoff placed before the first human message that
 * cites this conversation's own handoff file, once per conversation. A handoff injected by an
 * earlier build is kept only when the human message of the same step cites its file; otherwise
 * it belongs to a conversation that was never continued and is dropped.
 * @param events - logged session events.
 * @param sessionId - receiving conversation.
 * @param messages - messages entering this step.
 * @param home - DSH home holding the handoff files.
 * @returns the possibly changed message list, and what changed for the log.
 */
export async function handoffMessages(events, sessionId, messages, home) {
  const human = messages.filter(message => message.source?.kind === 'user').map(message => comparable(contentText(message.content)));
  const cites = path => typeof path === 'string' && human.some(text => text.includes(comparable(path)));
  const kept = messages.filter(message => message.source?.kind !== HANDOFF_SOURCE || cites(message.source.path));
  const dropped = messages.length - kept.length;
  const directory = handoffDirectory(home, sessionId);
  const delivered = events.some(event => event.type === 'user/message' && event.data.source?.kind === HANDOFF_SOURCE)
    || kept.some(message => message.source?.kind === HANDOFF_SOURCE);
  if (delivered || !human.some(text => text.includes(comparable(directory)))) return { messages: dropped > 0 ? kept : messages, dropped, added: false };
  const path = join(directory, HANDOFF_FILE);
  const text = await readFile(path, 'utf8');
  const meta = JSON.parse(await readFile(join(directory, HANDOFF_META), 'utf8'));
  const handoff = { content: [{ type: 'text', text }], role: 'user', id: randomUUID(),
    source: { kind: HANDOFF_SOURCE, fromSessionId: meta.fromSessionId, path, ...(meta.ledger ? { ledger: meta.ledger } : {}) } };
  const first = kept.findIndex(message => message.source?.kind === 'user');
  return { messages: [...kept.slice(0, first), handoff, ...kept.slice(first)], dropped, added: true };
}

/**
 * Register `POST /api/aiapi/handoff` on the authenticated local connection.
 * @param scope - context with `connection`, `sessionController`, and `workspaceRegistry`.
 * @param home - DSH home for the readable handoff copy.
 * @returns nothing; the route is an effect of `scope`.
 */
export function registerHandoffRoute(scope, home) {
  scope.effect(() => scope.connection.fetch.register({
    path: '/api/aiapi/handoff', methods: ['POST'], requestBody: 'buffered',
    fetch: async request => {
      try {
        const body = await request.json().catch(() => ({}));
        const sessionId = body?.sessionId;
        if (typeof sessionId !== 'string' || !/^[\w.:-]{1,200}$/.test(sessionId)) return Response.json({ error: '對話識別碼無效' }, { status: 400 });
        const inspection = await scope.sessionController.inspect(sessionId, request.signal);
        const header = inspection.meta;
        if ((header.delegationDepth ?? 0) > 0) return Response.json({ error: '子代理對話不能直接續做，請在主對話使用。' }, { status: 400 });
        const facts = handoffFacts(inspection.events, header.cwd);
        const text = buildHandoff({ ...facts, cwd: header.cwd, fromSessionId: sessionId, fromTitle: facts.title });
        const workspace = scope.workspaceRegistry.list().find(candidate => candidate.sessionIds.includes(sessionId));
        const created = await scope.sessionController.create(workspace ? { workspaceId: workspace.id } : { cwd: header.cwd });
        // Nothing enters the new conversation yet: the handoff joins its first message that cites this
        // file (see handoffMessages), so an unsent conversation reused as a blank one carries no stale context.
        const directory = handoffDirectory(home, created.sessionId);
        const path = join(directory, HANDOFF_FILE);
        await mkdir(directory, { recursive: true });
        await writeFile(path, text, 'utf8');
        await writeFile(join(directory, HANDOFF_META), JSON.stringify({ fromSessionId: sessionId, ...(facts.ledgerSeq >= 0 ? { ledger: facts.ledger } : {}) }), 'utf8');
        const pending = Object.values(facts.ledger.items).filter(item => ['pending', 'in_progress', 'blocked'].includes(item.status)).length;
        return Response.json({
          sessionId: created.sessionId,
          draft: '請依交接內容繼續未完成的工作。',
          path,
          summary: `已建立續做對話：帶入 ${facts.prompts.length} 則要求、${pending} 個未完成項目、${facts.deliverables.length + Object.keys(facts.ledger.outputs).length} 個成果檔記錄。按送出即可開始。`,
        }, { headers: { 'cache-control': 'no-store' } });
      } catch (error) {
        return Response.json({ error: error instanceof Error ? error.message : String(error) }, { status: 500 });
      }
    },
  }), 'aiapi conversation handoff');
}
