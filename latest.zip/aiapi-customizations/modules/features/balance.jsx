/**
 * AIAPI balance, in two places: a card on the plugin/settings row that shows the account state and owns the
 * "keep it on screen" switch, and a slim bar in the sidebar footer that stays visible while you work.
 * The number always comes from the Host (the Smart Key never reaches the page).
 */
import React, { useEffect, useState } from 'react';
import { PLUGIN_VERSION } from '../version.js';

/** Same-origin JSON call to the Host balance route. */
async function readBalance() {
  const response = await fetch(new URL('api/aiapi/balance', document.baseURI), {
    credentials: 'same-origin', cache: 'no-store',
  });
  const body = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(body?.error ?? `回應 ${response.status}`);
  return body;
}

/** Format money the way the platform bills it: two decimals, no currency guessing beyond the payload. */
function money(value, currency) {
  if (typeof value !== 'number' || !Number.isFinite(value)) return '—';
  const symbol = currency === 'CNY' ? '¥' : currency === 'TWD' ? 'NT$' : '$';
  return `${symbol}${value.toFixed(2)}`;
}

/**
 * Colour follows what is left, not a fixed theme: plenty green, getting thin amber, nearly gone red.
 * @param ratio - remaining share between 0 and 1.
 * @returns an `hsl()` colour used by both the bar and its glow.
 */
function toneFor(ratio) {
  const clamped = Math.max(0, Math.min(1, ratio));
  const hue = clamped >= 0.5 ? 145 - (1 - clamped) * 60 : 85 - (0.5 - clamped) * 170;
  return `hsl(${Math.round(hue)} 72% 48%)`;
}

/** Share of the ceiling that is still available; the key's quota wins over a made-up ceiling. */
function remainingRatio(payload) {
  if (payload.quota !== undefined && typeof payload.quota.limit === 'number' && payload.quota.limit > 0) {
    return (payload.quota.remaining ?? 0) / payload.quota.limit;
  }
  const balance = typeof payload.balance === 'number' ? payload.balance : 0;
  return balance / 50;
}

/** The sidebar footer bar: one line, live tone, click to refresh. */
export function BalanceBar() {
  const [payload, setPayload] = useState();
  const [error, setError] = useState('');

  const load = async () => {
    try { setPayload(await readBalance()); setError(''); }
    catch (failure) { setError(failure instanceof Error ? failure.message : '無法取得餘額'); }
  };
  useEffect(() => {
    void load();
    const timer = setInterval(() => { void load(); }, 120000);
    return () => clearInterval(timer);
  }, []);

  if (error !== '') return <div className="aiapi-bal aiapi-bal-off" title={error}>AIAPI 餘額無法讀取</div>;
  if (payload === undefined || payload.status !== 'ok') return <div className="aiapi-bal aiapi-bal-off">AIAPI 讀取中…</div>;

  const ratio = remainingRatio(payload);
  const tone = toneFor(ratio);
  const amount = money(payload.balance, payload.currency);
  return (
    <button type="button" className="aiapi-bal" title={`AIAPI 餘額 ${amount}${payload.group?.name ? `・分組 ${payload.group.name}` : ''}（點擊重新整理）`} onClick={() => { void load(); }}>
      <span className="aiapi-bal-dot" style={{ background: tone, boxShadow: `0 0 8px ${tone}` }} />
      <span className="aiapi-bal-amount">{amount}</span>
      <span className="aiapi-bal-track">
        <span className="aiapi-bal-fill" style={{ width: `${Math.max(4, Math.min(100, ratio * 100))}%`, background: `linear-gradient(90deg, ${tone}, ${tone} 60%, #ffffff55)` }} />
      </span>
    </button>
  );
}

/** The card: account state, balance, and the switch that owns the bar. */
export function BalanceCard({ enabled, onToggle }) {
  const [payload, setPayload] = useState();
  const [error, setError] = useState('');

  const load = async () => {
    try { setPayload(await readBalance()); setError(''); }
    catch (failure) { setError(failure instanceof Error ? failure.message : '無法取得餘額'); }
  };
  useEffect(() => { void load(); }, []);

  const ok = payload?.status === 'ok';
  return (
    <div className="aiapi-balance-card">
      <div className="row">
        <span className="aiapi-account-label">AIAPI 帳號</span>
        <span className={ok ? 'aiapi-account-on' : 'aiapi-account-off'}>{ok ? '已登入' : '未登入或讀取失敗'}</span>
        {ok && payload.group?.name ? <span className="muted">分組 {payload.group.name}</span> : null}
      </div>
      <div className="row" style={{ marginTop: 6 }}>
        <span className="aiapi-balance-figure">{ok ? money(payload.balance, payload.currency) : '—'}</span>
        {ok && payload.quota !== undefined
          ? <span className="muted">定額 {money(payload.quota.remaining, payload.currency)} / {money(payload.quota.limit, payload.currency)}</span>
          : null}
        <button type="button" onClick={() => { void load(); }}>重新整理</button>
      </div>
      <div className="row" style={{ marginTop: 8 }}>
        <label title="在側邊欄左下角常駐顯示一條餘額條">
          <input type="checkbox" checked={enabled} onChange={event => onToggle(event.target.checked)} />
          常駐顯示餘額條
        </label>
      </div>
      {error === '' ? null : <div className="error">{error}</div>}
    </div>
  );
}

/**
 * The settings section page: AIAPI 帳號狀態與平台餘額，就放在 DSH 設定裡「帳號」同一層級，
 * 不必先打開插件頁也知道自己有沒有登入、還剩多少錢。
 * @param props - section props from the settings shell (unused today).
 * @returns the page element.
 */
export function BalancePage({ ctx }) {
  const [payload, setPayload] = useState();
  const [error, setError] = useState('');
  const [enabled, setEnabled] = useState(false);

  useEffect(() => {
    void (async () => {
      try { setEnabled(await readBalanceBar(ctx) === true); }
      catch (failure) { console.warn('[aiapi] 讀取常駐餘額條設定失敗:', failure); }
    })();
  }, []);
  const [busy, setBusy] = useState(false);

  const load = async () => {
    setBusy(true);
    try { setPayload(await readBalance()); setError(''); }
    catch (failure) { setError(failure instanceof Error ? failure.message : '無法取得餘額'); }
    finally { setBusy(false); }
  };
  useEffect(() => { void load(); }, []);

  const ok = payload?.status === 'ok';
  return (
    <div className="aiapi-balance-page">
      <h3 className="aiapi-balance-title">AIAPI 帳號</h3>
      <p className="aiapi-balance-hint">
        {error !== '' ? `讀取失敗：${error}` : ok ? '已連線到 AIAPI 平台' : payload === undefined ? '讀取中…' : '尚未登入 AIAPI'}
      </p>
      <div className="aiapi-balance-figures">
        <div className="aiapi-balance-figure-block">
          <span className="aiapi-balance-figure-label">平台餘額</span>
          <span className="aiapi-balance-figure">{ok ? money(payload.balance, payload.currency) : '—'}</span>
        </div>
        <div className="aiapi-balance-figure-block">
          <span className="aiapi-balance-figure-label">凍結</span>
          <span className="aiapi-balance-figure">{ok ? money(payload.frozen_balance, payload.currency) : '—'}</span>
        </div>
        {ok && payload.quota !== undefined ? (
          <div className="aiapi-balance-figure-block">
            <span className="aiapi-balance-figure-label">這支 Key 定額</span>
            <span className="aiapi-balance-figure">{money(payload.quota.remaining, payload.currency)}<small> / {money(payload.quota.limit, payload.currency)}</small></span>
          </div>
        ) : null}
        <div className="aiapi-balance-figure-block">
          <span className="aiapi-balance-figure-label">分組</span>
          <span className="aiapi-balance-figure">{ok && payload.group?.name ? payload.group.name : '—'}{ok && payload.group?.rate_multiplier !== undefined ? <small> ×{payload.group.rate_multiplier}</small> : null}</span>
        </div>
      </div>
      <p className="aiapi-balance-version">
        插件版本 <code>{PLUGIN_VERSION}</code>
      </p>
      <div className="aiapi-balance-actions">
        <button type="button" onClick={() => { void load(); }} disabled={busy}>{busy ? '讀取中…' : '重新整理'}</button>
        <label className="aiapi-balance-toggle" title="在側邊欄左下角常駐顯示一條餘額條">
          <input type="checkbox" checked={enabled} onChange={event => { void persistBalanceBar(ctx, event.target.checked, setEnabled); }} />
          常駐顯示餘額條
        </label>
      </div>
    </div>
  );
}

/**
 * 讀取並寫回「常駐顯示」開關；寫入失敗就把畫面上的勾選還原，避免顯示與實際不一致。
 * @param next - 使用者要的狀態。
 * @param setEnabled - 該頁面的 setter。
 */
async function readBalanceBar(ctx) {
  const view = await namespaceView(ctx);
  return view?.value?.balanceBar === true;
}

/**
 * 取得本插件的設定命名空間視圖（含 revision）。
 * @param ctx - client plugin context.
 * @returns 命名空間視圖，找不到時為 undefined。
 */
async function namespaceView(ctx) {
  const response = await ctx.remote.settings.describe();
  const value = response?.value ?? response;
  const holders = value?.namespaces ?? [];
  return holders.find(row => row?.ns === 'aiapi-customizations') ?? holders[0];
}

/**
 * 寫回「常駐顯示」開關；失敗就把畫面還原，避免顯示與實際不一致。
 * @param ctx - client plugin context.
 * @param next - 使用者要的狀態。
 * @param setEnabled - 該頁面的 setter。
 */
async function persistBalanceBar(ctx, next, setEnabled) {
  setEnabled(next);
  try {
    const view = await namespaceView(ctx);
    if (view === undefined) throw new Error('找不到設定命名空間');
    const response = await ctx.remote.settings.mutate(view.ns, [{ op: 'set', path: 'balanceBar', value: next }], view.revision);
    if (response?.ok === false) throw new Error(response.error?.message ?? '寫入被拒絕');
  } catch (failure) {
    console.warn('[aiapi] 常駐餘額條設定寫入失敗:', failure);
    setEnabled(!next);
  }
}
