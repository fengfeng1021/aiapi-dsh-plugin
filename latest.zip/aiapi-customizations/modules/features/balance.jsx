/**
 * AIAPI balance, in two places: a card on the plugin/settings row that shows the account state and owns the
 * "keep it on screen" switch, and a slim bar in the sidebar footer that stays visible while you work.
 * The number always comes from the Host (the Smart Key never reaches the page).
 */
import React, { useEffect, useState } from 'react';

/** Same-origin JSON call to the Host balance route. */
async function readBalance() {
  const response = await fetch(new URL('api/aiapi/balance', document.baseURI), {
    credentials: 'same-origin', cache: 'no-store',
  });
  const body = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(body?.error ?? `回應 ${response.status}`);
  return body;
}

/** Format money the way the platform bills it: two decimals, no currency guessing beyond the payload. */
function money(value, currency) {
  if (typeof value !== 'number' || !Number.isFinite(value)) return '—';
  const symbol = currency === 'CNY' ? '¥' : currency === 'TWD' ? 'NT$' : '$';
  return `${symbol}${value.toFixed(2)}`;
}

/**
 * Colour follows what is left, not a fixed theme: plenty green, getting thin amber, nearly gone red.
 * @param ratio - remaining share between 0 and 1.
 * @returns an `hsl()` colour used by both the bar and its glow.
 */
function toneFor(ratio) {
  const clamped = Math.max(0, Math.min(1, ratio));
  const hue = clamped >= 0.5 ? 145 - (1 - clamped) * 60 : 85 - (0.5 - clamped) * 170;
  return `hsl(${Math.round(hue)} 72% 48%)`;
}

/** Share of the ceiling that is still available; the key's quota wins over a made-up ceiling. */
function remainingRatio(payload) {
  if (payload.quota !== undefined && typeof payload.quota.limit === 'number' && payload.quota.limit > 0) {
    return (payload.quota.remaining ?? 0) / payload.quota.limit;
  }
  const balance = typeof payload.balance === 'number' ? payload.balance : 0;
  return balance / 50;
}

/** The sidebar footer bar: one line, live tone, click to refresh. */
export function BalanceBar() {
  const [payload, setPayload] = useState();
  const [error, setError] = useState('');

  const load = async () => {
    try { setPayload(await readBalance()); setError(''); }
    catch (failure) { setError(failure instanceof Error ? failure.message : '無法取得餘額'); }
  };
  useEffect(() => {
    void load();
    const timer = setInterval(() => { void load(); }, 120000);
    return () => clearInterval(timer);
  }, []);

  if (error !== '') return <div className="aiapi-bal aiapi-bal-off" title={error}>AIAPI 餘額無法讀取</div>;
  if (payload === undefined || payload.status !== 'ok') return <div className="aiapi-bal aiapi-bal-off">AIAPI 讀取中…</div>;

  const ratio = remainingRatio(payload);
  const tone = toneFor(ratio);
  const amount = money(payload.balance, payload.currency);
  return (
    <button type="button" className="aiapi-bal" title={`AIAPI 餘額 ${amount}${payload.group?.name ? `・分組 ${payload.group.name}` : ''}（點擊重新整理）`} onClick={() => { void load(); }}>
      <span className="aiapi-bal-dot" style={{ background: tone, boxShadow: `0 0 8px ${tone}` }} />
      <span className="aiapi-bal-amount">{amount}</span>
      <span className="aiapi-bal-track">
        <span className="aiapi-bal-fill" style={{ width: `${Math.max(4, Math.min(100, ratio * 100))}%`, background: `linear-gradient(90deg, ${tone}, ${tone} 60%, #ffffff55)` }} />
      </span>
    </button>
  );
}

/** The card: account state, balance, and the switch that owns the bar. */
export function BalanceCard({ enabled, onToggle }) {
  const [payload, setPayload] = useState();
  const [error, setError] = useState('');

  const load = async () => {
    try { setPayload(await readBalance()); setError(''); }
    catch (failure) { setError(failure instanceof Error ? failure.message : '無法取得餘額'); }
  };
  useEffect(() => { void load(); }, []);

  const ok = payload?.status === 'ok';
  return (
    <div className="aiapi-balance-card">
      <div className="row">
        <span className="aiapi-account-label">AIAPI 帳號</span>
        <span className={ok ? 'aiapi-account-on' : 'aiapi-account-off'}>{ok ? '已登入' : '未登入或讀取失敗'}</span>
        {ok && payload.group?.name ? <span className="muted">分組 {payload.group.name}</span> : null}
      </div>
      <div className="row" style={{ marginTop: 6 }}>
        <span className="aiapi-balance-figure">{ok ? money(payload.balance, payload.currency) : '—'}</span>
        {ok && payload.quota !== undefined
          ? <span className="muted">定額 {money(payload.quota.remaining, payload.currency)} / {money(payload.quota.limit, payload.currency)}</span>
          : null}
        <button type="button" onClick={() => { void load(); }}>重新整理</button>
      </div>
      <div className="row" style={{ marginTop: 8 }}>
        <label title="在側邊欄左下角常駐顯示一條餘額條">
          <input type="checkbox" checked={enabled} onChange={event => onToggle(event.target.checked)} />
          常駐顯示餘額條
        </label>
      </div>
      {error === '' ? null : <div className="error">{error}</div>}
    </div>
  );
}
