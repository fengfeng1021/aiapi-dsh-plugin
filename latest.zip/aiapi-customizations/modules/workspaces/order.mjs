/**
 * Workspace order follows activity: the workspace you just talked in moves to the top.
 *
 * DSH stores the sidebar order as a manual list and only reorders it when the user drags. Two official remotes are
 * enough to do better without touching the stored order by hand:
 *
 * - `session.list()` returns the visible conversations already ordered by activity, so the first row is the one that
 *   just changed.
 * - `workspace.insertBefore({ workspaceId, beforeWorkspaceId })` rewrites the stored order.
 *
 * The conversation row in the sidebar carries `data-row-key="session:<id>"` and sits inside its workspace's
 * `data-row-key="workspace:<id>"` row, which is how a session is mapped back to the workspace that owns it. Nothing
 * is cached locally: every tick reads the row order the sidebar is showing, so a user drag stays authoritative.
 */

/** How often the newest conversation is checked. */
const INTERVAL_MS = 2500;

/**
 * Read the workspace id that owns a rendered row.
 * @param row - an element from the sidebar.
 * @returns the workspace id, or undefined when the row is not inside one.
 */
function workspaceOf(row) {
  const owner = row?.closest?.('[data-row-key^="workspace:"]');
  const key = owner?.getAttribute?.('data-row-key') ?? '';
  return key.startsWith('workspace:') ? key.slice('workspace:'.length) : undefined;
}

/**
 * Keep the most recently active workspace at the top.
 * @param ctx - client plugin context carrying `remote.workspace` and `remote.session`.
 */
export function apply(ctx) {
  const workspace = ctx?.remote?.workspace;
  const session = ctx?.remote?.session;
  if (typeof workspace?.insertBefore !== 'function' || typeof session?.list !== 'function') return;
  if (typeof document === 'undefined') return;
  /** Last conversation acted on, so one change reorders once instead of every tick. */
  let handled = '';
  const tick = async () => {
    const view = await session.list({});
    const newest = Array.isArray(view?.items) ? view.items[0] : undefined;
    const sessionId = newest?.sessionId;
    if (typeof sessionId !== 'string' || sessionId === '' || sessionId === handled) return;
    const rows = [...document.querySelectorAll('[data-row-key^="session:"]')];
    const row = rows.find(element => element.getAttribute('data-row-key') === `session:${sessionId}`);
    if (row === undefined) return; // collapsed workspace: leave the order alone rather than guess
    handled = sessionId;
    const ownId = workspaceOf(row);
    const firstKey = document.querySelector('[data-row-key^="workspace:"]')?.getAttribute('data-row-key') ?? '';
    const firstId = firstKey.startsWith('workspace:') ? firstKey.slice('workspace:'.length) : undefined;
    if (ownId === undefined || firstId === undefined || ownId === firstId) return;
    await workspace.insertBefore({ workspaceId: ownId, beforeWorkspaceId: firstId });
  };
  ctx.effect(() => {
    const timer = setInterval(() => { void tick().catch(() => {}); }, INTERVAL_MS);
    return () => clearInterval(timer);
  }, 'aiapi workspace order');
}
