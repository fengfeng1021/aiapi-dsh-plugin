/**
 * Ruler-style restyle of the official virtualized turn rail, derived from its CSS-module rules.
 * Only stylesheet rules are read; transcript rows and their geometry are never inspected.
 */

const singleClass = selector => (/^\.[\w-]+$/.test(selector ?? '') ? selector : undefined);
const squeeze = value => (value ?? '').replace(/\s+/g, '');
const LOCAL_NAMES = ['mark', 'markActive', 'markPreview', 'markUnloaded', 'preview'];

/**
 * Resolve the hashed class of every restyled local name from the frame's module prefix.
 * Production builds name classes `<hash>_<local>`; any other scheme falls back to property heuristics.
 * @param styled - style rules of the official stylesheet.
 * @param frame - the frame selector, e.g. `.mJ-lBG_frame`.
 * @returns selectors keyed by local name, limited to classes that occur in the stylesheet.
 */
function moduleClasses(styled, frame) {
  if (!frame.endsWith('frame')) return {};
  const prefix = frame.slice(0, -'frame'.length);
  const selectors = new Set(styled.flatMap(rule => rule.selectorText.split(',').map(part => part.trim())));
  const present = name => [...selectors].some(selector => selector === name || selector.startsWith(`${name}:`));
  return Object.fromEntries(LOCAL_NAMES.map(local => [local, `${prefix}${local}`]).filter(([, name]) => present(name)));
}

/**
 * Build the override for the official TurnNavigator stylesheet: a full-height column of thin,
 * evenly spaced ticks at the transcript's left edge, the current turn darker and longer, and the
 * hover preview opening to the right. Doubled class selectors outrank the official single-class
 * rules and its `@container (width <= 900px)` hide rule regardless of stylesheet order.
 * @param rules - CSSStyleRule-like objects: `{ selectorText, style: { getPropertyValue(name) } }`.
 * @returns override CSS, or undefined when the official rules are not recognized.
 */
export function railOverrideCss(rules) {
  const styled = [...rules].filter(rule => rule?.style && typeof rule.selectorText === 'string');
  const frame = singleClass(styled.find(rule => rule.style.getPropertyValue('--turn-rail-band'))?.selectorText);
  const named = frame === undefined ? {} : moduleClasses(styled, frame);
  const preview = named.preview
    ?? singleClass(styled.find(rule => squeeze(rule.style.getPropertyValue('right')) === 'calc(100%+10px)')?.selectorText);
  if (frame === undefined || preview === undefined) return undefined;
  const tick = styled.find(rule => /^\.[\w-]+::before$/.test(rule.selectorText)
    // Minifiers may print `right center` as `100% center`.
    && /^(right|100%)/.test(squeeze(rule.style.getPropertyValue('transform-origin'))))?.selectorText;
  const mark = named.mark ?? tick?.slice(0, -'::before'.length);
  const twice = selector => `${selector}${selector}`;
  const tickAt = (selector, body) => `${twice(selector)}::before{${body}}`;
  return [
    // Top-aligned and as tall as the visible band; overflow keeps scrolling inside the official frame.
    `${twice(frame)}{top:16px;left:6px;right:auto;width:24px;transform:none;display:block;background:none;`
      + 'max-height:max(0px,calc(var(--turn-rail-band) - 32px))}',
    `${twice(preview)}{left:calc(100% + 8px);right:auto;width:min(320px,calc(100cqw - 72px));border-radius:12px;padding:10px 14px}`,
    ...(mark === undefined ? [] : [
      tickAt(mark, 'left:2px;right:auto;width:16px;height:1.5px;border-radius:1px;opacity:.5;'
        + 'background:var(--dsw-alias-label-tertiary,#8f959e);transform:translateY(-50%) scaleX(.62);transform-origin:left center'),
      ...(named.markUnloaded === undefined ? [] : [tickAt(named.markUnloaded, 'opacity:.28;transform:translateY(-50%) scaleX(.5)')]),
      `${twice(mark)}:hover::before${named.markPreview === undefined ? '' : `,${twice(named.markPreview)}::before`}`
        + '{opacity:.95;background:var(--dsw-alias-label-secondary,#646a73);transform:translateY(-50%) scaleX(.85)}',
      ...(named.markActive === undefined ? [] : [
        `${twice(named.markActive)}::before,${twice(named.markActive)}:hover::before`
          + '{opacity:1;height:2px;background:var(--dsw-alias-label-primary,#1f2329);transform:translateY(-50%) scaleX(1)}',
      ]),
      `${twice(mark)}:focus-visible::before{opacity:1;transform:translateY(-50%) scaleX(1);`
        + 'background:var(--dsw-focus-ring-color,var(--dsw-alias-state-business-primary,#3370ff))}',
      `${twice(mark)}:focus-visible::after{inset:0 auto 0 0}`,
    ]),
    // Only a very narrow transcript hides the rail; ordinary window widths keep it visible.
    `@container (width <= 320px){${twice(frame)}{display:none}}`,
  ].join('');
}
