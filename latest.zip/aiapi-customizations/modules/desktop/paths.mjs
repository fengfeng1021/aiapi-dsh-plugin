/** Pure path helpers shared by desktop intake and the file context menu; nothing here touches the filesystem. */

/**
 * Whether a path is absolute on Windows (drive or UNC) or POSIX.
 * @param path - candidate path text.
 * @returns true for `C:\x`, `C:/x`, `\\server\share`, or `/x`.
 */
export function isAbsolutePath(path) {
  return /^[A-Za-z]:[\\/]/.test(path) || /^[\\/]{2}[^\\/]/.test(path) || /^\/(?!\/)/.test(path);
}

/**
 * Whether text names a URL rather than a local path (a drive letter is not a scheme).
 * @param text - link destination or label.
 * @returns true for `https:`, `mailto:`, `file:` and other schemes.
 */
export function isUrl(text) {
  return /^[a-z][a-z\d+.-]*:/i.test(text) && !/^[A-Za-z]:[\\/]/.test(text);
}

/**
 * Resolve a workspace-relative path against the owning session directory.
 * `.` and `..` segments collapse; the separator follows the base directory.
 * @param cwd - absolute session working directory, or undefined when unknown.
 * @param path - absolute or relative path.
 * @returns the absolute path, or undefined when a relative path has no base.
 */
export function resolvePath(cwd, path) {
  const text = path.trim();
  if (text === '') return undefined;
  if (isAbsolutePath(text)) return normalize(text);
  if (!cwd || !isAbsolutePath(cwd)) return undefined;
  const separator = cwd.includes('\\') || /^[A-Za-z]:/.test(cwd) ? '\\' : '/';
  return normalize(`${cwd.replace(/[\\/]+$/, '')}${separator}${text}`, separator);
}

function normalize(path, preferred) {
  const separator = preferred ?? (path.includes('\\') || /^[A-Za-z]:/.test(path) ? '\\' : '/');
  const unc = /^[\\/]{2}[^\\/]/.test(path);
  const drive = /^[A-Za-z]:/.exec(path)?.[0];
  const body = path.slice(unc ? 2 : drive ? 2 : 0);
  const parts = [];
  for (const part of body.split(/[\\/]+/)) {
    if (part === '' || part === '.') continue;
    if (part === '..') { if (parts.length > (unc ? 2 : 0)) parts.pop(); continue; }
    parts.push(part);
  }
  const prefix = unc ? separator + separator : drive ? `${drive}${separator}` : separator;
  return prefix + parts.join(separator);
}

/**
 * Last path segment for short user-facing messages.
 * @param path - absolute or relative path.
 * @returns the file or directory name.
 */
export function baseName(path) {
  return path.split(/[\\/]/).filter(Boolean).pop() ?? path;
}
