/**
 * Native-drop intake that feeds DSH's own attachment pipeline.
 *
 * The Tauri window reports drops as paths; DSH's browser handler expects a
 * DOM drop carrying `File` objects plus `__DSH_HOST_PATHS__.pathFor(file)`.
 * This module bridges the two: it builds those files, publishes the path map
 * for the duration of one synthetic drop, and lets the official `addFiles`
 * decide between reference chips, folder chips, and image uploads.
 */
import { baseName } from './paths.mjs';

/** Image types the official attachment intake accepts as thumbnails. */
export const IMAGE_PATH = /\.(png|jpe?g|webp|gif)$/i;
/** The shell refuses larger single image reads; such images stay original-location references. */
export const MAX_IMAGE_BYTES = 64 * 1024 * 1024;
const IMAGE_TYPES = { png: 'image/png', jpg: 'image/jpeg', jpeg: 'image/jpeg', webp: 'image/webp', gif: 'image/gif' };

/**
 * Classify shell-reported entries without reading any file.
 * Legacy string entries (older carriers) are treated as files of unknown size.
 * @param entries - `{ path, kind: 'file'|'directory'|'missing', size? }` items or plain paths.
 * @returns ordered references `{ path, size?, directory }`, image paths, directories, and missing paths; duplicates are dropped.
 */
export function planIntake(entries) {
  const seen = new Set();
  const plan = { references: [], images: [], directories: [], missing: [] };
  for (const raw of entries) {
    const entry = typeof raw === 'string' ? { path: raw, kind: 'file' } : raw;
    if (!entry || typeof entry.path !== 'string' || entry.path === '' || seen.has(entry.path)) continue;
    seen.add(entry.path);
    if (entry.kind === 'missing') plan.missing.push(entry.path);
    else if (entry.kind === 'directory') {
      plan.directories.push(entry.path);
      plan.references.push({ path: entry.path, directory: true });
    } else if (IMAGE_PATH.test(entry.path) && (entry.size ?? 0) <= MAX_IMAGE_BYTES) plan.images.push(entry.path);
    else plan.references.push({ path: entry.path, ...(typeof entry.size === 'number' ? { size: entry.size } : {}), directory: false });
  }
  return plan;
}

/**
 * Read one image from the shell as raw bytes; carriers before 0.1.25 only offer the base64 command.
 * @param invoke - Tauri command bridge.
 * @param path - absolute image path.
 * @returns a browser File carrying the image bytes.
 */
export async function readImage(invoke, path) {
  const type = IMAGE_TYPES[path.slice(path.lastIndexOf('.') + 1).toLowerCase()];
  try {
    const bytes = await invoke('desktop_read_image', { path, maxBytes: MAX_IMAGE_BYTES });
    return new File([bytes], baseName(path), { type });
  } catch (error) {
    // Only a missing command falls back; a read failure of this file is reported as is.
    if (!String(error?.message ?? error).includes('desktop_read_image')) throw error;
  }
  const payload = await invoke('desktop_read_file_bytes', { path, maxBytes: MAX_IMAGE_BYTES });
  const bytes = Uint8Array.from(atob(payload.base64), character => character.charCodeAt(0));
  return new File([bytes], payload.name || baseName(path), { type: payload.mime });
}

/** One synthetic drop: files, folder membership, and their host paths. */
export function createDrop() {
  return { files: [], directories: new Set(), paths: new Map(), missing: [], fallbacks: [], cancelled: false };
}

/**
 * Turn shell-classified entries into browser files for one official drop.
 * Non-images carry no bytes: the published path map turns them into reference
 * chips, and only images are read (bounded) so the official intake can upload
 * them. An unreadable or oversized image stays a reference instead of vanishing.
 * @param entries - shell-classified drop or clipboard entries.
 * @param hooks - image reader plus the draft's liveness and phase.
 * @returns the drop, with `cancelled` when the composer moved on mid-read.
 */
export async function prepareDrop(entries, { read, isActive, phase }) {
  const plan = planIntake(entries);
  const drop = createDrop();
  drop.missing = plan.missing;
  if (plan.references.length + plan.images.length === 0) return drop;
  if (!isActive() || phase() !== 'plain') return { ...drop, cancelled: true };
  for (const reference of plan.references) {
    const file = new File([], baseName(reference.path) || reference.path, { type: '' });
    if (reference.directory) drop.directories.add(file);
    drop.files.push(file);
    drop.paths.set(file, reference.path);
  }
  for (const path of plan.images) {
    let file;
    try {
      file = await read(path);
    } catch {
      drop.fallbacks.push(path);
      file = new File([], baseName(path) || path, { type: '' });
    }
    if (!isActive() || phase() !== 'plain') return { ...drop, cancelled: true };
    drop.files.push(file);
    drop.paths.set(file, path);
  }
  return drop;
}

/**
 * Synthesize one DOM drop over the official attachment listener.
 * The path bridge exists only for this dispatch: DSH's handler reads
 * `pathFor(file)` synchronously while turning files into reference chips, and
 * images keep their bytes for the upload that follows.
 * @param drop - value from {@link prepareDrop}.
 * @param document - page document owning the official listener.
 * @returns whether the page handled the drop.
 */
export function dispatchDrop(drop, document) {
  if (drop.files.length === 0) return false;
  if (typeof DataTransfer !== 'function' || typeof DragEvent !== 'function') return false;
  const transfer = new DataTransfer();
  for (const file of drop.files) transfer.items.add(file);
  // A synthetic item has no filesystem entry. The official handler reads
  // `isDirectory` to give the folder chip its trailing slash; patch the item
  // prototype for this synchronous dispatch, since each item is a fresh wrapper.
  const prototype = typeof DataTransferItem === 'function' ? DataTransferItem.prototype : undefined;
  const originalEntry = prototype?.webkitGetAsEntry;
  let restoreEntry;
  try {
    if (prototype !== undefined && typeof originalEntry === 'function') {
      prototype.webkitGetAsEntry = function () {
        const file = this.getAsFile();
        return drop.directories.has(file)
          ? { isDirectory: true, isFile: false, name: file.name, fullPath: `/${file.name}` }
          : originalEntry.call(this);
      };
      restoreEntry = () => { prototype.webkitGetAsEntry = originalEntry; };
    }
  } catch {
    restoreEntry = undefined;
  }
  if (restoreEntry === undefined) {
    // Non-extensible prototypes degrade to a file chip; the path still resolves.
    for (const file of drop.directories) {
      const item = transfer.items[drop.files.indexOf(file)];
      try {
        Object.defineProperty(item, 'webkitGetAsEntry', {
          configurable: true,
          value: () => ({ isDirectory: true, isFile: false, name: file.name, fullPath: `/${file.name}` }),
        });
      } catch {
        break;
      }
    }
  }
  const previous = globalThis.__DSH_HOST_PATHS__;
  globalThis.__DSH_HOST_PATHS__ = { pathFor: file => drop.paths.get(file) ?? '' };
  try {
    const event = new DragEvent('drop', { bubbles: true, cancelable: true, dataTransfer: transfer });
    return !document.dispatchEvent(event);
  } finally {
    restoreEntry?.();
    if (previous === undefined) delete globalThis.__DSH_HOST_PATHS__;
    else globalThis.__DSH_HOST_PATHS__ = previous;
  }
}

/**
 * Plain-language outcome for the composer notice, or undefined when nothing needs saying.
 * @param drop - value from {@link prepareDrop}, optionally with `unhandled` from {@link dispatchDrop}.
 * @returns `{ level, text }` for the notice line.
 */
export function dropNotice(drop) {
  if (drop.cancelled) return { level: 'error', text: '對話已切換或正在送出，這次加入的檔案沒有放進輸入框。請再試一次。' };
  if (drop.unhandled) return { level: 'error', text: '輸入框尚未就緒，這次加入的檔案沒有放進去。請回到主對話輸入框再試一次。' };
  const parts = [];
  let level = 'info';
  if (drop.missing.length > 0) {
    level = 'error';
    parts.push(`找不到 ${drop.missing.map(baseName).join('、')}，可能已被移動或刪除。`);
  }
  if (drop.directories.size > 0) {
    parts.push(`資料夾 ${[...drop.directories].map(file => file.name).join('、')} 以原位置引用，不會上傳內容；模型需要時會自行查看其中的檔案。`);
  }
  if (drop.fallbacks.length > 0) {
    parts.push(`${drop.fallbacks.map(baseName).join('、')} 無法作為圖片讀取，已改以原位置檔案加入。`);
  }
  return parts.length > 0 ? { level, text: parts.join(' ') } : undefined;
}
