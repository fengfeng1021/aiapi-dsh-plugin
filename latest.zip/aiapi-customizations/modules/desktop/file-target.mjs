/** Locate the local file a right-clicked control names; web links and plain text are never claimed. */
import { isUrl } from './paths.mjs';

/**
 * Find the file path behind one context-menu target.
 * Sources, in order: Markdown file links and resolved mentions (`data-file-path`),
 * delivered file cards (`data-presented-file` with an absolute-path title),
 * the workspace file tree (`data-files-path`), and the change-review file selector.
 * @param target - event target of a `contextmenu` event.
 * @returns `{ path, element, directory }`, or undefined when the target names no local file.
 */
export function fileTargetFrom(target) {
  const element = target?.nodeType === 1 ? target : target?.parentElement;
  if (!element?.closest) return undefined;
  const found = (path, owner, directory = false) => {
    const text = typeof path === 'string' ? path.trim() : '';
    return text === '' || isUrl(text) ? undefined : { path: text, element: owner, directory };
  };
  const link = element.closest('[data-file-path]');
  if (link) return found(link.getAttribute('data-file-path'), link);
  const card = element.closest('[data-presented-file]');
  if (card) return found(card.querySelector('button[title]')?.getAttribute('title'), card);
  const entry = element.closest('[data-files-path][data-files-entry]');
  if (entry && entry.getAttribute('data-files-entry') !== 'other') {
    return found(entry.getAttribute('data-files-path'), entry, entry.getAttribute('data-files-entry') === 'directory');
  }
  const review = element.closest('[data-review-file]');
  if (review) return found(review.getAttribute('data-review-file'), review);
  return undefined;
}
