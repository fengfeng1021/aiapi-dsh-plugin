import { discover, mergePublicPricingModels, publicModelSourceIds, readJson, parseListing, requestModelIdForPublicModel, enrichModelMetadata, capacityOverrides } from './discovery.mjs';
import { createHash, timingSafeEqual } from 'node:crypto';
import { readFileSync } from 'node:fs';
import { mkdir, writeFile } from 'node:fs/promises';
import { homedir } from 'node:os';
import { gunzipSync } from 'node:zlib';
import { fileURLToPath } from 'node:url';
import { dirname } from 'node:path';
import { join } from 'node:path';
export const name = 'aiapi-models';
export const inject = ['connection', 'settings', 'credentials'];
const AIAPI_MODEL_ENDPOINT = 'https://aiapi.tw/v1';
const AIAPI_PUBLIC_PRICING_ENDPOINT = 'https://aiapi.tw/api/v1/pricing/public';
const AIAPI_DESKTOP_AUTH_ENDPOINT = 'https://aiapi.tw/api/v1/desktop-auth';
const AIAPI_CREDENTIAL_REF = 'AIAPI_API_KEY';
const AIAPI_PENDING_CREDENTIAL_REF = 'AIAPI_DESKTOP_OAUTH_PENDING';
const AIAPI_DEVICE_CREDENTIAL_REF = 'AIAPI_DEVICE_PENDING';
/** This package's own manifest, read once so the version route and update check cannot drift. */
/**
 * The plugin's own package directory. Found by walking up from this module, so the same file works both in
 * the source tree and inside the installed bundle, and the updater can read the version on disk later.
 * @returns the directory that holds this plugin's package.json.
 */
function findPackageRoot() {
  let dir = dirname(fileURLToPath(import.meta.url));
  for (let depth = 0; depth < 6; depth += 1) {
    try {
      const manifest = JSON.parse(readFileSync(join(dir, 'package.json'), 'utf8'));
      if (manifest.name === '@aiapi/dsh-customizations') return dir;
    } catch { /* keep walking up */ }
    dir = dirname(dir);
  }
  throw new Error('找不到外掛自己的 package.json');
}

const PACKAGE_ROOT = findPackageRoot();
const PACKAGE_INFO = JSON.parse(readFileSync(join(PACKAGE_ROOT, 'package.json'), 'utf8'));

/** The version recorded on disk: after an in-app update it is newer than this running module until restart. */
function readOnDiskVersion() {
  try {
    return JSON.parse(readFileSync(join(PACKAGE_ROOT, 'package.json'), 'utf8')).version ?? '';
  } catch {
    return '';
  }
}

/** Last in-app update attempt; polled by the card because the install outlives its own HTTP request. */
const updateState = { phase: 'idle', version: '', error: '', application: '', restartReason: '', method: '', at: 0 };
/** Release index location used whenever the entry config says nothing (a profile patch may replace the whole config). */
const DEFAULT_UPDATE_MANIFEST = 'https://fengfeng1021.github.io/aiapi-dsh-plugin/index.json';
/** Values that switch the update check off on purpose. */
const UPDATE_MANIFEST_OFF = new Set(['off', 'none', 'disabled']);
const SETTINGS_NAMESPACE = 'llm-pi-ai';

/**
 * Install the authenticated model-discovery route without writing settings during boot.
 * @param ctx - the customization plugin context.
 * @param config - deployment-owned capacity overrides, validated before registration.
 */
export function apply(ctx, config = {}) {
  const limits = capacityOverrides(config.modelCapacityOverrides);
  const lifetime = new AbortController();
  const pending = new Set();
  let registry;
  let registryAt = 0;
  ctx.effect(() => ctx.connection.fetch.register({ path: '/api/aiapi/models', methods: ['POST'], requestBody: 'buffered', fetch: request => {
    const task = (async () => {
      try {
        const input = await request.json();
        if (!input || input.provider !== 'aiapi' || typeof input.enrich !== 'boolean') throw new Error('模型查詢參數無效');
        const stored = ctx.settings.describe().find(row => row.ns === SETTINGS_NAMESPACE)?.value?.providers?.aiapi;
        const signal = AbortSignal.any([request.signal, lifetime.signal, AbortSignal.timeout(20000)]);
        const pricing = await readJson(await fetch(AIAPI_PUBLIC_PRICING_ENDPOINT, {
          headers: { accept: 'application/json' }, signal, redirect: 'error', cache: 'no-store',
        }));
        let discovered = [];
        let accountListingAvailable = false;
        let warning;
        try {
          discovered = await discover({ provider: 'aiapi', api: 'openai-completions', baseURL: AIAPI_MODEL_ENDPOINT }, stored, async ref => (await ctx.credentials.resolve(ref))?.value, signal);
          accountListingAvailable = true;
        } catch {
          warning = '目前無法確認此 Smart Key 可用的模型，因此不顯示未驗證的模型。';
        }
        const models = accountListingAvailable ? mergePublicPricingModels(discovered, pricing) : [];
        if (accountListingAvailable && models.length === 0) warning = '此 Smart Key 的模型清單中沒有與公開價格表相符的可用模型。';
        const publicSourceIds = publicModelSourceIds(pricing);
        for (const model of models) {
          if (model.reasoningEfforts !== undefined) model.reasoningSource = 'AIAPI 帳號模型清單';
        }
        if (input.enrich === true && models.length > 0) {
          try {
            if (!registry || Date.now() - registryAt > 3600000) {
              // Public registry receives NO provider key, headers, or model query.
              registry = parseListing(await readJson(await fetch('https://openrouter.ai/api/v1/models', { signal, redirect: 'error' })));
              registryAt = Date.now();
            }
            const exact = new Map(registry.map(model => [model.id, model]));
            for (const model of models) {
              const sourceId = publicSourceIds.get(model.id);
              const match = sourceId ? exact.get(sourceId) : undefined;
              enrichModelMetadata(model, match);
              const publicModelId = sourceId?.slice(sourceId.indexOf('/') + 1);
              const isGatewayAlias = publicModelId !== undefined
                && publicModelId !== model.id
                && requestModelIdForPublicModel(publicModelId) === model.id;
              if (match && (isGatewayAlias || !model.name || model.name === model.id)) {
                model.name = match.name === match.id ? model.id : match.name;
              }
              if (model.reasoningEfforts === undefined && match?.reasoningEfforts !== undefined) {
                model.reasoningEfforts = match.reasoningEfforts;
                model.reasoningSource = `OpenRouter 公開目錄：${sourceId}`;
              }
            }
          } catch { warning = '公開目錄暫時無法讀取，已保留供應商直接回傳的資料。'; }
        }
        for (const model of models) Object.assign(model, limits.get(model.id));
        const knownEffortCount = models.filter(model => model.reasoningEfforts !== undefined).length;
        if (knownEffortCount < models.length) {
          const effortWarning = `已確認 ${knownEffortCount}/${models.length} 個模型的思考強度；其餘模型沒有明確等級資料，未猜測。`;
          warning = warning ? `${warning} ${effortWarning}` : effortWarning;
        }
        return Response.json({ models, warning }, { headers: { 'cache-control': 'no-store' } });
      } catch (error) {
        // Fetch errors may include remote details; keys and raw reply bodies are never echoed.
        const failure = error instanceof Error ? error : new Error('Unknown discovery failure');
        const message = failure instanceof SyntaxError ? '供應商回應不是有效 JSON' : failure.name === 'AbortError' || failure.name === 'TimeoutError' ? '查詢已取消或逾時' : /^模型|^供應商|^請填寫/.test(failure.message) ? failure.message : '模型查詢失敗，請檢查位址、金鑰及網路。';
        return Response.json({ error: message }, { status: 400, headers: { 'cache-control': 'no-store' } });
      }
    })();
    pending.add(task);
    void task.finally(() => pending.delete(task));
    return task;
  }}), 'aiapi authenticated discovery');
  ctx.effect(() => ctx.connection.fetch.register({ path: '/api/aiapi/desktop-auth/oauth/start', methods: ['POST'], requestBody: 'buffered', fetch: request => track(pending, startDesktopOAuth(ctx, request, lifetime.signal)) }), 'aiapi desktop authorization start');
  ctx.effect(() => ctx.connection.fetch.register({ path: '/api/aiapi/desktop-auth/oauth/callback', methods: ['POST'], requestBody: 'buffered', fetch: request => track(pending, completeDesktopOAuth(ctx, request, lifetime.signal)) }), 'aiapi desktop authorization callback');
  ctx.effect(() => ctx.connection.fetch.register({ path: '/api/aiapi/desktop-auth/oauth/resume', methods: ['POST'], requestBody: 'buffered', fetch: request => track(pending, resumeDesktopOAuth(ctx, request)) }), 'aiapi desktop authorization resume');
  ctx.effect(() => ctx.connection.fetch.register({ path: '/api/aiapi/device-auth/start', methods: ['POST'], requestBody: 'buffered', fetch: request => track(pending, startDeviceAuth(ctx, request, lifetime.signal)) }), 'aiapi device authorization start');
  ctx.effect(() => ctx.connection.fetch.register({ path: '/api/aiapi/device-auth/poll', methods: ['POST'], requestBody: 'buffered', fetch: request => track(pending, pollDeviceAuth(ctx, request, lifetime.signal)) }), 'aiapi device authorization poll');
  ctx.effect(() => ctx.connection.fetch.register({ path: '/api/aiapi/update', methods: ['GET'], requestBody: 'buffered', fetch: () => Response.json({ name: PACKAGE_INFO.name, version: PACKAGE_INFO.version, onDisk: readOnDiskVersion() }, { headers: { 'cache-control': 'no-store' } }) }), 'aiapi version');
  ctx.effect(() => ctx.connection.fetch.register({ path: '/api/aiapi/update/check', methods: ['POST'], requestBody: 'buffered', fetch: request => track(pending, checkForUpdate(ctx, config, request, lifetime.signal)) }), 'aiapi update check');
  ctx.effect(() => ctx.connection.fetch.register({ path: '/api/aiapi/update/status', methods: ['GET'], requestBody: 'buffered', fetch: () => Response.json({ ...updateState, running: PACKAGE_INFO.version, onDisk: readOnDiskVersion() }, { headers: { 'cache-control': 'no-store' } }) }), 'aiapi update status');
  ctx.effect(() => ctx.connection.fetch.register({ path: '/api/aiapi/update/apply', methods: ['POST'], requestBody: 'buffered', fetch: request => track(pending, applyUpdate(ctx, config, request, lifetime.signal)) }), 'aiapi update apply');
  ctx.effect(() => ctx.connection.fetch.register({ path: '/api/aiapi/disconnect', methods: ['POST'], requestBody: 'buffered', fetch: request => track(pending, disconnectAccount(ctx, request)) }), 'aiapi disconnect');
  ctx.effect(() => async () => { lifetime.abort(); await Promise.allSettled(pending); }, 'aiapi discovery cleanup');
}

function track(pending, task) {
  pending.add(task);
  void task.finally(() => pending.delete(task));
  return task;
}

async function startDesktopOAuth(ctx, request, lifetimeSignal) {
  try {
    const signal = AbortSignal.any([request.signal, lifetimeSignal, AbortSignal.timeout(15000)]);
    const input = await request.json();
    if (!input || typeof input.code_verifier !== 'string' || input.code_verifier.length < 43 || input.code_verifier.length > 128 || typeof input.code_challenge !== 'string' || typeof input.state !== 'string' || typeof input.redirect_uri !== 'string') throw new Error('桌面登入資料無效');
    const derived = createHash('sha256').update(input.code_verifier).digest('base64url');
    if (derived !== input.code_challenge || !validRedirectURI(input.redirect_uri)) throw new Error('桌面登入資料無效');
    const grant = await postDesktopAuth('/oauth/request', {
      code_challenge: input.code_challenge,
      state: input.state,
      redirect_uri: input.redirect_uri,
    }, signal);
    if (typeof grant.request_id !== 'string' || grant.request_id.length !== 43 || !Number.isSafeInteger(grant.expires_in)) throw new Error('授權服務回應格式無效');
    await ctx.credentials.set(AIAPI_PENDING_CREDENTIAL_REF, JSON.stringify({
      code_verifier: input.code_verifier,
      state: input.state,
      redirect_uri: input.redirect_uri,
      request_id: grant.request_id,
      expires_at: Date.now() + grant.expires_in * 1000,
    }));
    return Response.json({ authorization_url: `https://aiapi.tw/desktop/authorize?request_id=${encodeURIComponent(grant.request_id)}` }, { headers: { 'cache-control': 'no-store' } });
  } catch (error) {
    return desktopAuthFailure(error);
  }
}

async function completeDesktopOAuth(ctx, request, lifetimeSignal) {
  try {
    const input = await request.json();
    if (!input || typeof input.callback !== 'string' || input.callback.length > 512) throw new Error('桌面授權回呼無效');
    const grant = await ctx.credentials.resolve(AIAPI_PENDING_CREDENTIAL_REF);
    if (!grant?.value) throw new Error('找不到待完成的登入要求，請重新登入。');
    let transaction;
    try { transaction = JSON.parse(grant.value); } catch { throw new Error('桌面登入狀態已損毀，請重新登入。'); }
    if (typeof transaction.state !== 'string' || typeof transaction.code_verifier !== 'string' || typeof transaction.redirect_uri !== 'string' || !Number.isSafeInteger(transaction.expires_at) || transaction.expires_at <= Date.now()) {
      await ctx.credentials.unset(AIAPI_PENDING_CREDENTIAL_REF);
      throw new Error('桌面登入要求已過期，請重新登入。');
    }
    const callback = new URL(input.callback);
    if (`${callback.protocol}//${callback.host}${callback.pathname}` !== transaction.redirect_uri || callback.hash || callback.username || callback.password) throw new Error('桌面授權回呼不符合本機登入要求');
    const states = callback.searchParams.getAll('state');
    const codes = callback.searchParams.getAll('code');
    const errors = callback.searchParams.getAll('error');
    if ([...callback.searchParams.keys()].some(key => !['state', 'code', 'error'].includes(key))) throw new Error('桌面授權回呼無效，請重新登入。');
    const expectedState = Buffer.from(transaction.state);
    const actualState = Buffer.from(states[0] ?? '');
    if (states.length !== 1 || actualState.length !== expectedState.length || !timingSafeEqual(actualState, expectedState)) throw new Error('桌面授權狀態不符，請重新登入。');
    if (transaction.callback && transaction.callback !== input.callback) throw new Error('桌面授權回呼與待完成的登入不符。');
    if (!transaction.callback) {
      transaction.callback = input.callback;
      await ctx.credentials.set(AIAPI_PENDING_CREDENTIAL_REF, JSON.stringify(transaction));
    }
    if (codes.length === 0 && errors.length === 1 && errors[0] === 'access_denied') {
      await ctx.credentials.unset(AIAPI_PENDING_CREDENTIAL_REF);
      return Response.json({ status: 'access_denied' }, { headers: { 'cache-control': 'no-store' } });
    }
    if (codes.length !== 1 || errors.length !== 0 || !/^[A-Za-z0-9_-]{43}$/.test(codes[0])) throw new Error('桌面授權回呼無效，請重新登入。');
    const signal = AbortSignal.any([request.signal, lifetimeSignal, AbortSignal.timeout(15000)]);
    const result = await postDesktopAuth('/oauth/exchange', {
      code: codes[0],
      code_verifier: transaction.code_verifier,
      redirect_uri: transaction.redirect_uri,
    }, signal);
    if (result.status !== 'granted') {
      if (result.status === 'expired' || result.status === 'access_denied') await ctx.credentials.unset(AIAPI_PENDING_CREDENTIAL_REF);
      return Response.json({ status: result.status }, { headers: { 'cache-control': 'no-store' } });
    }
    if (typeof result.api_key !== 'string' || result.api_key.length < 16 || result.api_key.length > 256) throw new Error('授權服務未回傳有效的 Smart Key');
    await ctx.credentials.set(AIAPI_CREDENTIAL_REF, result.api_key);
    try { await postDesktopAuth('/oauth/ack', { code: codes[0] }, signal); } catch { /* The short-lived grant expires automatically. */ }
    await ctx.credentials.unset(AIAPI_PENDING_CREDENTIAL_REF);
    return Response.json({ status: 'complete' }, { headers: { 'cache-control': 'no-store' } });
  } catch (error) {
    return desktopAuthFailure(error);
  }
}

async function resumeDesktopOAuth(ctx, request) {
  try {
    if (request.signal.aborted) throw new Error('桌面登入要求已取消。');
    const grant = await ctx.credentials.resolve(AIAPI_PENDING_CREDENTIAL_REF);
    if (!grant?.value) return Response.json({ status: 'none' }, { headers: { 'cache-control': 'no-store' } });
    let transaction;
    try { transaction = JSON.parse(grant.value); } catch { await ctx.credentials.unset(AIAPI_PENDING_CREDENTIAL_REF); return Response.json({ status: 'expired' }, { headers: { 'cache-control': 'no-store' } }); }
    if (!Number.isSafeInteger(transaction.expires_at) || transaction.expires_at <= Date.now()) {
      await ctx.credentials.unset(AIAPI_PENDING_CREDENTIAL_REF);
      return Response.json({ status: 'expired' }, { headers: { 'cache-control': 'no-store' } });
    }
    if (typeof transaction.callback === 'string') return Response.json({ status: 'resume', callback: transaction.callback }, { headers: { 'cache-control': 'no-store' } });
    return Response.json({ status: 'pending' }, { headers: { 'cache-control': 'no-store' } });
  } catch (error) {
    return desktopAuthFailure(error);
  }
}


/**
 * Start a device authorization for a browser-only DSH: the account sign-in happens on aiapi.tw, and the
 * Smart Key returns through the Host's poll route instead of a desktop URL scheme callback.
 * @param ctx - unified plugin context, for the pending grant in the credential store.
 * @param request - the page's POST, whose body is unused.
 * @param lifetimeSignal - aborts the attempt when the plugin unloads.
 * @returns the user code and verification page the browser shows, never the device code.
 */
async function startDeviceAuth(ctx, request, lifetimeSignal) {
  try {
    const signal = AbortSignal.any([request.signal, lifetimeSignal, AbortSignal.timeout(15000)]);
    const grant = await postDesktopAuth('/device-code', {}, signal);
    if (typeof grant.device_code !== 'string' || grant.device_code.length < 16 || typeof grant.user_code !== 'string' || !/^[A-Za-z0-9-]{4,32}$/.test(grant.user_code) || typeof grant.verification_uri !== 'string' || !Number.isSafeInteger(grant.expires_in) || grant.expires_in <= 0) throw new Error('授權服務回應格式無效');
    const verification = new URL(grant.verification_uri);
    if (verification.origin !== 'https://aiapi.tw') throw new Error('AIAPI 授權網址無效');
    await ctx.credentials.set(AIAPI_DEVICE_CREDENTIAL_REF, JSON.stringify({
      device_code: grant.device_code,
      expires_at: Date.now() + grant.expires_in * 1000,
    }));
    return Response.json({
      user_code: grant.user_code,
      verification_uri: verification.href,
      expires_in: grant.expires_in,
      interval: Number.isSafeInteger(grant.interval) && grant.interval > 0 ? grant.interval : 5,
    }, { headers: { 'cache-control': 'no-store' } });
  } catch (error) {
    return desktopAuthFailure(error);
  }
}

/**
 * One poll of a pending device grant. A granted key lands in the same credential the desktop flow uses,
 * so the provider card and the model route read it unchanged.
 * @param ctx - unified plugin context.
 * @param request - the page's POST, whose body is unused.
 * @param lifetimeSignal - aborts the exchange when the plugin unloads.
 * @returns the grant status, and `complete` once the key is stored.
 */
async function pollDeviceAuth(ctx, request, lifetimeSignal) {
  try {
    const stored = await ctx.credentials.resolve(AIAPI_DEVICE_CREDENTIAL_REF);
    if (!stored?.value) return Response.json({ status: 'none' }, { headers: { 'cache-control': 'no-store' } });
    let state;
    try { state = JSON.parse(stored.value); } catch {
      await ctx.credentials.unset(AIAPI_DEVICE_CREDENTIAL_REF);
      return Response.json({ status: 'expired' }, { headers: { 'cache-control': 'no-store' } });
    }
    if (typeof state.device_code !== 'string' || !Number.isSafeInteger(state.expires_at) || state.expires_at <= Date.now()) {
      await ctx.credentials.unset(AIAPI_DEVICE_CREDENTIAL_REF);
      return Response.json({ status: 'expired' }, { headers: { 'cache-control': 'no-store' } });
    }
    const signal = AbortSignal.any([request.signal, lifetimeSignal, AbortSignal.timeout(15000)]);
    const result = await postDesktopAuth('/token', { device_code: state.device_code }, signal);
    if (result.status === 'authorization_pending') return Response.json({ status: 'authorization_pending' }, { headers: { 'cache-control': 'no-store' } });
    if (result.status !== 'granted') {
      await ctx.credentials.unset(AIAPI_DEVICE_CREDENTIAL_REF);
      return Response.json({ status: result.status === 'access_denied' ? 'access_denied' : 'expired' }, { headers: { 'cache-control': 'no-store' } });
    }
    if (typeof result.api_key !== 'string' || result.api_key.length < 16 || result.api_key.length > 256) throw new Error('授權服務未回傳有效的 Smart Key');
    await ctx.credentials.set(AIAPI_CREDENTIAL_REF, result.api_key);
    try { await postDesktopAuth('/token/ack', { device_code: state.device_code }, signal); } catch { /* The short-lived grant expires automatically. */ }
    await ctx.credentials.unset(AIAPI_DEVICE_CREDENTIAL_REF);
    return Response.json({ status: 'complete' }, { headers: { 'cache-control': 'no-store' } });
  } catch (error) {
    return desktopAuthFailure(error);
  }
}


/**
 * Compare this package's version with the published release index. The manifest is fetched by the Host,
 * not the page, so it works without CORS on the release host and never exposes the page to that origin.
 * @param ctx - unified plugin context, for the abort signal owner.
 * @param config - deployment config; `updateManifestUrl` may point at another index.
 * @param request - the page's POST, whose body is unused.
 * @param lifetimeSignal - aborts the lookup when the plugin unloads.
 * @returns the current version, the latest published one, and the install spec for it.
 */
/**
 * Where this deployment reads its release index. A profile patch replaces an entry's whole config, so an
 * override that only carries `features` must not silently disable updates: the default lives in code and
 * an explicit `off` (or `none` / `disabled`) is the only way to switch the check off.
 * @param config - the plugin config, possibly overridden by the profile patch.
 * @returns the manifest URL, or an empty string when the check was switched off on purpose.
 */
export function resolveUpdateManifest(config) {
  const raw = typeof config?.updateManifestUrl === 'string' ? config.updateManifestUrl.trim() : '';
  if (raw === '') return DEFAULT_UPDATE_MANIFEST;
  return UPDATE_MANIFEST_OFF.has(raw.toLowerCase()) ? '' : raw;
}

async function checkForUpdate(ctx, config, request, lifetimeSignal) {
  const manifestUrl = resolveUpdateManifest(config);
  if (manifestUrl === '') {
    return Response.json({ current: PACKAGE_INFO.version, latest: null, newer: false, unconfigured: true }, { headers: { 'cache-control': 'no-store' } });
  }
  try {
    const signal = AbortSignal.any([request.signal, lifetimeSignal, AbortSignal.timeout(10000)]);
    const response = await fetch(manifestUrl, { headers: { accept: 'application/json', 'cache-control': 'no-store' }, cache: 'no-store', redirect: 'follow', signal });
    if (!response.ok) throw new Error(`更新來源回應 ${response.status}`);
    const text = await response.text();
    let manifest;
    try { manifest = JSON.parse(text); } catch { throw new Error('更新來源不是 JSON：這個網址可能還沒放 index.json'); }
    const latest = manifest?.latest;
    if (latest === undefined || typeof latest.version !== 'string') throw new Error('更新來源格式無效');
    return Response.json({
      current: PACKAGE_INFO.version,
      latest: {
        version: latest.version,
        spec: typeof latest.spec === 'string' ? latest.spec : undefined,
        tarball: typeof latest.tarball === 'string' ? new URL(latest.tarball, manifestUrl).href : undefined,
        sha256: typeof latest.sha256 === 'string' ? latest.sha256 : undefined,
        notes: typeof latest.notes === 'string' ? latest.notes : undefined,
        publishedAt: typeof latest.publishedAt === 'string' ? latest.publishedAt : undefined,
      },
      newer: latest.version !== PACKAGE_INFO.version,
      manifest: manifestUrl,
    }, { headers: { 'cache-control': 'no-store' } });
  } catch (error) {
    return Response.json({
      current: PACKAGE_INFO.version,
      latest: null,
      newer: false,
      manifest: manifestUrl,
      error: error instanceof Error ? error.message : '無法檢查更新',
    }, { headers: { 'cache-control': 'no-store' } });
  }
}


/**
 * One-click update: fetch the published release, verify its checksum, then hand the local file to DSH's
 * own plugin manager. Installation is the manager's operation, and installing another version is a
 * removal plus an installation, so this plugin is stopped while it updates — the page must be reloaded
 * afterwards. Nothing is written into node_modules by this plugin itself.
 * @param ctx - unified plugin context, which also exposes the profile's plugin manager.
 * @param config - deployment config; `updateManifestUrl` may point at another index.
 * @param request - the page's POST, whose body is unused.
 * @param lifetimeSignal - aborts the download when the plugin unloads.
 * @returns `updating` once the manager accepted the file, or a refusal the page can show.
 */
/**
 * Read a .tgz without adding a dependency to a plugin that ships offline.
 * @param buffer - gzip-compressed tarball, as served by the release host.
 * @returns regular files keyed by path, with the tarball's leading `package/` removed.
 */
export function readTarball(buffer) {
  const tar = gunzipSync(buffer);
  const cstr = (block, start, length) => block.subarray(start, start + length).toString('utf8').replace(/\0[\s\S]*$/, '').trim();
  const files = new Map();
  let offset = 0;
  while (offset + 512 <= tar.length) {
    const header = tar.subarray(offset, offset + 512);
    if (header.every(byte => byte === 0)) break;
    let name = cstr(header, 0, 100);
    if (header.subarray(257, 262).toString('utf8') === 'ustar') {
      const prefix = cstr(header, 345, 155);
      if (prefix !== '') name = `${prefix}/${name}`;
    }
    const size = Number.parseInt(cstr(header, 124, 12) || '0', 8);
    const kind = header[156] === 0 ? 48 : header[156];
    const dataStart = offset + 512;
    offset = dataStart + Math.ceil(size / 512) * 512;
    if (kind !== 48) continue;                                  // only regular files carry content
    const path = name.replace(/^package\//, '');
    // Never write outside the package, and never touch installed dependencies.
    if (path === '' || path.startsWith('/') || path.split('/').includes('..') || path.startsWith('node_modules/')) continue;
    files.set(path, tar.subarray(dataStart, dataStart + size));
  }
  return files;
}

/**
 * Write a release's files over the installed package. Used when the plugin manager cannot swap a `link:`
 * install for a tarball (pnpm leaves a dangling link), and as the verification fallback otherwise.
 * @param files - the extracted tarball contents.
 * @returns how many files were written.
 */
export async function replaceInstalled(files) {
  let written = 0;
  for (const [relative, bytes] of files) {
    const target = join(PACKAGE_ROOT, relative);
    await mkdir(dirname(target), { recursive: true });
    await writeFile(target, bytes);
    written += 1;
  }
  return written;
}

async function applyUpdate(ctx, config, request, lifetimeSignal) {
  if (resolveUpdateManifest(config) === '') {
    return Response.json({ status: 'unconfigured', error: '尚未設定更新來源（updateManifestUrl）。' }, { status: 409, headers: { 'cache-control': 'no-store' } });
  }
  const manager = ctx.get?.('pluginManager');
  if (manager === undefined || typeof manager.installBundle !== 'function') {
    return Response.json({ status: 'unsupported', error: '這個 DSH 沒有提供外掛管理服務，請手動貼安裝字串。' }, { status: 501, headers: { 'cache-control': 'no-store' } });
  }
  try {
    const manifestUrl = typeof config?.updateManifestUrl === 'string' && config.updateManifestUrl.trim() !== ''
      ? config.updateManifestUrl.trim()
      : DEFAULT_UPDATE_MANIFEST;
    const signal = AbortSignal.any([request.signal, lifetimeSignal, AbortSignal.timeout(60000)]);
    const manifestResponse = await fetch(manifestUrl, { headers: { accept: 'application/json', 'cache-control': 'no-store' }, cache: 'no-store', redirect: 'follow', signal });
    if (!manifestResponse.ok) throw new Error(`更新來源回應 ${manifestResponse.status}`);
    const manifest = await manifestResponse.json();
    const latest = manifest?.latest;
    if (latest === undefined || typeof latest.version !== 'string') throw new Error('更新來源格式無效');
    if (latest.version === PACKAGE_INFO.version) return Response.json({ status: 'current', version: latest.version }, { headers: { 'cache-control': 'no-store' } });
    const tarball = new URL(typeof latest.tarball === 'string' ? latest.tarball : `aiapi-customizations-${latest.version}.tgz`, manifestUrl);
    const download = await fetch(tarball, { cache: 'no-store', redirect: 'follow', signal });
    if (!download.ok) throw new Error(`下載更新檔失敗 ${download.status}`);
    const bytes = Buffer.from(await download.arrayBuffer());
    const digest = createHash('sha256').update(bytes).digest('hex');
    if (typeof latest.sha256 === 'string' && latest.sha256.toLowerCase() !== digest) throw new Error('更新檔校驗碼不符，已停止更新');
    const dir = join(homedir(), '.aiapi', 'updates');
    await mkdir(dir, { recursive: true });
    const file = join(dir, `aiapi-customizations-${latest.version}.tgz`);
    await writeFile(file, bytes);
    Object.assign(updateState, { phase: 'installing', version: latest.version, error: '', application: '', restartReason: '', method: '', at: Date.now() });
    // Answer first: installing replaces this bundle, so the request must be complete before it starts.
    setTimeout(() => {
      void (async () => {
        let managerResult;
        let managerError;
        try {
          managerResult = await manager.installBundle(`file:${file}`, { requestId: `aiapi-update-${latest.version}` });
        } catch (error) {
          managerError = error;
        }
        // The manager's word is not enough: read the version it actually left on disk.
        let onDisk = readOnDiskVersion();
        let method = 'manager';
        if (onDisk !== latest.version) {
          // A `link:` install cannot always be replaced by the manager; write the files over it instead.
          const written = await replaceInstalled(readTarball(bytes));
          method = 'copy';
          onDisk = readOnDiskVersion();
          if (onDisk !== latest.version) {
            throw new Error(`安裝後版本仍是 ${onDisk || '讀不到'}（已寫入 ${written} 個檔案）${managerError instanceof Error ? `；管理器：${managerError.message}` : ''}`);
          }
        }
        const application = method === 'copy'
          ? 'restart-required'
          : (typeof managerResult?.application === 'string' ? managerResult.application : 'restart-required');
        Object.assign(updateState, {
          phase: 'done',
          method,
          application,
          restartReason: typeof managerResult?.restartReason === 'string' ? managerResult.restartReason : '',
          at: Date.now(),
        });
        ctx.logger?.info?.(`aiapi update: ${latest.version} via ${method} (${application})`);
      })().catch(error => {
        Object.assign(updateState, { phase: 'failed', error: error instanceof Error ? error.message : '安裝失敗', at: Date.now() });
        ctx.logger?.error?.(`aiapi update failed: ${error instanceof Error ? error.message : error}`);
      });
    }, 250);
    return Response.json({ status: 'updating', version: latest.version, sha256: digest, file }, { headers: { 'cache-control': 'no-store' } });
  } catch (error) {
    return Response.json({ status: 'failed', error: error instanceof Error ? error.message : '更新失敗' }, { status: 400, headers: { 'cache-control': 'no-store' } });
  }
}


/**
 * Forget the AIAPI connection this profile holds: the Smart Key and any half-finished sign-in.
 * The provider entry and the user's own settings are left untouched, so signing in again is one click.
 * @param ctx - unified plugin context, owner of the credential store.
 * @param request - the page's POST, whose body is unused.
 * @returns the state the card should show next.
 */
async function disconnectAccount(ctx, request) {
  try {
    if (request.signal.aborted) throw new Error('已取消');
    await ctx.credentials.unset(AIAPI_CREDENTIAL_REF);
    await ctx.credentials.unset(AIAPI_PENDING_CREDENTIAL_REF);
    await ctx.credentials.unset(AIAPI_DEVICE_CREDENTIAL_REF);
    return Response.json({ status: 'disconnected' }, { headers: { 'cache-control': 'no-store' } });
  } catch (error) {
    return Response.json({ status: 'failed', error: error instanceof Error ? error.message : '無法清除連接' }, { status: 500, headers: { 'cache-control': 'no-store' } });
  }
}

function validRedirectURI(value) {
  return value === 'aiapi-agent://oauth/callback' || value === 'aiapi-agent-preview://oauth/callback';
}

async function postDesktopAuth(path, body, signal) {
  const response = await fetch(`${AIAPI_DESKTOP_AUTH_ENDPOINT}${path}`, {
    method: 'POST',
    headers: { accept: 'application/json', 'content-type': 'application/json', 'cache-control': 'no-store' },
    body: JSON.stringify(body),
    cache: 'no-store',
    redirect: 'error',
    signal,
  });
  let payload;
  try { payload = await response.json(); } catch { throw new Error('AIAPI 授權服務暫時無法使用'); }
  if (!response.ok || payload?.code !== 0) throw new Error('AIAPI 授權服務暫時無法使用');
  return payload.data;
}

function desktopAuthFailure(error) {
  const failure = error instanceof Error ? error : new Error('Unknown desktop authorization failure');
  const message = /^桌面授權|^桌面登入|^找不到待完成|^授權服務/.test(failure.message) ? failure.message : '無法完成 AIAPI 帳號授權，請檢查網路後重試。';
  const status = /^桌面授權|^桌面登入|^找不到待完成/.test(failure.message) ? 400 : 503;
  return Response.json({ error: message }, { status, headers: { 'cache-control': 'no-store' } });
}
