/**
 * Per-conversation subagent model: the user picks one of the routes the conversation's official
 * model-selection policy allows, and every `subagent` call in that conversation must name it.
 * DSH lets plugins allow or deny a tool call but not rewrite its arguments, so a call without the
 * chosen route is denied with a reason telling the model exactly what to send.
 */
import { mkdir, readFile, rename, writeFile } from 'node:fs/promises';
import { homedir } from 'node:os';
import { dirname, join } from 'node:path';

const POLICY_EVENT = 'subagent/model-selection-policy';

/**
 * Routes a session's recorded policy allows.
 * @param events - session events.
 * @returns allowed `{ provider, model }` routes, or undefined when model selection was off at creation.
 */
export function allowedRoutes(events) {
  return events.find(event => event.type === POLICY_EVENT)?.data?.allowedModels;
}

/**
 * The decision for one `subagent` call under a conversation's chosen route.
 * @param args - parsed tool arguments.
 * @param chosen - the user's `{ provider, model }` for this conversation.
 * @returns undefined to allow, or the denial reason.
 */
export function routeViolation(args, chosen) {
  if (args?.provider === chosen.provider && args?.model === chosen.model) return undefined;
  return `使用者為這個對話指定子代理使用 ${chosen.provider} / ${chosen.model}。請重新呼叫 subagent，並加上 provider: "${chosen.provider}" 與 model: "${chosen.model}"（其他參數不變）。`;
}

/** Durable per-conversation choices in one JSON file under `$DSH_HOME`. */
export class SubagentModelStore {
  /**
   * @param path - JSON file path.
   */
  constructor(path) {
    this.path = path;
    this.cache = undefined;
    this.writes = Promise.resolve();
  }

  async all() {
    if (!this.cache) {
      try { this.cache = JSON.parse(await readFile(this.path, 'utf8')); } catch (error) {
        if (error?.code !== 'ENOENT') throw error;
        this.cache = {}; // never written yet
      }
    }
    return this.cache;
  }

  /**
   * The chosen route of a conversation.
   * @param sessionId - root conversation id.
   * @returns `{ provider, model }`, or undefined to follow the main model.
   */
  async get(sessionId) {
    return (await this.all())[sessionId];
  }

  /**
   * Set or clear a conversation's route.
   * @param sessionId - root conversation id.
   * @param route - `{ provider, model }`, or undefined to clear.
   * @returns after the file is written.
   */
  async set(sessionId, route) {
    const all = await this.all();
    if (route) all[sessionId] = { provider: route.provider, model: route.model, updatedAt: new Date().toISOString() };
    else delete all[sessionId];
    const text = JSON.stringify(all, null, 1);
    this.writes = this.writes.then(async () => {
      await mkdir(dirname(this.path), { recursive: true });
      const temporary = `${this.path}.${process.pid}.tmp`;
      await writeFile(temporary, text, 'utf8');
      await rename(temporary, this.path);
    });
    await this.writes;
  }
}

/**
 * Register the enforcement listener and the picker's routes.
 * @param ctx - unified plugin context.
 * @param lineage - subagent-to-conversation map.
 * @returns nothing; contributions are effects of `ctx`.
 */
export function apply(ctx, lineage) {
  const store = new SubagentModelStore(join(process.env.DSH_HOME || join(homedir(), '.dsh'), 'aiapi-subagent-models.json'));
  ctx.on('tools/pre-execute', async (exec, next) => {
    if (exec.name !== 'subagent' || !exec.agent) return next();
    const chosen = await store.get(lineage.rootOf(exec.agent.id)).catch(() => undefined);
    if (!chosen) return next();
    // Enforce only routes the calling session may actually select; otherwise the denial could never be satisfied.
    const allowed = allowedRoutes(exec.agent.session.snapshotEvents()) ?? [];
    if (!allowed.some(route => route.provider === chosen.provider && route.model === chosen.model)) return next();
    const reason = routeViolation(exec.arguments, chosen);
    return reason ? { kind: 'deny', reason } : next();
  });
  const json = (value, status = 200) => Response.json(value, { status, headers: { 'cache-control': 'no-store' } });
  ctx.inject(['connection', 'sessionController'], scope => {
    scope.effect(() => scope.connection.fetch.register({
      path: '/api/aiapi/subagent-model', methods: ['GET', 'POST'], requestBody: 'buffered',
      fetch: async request => {
        try {
          const body = request.method === 'POST' ? await request.json().catch(() => ({})) : {};
          const sessionId = request.method === 'POST' ? body.session : new URL(request.url).searchParams.get('session');
          if (typeof sessionId !== 'string' || !/^[\w.:-]{1,200}$/.test(sessionId)) return json({ error: '對話識別碼無效' }, 400);
          const inspection = await scope.sessionController.inspect(sessionId, request.signal);
          const allowed = allowedRoutes(inspection.events) ?? [];
          if (request.method === 'POST') {
            const route = body.provider && body.model ? { provider: String(body.provider), model: String(body.model) } : undefined;
            if (route && !allowed.some(entry => entry.provider === route.provider && entry.model === route.model)) return json({ error: '這個模型不在此對話允許的子代理模型內' }, 400);
            await store.set(sessionId, route);
          }
          return json({ enabled: allowed.length > 0, allowed, selected: (await store.get(sessionId)) ?? null });
        } catch (error) {
          return json({ error: error instanceof Error ? error.message : String(error) }, 500);
        }
      },
    }), 'aiapi subagent model');
  });
}
