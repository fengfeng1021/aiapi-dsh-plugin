/** System Chromium host: lazy shared process, background tabs, persistent profile. */
import { randomUUID } from 'node:crypto';
import { existsSync } from 'node:fs';
import { mkdir, open, unlink } from 'node:fs/promises';
import { homedir } from 'node:os';
import { isAbsolute, join } from 'node:path';

/**
 * Resolve explicit deployment choices without using a personal browser profile.
 * @param config - optional executable, profile and timeout/size limits.
 * @returns validated launch settings; missing system browser fails at first use.
 */
export function resolveBrowserConfig(config = {}) {
  const candidates = process.platform === 'win32'
    ? [join(process.env['PROGRAMFILES(X86)'] || 'C:/Program Files (x86)', 'Microsoft/Edge/Application/msedge.exe'), join(process.env.PROGRAMFILES || 'C:/Program Files', 'Google/Chrome/Application/chrome.exe')]
    : process.platform === 'darwin'
      ? ['/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge', '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome']
      : ['/usr/bin/microsoft-edge', '/usr/bin/google-chrome', '/usr/bin/chromium'];
  const result = {
    executablePath: config.executablePath || candidates.find(existsSync),
    profileDir: config.profileDir || join(process.env.DSH_HOME || join(homedir(), '.dsh'), 'aiapi-browser'),
    timeoutMs: config.timeoutMs ?? 15000,
    downloadTimeoutMs: config.downloadTimeoutMs ?? 45000,
    maxDownloadBytes: config.maxDownloadBytes ?? 104857600,
    // Open tabs one agent may keep; opening another closes its least recently active one.
    maxTabsPerAgent: config.maxTabsPerAgent ?? 4,
    // A tab another conversation used within this many seconds cannot be taken over.
    adoptIdleSeconds: config.adoptIdleSeconds ?? 120,
    closeSubagentTabs: config.closeSubagentTabs ?? true,
  };
  if (!isAbsolute(result.profileDir)) throw new Error('browser.profileDir must be absolute');
  if (result.executablePath && !isAbsolute(result.executablePath)) throw new Error('browser.executablePath must be absolute');
  for (const key of ['timeoutMs', 'downloadTimeoutMs', 'maxDownloadBytes', 'maxTabsPerAgent', 'adoptIdleSeconds']) {
    if (!Number.isSafeInteger(result[key]) || result[key] <= 0) throw new Error(`browser.${key} must be a positive integer`);
  }
  if (typeof result.closeSubagentTabs !== 'boolean') throw new Error('browser.closeSubagentTabs must be a boolean');
  return result;
}

/** A CDP host compatible with the upstream tools, without an Electron process. */
export class SystemBrowserHost {
  constructor(config, launch) {
    this.config = resolveBrowserConfig(config);
    this.launch = launch;
    this.views = new Map();
    this.pending = new Set();
    this.operationsBySession = new Map();
    this.closed = false;
  }

  available() {
    return !this.closed && Boolean(this.config.executablePath && existsSync(this.config.executablePath));
  }

  async browser() {
    if (this.closed) throw new Error('Aiapi browser host is closed');
    if (!this.available()) throw new Error('Install Microsoft Edge or Google Chrome, or configure browser.executablePath');
    if (!this.connection) {
      this.connection = (async () => {
        await mkdir(this.config.profileDir, { recursive: true });
        const browser = await this.launch({
          executablePath: this.config.executablePath,
          userDataDir: this.config.profileDir,
          headless: false,
          defaultViewport: null,
          timeout: this.config.timeoutMs,
          protocolTimeout: this.config.timeoutMs,
          // Pipe avoids a remotely reachable debugging port. No stealth/UA spoofing.
          pipe: true,
          args: ['--start-minimized', '--no-first-run', '--no-default-browser-check', '--disable-background-timer-throttling', '--disable-renderer-backgrounding'],
          env: Object.fromEntries(Object.entries(process.env).filter(([key]) => !/KEY|SECRET|TOKEN|PASSWORD/i.test(key))),
        });
        try {
          this.control = await browser.target().createCDPSession();
          const { targetInfos } = await this.control.send('Target.getTargets');
          const first = targetInfos.find(target => target.type === 'page');
          if (first) {
            const { windowId } = await this.control.send('Browser.getWindowForTarget', { targetId: first.targetId });
            await this.control.send('Browser.setWindowBounds', { windowId, bounds: { windowState: 'minimized' } });
          }
        } catch (error) {
          await browser.close();
          throw error;
        }
        browser.once('disconnected', () => { if (this.connection === connection) this.connection = undefined; });
        return browser;
      })();
      const connection = this.connection;
      connection.catch(() => { if (this.connection === connection) this.connection = undefined; });
    }
    return this.connection;
  }

  createView() {
    if (this.closed) throw new Error('Aiapi browser host is closed');
    const view = { id: randomUUID(), closed: false };
    view.sendCommand = async (method, params) => (await this.materialize(view)).cdp.send(method, params);
    view.capture = async (options = {}) => {
      const { page } = await this.materialize(view);
      const { width, height } = await page.evaluate(() => ({ width: innerWidth, height: innerHeight }));
      const scale = Math.min(1, (options.maxWidth || width) / width, (options.maxHeight || height) / height);
      const { data } = await view.sendCommand('Page.captureScreenshot', {
        format: options.format || 'png',
        ...(options.format === 'jpeg' && options.quality !== undefined ? { quality: options.quality } : {}),
        clip: { x: 0, y: 0, width, height, scale },
        captureBeyondViewport: false,
      });
      return { base64: data, mime: options.format === 'jpeg' ? 'image/jpeg' : 'image/png' };
    };
    view.flushAuth = async () => (await this.browser()).defaultBrowserContext().cookies();
    view.restoreAuth = async (cookies) => {
      const context = (await this.browser()).defaultBrowserContext();
      await context.setCookie(...cookies);
      return cookies.length;
    };
    view.download = (url, path) => {
      const operation = this.download(view, url, path);
      this.track(operation, view.owner);
      return operation;
    };
    this.views.set(view.id, view);
    return view;
  }

  async materialize(view) {
    if (this.closed || view.closed) throw new Error('Aiapi browser tab is closed');
    if (!view.ready) {
      view.ready = (async () => {
        const browser = await this.browser();
        const control = this.control;
        const marker = `about:blank#aiapi-${view.id}`;
        await control.send('Target.createTarget', { url: marker, background: true, newWindow: false });
        const target = await browser.waitForTarget(item => item.url() === marker, { timeout: this.config.timeoutMs });
        const page = await target.page();
        if (!page) throw new Error('System browser did not create a page');
        if (view.closed || this.closed) {
          await page.close();
          throw new Error('Aiapi browser tab closed while opening');
        }
        const cdp = await page.createCDPSession();
        return { page, cdp };
      })();
    }
    return view.ready;
  }

  /**
   * URL and title of a tab that has a real page; lazy (never used) tabs report nothing.
   * @param view - host view.
   * @returns `{ url, title }`, or undefined.
   */
  async pageInfo(view) {
    if (!view.ready || view.closed) return undefined;
    const ready = await view.ready.catch(() => undefined);
    if (!ready || ready.page.isClosed()) return undefined;
    return { url: ready.page.url(), title: await ready.page.title().catch(() => '') };
  }

  /**
   * Restore the window and bring a page to the front: only for an explicit user request.
   * @param page - puppeteer page.
   * @returns after the page is in front.
   */
  async revealPage(page) {
    const session = await page.createCDPSession();
    try {
      const { windowId } = await session.send('Browser.getWindowForTarget');
      await session.send('Browser.setWindowBounds', { windowId, bounds: { windowState: 'normal' } });
    } finally {
      await session.detach();
    }
    await page.bringToFront();
  }

  /**
   * Bring an agent tab to the front for the user.
   * @param view - host view.
   * @returns after the tab is in front.
   */
  async reveal(view) {
    await this.revealPage((await this.materialize(view)).page);
  }

  /**
   * Pages the user opened in the shared window; agent tabs and blank pages are excluded.
   * @returns puppeteer pages, without starting the browser.
   */
  async userPages() {
    const browser = await this.connection?.catch(() => undefined);
    if (!browser) return [];
    const owned = new Set();
    for (const view of this.views.values()) {
      const ready = view.ready && await view.ready.catch(() => undefined);
      if (ready) owned.add(ready.page);
    }
    return (await browser.pages()).filter(page => !owned.has(page) && !page.isClosed() && !page.url().startsWith('about:blank'));
  }

  /**
   * Wrap a page the user opened as a view an agent tab can own.
   * @param page - puppeteer page.
   * @returns host view backed by that page.
   */
  adoptPage(page) {
    const view = this.createView();
    view.ready = page.createCDPSession().then(cdp => ({ page, cdp }));
    return view;
  }

  // Normal agent actions never activate a tab or bring a window to the foreground.
  showView() {}
  groupView(view, session) { view.owner = session; }
  async presentView(view) { await this.materialize(view); }

  destroyView(view) {
    if (view.closed) return;
    view.closed = true;
    this.views.delete(view.id);
    if (view.ready) this.track(view.ready.then(({ page }) => page.close()), view.owner);
  }

  track(operation, session) {
    this.pending.add(operation);
    const owned = this.operationsBySession.get(session) || new Set();
    this.operationsBySession.set(session, owned);
    owned.add(operation);
    operation.catch(error => {
      if (!/closed|Target|Session|Connection/i.test(String(error))) process.stderr.write(`[aiapi-browser] ${error}\n`);
    }).finally(() => {
      this.pending.delete(operation);
      owned.delete(operation);
      if (!owned.size) this.operationsBySession.delete(session);
    });
  }

  async drain(session) { await Promise.allSettled(this.operationsBySession.get(session) || []); }

  async download(view, url, path) {
    const deadline = Date.now() + this.config.downloadTimeoutMs;
    const { cdp } = await this.materialize(view);
    const { frameTree } = await cdp.send('Page.getFrameTree');
    const { resource } = await cdp.send('Network.loadNetworkResource', {
      frameId: frameTree.frame.id, url, options: { disableCache: false, includeCredentials: true },
    });
    if (!resource.success || !resource.stream || resource.httpStatusCode >= 400) {
      if (resource.stream) await cdp.send('IO.close', { handle: resource.stream });
      throw new Error(`Browser download failed (${resource.httpStatusCode || resource.netErrorName})`);
    }
    let file;
    try {
      file = await open(path, 'wx');
      let total = 0;
      for (;;) {
        if (this.closed || view.closed) throw new Error('Browser download cancelled');
        if (Date.now() >= deadline) throw new Error('Browser download timed out');
        const chunk = await cdp.send('IO.read', { handle: resource.stream, size: 65536 });
        const data = Buffer.from(chunk.data, chunk.base64Encoded ? 'base64' : 'utf8');
        total += data.length;
        if (total > this.config.maxDownloadBytes) throw new Error('Browser download exceeds configured size limit');
        await file.write(data);
        if (chunk.eof) break;
      }
    } catch (error) {
      if (file) {
        await file.close();
        file = undefined;
        await unlink(path);
      }
      throw error;
    } finally {
      await file?.close();
      await cdp.send('IO.close', { handle: resource.stream });
    }
  }

  async dispose() {
    this.closed = true;
    for (const view of this.views.values()) this.destroyView(view);
    await Promise.allSettled(this.pending);
    const browser = await this.connection?.catch(() => undefined);
    if (browser) await browser.close();
  }
}
