/** Model tools that let an agent see every tab in the shared window and take over a usable one. */

/** Page addresses that usually mean the site waits for the user: login, CAPTCHA or human verification. */
export const ATTENTION_URL = /captcha|recaptcha|hcaptcha|turnstile|cf-chl|challenge|verify|verification|security[-_]?check|\/login|signin|sign-in|passport\.|\/buyer\/login|\/auth\//i;

const summaryOutput = { schema: { type: 'object', additionalProperties: false, properties: { summary: { type: 'string', required: true } } }, render: (_args, value) => [{ type: 'text', text: value.summary }] };
const minutes = ms => Math.max(1, Math.round(ms / 60000));

/**
 * One line per tab, marking whose it is and whether the site waits for the user.
 * @param tab - snapshot record.
 * @param agentId - calling agent.
 * @param rootOf - maps an agent id to its conversation's root agent id.
 * @param now - current epoch milliseconds.
 * @returns preview line.
 */
export function sharedTabLine(tab, agentId, rootOf, now) {
  const owner = tab.agentId === null ? '使用者開的'
    : tab.agentId === agentId ? '你的'
      : rootOf(tab.agentId) === rootOf(agentId) ? '同一對話的子代理'
        : `其他對話${tab.lastUsedAt ? `（${minutes(now - tab.lastUsedAt)} 分鐘前使用）` : ''}`;
  return `[${owner}] ${tab.tabId} | ${tab.title || '（無標題）'} | ${tab.url}${ATTENTION_URL.test(tab.url) ? ' | 可能在等登入或驗證' : ''}`;
}

/**
 * Build `browser_shared_tabs` and `browser_adopt_tab`.
 * @param defineTool - `defineTool` from `@deepseek-ai/dsh-tools`.
 * @param provider - the aiapi-system provider.
 * @param rootOf - maps an agent id to its conversation's root agent id.
 * @param now - clock seam.
 * @returns registry-ready definitions.
 */
export function createTabTools(defineTool, provider, rootOf, now = Date.now) {
  const sharedTabs = defineTool({
    name: 'browser_shared_tabs',
    description: 'List every real tab in the shared browser window: yours, other conversations\' (with how long ago they were used), and pages the user opened. '
      + 'Use it before opening a site the user may already have signed in to or verified; then take such a page over with browser_adopt_tab instead of opening a new tab.',
    parameters: {},
    output: summaryOutput,
    isConcurrencySafe: () => true,
    async execute(_args, exec) {
      const tabs = await provider.tabsSnapshot();
      if (tabs.length === 0) return { summary: '瀏覽器裡目前沒有開啟的分頁。' };
      return { summary: tabs.map(tab => sharedTabLine(tab, exec.agent?.id, rootOf, now())).join('\n') };
    },
    presentCall: () => ({ card: 'generic', title: '查看瀏覽器所有分頁', kind: 'read' }),
  });
  const adoptTab = defineTool({
    name: 'browser_adopt_tab',
    description: 'Take over a tab listed by browser_shared_tabs (a page the user opened, or another conversation\'s tab that has not been used recently) so your next browser_* calls act on it, keeping its login and verification. '
      + 'Call browser_session once first if you have not used the browser in this conversation.',
    parameters: { tab_id: { type: 'string', required: true, description: 'Tab id from browser_shared_tabs, e.g. tab:… or user:….' } },
    output: summaryOutput,
    async execute(args, exec) {
      if (!exec.agent) throw new Error('browser_adopt_tab requires an owning agent');
      const adopted = await provider.adoptTab(exec.agent.id, String(args.tab_id));
      return { summary: `已接手分頁 ${adopted.tabId}（${adopted.url || '空白頁'}）；之後的 browser_* 操作會作用在這個分頁。` };
    },
    presentCall: args => ({ card: 'generic', title: `接手瀏覽器分頁 ${args.tab_id ?? ''}`, kind: 'other' }),
  });
  return [sharedTabs, adoptTab];
}
