/** Optional browser contribution owned by the unified customization switch. */
import { randomUUID } from 'node:crypto';
import { resolveBrowserConfig, SystemBrowserHost } from './host.mjs';
import { ATTENTION_URL, createTabTools } from './tools.mjs';

const stripTab = id => String(id).replace(/^tab:/, '');

/**
 * Wrap upstream's public CDP provider with session-local tab selection, a per-agent tab cap,
 * user-facing tab listing and reveal, and explicit tab takeover between conversations.
 * @param Provider - upstream public provider constructor (no Electron import).
 * @param host - system browser host.
 * @param config - upstream navigation, content and download limits plus this plugin's tab policy.
 * @param now - clock seam.
 * @returns a provider selected as aiapi-system, never electron.
 */
export function createSystemProvider(Provider, host, config = {}, now = Date.now) {
  const policy = resolveBrowserConfig(config);
  return new class extends Provider {
    id = 'aiapi-system';
    userTabs = new Map();
    async switchTab(session, tabId) {
      await this.assertOwnTab(session, tabId);
      return super.switchTab(session, tabId);
    }
    async closeTab(session, tabId) {
      await this.assertOwnTab(session, tabId);
      await super.closeTab(session, tabId);
      await host.drain(session);
    }
    async assertOwnTab(session, tabId) {
      const tabs = await this.listTabs(session);
      if (!tabs.some(tab => stripTab(tab.id) === stripTab(tabId))) {
        throw new Error('This tab belongs to another agent or is already closed; use browser_list_tabs to list your own tabs, or browser_shared_tabs and browser_adopt_tab to take over another one');
      }
    }
    async close(session) {
      await super.close(session);
      await host.drain(session);
    }
    async reset(session) {
      await super.reset(session);
      await host.drain(session);
    }
    touch(session) {
      const s = this.sessions.get(session);
      if (s) s.lastUsedAt = now();
    }
    async openUrl(session, request, signal) {
      this.touch(session);
      if (request.newTab === true) await this.trimTabs(session);
      return super.openUrl(session, request, signal);
    }
    async execute(session, request, signal) { this.touch(session); return super.execute(session, request, signal); }
    async click(session, request, signal) { this.touch(session); return super.click(session, request, signal); }
    async type(session, request, signal) { this.touch(session); return super.type(session, request, signal); }
    async navigate(session, request, signal) { this.touch(session); return super.navigate(session, request, signal); }

    /** Close the least recently active real tabs until one more fits under the cap. */
    async trimTabs(session) {
      const s = this.session(session);
      for (;;) {
        const live = [];
        for (const [index, tab] of s.tabs.entries()) if (await host.pageInfo(tab.handle)) live.push({ tab, index });
        if (live.length < policy.maxTabsPerAgent) return;
        const victim = live.find(entry => entry.index !== s.activeIndex) ?? live[0];
        await super.closeTab(session, victim.tab.id);
        await host.drain(session);
      }
    }

    findTab(tabId) {
      for (const s of this.sessions.values()) {
        const index = s.tabs.findIndex(tab => stripTab(tab.id) === stripTab(tabId));
        if (index >= 0) return { s, index, tab: s.tabs[index] };
      }
      return undefined;
    }

    /**
     * Every real tab: agent tabs with their agent id, then pages the user opened.
     * @returns tab records `{ tabId, agentId, active, lastUsedAt, url, title }`.
     */
    async tabsSnapshot() {
      const out = [];
      for (const s of this.sessions.values()) {
        for (const [index, tab] of s.tabs.entries()) {
          const info = await host.pageInfo(tab.handle);
          if (info) out.push({ tabId: tab.id, agentId: s.label ?? null, active: index === s.activeIndex, lastUsedAt: s.lastUsedAt ?? null, ...info });
        }
      }
      const pages = await host.userPages();
      for (const [id, page] of this.userTabs) if (!pages.includes(page)) this.userTabs.delete(id);
      for (const page of pages) {
        let id = [...this.userTabs].find(([, known]) => known === page)?.[0];
        if (!id) { id = `user:${randomUUID()}`; this.userTabs.set(id, page); }
        out.push({ tabId: id, agentId: null, active: false, lastUsedAt: null, url: page.url(), title: await page.title().catch(() => '') });
      }
      return out;
    }

    /**
     * Show a tab to the user (user request only).
     * @param tabId - agent tab id or `user:` id.
     * @returns after the tab is in front.
     */
    async revealTab(tabId) {
      if (String(tabId).startsWith('user:')) {
        const page = this.userTabs.get(tabId);
        if (!page || page.isClosed()) throw new Error('這個分頁已經關閉');
        return host.revealPage(page);
      }
      const found = this.findTab(tabId);
      if (!found) throw new Error('這個分頁已經關閉');
      found.s.activeIndex = found.index;
      return host.reveal(found.tab.handle);
    }

    /**
     * Close a tab at the user's request, whoever owns it.
     * @param tabId - agent tab id or `user:` id.
     * @returns after the tab is closed.
     */
    async userCloseTab(tabId) {
      if (String(tabId).startsWith('user:')) {
        const page = this.userTabs.get(tabId);
        this.userTabs.delete(tabId);
        if (page && !page.isClosed()) await page.close();
        return;
      }
      const found = this.findTab(tabId);
      if (!found) return;
      await super.closeTab(found.s.id, found.tab.id);
      await host.drain(found.s.id);
    }

    /**
     * Close every real tab of agents (finished subagents, or a conversation the user cleans up).
     * Sessions stay open with a lazy blank tab, so a continued agent can browse again.
     * @param agentIds - agent ids whose tabs close.
     * @returns how many tabs closed.
     */
    async closeAgentTabs(agentIds) {
      let closed = 0;
      for (const s of [...this.sessions.values()].filter(candidate => agentIds.includes(candidate.label))) {
        // closeTab splices s.tabs; iterate a copy.
        for (const tab of s.tabs.slice()) {
          if (!(await host.pageInfo(tab.handle))) continue;
          await super.closeTab(s.id, tab.id);
          closed++;
        }
        await host.drain(s.id);
      }
      return closed;
    }

    /**
     * Move a tab into the calling agent's session: a page the user opened, or a tab of a conversation
     * that has not used its browser recently. The caller must already have a browser session.
     * @param agentId - calling agent id.
     * @param tabId - tab to take over.
     * @returns the adopted tab id and its URL.
     */
    async adoptTab(agentId, tabId) {
      const target = [...this.sessions.values()].find(s => s.label === agentId);
      if (!target) throw new Error('本對話還沒有瀏覽器工作階段：請先呼叫 browser_session，再接手分頁');
      let tab;
      if (String(tabId).startsWith('user:')) {
        const page = this.userTabs.get(tabId);
        if (!page || page.isClosed()) throw new Error('這個分頁已經關閉；請重新呼叫 browser_shared_tabs');
        this.userTabs.delete(tabId);
        tab = { id: `tab:${randomUUID()}`, handle: host.adoptPage(page) };
      } else {
        const found = this.findTab(tabId);
        if (!found) throw new Error('這個分頁已經關閉；請重新呼叫 browser_shared_tabs');
        if (found.s === target) {
          target.activeIndex = found.index;
          return { tabId: found.tab.id, url: (await host.pageInfo(found.tab.handle))?.url ?? '' };
        }
        if (found.s.lastUsedAt && now() - found.s.lastUsedAt < policy.adoptIdleSeconds * 1000) {
          throw new Error(`這個分頁所屬的對話在 ${policy.adoptIdleSeconds} 秒內還在使用瀏覽器；為避免互相干擾不能接手，請稍後再試或自行開新分頁`);
        }
        found.s.tabs.splice(found.index, 1);
        if (found.s.tabs.length === 0) this.newTab(found.s);
        else if (found.index <= found.s.activeIndex) found.s.activeIndex = Math.max(0, found.s.activeIndex - 1);
        tab = found.tab;
      }
      host.groupView(tab.handle, target.id);
      target.tabs.push(tab);
      target.activeIndex = target.tabs.length - 1;
      target.lastUsedAt = now();
      return { tabId: tab.id, url: (await host.pageInfo(tab.handle))?.url ?? '' };
    }

    /**
     * Tabs of the given agents whose address suggests the site waits for the user.
     * @param agentIds - agent ids of one conversation.
     * @returns `{ tabId, url, title }` records.
     */
    async attention(agentIds) {
      return (await this.tabsSnapshot()).filter(tab => agentIds.includes(tab.agentId) && ATTENTION_URL.test(tab.url))
        .map(({ tabId, url, title }) => ({ tabId, url, title }));
    }
  }(host, config);
}

/** Model-visible browser guidance section text. */
export const GUIDANCE = 'The browser_* tools use one shared system Edge/Chrome window in AiApi Agent, not Electron. Each agent owns its own tabs and active-tab selection. Tabs share cookies and website login/storage in a dedicated persistent application profile, not the user\'s personal browser profile. Normal operations run in background tabs without activating the window. '
  + 'Before opening a site the user may already have signed in or verified, call browser_shared_tabs; to work in such a page, call browser_session once, then browser_adopt_tab instead of opening a new tab. Each agent keeps at most a few real tabs; opening more closes its least recently active one, and a finished subagent\'s tabs close automatically, so close tabs you no longer need. '
  + 'Use browser_a11y or browser_snapshot before interacting; use target {by: css|text|xpath, value} or screenshot coordinates. Prefer browser_fill for batch forms and browser_scrape for extraction. Verify important actions with a fresh snapshot or browser_get_value. '
  + 'If a site asks for human verification or login, stop retries and tell the user; the conversation shows them a button that brings that exact tab to the front. Do not attempt to bypass verification.';

/**
 * Register only when the installed browser service exists; no eager browser launch.
 * @param ctx - unified plugin context.
 * @param config - deployment-owned browser settings.
 * @param lineage - subagent-to-conversation map from {@link trackLineage}.
 * @returns optional injection fiber; resolves when its dependencies register the backend.
 */
export function apply(ctx, config = {}, lineage) {
  const policy = resolveBrowserConfig(config.browser ?? {});
  const { rootOf, family } = lineage;
  const titles = new Map();
  return ctx.inject(['browser', 'systemPrompt'], async scope => {
    // The public CDP provider rides an optional peer: without it this feature stays inert instead of
    // failing the plugin, and the other features keep running.
    let ElectronBrowserProvider, launch;
    try {
      [{ ElectronBrowserProvider }, { launch }] = await Promise.all([
        import('dsh-builtin-browser/browser-electron'), import('puppeteer-core'),
      ]);
    } catch (error) {
      scope.logger?.warn?.(`aiapi-browser: browser provider unavailable, keeping the feature off: ${error instanceof Error ? error.message : error}`);
      return;
    }
    const host = new SystemBrowserHost(config.browser, launch);
    const provider = createSystemProvider(ElectronBrowserProvider, host, config.browser);
    const unregister = scope.browser.registerBrowserProvider(provider);
    scope.effect(() => async () => { unregister(); await host.dispose(); });
    scope.systemPrompt.section({ name: 'aiapi:browser', order: 150, text: GUIDANCE });
    scope.on('system-prompt/assemble', async (assembly, _context, next) => {
      assembly.sections = assembly.sections.filter(section => section.name !== 'tool:browser');
      return next();
    });
    if (policy.closeSubagentTabs) {
      scope.on('subagent/end', info => {
        void provider.closeAgentTabs([info.id]).catch(error => scope.logger?.warn?.(`aiapi-browser: closing a finished subagent's tabs failed: ${error instanceof Error ? error.message : error}`));
      });
    }
    try {
      const { defineTool } = await import('@deepseek-ai/dsh-tools');
      scope.inject(['tools'], tools => { for (const tool of createTabTools(defineTool, provider, rootOf)) tools.tools.register(tool); });
    } catch (error) {
      scope.logger?.warn?.(`aiapi-browser: shared-tab tools are unavailable: ${error instanceof Error ? error.message : error}`);
    }
    const title = async id => {
      if (!titles.has(id)) {
        let value = null;
        try {
          const inspection = await ctx.get('sessionController')?.inspect(id);
          value = inspection?.events?.filter(event => event.type === 'session/title').at(-1)?.data?.title ?? null;
        } catch {
          value = null; // a subagent or deleted conversation has no inspectable title
        }
        titles.set(id, value);
      }
      return titles.get(id);
    };
    const json = (value, status = 200) => Response.json(value, { status, headers: { 'cache-control': 'no-store' } });
    scope.effect(() => ctx.connection.fetch.register({
      path: '/api/aiapi/browser/tabs', methods: ['GET'], requestBody: 'buffered',
      fetch: async request => {
        const session = new URL(request.url).searchParams.get('session');
        const tabs = await provider.tabsSnapshot();
        if (session) {
          const members = family(session);
          const own = tabs.filter(tab => members.includes(tab.agentId));
          return json({ tabs: own, attention: own.filter(tab => ATTENTION_URL.test(tab.url)).map(({ tabId, url, title: name }) => ({ tabId, url, title: name })) });
        }
        const groups = new Map();
        for (const tab of tabs) {
          const root = tab.agentId ? rootOf(tab.agentId) : 'user';
          if (!groups.has(root)) groups.set(root, []);
          groups.get(root).push({ ...tab, needsUser: ATTENTION_URL.test(tab.url), subagent: tab.agentId !== null && tab.agentId !== root });
        }
        return json({ groups: await Promise.all([...groups].map(async ([root, list]) => ({ root, title: root === 'user' ? '你自己開的分頁' : await title(root), tabs: list }))) });
      },
    }), 'aiapi browser tabs');
    scope.effect(() => ctx.connection.fetch.register({
      path: '/api/aiapi/browser/tab', methods: ['POST'], requestBody: 'buffered',
      fetch: async request => {
        const body = await request.json().catch(() => ({}));
        try {
          switch (body?.action) {
            case 'reveal': await provider.revealTab(String(body.tabId)); return json({ ok: true });
            case 'close': await provider.userCloseTab(String(body.tabId)); return json({ ok: true });
            case 'close-group': return json({ closed: await provider.closeAgentTabs(family(String(body.root))) });
            default: return json({ error: '未知的操作' }, 400);
          }
        } catch (error) {
          return json({ error: error instanceof Error ? error.message : String(error) }, 500);
        }
      },
    }), 'aiapi browser tab actions');
  });
}
