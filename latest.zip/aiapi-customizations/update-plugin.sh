#!/usr/bin/env bash
# One-command update of @aiapi/dsh-customizations on any machine that runs DSH.
#
#   bash update-remote.sh                 # update the `web` profile if a newer release exists
#   bash update-remote.sh --check         # only report installed vs published
#   bash update-remote.sh --profile acp   # another profile
#   DSH_BIN=/path/to/dsh bash update-remote.sh
#
# The release host serves index.json + the tarball. The tarball is downloaded and its sha256 verified
# before DSH installs it, so a broken or tampered release never reaches the profile.
set -euo pipefail

INDEX_URL="${AIAPI_INDEX_URL:-https://aiapi.tw/install/aiapi-customizations/index.json}"
PROFILE="web"
CHECK_ONLY=0
while [ $# -gt 0 ]; do
  case "$1" in
    --check) CHECK_ONLY=1; shift ;;
    --profile) PROFILE="${2:?--profile needs a name}"; shift 2 ;;
    *) echo "unknown argument: $1" >&2; exit 2 ;;
  esac
done

say() { printf '%s\n' "$*"; }
# Only an https source is pinned to TLS; a local http index is allowed so the flow can be tested.
curl_get() {
  local url="$1"; shift
  case "$url" in
    https://*) curl --proto '=https' --tlsv1.2 -fsSL --connect-timeout 15 --max-time 60 "$@" "$url" ;;
    *) curl -fsSL --connect-timeout 15 --max-time 60 "$@" "$url" ;;
  esac
}
fail() { printf '✗ %s\n' "$*" >&2; exit 1; }

# 1. What is published.
command -v curl >/dev/null 2>&1 || fail "curl is required"
command -v node >/dev/null 2>&1 || fail "node is required"
manifest="$(curl_get "$INDEX_URL")" \
  || fail "cannot reach $INDEX_URL (has the gateway been deployed with /install/aiapi-customizations/ ?)"
latest="$(printf '%s' "$manifest" | node -e 'let s="";process.stdin.on("data",d=>s+=d).on("end",()=>{const m=JSON.parse(s);const l=m.latest;if(!l||!l.version)process.exit(1);process.stdout.write([l.version,l.tarball,l.sha256??""].join("\n"))})')" \
  || fail "release index is not the expected JSON"
LATEST_VERSION="$(printf '%s' "$latest" | sed -n 1p)"
TARBALL="$(printf '%s' "$latest" | sed -n 2p)"
SHA256="$(printf '%s' "$latest" | sed -n 3p)"
case "$TARBALL" in
  http://*|https://*) TARBALL_URL="$TARBALL" ;;
  *) TARBALL_URL="${INDEX_URL%/*}/$TARBALL" ;;
esac

# 2. What is installed.
DSH_HOME_DIR="${DSH_HOME:-$HOME/.dsh}"
[ -d "$DSH_HOME_DIR/profiles" ] || DSH_HOME_DIR="$HOME/Library/Application Support/com.aiapi.agent.desktop/dsh-home"
PROFILE_DIR="$DSH_HOME_DIR/profiles/$PROFILE"
INSTALLED="$(node -e 'try{process.stdout.write(require(process.argv[1]).version)}catch{process.stdout.write("")}' \
  "$PROFILE_DIR/node_modules/@aiapi/dsh-customizations/package.json" 2>/dev/null || true)"

say "profile   $PROFILE ($PROFILE_DIR)"
say "installed ${INSTALLED:-<not installed>}"
say "published $LATEST_VERSION"

if [ -n "$INSTALLED" ] && [ "$INSTALLED" = "$LATEST_VERSION" ]; then
  say "✓ already up to date"
  exit 0
fi
if [ "$CHECK_ONLY" = "1" ]; then
  say "→ a newer release is available"
  exit 0
fi

# 3. Download and verify.
tmpdir="$(mktemp -d "${TMPDIR:-/tmp}/aiapi-plugin.XXXXXX")"
tmp="$tmpdir/plugin.tgz"
trap 'rm -rf "$tmpdir"' EXIT
curl_get "$TARBALL_URL" -o "$tmp" \
  || fail "cannot download $TARBALL_URL"
ACTUAL="$(node -e 'const c=require("node:crypto"),f=require("node:fs");process.stdout.write(c.createHash("sha256").update(f.readFileSync(process.argv[1])).digest("hex"))' "$tmp")"
if [ -n "$SHA256" ] && [ "$ACTUAL" != "$SHA256" ]; then fail "sha256 mismatch (expected $SHA256, got $ACTUAL)"; fi
say "✓ downloaded and verified ($ACTUAL)"

# 4. Install through DSH, which owns the profile.
DSH_BIN="${DSH_BIN:-dsh}"
if ! command -v "$DSH_BIN" >/dev/null 2>&1 && [ ! -x "$DSH_BIN" ]; then
  fail "dsh not found; set DSH_BIN (Desktop: '/Applications/DeepSeek Harness.app/Contents/Resources/app/node_modules/.bin/dsh')"
fi
set -x
"$DSH_BIN" plugin --profile "$PROFILE" add "file:$tmp"
set +x
say "✓ installed $LATEST_VERSION — restart DSH (or reload the page) if it asks"
