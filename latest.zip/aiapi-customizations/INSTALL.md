# Aiapi 插件 1.8.0

## 新增：AIAPI 帳號與餘額
- 插件頁多一張「**AIAPI 帳號**」卡：顯示登入狀態、分組、**平台餘額**（`$12.34`）、
  以及定額資訊（若這支 key 有 quota：剩餘 / 上限），可「重新整理」。
- **常駐餘額條**開關：打開後，左側工作區**左下角**出現一條精緻餘額條
  - 動態彩色：`剩餘比例` 由綠 → 琥珀 → 紅（HSL 連續漸變），點會呼吸
  - 細進度條：以 quota 上限為分母；沒有 quota 時以 $50 為參考刻度
  - 每 2 分鐘自動更新，點一下就手動刷新；滑鼠移上去顯示完整金額與分組
- 資料來源：gateway 新增 `GET /v1/balance`（以 API Key 認證），回傳
  `{balance, frozen_balance, currency, quota?, group?}`；
  插件主機端以 `/api/aiapi/balance` 代理，**Smart Key 不會出現在網頁層**。

## 對應的 gateway 版本
本功能對應 gateway `0.2.13-aiapi.71`（已部署）。

## 安裝 / 更新
- 下載：https://fengfeng1021.github.io/aiapi-dsh-plugin/latest.zip
- 已裝過的機器：`bash update-plugin.sh`
