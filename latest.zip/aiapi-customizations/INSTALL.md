# Aiapi 插件 1.3.6

## 更新來源（GitHub Pages，與 AIAPI 無關）

bundle patch 已內建：

```yaml
updateManifestUrl: https://fengfeng1021.github.io/aiapi-dsh-plugin/index.json
```

插件頁 → 檢查更新 → 立即更新；或舊版機器跑 `bash update-plugin.sh`。

## 安裝

貼 `aiapi-customizations` 資料夾路徑，或
`https://fengfeng1021.github.io/aiapi-dsh-plugin/latest.tgz`。

## 發佈新版本

```bash
node release.mjs --notes "…" --base-url https://fengfeng1021.github.io/aiapi-dsh-plugin/
OUT_DIR=github-release bash publish-cloud.sh --dir release/<版本> --provider github-raw --repo fengfeng1021/aiapi-dsh-plugin --no-verify
cd github-release && git add -A && git commit -m "release <版本>" && git push
```

## 功能開關
Plugins → 本插件頁面，或 設定 → 一般（`opencode` 顯示為「智能配色」）。
