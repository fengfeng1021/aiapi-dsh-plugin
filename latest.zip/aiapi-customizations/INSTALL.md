# Aiapi 插件 1.8.7

## 新增：使用者端錯誤自動回傳

使用者的介面一丟錯，就會自動把「錯誤本身」送到 AIAPI 平台，你可以在後台看到，不必再請人貼 Console。

**送去什麼**
- 插件版本、DSH 版本、平台
- 錯誤訊息、堆疊、發生位置（`window:` / `card:` / `unhandledrejection`）
- 一個隨機安裝 ID（可串同一位使用者的多筆回報）、頁面 URL

**不送什麼**
- 對話內容、提示詞、檔案內容、API Key、個資

**機制**
- 客戶端 `modules/features/reporter.js`：去重（同簽章 10 分鐘一次）＋限速（每小時 20 則）
- 主機端 `/api/aiapi/report` → 平台 `POST /v1/client-report`（金鑰只在主機端使用）
- 平台端寫入 **ops 錯誤日誌**（`error_type=client_error`、`error_source=client`、`inbound_endpoint=/v1/client-report`）

**關閉方式**
設定 →「AIAPI 帳號」→ 取消勾選「回傳介面錯誤」（寫入 `errorReporting: false`，volatile，不用重啟）

## 對應的 gateway 版本
`0.2.18-aiapi.3`（已部署）：新增 `POST /v1/client-report`，無 key 回 401。

## 安裝
- 下載：https://fengfeng1021.github.io/aiapi-dsh-plugin/latest.zip
- 已裝過：`bash update-plugin.sh`，然後**完全結束 DSH 再開**
