# Aiapi 插件 1.8.2

## 修好兩個問題

### 1. 餘額條不出現
`applyBalanceBar` 與餘額卡片讀設定時用了 **未定義的常數 `NAMESPACE`**（實際叫 `DEFAULT_NS`），
啟動後那一行直接丟 `ReferenceError`，於是開關狀態永遠是 false、條子永遠不掛。
現在統一走 `pickNamespace()`，並且**啟動時就讀一次設定**（不再依賴「先打開插件頁」）。

### 2. 更新提示不彈
`readJson()` 用 `document.baseURI` 組網址；桌面殼的 baseURI 不一定是 http(s)（可能是 `tauri://…`），
相對路徑因此解析到殼自己的 origin → 404 → 檢查失敗且靜默重試。
現在一律從 `location.origin`（http(s) 時）或 baseURI 組**站點根絕對路徑**，失敗會印出實際 URL。

## 另外加的
- 每個介面區塊（功能列／插件頁／更新提示／餘額條）各自 try/catch，一個掛了不影響其他
- 診斷訊息（Console 前綴 `[aiapi]`）：
  - `balanceBar 設定讀取: true|false`
  - `已註冊 sidebar.footer.action 餘額條`
  - `更新檢查: {current, latest, newer, installed}`
  - `更新檢查失敗:` / `掛載失敗:`

## 安裝
- 下載：https://fengfeng1021.github.io/aiapi-dsh-plugin/latest.zip
- 已裝過：`bash update-plugin.sh`，然後**完全結束 DSH 再開**
