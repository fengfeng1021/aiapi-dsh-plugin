# Aiapi 插件 1.7.0

## 移除（官方桌面端已具備）
- **任務狀態與原話查找**（`task_state` / `context_recall` / 交接路由）整支移除。
- **原生拖放與對話交接**整支移除：官方 `dsh-client-ui-attachment`（`drop-events.ts`）與
  `dsh-client-ui-workspace` 已處理拖放；交接功能原本依賴 `task_state`，所以一併移除。
- `showToast` 抽到 `modules/toast.jsx`，Skills 管理不受影響。

## 剩下 6 個功能
| 開關 | 內容 |
| --- | --- |
| 品牌外觀 | 固定啟用 |
| 模型與提供者 | 固定啟用 |
| 工程審查包 | 單一引導 skill，六份審查文件按需讀取 |
| 白話進度與結論優先回覆 | 對話風格 |
| 智能配色 | OpenCode 風格配色 |
| 字型設定 | 介面字型 |
| Skills 管理 | 側邊欄管理頁 |

## 更新流程
- 卡片依 `pluginManager.installBundle()` 真實回報：需重啟／可重載／失敗。
- 磁碟版本 ≠ 執行中版本時，提示「請完全結束 DSH 再開」。

## 安裝 / 更新
- 下載：https://fengfeng1021.github.io/aiapi-dsh-plugin/latest.zip
- 已裝過的機器：`bash update-plugin.sh`
