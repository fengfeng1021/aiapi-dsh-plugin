# Aiapi 插件 1.8.6

## 修好什麼（你的 Console 直接指出來的）

```
[aiapi] balanceBar 設定讀取失敗: ReferenceError: setBalanceFlag is not defined
ReferenceError: balanceFlag is not defined   at BalanceFooterBar
ReferenceError: balanceFlag is not defined   at BalanceRow
```

`balanceFlag` / `setBalanceFlag` 這組共享狀態**從來沒有被定義**（1.8.0 我改寫時只留下引用）。
所以：
- 側邊欄餘額條 → 渲染時丟錯 → 被 slot 的錯誤邊界吞掉 → **永遠看不到**
- 插件頁的餘額卡 → 同樣丟錯 → 整張卡消失
- 開關寫入也走同一組函式 → 勾了也不會生效

現在移到獨立模組 `modules/features/balance-flag.js`，由 `client.jsx` 具名匯入。

## 順帶確認的
- 你的更新檢查是正常的：`{current: '1.8.5', latest: '1.8.5', newer: false}` → 已是最新，所以本來就不該彈
- 全域字型 404（`noto-sans-mono`、`maple-mono-cn`）與本插件無關

## 新增：client bundle 冒煙測試
`smoke.test.mjs` 用最小 React + 假 Context 載入 `lib/client.js` 並呼叫 `apply()`，
專門抓「未定義識別字」這類 host 測試看不到、型別檢查也看不到的錯誤。目前 1 pass。

## 安裝
- 下載：https://fengfeng1021.github.io/aiapi-dsh-plugin/latest.zip
- 已裝過：`bash update-plugin.sh`，然後**完全結束 DSH 再開**
