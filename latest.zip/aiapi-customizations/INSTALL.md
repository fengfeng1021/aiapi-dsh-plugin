# Aiapi 插件 1.3.8

## 這一版
- **系統瀏覽器改為 opt-in**：預設關閉，且不再停用官方的 `browser-electron`／不再改 `browserProvider`。
  想在 DSH 用共用 Edge/Chrome 分頁，把 `features.browser` 開起來即可。
- 模型頁 Aiapi 卡片：新增「**AI API 帳號**」列，已登入顯示 **已登入**，並有 **清除連接**。
- 一般 DSH 的裝置授權頁面（gateway 前端）已修好，確認授權可按。

## 安裝 / 更新
- 下載：https://fengfeng1021.github.io/aiapi-dsh-plugin/latest.zip
- 已裝過的機器：`bash update-plugin.sh`
