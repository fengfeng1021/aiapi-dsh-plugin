# Aiapi 插件 1.6.1

## 更新流程修好（重點）
之前按「立即更新」只會回一句「正在安裝…」，安裝結果被丟掉，而且就算裝好了，**執行中的 DSH 仍載著舊模組**，
所以重新載入頁面版本不會變。現在：

- 安裝結果由 `pluginManager.installBundle()` 實際回報：
  - `restart-required`（沒有 HMR、套件搬移、host module 變更…）→ 卡片直接說「請**完全結束 DSH 再重新開啟**」
  - `applied` → 卡片說可按「重新載入頁面」
  - `failed` → 顯示真正錯誤，不再假裝成功
- 新增 `GET /api/aiapi/update/status`：卡片每秒輪詢，最多 2 分鐘
- 新增磁碟版本偵測：`GET /api/aiapi/update` 回傳 `{version, onDisk}`；
  兩者不同就顯示「磁碟上已是 X（執行中 Y）→ 請完全結束 DSH 再開」
- 啟動提醒也會優先報「已安裝、只差重啟」

## 安裝 / 更新
- 下載：https://fengfeng1021.github.io/aiapi-dsh-plugin/latest.zip
- 已裝過的機器：`bash update-plugin.sh`
