# Aiapi 插件 1.7.1

## 更新為什麼之前沒生效（已修）
用資料夾安裝（pnpm 的 `link:`）時，管理器的 `installBundle('file:…tgz')` **不會真的換掉**：
pnpm 會留在舊的 link 目標，甚至產生一個指向不存在的 `.pnpm` 目錄的連結 —— 版本當然還是舊的，
重啟也沒用。這一版改成：

1. 先照正常流程交給 `pluginManager.installBundle()`；
2. **再讀一次磁碟上的 package.json 版本**驗證；
3. 版本沒變就**直接把 tarball 內容覆寫到已安裝目錄**（不動 `node_modules`），再驗證一次；
4. 只有磁碟版本真的變成新版才回報成功，否則顯示失敗與原因。

回報欄位：`{ phase, method: 'manager'|'copy', application: 'restart-required'|'applied', onDisk, running }`。
覆寫方式一律需要**完全結束 DSH 再開**。

## 安裝 / 更新
- 下載：https://fengfeng1021.github.io/aiapi-dsh-plugin/latest.zip
- 已裝過的機器：`bash update-plugin.sh`
