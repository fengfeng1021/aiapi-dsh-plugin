# Aiapi 插件 1.4.0

## 這一版移除系統瀏覽器

- 刪除 `browser` 功能：`modules/browser/`（宿主 provider、工具、分頁頁面）整個移除，
  `puppeteer-core`（28 MB）與 `dsh-builtin-browser` peer 依賴一併移除。
- 官方 DSH 的瀏覽器（`browser-electron`）本來就不受影響，現在更乾淨：本插件不再碰瀏覽器。
- 舊 patch 的 `features.browser` / `browser:` 仍可載入，但會被忽略。

## 其他
- 模型頁 Aiapi 卡片有「**AI API 帳號**」列（已登入 / 未登入）與「**清除連接**」。
- 一般 DSH 的裝置授權頁面已在 gateway 端修好。

## 安裝 / 更新
- 下載：https://fengfeng1021.github.io/aiapi-dsh-plugin/latest.zip
- 已裝過的機器：`bash update-plugin.sh`
