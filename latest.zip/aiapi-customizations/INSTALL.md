# Aiapi 插件 1.8.5

## 目的：讓「介面空白 / 沒更新提示」變成可診斷

1. **每張卡各自錯誤邊界**：更新卡、餘額卡、功能開關卡互不影響，一張炸掉只顯示
   `這個區塊載入失敗：<原因>`，不會整區空白。
2. **全域錯誤紀錄**（Console，前綴 `[aiapi]`）：
   - `未捕捉錯誤: <message> <file> <line>`
   - `未處理的 Promise: <reason>`
3. **版本顯示**：設定 →「AIAPI 帳號」頁底顯示 `插件版本 1.8.5`；
   啟動時 Console 印 `[aiapi] 客戶端版本 1.8.5`。
4. 移除 `client.jsx ↔ balance.jsx` 的循環相依（版本常數改放 `modules/version.js`）。

## 排查順序（1.8.5 裝好之後）
1. Console 是否出現 `[aiapi] 客戶端版本 1.8.5`？
   - 沒有 → 這個 DSH 沒有載入插件（profile 不對 / 安裝失敗 / engines 不符）
   - 有 → 繼續看下一條
2. 有沒有 `[aiapi] 掛載失敗` / `卡片渲染失敗` / `未捕捉錯誤`？把整行貼出來。
3. 有沒有 `[aiapi] 更新檢查: {current, latest, newer}`？
   - `newer: false` → 已是最新或 manifest 讀到舊值
   - 沒有這行 → `/api/aiapi/update` 打不到（會伴隨 `請求失敗 <url>`）

## 安裝
- 下載：https://fengfeng1021.github.io/aiapi-dsh-plugin/latest.zip
- 已裝過：`bash update-plugin.sh`，然後**完全結束 DSH 再開**
