# Aiapi 插件 1.5.0

## 功能清單（8 個）
| 開關 | 狀態 |
| --- | --- |
| 品牌外觀 | **固定啟用**（不給關） |
| 模型與提供者 | **固定啟用**（不給關） |
| 工程審查 skills | 可關（短工程提示＋6 個審查 skills；**不是**自動壓縮上下文） |
| 白話進度與結論優先回覆 | 可關（原「進度與回覆風格」） |
| 任務狀態與原話查找 | 可關 |
| 拖放參照與對話交接 | 可關（檔案位置、回合導覽交給官方） |
| 智能配色 | 可關 |
| 字型設定 | 可關 |
| Skills 管理 | 可關 |

## 這一版
- 品牌、模型兩個開關改成固定啟用（UI 顯示「固定啟用」）。
- 刪除「子代理模型」：官方 `dsh-client-ui-settings-subagent`／`subagent-model-selection-card-controller` 已有。
- 桌面模組移除「開啟檔案所在位置」與「左側回合導覽」：官方 `dsh-client-ui-open-in-app`、`dsh-session-turn-outline` 已有；保留拖放參照與對話交接。
- Skills 管理：新增搜尋（名稱/說明/來源）、重新整理、送出期間防重複點擊、依名稱排序、搜尋無結果提示。
- 工程規範查核：`ctx.systemPrompt.context` 只是一段約 90 字的靜態提示，不是自動壓縮 → 保留，標籤改為「工程審查 skills」。

## 安裝 / 更新
- 下載：https://fengfeng1021.github.io/aiapi-dsh-plugin/latest.zip
- 已裝過的機器：`bash update-plugin.sh`
