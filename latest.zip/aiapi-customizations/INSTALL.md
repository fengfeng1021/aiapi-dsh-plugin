# Aiapi 插件 1.6.0

## 工程審查包（本版重點）
- 不再注入任何提示（原本那段 `systemPrompt.context` 已刪除）。
- 6 份審查文件**不再登記成 skill**，所以不會出現在 AI 的清單、也不會被自動載入。
- 只登記一個引導 skill：`aiapi-engineering-review`。
- 對話中叫它（名稱或 `/`），它會告訴 AI 依需要去讀 `modules/engineering/skills/` 裡的哪一份文件。

## 功能
| 開關 | 內容 |
| --- | --- |
| 品牌外觀 | 固定啟用 |
| 模型與提供者 | 固定啟用 |
| 工程審查包 | 單一引導 skill（不自動注入） |
| 白話進度與結論優先回覆 | 對話風格 |
| 任務狀態與原話查找 | `task_state` + `context_recall` + 對話交接 |
| 拖放參照與對話交接 | 原生拖放 → @ 參照、在新對話續做 |
| 智能配色 / 字型設定 / Skills 管理 | 介面 |

## 安裝 / 更新
- 下載：https://fengfeng1021.github.io/aiapi-dsh-plugin/latest.zip
- 已裝過的機器：`bash update-plugin.sh`
