# Aiapi 插件 1.3.7

## 這一版
- 模型頁的 Aiapi 卡片改成「**AI API 帳號**」列：已登入顯示 **已登入**，並多了 **清除連接** 按鈕。
- 一般 DSH 的裝置授權頁面問題在 gateway 側修好（確認授權按鈕可點）。

## 安裝 / 更新
- 下載：https://fengfeng1021.github.io/aiapi-dsh-plugin/latest.zip
- 貼 `aiapi-customizations` 資料夾路徑到 Plugins → 安装
- 已裝過的機器：`bash update-plugin.sh`

## 自動更新來源
```yaml
updateManifestUrl: https://fengfeng1021.github.io/aiapi-dsh-plugin/index.json
```

## 功能開關
Plugins → 本插件頁面，或 設定 → 一般（`opencode` 顯示為「智能配色」）。
