# Aiapi 插件 1.7.2

## 登入流程
- **預設改用裝置代碼**（Device Code）：卡片按「使用 AIAPI 帳號登入」→ 瀏覽器開授權頁 →
  輸入卡片上顯示的代碼 → 按「允許這次登入」→ 插件自動完成（輪詢），**不需要 `aiapi-agent://` 回呼**。
- 桌面回呼（OAuth）保留為備援連結「改用桌面回呼登入」，只有在應用程式有註冊協定時才有用。

## 注意：授權頁需要 gateway 前端更新
`/desktop/authorize?user_code=…` 的「允許」按鈕要在 **gateway 前端部署後**才會啟用
（目前線上建置只讀 `request_id`，所以代碼流程的按鈕是灰的）。
檢查方式：

```bash
curl -s https://aiapi.tw/ | grep -oE '/assets/index-[^"]+\.js' | head -1 | \
  xargs -I{} curl -s "https://aiapi.tw{}" | grep -c user_code
```

輸出大於 0 代表已部署。

## 安裝 / 更新
- 下載：https://fengfeng1021.github.io/aiapi-dsh-plugin/latest.zip
- 已裝過的機器：`bash update-plugin.sh`
