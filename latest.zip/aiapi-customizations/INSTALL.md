# Aiapi 插件 1.8.3

## 新增：設定 →「AIAPI 帳號」區塊

插件原本只把帳號與餘額放在插件頁，現在 **DSH 設定的側欄多一個「AIAPI 帳號」**（就在「帳號」那一層附近），
打開就能看到：

- 連線狀態（已連線 / 尚未登入 / 讀取失敗原因）
- **平台餘額**（`$12.34`）、凍結金額
- 這支 Key 的定額（若有）：剩餘 / 上限
- 所屬分組與倍率
- 「重新整理」按鈕
- 「常駐顯示餘額條」開關（與側邊欄左下角那條同步）

資料來源：`GET /v1/balance`（gateway 0.2.18 已含），主機端以 `/api/aiapi/balance` 代理，Smart Key 不會出現在網頁層。

## 修正（1.8.2 的事，若你還沒升）
- 餘額條不顯示：常數 `NAMESPACE` 未定義 → 改用 `pickNamespace()`
- 更新提示不彈：請求網址改用 `location.origin` 組絕對路徑

## 安裝
- 下載：https://fengfeng1021.github.io/aiapi-dsh-plugin/latest.zip
- 已裝過：`bash update-plugin.sh`，然後**完全結束 DSH 再開**
