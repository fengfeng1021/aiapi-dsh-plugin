# Aiapi 插件 1.8.1

## 修好兩件事
1. **更新提示不一定會彈**：原本啟動時只查一次，失敗就再也不查。現在
   - 提示與插件頁共用同一份狀態（`updateStore`）：在插件頁按「檢查更新」查到新版，**也會**彈出提示
   - 啟動後重試 `0s / 4s / 12s / 30s / 90s`，之後每 10 分鐘，切回視窗時再查
2. **重啟按鈕按了沒反應**：桌面殼不一定開放重啟指令。現在會依次嘗試
   `plugin:process|restart`、`plugin:process|relaunch`、`plugin:app|restart`、`restart_app`；
   全部失敗時**明確告知**「這個 DSH 不支援自動重啟，請完全結束 DSH（⌘Q）再重新開啟」，
   不會再假裝成功。

## 已知限制
純瀏覽器版（沒有桌面殼）沒有重啟宿主的 API，只能手動結束再開。

## 安裝 / 更新
- 下載：https://fengfeng1021.github.io/aiapi-dsh-plugin/latest.zip
- 已裝過的機器：`bash update-plugin.sh`
