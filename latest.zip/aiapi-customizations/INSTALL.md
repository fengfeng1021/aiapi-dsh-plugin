# Aiapi 插件 1.7.4

## 更新流程（依你的回饋）
- **更新提示改成「重新啟動 DSH」**：安裝完成後，彈窗與卡片上的主要按鈕直接是「重新啟動 DSH」。
  - 桌面版（Tauri）會嘗試 `plugin:process|restart` / `relaunch`，成功就自己重啟
  - 其他載體無法重啟 Host，會直接說明「請完全結束 DSH 再開」
- **提示不再晚到**：啟動檢查加入重試（0s / 4s / 12s / 30s / 90s，之後每 10 分鐘），
  並在視窗重新可見（切回 DSH）時再查一次；先前只在載入時查一次，網路還沒好就永久錯過。
- 安裝後輪詢 `/api/aiapi/update/status`，依 `application`／`method` 決定給「重新啟動」還是「重新載入頁面」。

## 安裝 / 更新
- 下載：https://fengfeng1021.github.io/aiapi-dsh-plugin/latest.zip
- 已裝過的機器：`bash update-plugin.sh`
