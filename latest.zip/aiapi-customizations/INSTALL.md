# Aiapi 插件 1.8.4

## 這一版的重點：讓你確認「到底裝進去了沒有」

- 設定 →「AIAPI 帳號」頁面底部會顯示 **插件版本 X.Y.Z**
- 啟動時 Console 印：`[aiapi] 客戶端版本 X.Y.Z`

如果你的 DSH 顯示的版本不是 1.8.4，代表更新沒有真的裝進去（而不是「新功能沒生效」）。

## 排查：這台 Mac 上有一個 1.0.135 的舊副本

`~/Library/Application Support/com.aiapi.agent.desktop/runtime/v0.1.26-aarch64/app/node_modules/@aiapi/dsh-customizations`
→ **1.0.135**（Aiapi Agent.app 0.1.26 內建的舊版，沒有 1.8.x 的介面）

如果 DSH 載入的是這一份，你就會看到舊介面、沒有餘額條、也沒有更新提示。
正確做法是把 1.8.4 裝進 DSH 的 profile（插件管理員安裝），而不是改 app 內的內建副本
（app 更新時會被 runtime.tar.gz 覆蓋）。

## 安裝
- 下載：https://fengfeng1021.github.io/aiapi-dsh-plugin/latest.zip
- 已裝過：`bash update-plugin.sh`，然後**完全結束 DSH 再開**
