# Aiapi 插件 1.7.5

## 「模型價格清單目前沒有已公布的模型」的真正原因
這不是你的帳號問題。實測本站：

```
GET https://aiapi.tw/api/v1/pricing/public
{"code":0,"data":{"exchange_rate":7,"groups":[]}}      ← 空的
```

資料庫裡所有 **active 的分組都是 `is_exclusive = true`（專屬分組）**，而非專屬分組都是
`disabled` / `inactive`。後端 `ListPublicPricing()` 會跳過 exclusive 分組，所以公開價格表本來就會是空的。

## 這一版的行為
- 公開價格表為空 → **視為正常**，不報錯、不擋清單
- 改為直接顯示 `/v1/models` 回傳的帳號可用模型（別名會正規化，例如 `deepseek-flash` → `deepseek-v4.1-flash`）
- 提示改寫成：「這個 AIAPI 站點目前沒有公開價格表（分組都是專屬分組），以下為帳號可直接使用的模型。」
- 只有「帳號模型清單本身是空的」才會提示權限問題

## 安裝 / 更新
- 下載：https://fengfeng1021.github.io/aiapi-dsh-plugin/latest.zip
- 已裝過的機器：`bash update-plugin.sh`
