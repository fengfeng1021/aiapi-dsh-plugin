# Aiapi 插件 1.4.1

## 這一版修好「尚未設定更新來源」

DSH 的 profile patch 對同一個 entry 是**整個 config 覆寫**（官方文件：replace one entry's whole config），
所以只要有任何覆寫（例如切換功能開關時寫入 features），bundle patch 裡的 `updateManifestUrl` 就會被蓋掉。

1.4.1 起更新來源寫在**程式內建預設**：

```
https://fengfeng1021.github.io/aiapi-dsh-plugin/index.json
```

- 覆寫 config 不帶 `updateManifestUrl` → 仍用預設，更新照常可用。
- 真的要停用更新檢查 → 明確寫 `updateManifestUrl: "off"`（或 `none` / `disabled`）。

## 其他
- 系統瀏覽器功能已移除（1.4.0）；官方 DSH 的瀏覽器不受影響。
- 模型頁 Aiapi 卡片有「AI API 帳號」列與「清除連接」。

## 安裝 / 更新
- 下載：https://fengfeng1021.github.io/aiapi-dsh-plugin/latest.zip
- 已裝過的機器：`bash update-plugin.sh`
