#!/usr/bin/env bash
set -euo pipefail
here="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
echo "本機安裝："; echo "  $here"
echo "最新版 ZIP："; echo "  https://fengfeng1021.github.io/aiapi-dsh-plugin/latest.zip"
echo "更新這一台："; echo "  bash $here/update-plugin.sh"
