#!/usr/bin/env bash
set -euo pipefail
here="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
echo "本機安裝：$here"
echo "最新版：https://fengfeng1021.github.io/aiapi-dsh-plugin/latest.zip"
echo "更新：bash $here/update-plugin.sh"
