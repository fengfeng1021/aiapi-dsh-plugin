/**
 * AIAPI balance, in two places: a card on the plugin/settings row that shows the account state and owns the
 * "keep it on screen" switch, and a slim bar in the sidebar footer that stays visible while you work.
 * The number always comes from the Host (the Smart Key never reaches the page).
 */
import React, { useEffect, useState } from 'react';
import { PLUGIN_VERSION } from '../version.js';
import { setBalanceFlag } from './balance-flag.js';

/**
 * Same-origin JSON call to the Host balance route.
 * @returns the balance payload (`status: 'ok'`).
 * @throws an Error whose `status` is the HTTP status and `code` the Host's `status` field
 *   (`unauthenticated`: no Smart Key; `invalid-key`: AIAPI rejected it).
 */
export async function readBalance() {
  // 相對 document.baseURI 解析，才會保留 app 的 base path。
  const response = await fetch(new URL('api/aiapi/balance', document.baseURI), {
    credentials: 'same-origin', cache: 'no-store',
  });
  const text = await response.text();
  let body;
  try { body = JSON.parse(text); } catch { body = undefined; }
  if (!response.ok) {
    const failure = new Error(body?.error ?? (response.status === 401 ? '尚未登入 AIAPI' : `回應 ${response.status}${text ? `：${text.slice(0, 120)}` : ''}`));
    failure.status = response.status;
    failure.code = body?.status;
    throw failure;
  }
  return body ?? {};
}

/**
 * POST to one of this bundle's Host routes.
 * @param path - route relative to the app root, e.g. `api/aiapi/disconnect`.
 * @param body - JSON body.
 * @returns the parsed reply.
 * @throws an Error carrying the HTTP status.
 */
async function hostPost(path, body = {}) {
  const response = await fetch(new URL(path, document.baseURI), {
    method: 'POST', credentials: 'same-origin', cache: 'no-store',
    headers: { 'content-type': 'application/json' }, body: JSON.stringify(body),
  });
  const result = await response.json().catch(() => ({}));
  if (!response.ok) {
    const failure = new Error(result.error ?? `回應 ${response.status}`);
    failure.status = response.status;
    throw failure;
  }
  return result;
}

/** Format money the way the platform bills it: two decimals, no currency guessing beyond the payload. */
function money(value, currency) {
  if (typeof value !== 'number' || !Number.isFinite(value)) return '—';
  const symbol = currency === 'CNY' ? '¥' : currency === 'TWD' ? 'NT$' : '$';
  return `${symbol}${value.toFixed(2)}`;
}

/**
 * Colour follows what is left, not a fixed theme: plenty green, getting thin amber, nearly gone red.
 * @param ratio - remaining share between 0 and 1.
 * @returns an `hsl()` colour used by both the bar and its glow.
 */
function toneFor(ratio) {
  const clamped = Math.max(0, Math.min(1, ratio));
  const hue = clamped >= 0.5 ? 145 - (1 - clamped) * 60 : 85 - (0.5 - clamped) * 170;
  return `hsl(${Math.round(hue)} 72% 48%)`;
}

/** Share of the ceiling that is still available; the key's quota wins over a made-up ceiling. */
function remainingRatio(payload) {
  if (payload.quota !== undefined && typeof payload.quota.limit === 'number' && payload.quota.limit > 0) {
    return (payload.quota.remaining ?? 0) / payload.quota.limit;
  }
  const balance = typeof payload.balance === 'number' ? payload.balance : 0;
  return balance / 50;
}

/** The sidebar footer bar: one line, live tone, click to refresh. */
export function BalanceBar() {
  const [payload, setPayload] = useState();
  const [error, setError] = useState('');

  const load = async () => {
    try { setPayload(await readBalance()); setError(''); }
    catch (failure) { setError(failure instanceof Error ? failure.message : '無法取得餘額'); }
  };
  useEffect(() => {
    void load();
    const timer = setInterval(() => { void load(); }, 120000);
    return () => clearInterval(timer);
  }, []);

  if (error === '尚未登入 AIAPI') return <div className="aiapi-bal aiapi-bal-off" title="到「設定 → AIAPI 帳號」登入">AIAPI 未登入</div>;
  if (error !== '') return <div className="aiapi-bal aiapi-bal-off" title={error}>AIAPI 餘額無法讀取</div>;
  if (payload === undefined || payload.status !== 'ok') return <div className="aiapi-bal aiapi-bal-off">AIAPI 讀取中…</div>;

  const ratio = remainingRatio(payload);
  const tone = toneFor(ratio);
  const amount = money(payload.balance, payload.currency);
  return (
    <button type="button" className="aiapi-bal" title={`AIAPI 餘額 ${amount}${payload.group?.name ? `・分組 ${payload.group.name}` : ''}（點擊重新整理）`} onClick={() => { void load(); }}>
      <span className="aiapi-bal-dot" style={{ background: tone, boxShadow: `0 0 8px ${tone}` }} />
      <span className="aiapi-bal-amount">{amount}</span>
      <span className="aiapi-bal-track">
        <span className="aiapi-bal-fill" style={{ width: `${Math.max(4, Math.min(100, ratio * 100))}%`, background: `linear-gradient(90deg, ${tone}, ${tone} 60%, #ffffff55)` }} />
      </span>
    </button>
  );
}

/** The card: account state, balance, and the switch that owns the bar. */
export function BalanceCard({ enabled, onToggle }) {
  const [payload, setPayload] = useState();
  const [error, setError] = useState('');

  const load = async () => {
    try { setPayload(await readBalance()); setError(''); }
    catch (failure) { setError(failure instanceof Error ? failure.message : '無法取得餘額'); }
  };
  useEffect(() => { void load(); }, []);

  const ok = payload?.status === 'ok';
  return (
    <div className="aiapi-balance-card">
      <div className="row">
        <span className="aiapi-account-label">AIAPI 帳號</span>
        <span className={ok ? 'aiapi-account-on' : 'aiapi-account-off'}>{ok ? '已登入' : '未登入或讀取失敗'}</span>
        {ok && payload.group?.name ? <span className="muted">分組 {payload.group.name}</span> : null}
      </div>
      <div className="row" style={{ marginTop: 6 }}>
        <span className="aiapi-balance-figure">{ok ? money(payload.balance, payload.currency) : '—'}</span>
        {ok && payload.quota !== undefined
          ? <span className="muted">定額 {money(payload.quota.remaining, payload.currency)} / {money(payload.quota.limit, payload.currency)}</span>
          : null}
        <button type="button" onClick={() => { void load(); }}>重新整理</button>
      </div>
      <div className="row" style={{ marginTop: 8 }}>
        <label title="在側邊欄左下角常駐顯示一條餘額條">
          <input type="checkbox" checked={enabled} onChange={event => onToggle(event.target.checked)} />
          常駐顯示餘額條
        </label>
      </div>
      {error === '' ? null : <div className="error">{error}</div>}
    </div>
  );
}

/**
 * The 「AIAPI 帳號」 settings page: sign-in state, platform balance, the two switches, and the sign-in itself,
 * so an AIAPI user never has to find the provider card on the Models page first.
 * @param props - `ctx`, the client plugin context.
 * @returns the page element.
 */
export function BalancePage({ ctx }) {
  const [payload, setPayload] = useState();
  const [error, setError] = useState(undefined);
  const [enabled, setEnabled] = useState(false);
  const [reporting, setReporting] = useState(true);
  const [busy, setBusy] = useState(false);
  const [grant, setGrant] = useState();
  const [notice, setNotice] = useState('');

  useEffect(() => {
    void (async () => {
      try {
        const view = await namespaceView(ctx);
        setEnabled(view?.value?.balanceBar === true);
        setReporting(view?.value?.errorReporting !== false);
      }
      catch (failure) { console.warn('[aiapi] 讀取 AIAPI 帳號頁設定失敗:', failure); }
    })();
  }, []);

  const load = async () => {
    setBusy(true);
    try { setPayload(await readBalance()); setError(undefined); }
    catch (failure) { setPayload(undefined); setError(failure); }
    finally { setBusy(false); }
  };
  useEffect(() => { void load(); }, []);

  /** Device-code sign-in: approval happens on aiapi.tw, and the Host stores the Smart Key it returns. */
  const signIn = async () => {
    setBusy(true);
    setNotice('');
    try {
      const started = await hostPost('api/aiapi/device-auth/start');
      setGrant(started);
      window.open(started.verification_uri, '_blank', 'noopener');
      const interval = Math.max(3, Number.isFinite(started.interval) ? started.interval : 5) * 1000;
      const deadline = Date.now() + (Number.isFinite(started.expires_in) ? started.expires_in : 600) * 1000;
      let outcome = 'expired';
      while (Date.now() < deadline) {
        await new Promise(resolve => setTimeout(resolve, interval));
        const state = await hostPost('api/aiapi/device-auth/poll');
        if (state.status === 'authorization_pending') continue;
        outcome = state.status;
        break;
      }
      setNotice(outcome === 'complete'
        ? '已登入 AIAPI。模型已加到「設定 → 模型 → AIAPI」，可以直接選用。'
        : outcome === 'access_denied' ? '你已拒絕這次授權。' : '授權已逾時，請重新登入。');
    } catch (failure) {
      setNotice(failure instanceof Error ? failure.message : '無法開始登入');
    } finally {
      setGrant(undefined);
      setBusy(false);
      void load();
    }
  };

  /** Forget this DSH's Smart Key; the key itself stays on aiapi.tw and signing in again is one click. */
  const signOut = async () => {
    setBusy(true);
    setNotice('');
    try {
      await hostPost('api/aiapi/disconnect');
      setNotice('已清除這台 DSH 的 AIAPI 登入。');
    } catch (failure) {
      setNotice(failure instanceof Error ? failure.message : '無法清除登入');
    } finally {
      setBusy(false);
      void load();
    }
  };

  const ok = payload?.status === 'ok';
  const signedOut = error?.status === 401;
  const hint = ok ? '已連線到 AIAPI 平台'
    : signedOut ? (error.code === 'invalid-key' ? error.message : '尚未登入 AIAPI：按「使用 AIAPI 帳號登入」，在瀏覽器核准後就會自動完成。')
      : error !== undefined ? `讀取失敗：${error.message}`
        : '讀取中…';
  return (
    <div className="aiapi-balance-page">
      <h3 className="aiapi-balance-title">AIAPI 帳號</h3>
      <p className="aiapi-balance-hint">{hint}</p>
      {grant === undefined ? null : (
        <p className="aiapi-balance-hint" role="status">
          已開啟授權頁：登入 AIAPI 後輸入代碼 <b>{grant.user_code}</b>，再按「允許這次登入」。
          {' '}<a href={grant.verification_uri} target="_blank" rel="noreferrer">重新開啟授權頁</a>
        </p>
      )}
      <div className="aiapi-balance-figures">
        <div className="aiapi-balance-figure-block">
          <span className="aiapi-balance-figure-label">平台餘額</span>
          <span className="aiapi-balance-figure">{ok ? money(payload.balance, payload.currency) : '—'}</span>
        </div>
        <div className="aiapi-balance-figure-block">
          <span className="aiapi-balance-figure-label">凍結</span>
          <span className="aiapi-balance-figure">{ok ? money(payload.frozen_balance, payload.currency) : '—'}</span>
        </div>
        {ok && payload.quota !== undefined ? (
          <div className="aiapi-balance-figure-block">
            <span className="aiapi-balance-figure-label">這支 Key 定額</span>
            <span className="aiapi-balance-figure">{money(payload.quota.remaining, payload.currency)}<small> / {money(payload.quota.limit, payload.currency)}</small></span>
          </div>
        ) : null}
        {ok && payload.group?.name ? (
          <div className="aiapi-balance-figure-block">
            <span className="aiapi-balance-figure-label">分組</span>
            <span className="aiapi-balance-figure">{payload.group.name}{payload.group.rate_multiplier !== undefined ? <small> ×{payload.group.rate_multiplier}</small> : null}</span>
          </div>
        ) : null}
      </div>
      <p className="aiapi-balance-version">
        插件版本 <code>{PLUGIN_VERSION}</code>
      </p>
      <div className="aiapi-balance-actions">
        {signedOut
          ? <button type="button" onClick={() => { void signIn(); }} disabled={busy}>{grant !== undefined ? '等待授權中…' : busy ? '處理中…' : '使用 AIAPI 帳號登入'}</button>
          : <button type="button" onClick={() => { void load(); }} disabled={busy}>{busy ? '讀取中…' : '重新整理'}</button>}
        {ok ? <button type="button" onClick={() => { void signOut(); }} disabled={busy}>登出</button> : null}
        <label className="aiapi-balance-toggle" title="介面出錯時自動回傳給 AIAPI（只送回錯誤訊息與版本，不含對話內容）">
          <input type="checkbox" checked={reporting} onChange={event => { void persistErrorReporting(ctx, event.target.checked, setReporting); }} />
          回傳介面錯誤
        </label>
        <label className="aiapi-balance-toggle" title="在側邊欄左下角常駐顯示一條餘額條">
          <input type="checkbox" checked={enabled} onChange={event => { void persistBalanceBar(ctx, event.target.checked, setEnabled); }} />
          常駐顯示餘額條
        </label>
      </div>
      {notice === '' ? null : <p className="aiapi-balance-hint" role="status">{notice}</p>}
    </div>
  );
}

/**
 * 取得本插件的設定命名空間視圖（含 revision）。
 * @param ctx - client plugin context.
 * @returns 命名空間視圖，找不到時為 undefined。
 */
async function namespaceView(ctx) {
  const response = await ctx.remote.settings.describe();
  const value = response?.value ?? response;
  const holders = value?.namespaces ?? [];
  // Never fall back to another entry: a write meant for this plugin must not land in someone else's config.
  return holders.find(row => row?.ns === 'aiapi-customizations');
}

/**
 * 寫回「常駐顯示」開關；失敗就把畫面還原，避免顯示與實際不一致。
 * @param ctx - client plugin context.
 * @param next - 使用者要的狀態。
 * @param setEnabled - 該頁面的 setter。
 */
async function persistBalanceBar(ctx, next, setEnabled) {
  setEnabled(next);
  setBalanceFlag(next);
  try {
    const view = await namespaceView(ctx);
    if (view === undefined) throw new Error('找不到設定命名空間');
    const response = await ctx.remote.settings.mutate(view.ns, [{ op: 'set', path: ['balanceBar'], value: next }], view.revision);
    if (response?.ok === false) throw new Error(response.error?.message ?? '寫入被拒絕');
  } catch (failure) {
    console.warn('[aiapi] 常駐餘額條設定寫入失敗:', failure);
    setEnabled(!next);
    setBalanceFlag(!next);
  }
}

/**
 * 寫回「回傳介面錯誤」開關；失敗時把畫面還原。
 * @param ctx - client plugin context.
 * @param next - 是否允許回報。
 * @param setReporting - 該頁面的 setter。
 */
async function persistErrorReporting(ctx, next, setReporting) {
  setReporting(next);
  globalThis.__aiapiReportingEnabled = next;
  try {
    const view = await namespaceView(ctx);
    if (view === undefined) throw new Error('找不到設定命名空間');
    const response = await ctx.remote.settings.mutate(view.ns, [{ op: 'set', path: ['errorReporting'], value: next }], view.revision);
    if (response?.ok === false) throw new Error(response.error?.message ?? '寫入被拒絕');
  } catch (failure) {
    console.warn('[aiapi] 回報開關寫入失敗:', failure);
    setReporting(!next);
    globalThis.__aiapiReportingEnabled = !next;
  }
}
