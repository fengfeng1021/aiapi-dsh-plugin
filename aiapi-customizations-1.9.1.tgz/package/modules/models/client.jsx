import React, { useEffect, useState } from 'react';
import { requestModelIdForPublicModel } from './discovery.mjs';
import css from './style.txt';

export const name = 'aiapi-models';
export const inject = ['slots', 'remote', 'remote.settings'];
const ns = 'llm-pi-ai';
const unwrap = response => { if (!response.ok) throw new Error(response.error.message); return response.value; };

/** Extend the official provider card; the official Models section remains its owner. */
export function apply(ctx) {
  ctx.effect(() => {
    const style = document.createElement('style');
    style.textContent = css;
    document.head.append(style);
    return () => style.remove();
  });
  ctx.slots.inject('settings.models.provider-card', () => ctx.slots.register({
    name: 'settings.models.provider-card',
    key: ns,
    inject: () => ({ remote: ctx.remote }),
  }, ProviderCard));
  ctx.effect(() => installDesktopOAuthListener());
}

function ProviderCard({ remote, provider, configured, keyConfigured }) {
  // The browser half runs both inside the Aiapi Agent desktop carrier and in a plain DSH page; only the
  // carrier can receive the `aiapi-agent://` callback, so plain DSH is offered an API key instead.
  const desktop = typeof window !== 'undefined' && Boolean(window.__TAURI_INTERNALS__);
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState('');
  const [catalog, setCatalog] = useState();
  const [selected, setSelected] = useState([]);
  const [device, setDevice] = useState();
  const [linked, setLinked] = useState(false);
  const [disconnected, setDisconnected] = useState(false);
  useEffect(() => {
    const onOAuthResult = event => {
      if (event.detail?.status === 'complete') setMessage('AIAPI 帳號已連結，Smart Key 已安全保存到本機。');
      if (event.detail?.status === 'access_denied') setMessage('你已拒絕此次授權。');
      if (event.detail?.status === 'expired') setMessage('登入要求已逾時，請重新開始。');
      if (event.detail?.status === 'error') setMessage('無法完成桌面登入，請重新開始。');
    };
    window.addEventListener('aiapi-desktop-oauth-result', onOAuthResult);
    return () => window.removeEventListener('aiapi-desktop-oauth-result', onOAuthResult);
  }, []);

  if (provider.provider !== 'aiapi') return null;
  const connected = (keyConfigured || linked) && !disconnected;

  /** Drop the stored Smart Key and pending grants for this profile. */
  const disconnect = async () => {
    setBusy(true);
    setMessage('');
    try {
      const result = await hostRequest('/api/aiapi/disconnect', {});
      if (result.status !== 'disconnected') throw new Error(result.error ?? '無法清除連接');
      setDisconnected(true);
      setLinked(false);
      setDevice(undefined);
      setMessage('已清除這台 DSH 的 AIAPI 連接。');
    } catch (error) {
      setMessage(error instanceof Error ? error.message : '無法清除連接');
    } finally {
      setBusy(false);
    }
  };

  const discover = async () => {
    setBusy(true);
    setMessage('');
    try {
      const described = unwrap(await remote.settings.describe());
      const section = described.namespaces.find(row => row.ns === ns);
      const profile = section?.value?.providers?.aiapi;
      if (!section || !profile) throw new Error('請先在官方模型頁新增並儲存 Aiapi 供應商。');
      if (!keyConfigured) throw new Error('請先在官方供應商卡片設定 Aiapi API 金鑰。');

      const response = await fetch(new URL('api/aiapi/models', document.baseURI), {
        method: 'POST',
        credentials: 'same-origin',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ provider: 'aiapi', enrich: true }),
      });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error ?? '查詢失敗');
      setSelected(Array.isArray(profile.models) ? profile.models : []);
      setCatalog(result.models);
      setMessage(result.warning ?? `取得 ${result.models.length} 個可用模型，請選擇要加入的項目。`);
    } catch (error) {
      setMessage(error instanceof Error ? error.message : '模型查詢失敗。');
    } finally {
      setBusy(false);
    }
  };

  const saveModels = async models => {
    setCatalog(undefined);
    setBusy(true);
    setMessage('');
    try {
      const described = unwrap(await remote.settings.describe());
      const section = described.namespaces.find(row => row.ns === ns);
      if (!section?.value?.providers?.aiapi) throw new Error('Aiapi 設定已變更，請重新載入後再試。');
      unwrap(await remote.settings.mutate(ns, [{
        op: 'set',
        path: ['providers', 'aiapi', 'models'],
        value: models,
      }], section.revision));
      setSelected(models);
      setMessage(`已更新 ${models.length} 個模型。`);
    } catch (error) {
      setMessage(error instanceof Error ? error.message : '模型設定儲存失敗。');
    } finally {
      setBusy(false);
    }
  };

  /**
   * Browser-only sign-in: the device grant takes the account login to aiapi.tw, and this page polls the
   * Host until the Smart Key is stored. No key is typed or copied by the user.
   */
  const startDeviceAuthorization = async () => {
    setBusy(true);
    setMessage('');
    setDevice(undefined);
    try {
      const grant = await hostRequest('/api/aiapi/device-auth/start', {});
      setDevice(grant);
      window.open(grant.verification_uri, '_blank', 'noopener');
      setMessage('已開啟授權頁；請登入 AIAPI 帳號並核准這次授權。');
      const interval = Math.max(3, Number.isFinite(grant.interval) ? grant.interval : 5) * 1000;
      const deadline = Date.now() + (Number.isFinite(grant.expires_in) ? grant.expires_in : 600) * 1000;
      while (Date.now() < deadline) {
        await new Promise(resolve => setTimeout(resolve, interval));
        const state = await hostRequest('/api/aiapi/device-auth/poll', {});
        if (state.status === 'authorization_pending') continue;
        if (state.status === 'complete') {
          setLinked(true);
          setMessage('AIAPI 帳號已連結，Smart Key 已存進這個 DSH。');
          return;
        }
        if (state.status === 'access_denied') { setMessage('你已拒絕此次授權。'); return; }
        if (state.status === 'expired' || state.status === 'none') { setMessage('授權已逾時，請重新開始。'); return; }
      }
      setMessage('授權已逾時，請重新開始。');
    } catch (error) {
      setMessage(error instanceof Error ? error.message : '無法開始登入。');
    } finally {
      setBusy(false);
    }
  };

  const startAuthorization = async () => {
    setBusy(true);
    setMessage('正在安全地連接 AIAPI 帳號…');
    try {
      if (!window.__TAURI_INTERNALS__) throw new Error('這個 DSH 沒有桌面授權回呼，請改用 API Key 登入。');
      const verifier = randomOAuthToken();
      const state = randomOAuthToken();
      const challenge = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(verifier));
      const codeChallenge = encodeBase64Url(new Uint8Array(challenge));
      const channel = window.__DSH_DESKTOP_RELEASE_CHANNEL__
        ?? new URL(window.location.href).searchParams.get('dsh-release-channel');
      if (!['stable', 'preview'].includes(channel)) throw new Error('無法確認桌面版本通道，請重新啟動應用程式。');
      const redirectUri = `aiapi-agent${channel === 'preview' ? '-preview' : ''}://oauth/callback`;
      const grant = await hostRequest('/api/aiapi/desktop-auth/oauth/start', {
        code_verifier: verifier,
        code_challenge: codeChallenge,
        state,
        redirect_uri: redirectUri,
      });
      const authorizationUrl = new URL(grant.authorization_url);
      if (authorizationUrl.origin !== 'https://aiapi.tw' || authorizationUrl.pathname !== '/desktop/authorize' || !authorizationUrl.searchParams.has('request_id')) throw new Error('AIAPI 授權網址無效');
      setMessage('已開啟瀏覽器，登入並核准後會自動返回此應用程式。');
      window.location.assign(authorizationUrl.href);
    } catch (error) {
      setMessage(error instanceof Error ? error.message : '無法開始登入。');
    } finally {
      setBusy(false);
    }
  };

  return <div className="aiapi-models aiapi-models-slot" data-aiapi-models-slot>
    <div className="aiapi-platform-line">
      <span>平台</span>
      <a href="https://aiapi.tw/" target="_blank" rel="noreferrer">https://aiapi.tw/</a>
    </div>
    {!configured ? <p>請先在官方模型頁新增並儲存 Aiapi 供應商。</p> : null}
    <div className="aiapi-account">
      <span className="aiapi-account-label">AI API 帳號</span>
      <span className={connected ? 'aiapi-account-on' : 'aiapi-account-off'}>{connected ? '已登入' : '未登入'}</span>
      {connected
        ? <button type="button" className="aiapi-account-clear" disabled={busy} onClick={() => { void disconnect(); }}>{busy ? '處理中…' : '清除連接'}</button>
        : null}
    </div>
    {connected
      ? null
      : <div className="aiapi-auth">
          {/* Device code works in every carrier: approval happens on the page, so no aiapi-agent:// handoff is needed. */}
          <p>使用 AIAPI 帳號登入：會在瀏覽器開啟授權頁，核准後 API Key 會自動存進這個 DSH，不需要自己建立。</p>
          {device
            ? <p role="status">請在授權頁登入，輸入代碼 <b>{device.user_code}</b> 後按「允許這次登入」。<a className="aiapi-link" href={device.verification_uri} target="_blank" rel="noreferrer">重新開啟授權頁</a></p>
            : null}
          <button type="button" disabled={!configured || busy} onClick={() => { void startDeviceAuthorization(); }}>{busy ? '處理中…' : '使用 AIAPI 帳號登入'}</button>
          {desktop
            ? <p className="aiapi-auth-alt">授權頁打不開，或想用桌面回呼？<button type="button" disabled={!configured || busy} onClick={() => { void startAuthorization(); }}>改用桌面回呼登入</button></p>
            : null}
        </div>}
    {connected ? <button type="button" disabled={!configured || busy} onClick={() => { void discover(); }}>{busy ? '處理中…' : '獲取可用模型'}</button> : null}
    {message ? <p role="status">{message}</p> : null}
    {catalog ? <Catalog models={catalog} selected={selected} close={() => setCatalog(undefined)} apply={saveModels} /> : null}
  </div>;
}

function randomOAuthToken() {
  const bytes = new Uint8Array(32);
  crypto.getRandomValues(bytes);
  return encodeBase64Url(bytes);
}

function encodeBase64Url(bytes) {
  let binary = '';
  for (const byte of bytes) binary += String.fromCharCode(byte);
  return btoa(binary).replaceAll('+', '-').replaceAll('/', '_').replace(/=+$/, '');
}

function installDesktopOAuthListener() {
  if (!window.__TAURI_INTERNALS__) return () => {};
  let disposed = false;
  let processing = false;
  let retryTimer;
  let activeCallback;
  const completedCallbacks = new Set();
  const attempt = async callback => {
    if (disposed || processing || typeof callback !== 'string') return;
    processing = true;
    try {
      const result = await hostRequest('/api/aiapi/desktop-auth/oauth/callback', { callback });
      if (result.status === 'authorization_pending') {
        retryTimer = window.setTimeout(() => { void attempt(callback); }, 2000);
        return;
      }
      completedCallbacks.add(callback);
      activeCallback = undefined;
      // 授權完成就立刻把 AIAPI 註冊成模型供應商，使用者不必再手動加一次。
      if (result.status === 'granted' || result.status === 'complete') {
        void hostRequest('/api/aiapi/provider', {}).catch(error => console.warn('[aiapi] 供應商註冊失敗:', error));
      }
      window.dispatchEvent(new CustomEvent('aiapi-desktop-oauth-result', { detail: { status: result.status } }));
      finishDesktopCallback(callback);
    } catch (error) {
      if (error?.status >= 400 && error.status < 500) {
        completedCallbacks.add(callback);
        activeCallback = undefined;
        window.dispatchEvent(new CustomEvent('aiapi-desktop-oauth-result', { detail: { status: 'error' } }));
        finishDesktopCallback(callback);
      } else {
        retryTimer = window.setTimeout(() => { void attempt(callback); }, 5000);
      }
    } finally {
      processing = false;
    }
  };
  const receive = callback => {
    if (disposed || typeof callback !== 'string' || completedCallbacks.has(callback)) return;
    if (activeCallback && activeCallback !== callback) return;
    activeCallback = callback;
    void attempt(callback);
  };
  const onCallback = event => receive(event.detail);
  window.addEventListener('dsh-desktop-oauth-callback', onCallback);
  for (const callback of window.__DSH_DESKTOP_OAUTH_CALLBACKS__ ?? []) receive(callback);
  void hostRequest('/api/aiapi/desktop-auth/oauth/resume', {}).then(result => {
    if (result.status === 'resume' && typeof result.callback === 'string') receive(result.callback);
    if (result.status === 'expired') window.dispatchEvent(new CustomEvent('aiapi-desktop-oauth-result', { detail: { status: 'expired' } }));
  }).catch(() => {});
  return () => {
    disposed = true;
    window.removeEventListener('dsh-desktop-oauth-callback', onCallback);
    window.clearTimeout(retryTimer);
  };
}

function finishDesktopCallback(callback) {
  let state;
  try { state = new URL(callback).searchParams.get('state'); } catch { return; }
  if (!state) return;
  const callbacks = window.__DSH_DESKTOP_OAUTH_CALLBACKS__;
  if (Array.isArray(callbacks)) {
    const index = callbacks.indexOf(callback);
    if (index >= 0) callbacks.splice(index, 1);
  }
  window.location.assign(`dsh-action://oauth-complete?state=${encodeURIComponent(state)}`);
}

async function hostRequest(path, body) {
  const response = await fetch(new URL(path.replace(/^\//, ''), document.baseURI), {
    method: 'POST',
    credentials: 'same-origin',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(body),
    cache: 'no-store',
  });
  const result = await response.json();
  if (!response.ok) {
    const error = new Error(result.error ?? 'AIAPI 授權失敗，請稍後再試。');
    error.status = response.status;
    throw error;
  }
  return result;
}

function Catalog({ models, selected, close, apply }) {
  const availableById = new Map(models.map(model => [model.id, model]));
  const resolvedSelected = selected.map(model => {
    const id = requestModelIdForPublicModel(model.id);
    const resolved = { ...model, id, ...availableById.get(id) };
    if (model.input?.length) resolved.input = [...model.input];
    delete resolved.requestModelId;
    return resolved;
  });
  const existingIds = new Set(resolvedSelected.map(model => model.id));
  const availableIds = new Set(models.map(model => model.id));
  const [query, setQuery] = useState('');
  const [tab, setTab] = useState('all');
  const [collapsed, setCollapsed] = useState(new Set());
  const [checked, setChecked] = useState(() => selected.length
    ? new Set(existingIds)
    : new Set(models.map(model => model.id)));

  const newModels = models.filter(model => !existingIds.has(model.id));
  const selectedModels = models.filter(model => checked.has(model.id));
  const removedModels = resolvedSelected.filter(model => !availableIds.has(model.id));
  const allSelected = models.length > 0 && models.every(model => checked.has(model.id));
  const candidates = tab === 'new' ? newModels
    : tab === 'selected' ? selectedModels
      : tab === 'removed' ? removedModels
        : models;
  const normalizedQuery = query.trim().toLowerCase();
  const rows = candidates.filter(model => `${model.id} ${model.name ?? ''}`.toLowerCase().includes(normalizedQuery));
  const groups = new Map();
  for (const model of rows) {
    const brand = categorizeModelId(model.id, model.name);
    const group = groups.get(brand) ?? [];
    group.push(model);
    groups.set(brand, group);
  }
  const groupNames = [...groups.keys()].sort((a, b) => {
    const indexA = MODEL_BRAND_ORDER.indexOf(a);
    const indexB = MODEL_BRAND_ORDER.indexOf(b);
    if (indexA !== -1 && indexB !== -1) return indexA - indexB;
    if (indexA !== -1) return -1;
    if (indexB !== -1) return 1;
    return a.localeCompare(b);
  });

  const toggle = id => setChecked(previous => {
    const next = new Set(previous);
    if (next.has(id)) next.delete(id);
    else next.add(id);
    return next;
  });
  const toggleAll = () => setChecked(previous => {
    const next = new Set(previous);
    if (allSelected) for (const model of models) next.delete(model.id);
    else for (const model of models) next.add(model.id);
    return next;
  });
  const toggleGroup = (brand, event) => {
    event.stopPropagation();
    const group = groups.get(brand) ?? [];
    const allInGroupSelected = group.every(model => checked.has(model.id));
    setChecked(previous => {
      const next = new Set(previous);
      for (const model of group) {
        if (allInGroupSelected) next.delete(model.id);
        else next.add(model.id);
      }
      return next;
    });
  };
  const save = () => {
    const existingById = new Map(resolvedSelected.map(model => [model.id, model]));
    const result = [];
    for (const model of models) {
      if (!checked.has(model.id)) continue;
      const existing = existingById.get(model.id);
      const name = cleanModelDisplayName(model.name);
      const candidate = { ...model };
      if (existing?.input?.length) candidate.input = [...existing.input];
      delete candidate.reasoningSource;
      if (existing) {
        const merged = { ...existing, ...candidate, ...(name ? { name } : {}) };
        if (candidate.requestModelId === undefined) delete merged.requestModelId;
        result.push(merged);
      } else {
        result.push({ ...candidate, ...(name ? { name } : {}) });
      }
      existingById.delete(model.id);
    }
    for (const [id, model] of existingById) if (checked.has(id)) result.push({ ...model });
    apply(result);
    close();
  };

  return <div className="aiapi-modal" role="dialog" aria-modal="true" aria-label="選擇要加入的模型" onClick={close}>
    <div className="aiapi-modal-content" onClick={event => event.stopPropagation()}>
      <div className="aiapi-modal-header">
        <div className="aiapi-modal-title-row">
          <h3 className="aiapi-modal-title">選擇要加入的模型</h3>
          <div className="aiapi-modal-header-actions">
            <button type="button" className="aiapi-select-all" onClick={toggleAll}>{allSelected ? '取消全選' : '全選'}</button>
            <button type="button" className="aiapi-close" aria-label="關閉" onClick={close}>
              <svg width="18" height="18" viewBox="0 0 16 16" fill="none" aria-hidden>
                <path d="M4 4L12 12M12 4L4 12" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" />
              </svg>
            </button>
          </div>
        </div>
        <div className="aiapi-channel-row"><span>平台：</span><span className="aiapi-channel-name">AIAPI</span></div>
        <label className="aiapi-search-box">
          <svg className="aiapi-search-icon" width="14" height="14" viewBox="0 0 16 16" fill="none" aria-hidden>
            <path d="M7 12C9.76142 12 12 9.76142 12 7C12 4.23858 9.76142 2 7 2C4.23858 2 2 4.23858 2 7C2 9.76142 4.23858 12 7 12Z" stroke="currentColor" strokeWidth="1.5" />
            <path d="M11 11L14.5 14.5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
          </svg>
          <input className="aiapi-search-input" type="search" aria-label="搜尋模型" placeholder="搜尋模型名稱或 ID" value={query} onChange={event => setQuery(event.target.value)} />
        </label>
        <div className="aiapi-tabs" aria-label="模型篩選">
          {[
            ['all', `全部模型（${models.length}）`],
            ['new', `新模型（${newModels.length}）`],
            ['selected', `已選模型（${selectedModels.length}）`],
            ...(removedModels.length ? [['removed', `已移除（${removedModels.length}）`]] : []),
          ].map(([id, label]) => <button type="button" className={tab === id ? 'aiapi-tab aiapi-tab-active' : 'aiapi-tab'} key={id} aria-pressed={tab === id} onClick={() => setTab(id)}>{label}</button>)}
        </div>
      </div>
      <div className="aiapi-modal-body">
        {groupNames.length === 0
          ? <div className="aiapi-empty">{query ? '沒有符合搜尋條件的模型' : '目前沒有可顯示的模型'}</div>
          : groupNames.map(brand => {
            const group = groups.get(brand);
            const isExpanded = !collapsed.has(brand);
            const groupSelected = group.filter(model => checked.has(model.id)).length;
            const allInGroupSelected = groupSelected === group.length;
            return <section className="aiapi-group" key={brand}>
              <div className="aiapi-group-header">
                <button type="button" className="aiapi-group-toggle" aria-expanded={isExpanded} onClick={() => setCollapsed(previous => {
                  const next = new Set(previous);
                  if (next.has(brand)) next.delete(brand);
                  else next.add(brand);
                  return next;
                })}>
                  <span className={isExpanded ? 'aiapi-chevron' : 'aiapi-chevron aiapi-chevron-collapsed'}>
                    <svg width="14" height="14" viewBox="0 0 16 16" fill="none" aria-hidden><path d="M4 6L8 10L12 6" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" /></svg>
                  </span>
                  <span className="aiapi-group-title">{brand}（{group.length}）</span>
                </button>
                <div className="aiapi-group-actions">
                  <span className="aiapi-group-status">已選 {groupSelected} / {group.length}</span>
                  <button type="button" className="aiapi-group-check" aria-label={`${allInGroupSelected ? '取消全選' : '全選'}${brand}`} aria-pressed={allInGroupSelected} onClick={event => toggleGroup(brand, event)}>
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" aria-hidden>
                      <circle cx="12" cy="12" r="9" stroke={allInGroupSelected ? '#1677ff' : '#d2d2d7'} strokeWidth="1.8" fill={allInGroupSelected ? '#1677ff' : 'none'} />
                      {allInGroupSelected ? <path d="M8 12L11 15L16 9" stroke="#ffffff" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" /> : null}
                    </svg>
                  </button>
                </div>
              </div>
              {isExpanded ? <div className="aiapi-group-content">{group.map(model => {
                const name = cleanModelDisplayName(model.name);
                const isChecked = checked.has(model.id);
                return <label className="aiapi-model-item" key={model.id} title={name && name !== model.id ? `${name} (${model.id})` : model.id}>
                  <input type="checkbox" checked={isChecked} onChange={() => toggle(model.id)} />
                  <span className={isChecked ? 'aiapi-check-circle aiapi-check-active' : 'aiapi-check-circle'}>
                    {isChecked ? <svg width="12" height="12" viewBox="0 0 16 16" fill="none" aria-hidden><path d="M3.5 8.5L6.5 11.5L12.5 4.5" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" /></svg> : null}
                  </span>
                  <span className="aiapi-model-copy">
                    <span className="aiapi-model-id">{name && name !== model.id ? <><span className="aiapi-model-name">{name}</span><span className="aiapi-model-sub-id">（{model.id}）</span></> : model.id}</span>
                  </span>
                </label>;
              })}</div> : null}
            </section>;
          })}
      </div>
      <div className="aiapi-modal-footer">
        <div className="aiapi-selection-summary">已選 {checked.size} 個模型</div>
        <div className="aiapi-footer-actions">
          <button type="button" className="aiapi-cancel" onClick={close}>取消</button>
          <button type="button" className="aiapi-save" onClick={save}>套用所選</button>
        </div>
      </div>
    </div>
  </div>;
}

const MODEL_BRAND_ORDER = [
  'DeepSeek', 'GLM（智譜）', 'Kimi（月之暗面）', 'MiniMax', 'MiMo（小米）',
  'Hunyuan（騰訊混元）', 'Muse（Meta）', 'Qwen（阿里通義）', 'OpenAI',
  'Anthropic', 'Google（Gemini）', 'xAI（Grok）', 'Doubao（豆包）',
  'LongCat（美團）', 'Mistral', 'Other',
];

function cleanModelDisplayName(name) {
  if (typeof name !== 'string' || name.trim().length === 0) return undefined;
  return name.replace(/^(?:(?:[a-zA-Z0-9\s._-]+):\s+)/, '').trim() || name;
}

function categorizeModelId(id, name) {
  const combined = `${id} ${name ?? ''}`.toLowerCase();
  if (combined.includes('deepseek')) return 'DeepSeek';
  if (['glm', 'chatglm', 'zhipu', 'z.ai'].some(value => combined.includes(value))) return 'GLM（智譜）';
  if (['kimi', 'moonshot'].some(value => combined.includes(value))) return 'Kimi（月之暗面）';
  if (['hunyuan', 'hy4', 'hy3', 'tencent'].some(value => combined.includes(value))) return 'Hunyuan（騰訊混元）';
  if (['minimax', 'abab'].some(value => combined.includes(value))) return 'MiniMax';
  if (['mimo', 'xiaomi'].some(value => combined.includes(value))) return 'MiMo（小米）';
  if (combined.includes('muse')) return 'Muse（Meta）';
  if (['meta', 'llama'].some(value => combined.includes(value))) return 'Meta';
  if (['qwen', 'qwq', 'tongyi', 'alibaba'].some(value => combined.includes(value))) return 'Qwen（阿里通義）';
  if (['claude', 'anthropic'].some(value => combined.includes(value))) return 'Anthropic';
  if (['gpt', 'o1', 'o3', 'o4', 'o5', 'openai', 'chatgpt'].some(value => combined.includes(value))) return 'OpenAI';
  if (['gemini', 'gemma', 'google'].some(value => combined.includes(value))) return 'Google（Gemini）';
  if (['grok', 'xai', 'x-ai'].some(value => combined.includes(value))) return 'xAI（Grok）';
  if (['doubao', 'seedance', 'bytedance', 'volcengine'].some(value => combined.includes(value))) return 'Doubao（豆包）';
  if (['longcat', 'meituan'].some(value => combined.includes(value))) return 'LongCat（美團）';
  if (['mistral', 'codestral', 'pixtral', 'ministral'].some(value => combined.includes(value))) return 'Mistral';
  if (id.includes('/')) return id.split('/')[0].replace(/^./, character => character.toUpperCase());
  return 'Other';
}
