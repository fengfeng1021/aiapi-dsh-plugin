/**
 * Aiapi palette: a near-black base with soft greys, purple headings and orange links, after opencode's v2
 * tokens (MIT, https://github.com/anomalyco/opencode), with a matching light set.
 *
 * The palette is one token layer on DSH's theme service (`overrideTokens`): every value names its light and dark
 * form, the user's light/dark/system choice keeps working, and switching the feature off removes exactly this
 * layer. On/off is the 「Aiapi 配色」 feature switch itself (Plugins page or Settings → General); there is no second
 * switch to disagree with it.
 */

import { installStyle } from '../ui/kit.jsx';
import { colorizeColourCodes } from './swatches.js';

/** Layer identity on the theme service. */
const SOURCE = '@aiapi/dsh-customizations:palette';

/**
 * The answer's own structure colours: opencode's `theme.markdown.*` tokens, value for value.
 *
 * DSH gives markdown only background tokens (`markdown-code-block`, `inline-code`, `tag`, `citation`); headings,
 * strong, emphasis, inline code, quotes and list markers all inherit one text colour, so a long answer reads as a
 * single grey mass. opencode's CLI colours each of them — heading accent, strong orange, emphasis yellow, inline
 * code green, quote yellow, list bullets step-9, ordered markers cyan — and that is the look this palette is for.
 *
 * The class prefix is DSH's CSS module (`_markdown_1ypvv_5`, from the web bundle's own class table); `body` in front
 * keeps these rules above the module's, and the `.compact` variants used by tool cards keep inheriting so they stay
 * plain. The dark half keys off `body[data-ds-dark-theme]`, the same hook DSH's own shiki stylesheet uses.
 */

const MARKDOWN_CSS = `
/* opencode 的 markdown 色票（theme.markdown.*），淺色一套 */
body [class*="_markdown"] :is(h1,h2,h3){color:#d68c27}
body [class*="_markdown"] :is(h4,h5,h6){color:#8a8a8a}
body [class*="_markdown"] strong{color:#d68c27}
body [class*="_markdown"] em{color:#b0851f}
body [class*="_markdown"] a{color:#3b7dd8}
body [class*="_markdown"] :not(pre)>code{color:#3d9a57}
body [class*="_markdown"] blockquote{color:#b0851f;border-left-color:#d4d4d4}
body [class*="_markdown"] ul>li::marker{color:#3b7dd8}
body [class*="_markdown"] ol>li::marker{color:#318795}
body [class*="_markdown"] th{color:#8a8a8a}
/* 深色同一組 token 的另一套值 */
body[data-ds-dark-theme] [class*="_markdown"] :is(h1,h2,h3){color:#9d7cd8}
body[data-ds-dark-theme] [class*="_markdown"] :is(h4,h5,h6){color:#808080}
body[data-ds-dark-theme] [class*="_markdown"] strong{color:#f5a742}
body[data-ds-dark-theme] [class*="_markdown"] em{color:#e5c07b}
body[data-ds-dark-theme] [class*="_markdown"] a{color:#fab283}
body[data-ds-dark-theme] [class*="_markdown"] :not(pre)>code{color:#7fd88f}
body[data-ds-dark-theme] [class*="_markdown"] blockquote{color:#e5c07b;border-left-color:#484848}
body[data-ds-dark-theme] [class*="_markdown"] ul>li::marker{color:#fab283}
body[data-ds-dark-theme] [class*="_markdown"] ol>li::marker{color:#56b6c2}
body[data-ds-dark-theme] [class*="_markdown"] th{color:#a0a0a0}
`;

/**
 * Syntax colours inside code blocks.
 *
 * DSH renders code with shiki's `css-variables` theme, so every token colour is a CSS variable. Its defaults are
 * five unrelated saturated hues (keyword #d6336c, function #6741d9, constant #1c7ed6, string #2f9e44,
 * parameter #e8590c), which is what makes a code block look like a rainbow next to the muted answer. These are
 * opencode's own syntax tokens — comment / keyword / function / variable / string / number / type / operator — the
 * same family the palette is built from, so code, headings and links stay in one key.
 */
const SHIKI_CSS = `
html:root{--shiki-token-constant:#d68c27;--shiki-token-string:#3d9a57;--shiki-token-comment:#8a8a8a;--shiki-token-keyword:#d68c27;--shiki-token-parameter:#d1383d;--shiki-token-function:#3b7dd8;--shiki-token-string-expression:#b0851f;--shiki-token-punctuation:#4b4b4b;--shiki-token-link:#318795}
html body[data-ds-dark-theme]{--shiki-token-constant:#f5a742;--shiki-token-string:#7fd88f;--shiki-token-comment:#808080;--shiki-token-keyword:#9d7cd8;--shiki-token-parameter:#e06c75;--shiki-token-function:#fab283;--shiki-token-string-expression:#e5c07b;--shiki-token-punctuation:#c8c8c8;--shiki-token-link:#56b6c2}
`;

/** Token → { light, dark } pairs; names are the CSS variables DSH's components read. */
export const PALETTE = Object.freeze({
  '--dsw-alias-bg-base': { light: '#ffffff', dark: '#1a1a1a' },
  '--dsw-alias-bg-layer-1': { light: '#ffffff', dark: '#1a1a1a' },
  '--dsw-alias-bg-layer-2': { light: '#f6f6f6', dark: '#232323' },
  '--dsw-alias-bg-layer-3': { light: '#ffffff', dark: '#2c2c2c' },
  '--dsw-alias-bg-module-platform': { light: '#f1f1f1', dark: '#232323' },
  '--dsw-alias-bg-multi-select': { light: '#f1f1f1', dark: '#232323' },
  '--dsw-alias-bg-overlay': { light: '#f6f6f6', dark: '#2c2c2c' },
  '--dsw-alias-bg-skeleton': { light: 'rgba(0, 0, 0, 0.05)', dark: 'rgba(255, 255, 255, 0.06)' },
  '--dsw-alias-border-l1': { light: 'rgba(0, 0, 0, 0.06)', dark: 'rgba(255, 255, 255, 0.06)' },
  '--dsw-alias-border-l2': { light: '#b8b8b8', dark: '#2c2c2c' },
  '--dsw-alias-border-l2-darkmode-thin': { light: 'rgba(0, 0, 0, 0.12)', dark: 'rgba(255, 255, 255, 0.08)' },
  '--dsw-alias-border-l3': { light: '#b8b8b8', dark: '#484848' },
  '--dsw-alias-border-l4': { light: '#9a9a9a', dark: '#606060' },
  '--dsw-alias-label-primary': { light: '#161616', dark: '#e6e6e6' },
  '--dsw-alias-label-secondary': { light: '#4b4b4b', dark: '#c2c2c2' },
  '--dsw-alias-label-tertiary': { light: '#6b6b6b', dark: '#9a9a9a' },
  '--dsw-alias-label-caption': { light: '#808080', dark: '#808080' },
  '--dsw-alias-label-dimmed': { light: '#d0d0d0', dark: '#4c4c4c' },
  '--dsw-alias-label-primary-inverted': { light: '#ffffff', dark: '#1a1a1a' },
  '--dsw-alias-label-primary-foreground': { light: '#ffffff', dark: '#1a1a1a' },
  '--dsw-alias-link': { light: '#c2410c', dark: '#fab283' },
  '--dsw-alias-brand-primary': { light: '#c2410c', dark: '#9d7cd8' },
  '--dsw-alias-brand-text': { light: '#161616', dark: '#eeeeee' },
  '--dsw-alias-button-primary-fill': { light: '#c2410c', dark: '#fab283' },
  '--dsw-alias-button-primary-hover': { light: '#9a3412', dark: '#e89b6a' },
  '--dsw-alias-button-info-fill': { light: '#2563eb', dark: '#9d7cd8' },
  '--dsw-alias-button-info-hover': { light: '#1d4ed8', dark: '#8a68c4' },
  '--dsw-alias-markdown-code-block': { light: '#f6f6f6', dark: '#232323' },
  '--dsw-alias-markdown-code-block-banner': { light: '#efefef', dark: '#2c2c2c' },
  '--dsw-alias-markdown-inline-code': { light: 'rgba(0, 0, 0, 0.055)', dark: 'rgba(255, 255, 255, 0.07)' },
  '--dsw-alias-markdown-tag': { light: '#efefef', dark: '#2c2c2c' },
  '--dsw-alias-markdown-citation': { light: '#f1f1f1', dark: '#2c2c2c' },
  '--dsw-alias-state-success-primary': { light: '#1e725c', dark: '#7fd88f' },
  '--dsw-alias-state-error-primary': { light: '#c53b53', dark: '#e06c75' },
  '--dsw-alias-state-warn-primary': { light: '#b45309', dark: '#f5a742' },
  '--dsw-alias-state-business-primary': { light: '#7c3aed', dark: '#9d7cd8' },
  '--dsw-alias-code-diff-added': { light: 'rgba(30, 114, 92, 0.12)', dark: 'rgba(79, 214, 190, 0.14)' },
  '--dsw-alias-code-diff-deleted': { light: 'rgba(197, 59, 83, 0.12)', dark: 'rgba(197, 59, 83, 0.16)' },
  '--dsw-alias-file-diff-added-bg': { light: '#e6f4ee', dark: '#20303b' },
  '--dsw-alias-file-diff-added-gutter': { light: '#d9ece3', dark: '#1a2831' },
  '--dsw-alias-file-diff-added-marker': { light: '#1e725c', dark: '#4fd6be' },
  '--dsw-alias-file-diff-deleted-bg': { light: '#fbe9ec', dark: '#37222c' },
  '--dsw-alias-file-diff-deleted-gutter': { light: '#f7dde1', dark: '#2d1c24' },
  '--dsw-alias-file-diff-deleted-marker': { light: '#c53b53', dark: '#c53b53' },
  '--dsw-alias-scrollbar-bg-l1': { light: '#d0d0d0', dark: '#484848' },
  '--dsw-alias-scrollbar-bg-l2': { light: '#d0d0d0', dark: '#484848' },
  '--dsw-alias-scrollbar-hover-l1': { light: '#b8b8b8', dark: '#606060' },
  '--dsw-alias-scrollbar-hover-l2': { light: '#b8b8b8', dark: '#606060' },
  '--dsw-specific-bubble': { light: '#f6f6f6', dark: '#232323' },
  '--dsw-specific-bubble-highlight': { light: '#ececec', dark: '#2c2c2c' },
  '--dsw-specific-input-major': { light: '#ffffff', dark: '#232323' },
  '--dsw-specific-sidebar-fill': { light: '#fafafa', dark: '#161616' },
  '--dsw-specific-sidebar-nav-item-hover': { light: '#f1f1f1', dark: '#232323' },
  '--dsw-specific-sidebar-nav-item-active': { light: '#e7e7e7', dark: '#2c2c2c' },
  '--dsw-specific-sidebar-nav-item-active-accent': { light: '#fde8d7', dark: '#2b2338' },
  '--dsw-specific-selector': { light: '#f1f1f1', dark: '#2c2c2c' },
  '--dsw-specific-tip': { light: '#f1f1f1', dark: '#2c2c2c' },
});

/**
 * Stack the palette for exactly this client plugin lifetime.
 * @param ctx - client plugin context, which may receive the theme service after it starts.
 */
export function apply(ctx) {
  // These do not need the theme service, so they go in before it may appear.
  installStyle(ctx, 'palette-markdown', MARKDOWN_CSS);
  installStyle(ctx, 'palette-shiki', SHIKI_CSS);
  colorizeColourCodes(ctx);
  const install = scope => {
    const theme = scope.get?.('theme') ?? scope.theme;
    if (typeof theme?.overrideTokens !== 'function') return;
    scope.effect(() => theme.overrideTokens(SOURCE, PALETTE), 'aiapi palette layer');
  };
  if (typeof ctx.inject === 'function') ctx.inject(['theme'], install);
  else install(ctx);
}
