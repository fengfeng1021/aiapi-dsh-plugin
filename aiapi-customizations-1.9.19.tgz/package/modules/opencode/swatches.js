/**
 * Inline colour codes read as their own colour.
 *
 * A message that lists `#9d7cd8` / `#f5a742` is asking the reader to decode hex by hand; painting the code in the
 * colour it names is the one thing the palette can add that neither DSH nor opencode does. Only inline code inside a
 * markdown container is touched, the value goes on as an inline `color` (so it beats the palette's green inline-code
 * rule without any specificity games), and anything that is not a colour code is left exactly as it was — a streamed
 * message keeps editing the same `<code>` node, so the last text wins and the paint is removed when it stops being a
 * colour. Code blocks are skipped (`:not(pre) > code`): there the hex is part of the program text and shiki's
 * syntax colours own it.
 */

/** Bare colour codes only: `#rgb`, `#rrggbb`, `#rrggbbaa`. */
const COLOUR_CODE = /^#(?:[0-9a-f]{3}|[0-9a-f]{6}|[0-9a-f]{8})$/i;

/** The containers whose inline code is styled by the palette. */
const SCOPE = '[class*="_markdown"] :not(pre) > code';

/**
 * Paint every `#rrggbb` inline code in the conversation, and keep doing it as messages stream in.
 * @param ctx - client plugin context; the observer dies with the feature.
 */
export function colorizeColourCodes(ctx) {
  if (typeof document === 'undefined' || typeof MutationObserver !== 'function') return;
  let painted = false;
  const paint = code => {
    const text = (code.textContent ?? '').trim();
    if (code.dataset.aiapiColour === text) return;
    code.dataset.aiapiColour = text;
    if (COLOUR_CODE.test(text)) {
      code.style.color = text;
      painted = true;
      return;
    }
    if (code.style.color !== '') code.style.color = '';
  };
  const scan = () => {
    for (const code of document.querySelectorAll(SCOPE)) paint(code);
  };
  let scheduled = false;
  const schedule = () => {
    if (scheduled) return;
    scheduled = true;
    requestAnimationFrame(() => { scheduled = false; scan(); });
  };
  const observer = new MutationObserver(schedule);
  observer.observe(document.body, { childList: true, subtree: true, characterData: true });
  // One pass at mount covers a conversation that was already on screen; `painted` documents why the first scan is
  // worth doing even when no mutation follows.
  scan();
  ctx.effect(() => () => { painted = false; observer.disconnect(); }, 'aiapi colour-code swatches');
  void painted;
}
