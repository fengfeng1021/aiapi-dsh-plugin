/**
 * Every feature this bundle contributes, one switch each.
 *
 * The manifest is shared by the Host entry, the browser entry and the settings row, so a feature's
 * identity and default exist in exactly one place. A Host module or browser module listed here is
 * mounted only while its switch is on; turning it off disposes just that contribution and leaves
 * history, credentials and other features untouched.
 */

/**
 * One feature: its stable id, which halves contribute it, and its row text.
 * @typedef {object} Feature
 * @property {string} id - config key under `features`.
 * @property {boolean} [defaultOn] - false for a feature that ships switched off (opt-in).
 * @property {boolean} [fixed] - always on; shown without a switch because the product depends on it.
 * @property {boolean} host - the Host entry mounts a module for it.
 * @property {boolean} client - the browser entry mounts a module for it.
 * @property {string} zh - Traditional Chinese row label.
 * @property {string} en - English row label.
 * @property {string} zhDetail - Traditional Chinese one-line description.
 * @property {string} enDetail - English one-line description.
 */

/** @type {readonly Feature[]} */
export const FEATURES = Object.freeze([
  {
    id: 'brand',
    fixed: true,
    host: false,
    client: true,
    zh: '品牌外觀',
    en: 'Brand',
    zhDetail: '側邊欄與新對話頁顯示 Aiapi 的標誌與名稱',
    enDetail: 'The Aiapi mark and name in the sidebar and on a new conversation',
  },
  {
    id: 'models',
    fixed: true,
    host: true,
    client: true,
    zh: 'AIAPI 模型',
    en: 'AIAPI models',
    zhDetail: '在「設定 → 模型」提供 AIAPI；登入後自動帶入你的帳號能用的模型與思考等級',
    enDetail: 'AIAPI on Settings → Models, with the models and reasoning levels your account can use',
  },
  {
    id: 'engineering',
    host: true,
    client: false,
    zh: '工程審查',
    en: 'Engineering review',
    zhDetail: '請 AI 審查程式變更時，依六份審查清單逐項檢查；平常不會出現在對話裡',
    enDetail: 'Six review checklists the AI follows when you ask it to review a change; silent otherwise',
  },
  {
    id: 'communication',
    host: true,
    client: false,
    zh: '白話回覆',
    en: 'Plain answers',
    zhDetail: '先講結論、用白話說明；該分段就分段，長任務每隔一段時間回報進度',
    enDetail: 'Outcome first in plain words but still shaped with headings and lists; progress updates on long tasks',
  },
  {
    id: 'opencode',
    host: false,
    client: true,
    zh: 'Aiapi 配色',
    en: 'Aiapi palette',
    zhDetail: '近黑底與柔和灰階，紫色標題、橙色連結；淺色與深色模式各有一套',
    enDetail: 'Near-black base, soft greys, purple headings and orange links, in light and dark',
  },
  {
    id: 'fonts',
    host: true,
    client: true,
    zh: '字型與字級',
    en: 'Fonts',
    zhDetail: '內建 Cascadia Mono、Maple Mono CN 等字型；在「設定 → 通用」為對話、程式碼與終端機選字型與字級',
    enDetail: 'Bundled Cascadia Mono, Maple Mono CN and more; pick fonts and sizes for conversation, code and terminal',
  },
  {
    id: 'skills',
    host: true,
    client: true,
    zh: 'Skills 管理',
    en: 'Skills manager',
    zhDetail: '側邊欄的 Skills 頁：搜尋、匯入、停用自動使用、備份與還原',
    enDetail: 'A sidebar page to search, import, restrict, back up and restore skills',
  },
]);

/** Stable ids in manifest order. */
export const FEATURE_IDS = Object.freeze(FEATURES.map(feature => feature.id));

/**
 * Read one switch, accepting both a plain value and a volatile config reference.
 * @param candidate - stored value, `Volatile` reference, or `undefined`.
 * @returns the boolean, or `undefined` when the switch was never set.
 */
function unwrap(candidate) {
  if (candidate !== null && typeof candidate === 'object' && typeof candidate.get === 'function') {
    return candidate.get();
  }
  return candidate;
}

/**
 * Resolve every switch for a plugin config, filling defaults for anything absent.
 *
 * Missing `features` (an older entry) means every feature stays on, which is the behaviour before
 * per-feature switches existed.
 * @param config - the plugin config, whose `features` may hold volatile references.
 * @returns a complete `{ [featureId]: boolean }` record.
 */
export function readFeatures(config) {
  // A 1.3.x patch may still carry features.browser; it no longer has an entry here and is ignored.
  const raw = unwrap(config?.features);
  const stored = raw !== null && typeof raw === 'object' ? raw : {};
  /** @type {Record<string, boolean>} */
  const values = {};
  for (const feature of FEATURES) {
    // A fixed feature backs the product itself (brand, provider), so its switch is read-only.
    if (feature.fixed === true) { values[feature.id] = true; continue; }
    values[feature.id] = unwrap(stored[feature.id]) === undefined ? feature.defaultOn !== false : unwrap(stored[feature.id]) !== false;
  }
  return values;
}

/**
 * Whether one feature is on.
 * @param config - the plugin config.
 * @param id - feature id.
 * @returns true unless the switch is explicitly off.
 */
export function featureEnabled(config, id) {
  return readFeatures(config)[id] === true;
}
