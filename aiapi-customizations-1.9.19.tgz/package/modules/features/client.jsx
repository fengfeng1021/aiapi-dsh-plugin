/**
 * The plugin's own page in Plugins (version and updates, the AIAPI account entry, one switch per feature), the
 * palette row in Settings → General, and the update notice. Feature switches are the plugin config's `features`
 * object: a change written here reaches the Host entry through `loader/volatile-update` and the browser modules
 * through {@link subscribeFeatures}, so nothing needs a reload.
 */
import React, { useEffect, useState } from 'react';
import { createRoot } from 'react-dom/client';
import { FEATURES, readFeatures } from '../features.mjs';
import { reportError } from './reporter.js';
import { Logo } from '../../../aiapi-brand/client.jsx';
import {
  KIT_CSS, Switch, accountStore, host, installStyle, money, openSettings, useAccount,
} from '../ui/kit.jsx';
import { LUX_CSS, installRipples } from '../ui/lux.js';

/** Package name the Plugins page keys its own detail section by. */
const PACKAGE_NAME = '@aiapi/dsh-customizations';

/** Entry id this bundle is mounted under. */
const DEFAULT_NS = 'aiapi-customizations';

const FEATURES_CSS = `
.aiapi-plugin-page{padding-top:4px}
.aiapi-plugin-page .aiapi-lux-lite,.aiapi-plugin-page .aiapi-version{padding:4px 18px}
.aiapi-version{padding:14px 18px!important}
.aiapi-version-name{font-size:15px;font-weight:650;letter-spacing:.04em}
.aiapi-notice{right:20px;bottom:20px;z-index:9999;width:380px;max-width:calc(100vw - 40px);box-sizing:border-box;padding:16px 18px;font-size:13px;line-height:20px}
/* 定位寫在兩個 class 的選擇器上：aiapi-lux-card 也宣告 position，兩者特異度相同，而 lux 樣式會被後載入的
   模組重新注入、排在後面，於是 fixed 被 relative 蓋掉，提示掉回文件流、跑到畫面左下角被裁掉
   （2026-10-29 回報）。CSS 不看 HTML 的 class 順序，只能靠選擇器特異度。 */
.aiapi-notice.aiapi-lux-card{position:fixed}
.aiapi-notice-title{display:flex;align-items:center;gap:10px;font-weight:650;font-size:14px}
.aiapi-notice-body{margin-top:6px;color:var(--lux-dim)}
.aiapi-notice-actions{display:flex;justify-content:flex-end;gap:8px;margin-top:14px}
/* 配色預覽：容器 class 帶 _markdown，讓配色層的規則直接套在同一組選擇器上，看到的就是回覆的樣子。 */
.aiapi-palette-preview{padding:14px 16px;font-size:13px;line-height:1.7;color:var(--dsw-alias-label-primary);border:.5px solid var(--dsw-alias-settings-card-stroke);border-radius:var(--dsw-radius-xl);background:var(--dsw-alias-settings-card-fill)}
.aiapi-palette-preview>:first-child{margin-top:0}
.aiapi-palette-preview h3{margin:0 0 6px;font-size:15px;font-weight:600}
.aiapi-palette-preview p{margin:0 0 8px}
.aiapi-palette-preview blockquote{margin:0 0 8px;padding-left:10px;border-left:2px solid}
.aiapi-palette-preview ul,.aiapi-palette-preview ol{margin:0 0 8px;padding-left:20px}
.aiapi-palette-preview code{font-family:var(--ds-font-family-code);font-size:.875em;padding:0 5px;border-radius:4px;background:var(--dsw-alias-markdown-inline-code);border:.5px solid var(--dsw-alias-border-l1)}
.aiapi-palette-preview pre{margin:0;padding:10px 12px;border-radius:8px;background:var(--dsw-alias-markdown-code-block);color:var(--shiki-foreground);font-family:var(--ds-font-family-code);font-size:12px;line-height:1.5;overflow:auto}
.aiapi-palette-preview-note{margin-top:10px;font-size:12px;line-height:18px;color:var(--dsw-alias-label-tertiary)}
`;

// ── Feature switches ────────────────────────────────────────────────────────────────────────────

/** Listeners re-gated by a switch change; module scope keeps them across page remounts. */
const listeners = new Set();

/** Last known complete set of switches. */
let current = null;

/** Publish a complete switch set to the feature mounters. */
export function setFeatureValues(values) {
  current = { ...values };
  for (const listener of listeners) listener(current);
}

/** The last published switches, or an empty object before the first publish. */
export function getFeatureValues() {
  return current ?? {};
}

/** Follow switch changes, so a feature can unmount itself without a page reload. */
export function subscribeFeatures(listener) {
  listeners.add(listener);
  return () => listeners.delete(listener);
}

/** This plugin's namespace in a describe response. */
async function namespaceView(ctx) {
  const response = await ctx.remote.settings.describe();
  if (response?.ok === false) throw new Error(response.error?.message ?? '無法讀取設定');
  const namespaces = (response?.value ?? response)?.namespaces ?? [];
  return namespaces.find(view => view?.ns === DEFAULT_NS);
}

/** Write one switch through the settings service, which validates the Config and applies it live. */
async function persistFeature(ctx, id, on) {
  const view = await namespaceView(ctx);
  if (view === undefined) throw new Error('找不到 Aiapi 插件的設定');
  const response = await ctx.remote.settings.mutate(view.ns, [{ op: 'set', path: ['features', id], value: on }], view.revision);
  if (response?.ok === false) throw new Error(response.error?.message ?? '設定寫入被拒絕');
}

/** Current switches, kept in step with the Host and with other surfaces. */
function useFeatures(ctx) {
  const [values, setValues] = useState(() => getFeatureValues());
  useEffect(() => subscribeFeatures(next => setValues(next)), []);
  useEffect(() => {
    let alive = true;
    void namespaceView(ctx).then(view => {
      if (alive && view !== undefined) setFeatureValues(readFeatures({ features: view.value?.features }));
    }).catch(() => {});
    return () => { alive = false; };
  }, [ctx]);
  const toggle = async (id, on) => {
    const previous = getFeatureValues();
    setFeatureValues({ ...previous, [id]: on });
    try {
      await persistFeature(ctx, id, on);
      return '';
    } catch (failure) {
      setFeatureValues(previous);
      return failure instanceof Error ? failure.message : String(failure);
    }
  };
  return [values, toggle];
}

/** One card, one row per feature: what it does, and its switch. Product features show as required. */
function FeatureList({ ctx }) {
  const [values, toggle] = useFeatures(ctx);
  const [error, setError] = useState('');
  return <div className="aiapi-lux-lite">
    {FEATURES.map(feature => <div className="aiapi-row" key={feature.id}>
      <div className="aiapi-row-copy">
        <span className="aiapi-row-title">{feature.zh}</span>
        <span className="aiapi-row-caption">{feature.zhDetail}</span>
      </div>
      {feature.fixed === true
        ? <span className="aiapi-lux-chip" data-tone="gold">必要</span>
        : <Switch checked={values[feature.id] !== false} label={feature.zh} onChange={on => { void toggle(feature.id, on).then(setError); }} />}
    </div>)}
    {error === '' ? null : <div className="aiapi-row"><span className="aiapi-row-caption aiapi-error-text" role="alert">{error}</span></div>}
  </div>;
}

// ── Version and updates ─────────────────────────────────────────────────────────────────────────

/** One shared record of what the release host offers, so the card and the notice cannot disagree. */
export const updateStore = {
  state: { current: '', latest: undefined, installed: '', newer: false },
  listeners: new Set(),
  publish(patch) {
    this.state = { ...this.state, ...patch };
    for (const listener of this.listeners) listener(this.state);
  },
  subscribe(listener) {
    this.listeners.add(listener);
    listener(this.state);
    return () => { this.listeners.delete(listener); };
  },
};

/**
 * Whether this carrier can restart itself. The DeepSeek Harness desktop app is Electron and gives the page no
 * relaunch call, so there the user is told to quit and reopen instead of being shown a button that cannot work.
 */
function canRestartDsh() {
  return typeof window.__TAURI_INTERNALS__?.invoke === 'function';
}

/** Restart a Tauri shell; every relaunch command such a shell may expose is tried in turn. */
async function restartDsh() {
  if (!canRestartDsh()) return false;
  for (const command of ['plugin:process|restart', 'plugin:process|relaunch', 'plugin:app|restart', 'restart_app']) {
    try {
      await window.__TAURI_INTERNALS__.invoke(command, {});
      return true;
    } catch { /* try the next name */ }
  }
  return false;
}

/** How the page says "restart" when it cannot restart by itself. */
const QUIT_AND_REOPEN = /mac/i.test(globalThis.navigator?.platform ?? '') ? '完全結束 DSH（⌘Q）再重新開啟' : '完全結束 DSH 再重新開啟';

/**
 * Wait for an install the Host accepted. With HMR the plugin may be restarted mid-install, and the new instance
 * answers with its own idle state, so the version it runs is the reliable signal that the install landed.
 * @throws when the Host reports a failure, or nothing happens within two minutes.
 */
async function waitForInstall(target) {
  for (let attempt = 0; attempt < 120; attempt += 1) {
    await new Promise(resolve => setTimeout(resolve, 1000));
    const state = await host('api/aiapi/update/status').catch(() => undefined);
    if (state === undefined) continue;
    if (state.running === target) return state;
    if (state.phase === 'failed') throw new Error(state.error || '安裝失敗');
    if (state.phase === 'done') return state;
  }
  throw new Error(`安裝已送出，但兩分鐘內沒有結果。請${QUIT_AND_REOPEN}後回到這裡確認版本。`);
}

/** Ask the Host for the running version and the published one, and share the answer. */
async function checkUpdate() {
  const info = await host('api/aiapi/update');
  const result = await host('api/aiapi/update/check', {});
  const installed = typeof info.onDisk === 'string' ? info.onDisk : '';
  updateStore.publish({ current: info.version, latest: result.latest ?? undefined, installed, newer: result.newer === true });
  return { info, result, installed };
}

/** Install the published release, then reload the page into it. */
async function installUpdate(onProgress) {
  const result = await host('api/aiapi/update/apply', {});
  if (result.status === 'current') { onProgress('已是最新版本。'); return; }
  if (result.status !== 'updating') throw new Error(result.error ?? '更新未被接受');
  onProgress(`正在安裝 ${result.version}…`);
  await waitForInstall(result.version);
  // A reload swaps in the new interface; if the background half did not reload with it, the next page load
  // raises the notice in its "restart needed" form.
  onProgress(`已安裝 ${result.version}，正在重新載入…`);
  window.setTimeout(() => window.location.reload(), 400);
}

/** Version card: this build, the published one, and the one-click update. */
function UpdateCard() {
  const [state, setState] = useState(updateStore.state);
  const [phase, setPhase] = useState('checking');
  const [message, setMessage] = useState('');
  useEffect(() => updateStore.subscribe(setState), []);
  const check = async () => {
    setPhase('checking');
    setMessage('');
    try {
      const { result } = await checkUpdate();
      if (result.unconfigured === true) setMessage('這份設定關閉了更新檢查（updateManifestUrl）。');
      else if (result.error !== undefined) setMessage(`無法檢查更新：${result.error}`);
    } catch (failure) {
      setMessage(`無法檢查更新：${failure?.message ?? failure}`);
    } finally {
      setPhase('idle');
    }
  };
  useEffect(() => { void check(); }, []);
  const apply = async () => {
    setPhase('installing');
    try { await installUpdate(setMessage); }
    catch (failure) { setPhase('idle'); setMessage(failure?.message ?? String(failure)); }
  };
  const stale = state.installed !== '' && state.current !== '' && state.installed !== state.current;
  const status = phase === 'checking' ? <span className="aiapi-row-caption">檢查中…</span>
    : stale ? <span className="aiapi-lux-chip" data-tone="gold">待重新開啟</span>
      : state.newer && state.latest ? <span className="aiapi-lux-chip" data-tone="neon">可更新到 {state.latest.version}</span>
        : state.latest ? <span className="aiapi-lux-chip" data-tone="gold">已是最新</span> : null;
  return <div className="aiapi-lux-card aiapi-lux-ripple aiapi-version">
    <div className="aiapi-row">
      <div className="aiapi-identity">
        <Logo size={30} />
        <div className="aiapi-row-copy">
          <span className="aiapi-version-name aiapi-lux-gold">Aiapi 插件 {state.current}</span>
          <span className="aiapi-row-caption">
            {stale ? `新版 ${state.installed} 已安裝，背景程式要${QUIT_AND_REOPEN}後才會換新`
              : state.newer && state.latest?.notes ? state.latest.notes
                : '啟動時會自動檢查新版本'}
          </span>
        </div>
      </div>
      <div className="aiapi-row-actions">
        {status}
        {state.newer && !stale && phase !== 'installing'
          ? <button type="button" className="aiapi-lux-btn" onClick={() => { void apply(); }}>立即更新</button>
          : <button type="button" className="aiapi-lux-btn-line" disabled={phase !== 'idle'} onClick={() => { void check(); }}>檢查更新</button>}
      </div>
    </div>
    {message === '' ? null : <div className="aiapi-row"><span className="aiapi-row-caption" role="status">{message}</span></div>}
  </div>;
}

/** A one-line view of the AIAPI account with the way to 「账号与余额」. */
function AccountEntry({ ctx }) {
  const account = useAccount();
  const data = account.data;
  const caption = account.phase === 'ok' && data
    ? `餘額 ${money(data.balance, data.currency)}${data.group?.name ? ` · 分組 ${data.group.name}` : ''}`
    : account.phase === 'loading' ? '讀取中…'
      : account.phase === 'error' ? `暫時無法更新：${account.error}` : '尚未登入';
  return <div className="aiapi-lux-lite">
    <div className="aiapi-row">
      <div className="aiapi-row-copy">
        <span className="aiapi-row-title">AIAPI 帳號</span>
        <span className="aiapi-row-caption aiapi-status">
          <span className="aiapi-lux-pulse" data-tone={account.phase === 'ok' ? undefined : account.phase === 'loading' ? 'idle' : 'warn'} />{caption}
        </span>
      </div>
      <button type="button" className="aiapi-lux-btn-line" onClick={() => { if (!openSettings(ctx)) void accountStore.refresh(); }}>
        {account.phase === 'ok' ? '帳號與餘額' : '前往登入'}
      </button>
    </div>
  </div>;
}

/**
 * What the palette actually does to an answer, rendered with the same rules the answer uses.
 *
 * The container's class carries `_markdown`, so the structure colours match it exactly as they match DSH's own
 * `_markdown_*` container — the preview cannot drift from the real thing, and a stale bundle is visible here at once
 * instead of only after writing a long answer.
 * @returns the preview block.
 */
function PalettePreview() {
  return <div className="aiapi-palette-preview _markdown_preview">
    <h3>三級標題</h3>
    <p>一般文字，<strong>粗體</strong>、<em>斜體</em>、<code>行內程式碼</code>、<a href="#" onClick={event => event.preventDefault()}>連結</a>。</p>
    <blockquote>引用的一段話，左邊一條細線。</blockquote>
    <ul><li>無序清單項目</li><li>第二項</li></ul>
    <ol><li>有序清單項目</li><li>第二項</li></ol>
    <pre>{'const answer = 42\n// 程式碼區塊（語法色見實際回覆）'}</pre>
    <div className="aiapi-palette-preview-note">以上顏色即回覆所用的那一組；若這裡還是舊色，代表介面仍在跑舊版 bundle。</div>
  </div>;
}

/**
 * The plugin's own detail page in Plugins: version, account, features.
 * @param ctx - client plugin context.
 */
export function applyPluginPageRow(ctx) {
  installStyle(ctx, 'kit', KIT_CSS);
  installStyle(ctx, 'lux', LUX_CSS);
  installStyle(ctx, 'features', FEATURES_CSS);
  installRipples(ctx);
  ctx.slots.inject('plugins.detail.section', () => ctx.slots.register({
    name: 'plugins.detail.section', id: 'aiapi-features',
  }, ({ subject }) => {
    const name = subject?.kind === 'bundle' || subject?.kind === 'row' ? subject.pkg?.name : undefined;
    if (name !== PACKAGE_NAME) return null;
    return <section className="aiapi-section aiapi-plugin-page aiapi-lux" data-aiapi-features-section>
      <CardBoundary label="update"><UpdateCard /></CardBoundary>
      <div className="aiapi-lux-heading">AIAPI</div>
      <CardBoundary label="account"><AccountEntry ctx={ctx} /></CardBoundary>
      <div className="aiapi-lux-heading">功能</div>
      <CardBoundary label="features"><FeatureList ctx={ctx} /></CardBoundary>
      <div className="aiapi-lux-heading">配色</div>
      <CardBoundary label="palette"><PalettePreview /></CardBoundary>
    </section>;
  }));
}

/** Settings → General: the palette switch, the same value as the 「Aiapi 配色」 feature switch. */
function PaletteRow({ ctx }) {
  const [values, toggle] = useFeatures(ctx);
  return <div className="aiapi-general-row">
    <div>
      <div className="aiapi-general-title">Aiapi 配色</div>
      <div className="aiapi-general-description">近黑底與柔和灰階，紫色標題、橙色連結；淺色與深色模式各有一套</div>
    </div>
    <Switch checked={values.opencode !== false} label="Aiapi 配色" onChange={on => { void toggle('opencode', on); }} />
  </div>;
}

/**
 * Rows this plugin adds to Settings → General.
 * @param ctx - client plugin context.
 */
export function applyGeneralRows(ctx) {
  installStyle(ctx, 'features', FEATURES_CSS);
  ctx.slots.inject('settings.general.item', () => ctx.slots.register({
    name: 'settings.general.item', id: 'aiapi-palette', order: 12,
  }, () => <PaletteRow ctx={ctx} />));
}

// ── Update notice ───────────────────────────────────────────────────────────────────────────────

/** The corner notice: a newer release, or an install that still waits for the background half. */
function UpdateNotice({ latest, current, needsRestart, close }) {
  const [message, setMessage] = useState('');
  const [busy, setBusy] = useState(false);
  const update = async () => {
    setBusy(true);
    try { await installUpdate(setMessage); }
    catch (failure) { setMessage(failure?.message ?? String(failure)); setBusy(false); }
  };
  const restart = async () => {
    setBusy(true);
    if (!await restartDsh()) { setMessage(`這個 DSH 不能自動重啟，請${QUIT_AND_REOPEN}。`); setBusy(false); }
  };
  return <div className="aiapi-notice aiapi-lux aiapi-lux-card aiapi-lux-ripple" role="dialog" aria-label="Aiapi 插件更新">
    <div className="aiapi-notice-title"><Logo size={22} /><span className="aiapi-lux-gold">{needsRestart ? `Aiapi 插件 ${latest.version} 已安裝` : `Aiapi 插件有新版本 ${latest.version}`}</span></div>
    <div className="aiapi-notice-body">
      {message !== '' ? message
        : needsRestart ? `介面已經是新版；背景程式還在跑 ${current}，${canRestartDsh() ? '重新啟動 DSH' : QUIT_AND_REOPEN}後全部生效。`
          : latest.notes ? latest.notes : `目前是 ${current}。`}
    </div>
    <div className="aiapi-notice-actions">
      <button type="button" className="aiapi-lux-btn-quiet" onClick={close}>{needsRestart && !canRestartDsh() ? '知道了' : '稍後'}</button>
      {needsRestart
        ? canRestartDsh() ? <button type="button" className="aiapi-lux-btn" disabled={busy} onClick={() => { void restart(); }}>重新啟動 DSH</button> : null
        : <button type="button" className="aiapi-lux-btn" disabled={busy} onClick={() => { void update(); }}>{busy ? '更新中…' : '立即更新'}</button>}
    </div>
  </div>;
}

/**
 * Offer the update once per page load while this build is behind the published one. Checks retry with backoff
 * and when the window comes back into view; a failure is logged, never shown.
 * @param ctx - client plugin context.
 */
export function applyUpdateNotice(ctx) {
  installStyle(ctx, 'lux', LUX_CSS);
  installStyle(ctx, 'features', FEATURES_CSS);
  installRipples(ctx);
  ctx.effect(() => {
    let disposed = false;
    let shown = false;
    let container;
    let root;
    const timers = new Set();
    const close = () => {
      root?.unmount();
      container?.remove();
      root = undefined;
      container = undefined;
    };
    const show = (latest, current, needsRestart) => {
      if (shown || disposed) return;
      shown = true;
      container = document.createElement('div');
      container.dataset.aiapiUpdateNotice = '';
      document.body.append(container);
      root = createRoot(container);
      root.render(<UpdateNotice latest={latest} current={current} needsRestart={needsRestart} close={close} />);
    };
    const unsubscribe = updateStore.subscribe(state => {
      if (state.current === '') return;
      if (state.installed !== '' && state.installed !== state.current) show({ version: state.installed, notes: '' }, state.current, true);
      else if (state.newer && state.latest !== undefined) show(state.latest, state.current, false);
    });
    let attempt = 0;
    const schedule = () => {
      const delays = [2000, 8000, 30000, 90000];
      const delay = attempt < delays.length ? delays[attempt] : 600000;
      attempt += 1;
      const timer = setTimeout(async () => {
        timers.delete(timer);
        if (disposed || shown) return;
        try { await checkUpdate(); } catch (failure) { console.warn('[aiapi] 更新檢查失敗:', failure); schedule(); }
      }, delay);
      timers.add(timer);
    };
    const onVisible = () => { if (document.visibilityState === 'visible' && !shown) void checkUpdate().catch(() => {}); };
    document.addEventListener('visibilitychange', onVisible);
    schedule();
    return () => {
      disposed = true;
      unsubscribe();
      document.removeEventListener('visibilitychange', onVisible);
      for (const timer of timers) clearTimeout(timer);
      close();
    };
  }, 'aiapi update notice');
}

/** Minimal error boundary: a failing card shows one line and leaves the rest of the page working. */
class CardBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { error: undefined };
  }
  static getDerivedStateFromError(error) {
    return { error };
  }
  componentDidCatch(error) {
    console.warn('[aiapi] 卡片渲染失敗:', this.props?.label ?? '', error);
    void reportError({ message: String(error?.message ?? error), stack: error?.stack, where: `card:${this.props?.label ?? ''}` }, globalThis.__aiapiReportingEnabled !== false);
  }
  render() {
    if (this.state.error !== undefined) {
      return <div className="aiapi-lux-lite"><div className="aiapi-row" style={{ padding: '8px 16px' }}><span className="aiapi-row-caption aiapi-error-text">這個區塊載入失敗：{String(this.state.error?.message ?? this.state.error)}</span></div></div>;
    }
    return this.props.children;
  }
}
