/**
 * Settings schema of the unified customization plugin; each module reads its own fields.
 *
 * `@deepseek-ai/schemastery` ships with DSH, but a plugin folder copied by hand has no `node_modules`,
 * so the import would abort activation with ERR_MODULE_NOT_FOUND (2026-10-29 report). Prefer the real
 * schema; degrade to a permissive stand-in when it cannot be resolved, so the plugin still loads.
 */
import { FEATURES } from './features.mjs';

/** Minimal stand-in for the schemastery builder chain: accepts any value, remembers defaults. */
function fallbackSchema() {
  const schema = (defaults = {}) => {
    const node = {
      ...defaults,
      default(value) { return schema({ ...this, defaultValue: value }); },
      description(value) { return schema({ ...this, description: value }); },
      volatile() { return schema({ ...this, volatile: true }); },
      step(value) { return schema({ ...this, step: value }); },
      min(value) { return schema({ ...this, min: value }); },
      max(value) { return schema({ ...this, max: value }); },
      required() { return this; },
      hidden() { return this; },
    };
    return node;
  };
  const builder = () => schema();
  return {
    any: builder, boolean: builder, string: builder, number: builder,
    object: fields => schema({ fields }), dict: builder, array: builder, union: builder, const: builder,
  };
}

let z;
try { z = (await import('@deepseek-ai/schemastery')).default; }
catch (error) {
  console.warn('[aiapi] 找不到 @deepseek-ai/schemastery，改用內建 schema 替代（功能不受影響）:', error?.code ?? error);
  z = fallbackSchema();
}

/**
 * One live switch per feature. `volatile()` keeps the loader from remounting the entry when a
 * switch changes: it commits the value into the running reference and emits
 * `loader/volatile-update`, so the Host entry mounts or disposes a single feature in place.
 * @param feature - manifest entry the switch belongs to.
 * @returns the boolean schema for that feature.
 */
function switchOf(feature) {
  return z.boolean().default(feature.defaultOn !== false).volatile().description(`${feature.zh}／${feature.en}：${feature.zhDetail}`);
}

const switches = Object.fromEntries(FEATURES.map(feature => [feature.id, switchOf(feature)]));

/**
 * Ordinary fields kept in this plugin's entry. Subagent and tool-call concurrency are the official
 * `@deepseek-ai/dsh-subagent` and `@deepseek-ai/dsh-agent-loop` settings; older entries that still carry
 * this plugin's former limit fields load unchanged and those fields are ignored.
 *
 * `features` is the only section a settings form edits: every field under it is live, so the Plugins
 * page and the plugin's own settings row can flip one feature without restarting the host or the
 * browser page.
 */
export const Config = z.object({
  features: z.object(switches).description('逐項功能開關；關閉即收回該功能的宿主與介面貢獻，不影響歷史、憑證或其他功能'),
  updateManifestUrl: z.string().description('版本檢查用的發佈索引網址；留空則用內建的 AIAPI 發佈位置'),
  /**
   * Removed with the system-browser feature. Kept as an accepted legacy field so a profile patch
   * written for 1.3.x still loads; the value is ignored.
   */
  browser: z.any(),
  /** Legacy switch of the removed browser feature; ignored, and no longer listed in the switches row. */
  modelCapacityOverrides: z.any(),
  /** 把使用者端的錯誤自動回傳到 AIAPI 平台（不含任何提示詞或對話內容）。 */
  errorReporting: z.boolean().default(true).volatile().description('自動回傳介面錯誤到 AIAPI，方便我們修（不含對話內容）'),
  /** Keep a live AIAPI balance bar in the sidebar footer. */
  balanceBar: z.boolean().default(false).volatile().description('在側邊欄左下角常駐顯示 AIAPI 餘額條'),
  progressIntervalSeconds: z.number().step(1).min(15).max(300).default(45),
});
