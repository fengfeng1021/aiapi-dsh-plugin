/** 由 build 注入（見 build-aiapi.mjs 的 define 與佔位替換），供 UI 與 Console 顯示實際執行版本。 */
export const PLUGIN_VERSION = '__PLUGIN_VERSION__';
