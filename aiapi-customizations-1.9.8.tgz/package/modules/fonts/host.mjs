/**
 * Serve the fonts this plugin ships, so every machine has them without installing anything. The page loads them
 * through `@font-face` from these exact routes; the files are immutable per release, so browsers cache them.
 */
import { readFile } from 'node:fs/promises';

/** Font files under `fonts/` in the package, each served at `/api/aiapi/fonts/<file>`. */
export const BUNDLED_FONT_FILES = Object.freeze([
  'cascadia-mono.woff2',
  'cascadia-mono-italic.woff2',
  'maple-mono-cn-400.woff2',
  'maple-mono-cn-700.woff2',
  'noto-sans-mono-latin.woff2',
  'noto-sans-mono-latin-ext.woff2',
]);

/**
 * Register one route per bundled font.
 * @param ctx - the feature's plugin context.
 */
export function apply(ctx) {
  const folder = new URL('../../fonts/', import.meta.url);
  for (const file of BUNDLED_FONT_FILES) {
    ctx.effect(() => ctx.connection.fetch.register({
      path: `/api/aiapi/fonts/${file}`, methods: ['GET'], requestBody: 'buffered',
      fetch: async () => {
        try {
          return new Response(await readFile(new URL(file, folder)), {
            headers: { 'content-type': 'font/woff2', 'cache-control': 'public, max-age=31536000, immutable' },
          });
        } catch {
          return new Response('font missing', { status: 404 });
        }
      },
    }), `aiapi font ${file}`);
  }
}
