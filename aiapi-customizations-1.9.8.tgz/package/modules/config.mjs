/**
 * Settings schema of the unified customization plugin; each module reads its own fields.
 *
 * `@deepseek-ai/schemastery` ships with DSH, but a plugin folder copied by hand has no `node_modules`,
 * so the import would abort activation with ERR_MODULE_NOT_FOUND (2026-10-29 report). The package's own
 * copy is preferred; otherwise the build's vendored bundle of the same version is used. It is the real
 * library, not a stand-in: the loader calls `Config(config)` and the settings service reads `toJSON()`,
 * and schemastery and cosmokit identify their objects through `Symbol.for`, so the two copies interoperate.
 */
import { FEATURES } from './features.mjs';

let z;
try { z = (await import('@deepseek-ai/schemastery')).default; }
catch (error) {
  if (error?.code !== 'ERR_MODULE_NOT_FOUND') throw error;
  z = (await import('./vendor/schemastery.mjs')).default;
}

/**
 * One live switch per feature. `volatile()` keeps the loader from remounting the entry when a
 * switch changes: it commits the value into the running reference and emits
 * `loader/volatile-update`, so the Host entry mounts or disposes a single feature in place.
 * @param feature - manifest entry the switch belongs to.
 * @returns the boolean schema for that feature.
 */
function switchOf(feature) {
  return z.boolean().default(feature.defaultOn !== false).volatile().description(`${feature.zh}／${feature.en}：${feature.zhDetail}`);
}

const switches = Object.fromEntries(FEATURES.map(feature => [feature.id, switchOf(feature)]));

/**
 * Ordinary fields kept in this plugin's entry. Subagent and tool-call concurrency are the official
 * `@deepseek-ai/dsh-subagent` and `@deepseek-ai/dsh-agent-loop` settings; older entries that still carry
 * this plugin's former limit fields load unchanged and those fields are ignored.
 *
 * `features` is the only section a settings form edits: every field under it is live, so the Plugins
 * page and the plugin's own settings row can flip one feature without restarting the host or the
 * browser page.
 */
export const Config = z.object({
  features: z.object(switches).description('逐項功能開關；關閉即收回該功能的宿主與介面貢獻，不影響歷史、憑證或其他功能'),
  updateManifestUrl: z.string().description('版本檢查用的發佈索引網址；留空則用內建的 AIAPI 發佈位置'),
  /**
   * Removed with the system-browser feature. Kept as an accepted legacy field so a profile patch
   * written for 1.3.x still loads; the value is ignored.
   */
  browser: z.any(),
  /** Legacy switch of the removed browser feature; ignored, and no longer listed in the switches row. */
  modelCapacityOverrides: z.any(),
  /** 把使用者端的錯誤自動回傳到 AIAPI 平台（不含任何提示詞或對話內容）。 */
  errorReporting: z.boolean().default(true).volatile().description('自動回傳介面錯誤到 AIAPI，方便我們修（不含對話內容）'),
  /** Whether the AIAPI model list follows the account (every chat model it can use) or the user's own pick. */
  autoModels: z.boolean().default(true).volatile().description('AIAPI 模型清單自動跟隨帳號（新模型自動加入、下架的自動移除）；在模型挑選視窗手動選擇後會關閉'),
  /** Keep a live AIAPI balance bar in the sidebar footer. */
  balanceBar: z.boolean().default(false).volatile().description('在側邊欄左下角常駐顯示 AIAPI 餘額條'),
  progressIntervalSeconds: z.number().step(1).min(15).max(300).default(45),
});
