/**
 * 「常駐顯示餘額條」開關的共享狀態：設定頁的卡片負責寫，側邊欄那條負責讀。
 * 放在獨立模組，避免 client.jsx 內部散落未定義的識別字（1.8.0–1.8.5 就是這樣壞掉的）。
 */
export const balanceFlag = { on: false, listeners: new Set() };

/**
 * 更新開關並通知所有訂閱者。
 * @param on - 是否要在側邊欄常駐顯示。
 */
export function setBalanceFlag(on) {
  balanceFlag.on = on === true;
  for (const listener of balanceFlag.listeners) {
    try { listener(balanceFlag.on); } catch (failure) { console.warn('[aiapi] 餘額條訂閱者出錯:', failure); }
  }
}
