/**
 * 使用者端錯誤自動回傳。
 *
 * 只送「出錯這件事」：插件版本、DSH 版本、平台、訊息、堆疊、發生位置，以及一個隨機安裝 ID。
 * 不送提示詞、對話內容、檔案路徑或 API Key（金鑰只在主機端使用，這裡拿不到）。
 * 去重 + 限速，避免同一個錯誤洗版：同一簽章 10 分鐘內只送一次，每小時最多 20 則。
 */
import { PLUGIN_VERSION } from '../version.js';

const HOUR = 60 * 60 * 1000;
const DEDUPE = 10 * 60 * 1000;
const MAX_PER_HOUR = 20;

const seen = new Map();
const sent = [];

/** 隨機安裝 ID：讓同一位使用者的多筆回報可以串起來，但不含任何可識別資訊。 */
function installId() {
  try {
    const key = 'aiapi-install-id';
    const existing = localStorage.getItem(key);
    if (existing !== null && existing !== '') return existing;
    const created = `aiapi-${Math.random().toString(36).slice(2, 10)}${Date.now().toString(36)}`;
    localStorage.setItem(key, created);
    return created;
  } catch {
    return 'aiapi-unknown';
  }
}

/**
 * 回傳一筆錯誤；失敗完全靜默（回報器本身不該再產生錯誤）。
 * @param info - { message, stack, where }。
 * @param enabled - 使用者是否允許回報。
 */
export async function reportError(info, enabled = true) {
  if (enabled !== true) return;
  try {
    const message = String(info?.message ?? '').trim();
    if (message === '') return;
    const signature = `${info?.where ?? ''}|${message}`.slice(0, 300);
    const now = Date.now();
    if ((seen.get(signature) ?? 0) + DEDUPE > now) return;
    seen.set(signature, now);
    while (sent.length > 0 && now - sent[0] > HOUR) sent.shift();
    if (sent.length >= MAX_PER_HOUR) return;
    sent.push(now);

    await fetch(new URL('api/aiapi/report', document.baseURI), {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({
        plugin: '@aiapi/dsh-customizations',
        version: PLUGIN_VERSION,
        dsh: String(globalThis.__DSH_VERSION__ ?? ''),
        platform: navigator?.platform ?? '',
        message: message.slice(0, 2000),
        stack: String(info?.stack ?? '').slice(0, 4000),
        where: String(info?.where ?? '').slice(0, 200),
        installId: installId(),
        url: String(location.href).slice(0, 300),
      }),
    });
  } catch { /* 回報失敗不影響使用者 */ }
}
