/**
 * Aiapi palette: a near-black base with soft greys, purple headings and orange links, after opencode's v2
 * tokens (MIT, https://github.com/anomalyco/opencode), with a matching light set.
 *
 * The palette is one token layer on DSH's theme service (`overrideTokens`): every value names its light and dark
 * form, the user's light/dark/system choice keeps working, and switching the feature off removes exactly this
 * layer. On/off is the 「Aiapi 配色」 feature switch itself (Plugins page or Settings → General); there is no second
 * switch to disagree with it.
 */

/** Layer identity on the theme service. */
const SOURCE = '@aiapi/dsh-customizations:palette';

/** Token → { light, dark } pairs; names are the CSS variables DSH's components read. */
export const PALETTE = Object.freeze({
  '--dsw-alias-bg-base': { light: '#ffffff', dark: '#0a0a0a' },
  '--dsw-alias-bg-layer-1': { light: '#ffffff', dark: '#0a0a0a' },
  '--dsw-alias-bg-layer-2': { light: '#f6f6f6', dark: '#141414' },
  '--dsw-alias-bg-layer-3': { light: '#ffffff', dark: '#1e1e1e' },
  '--dsw-alias-bg-module-platform': { light: '#f1f1f1', dark: '#141414' },
  '--dsw-alias-bg-multi-select': { light: '#f1f1f1', dark: '#141414' },
  '--dsw-alias-bg-overlay': { light: '#f6f6f6', dark: '#1e1e1e' },
  '--dsw-alias-bg-skeleton': { light: 'rgba(0, 0, 0, 0.05)', dark: 'rgba(255, 255, 255, 0.06)' },
  '--dsw-alias-border-l1': { light: 'rgba(0, 0, 0, 0.06)', dark: 'rgba(255, 255, 255, 0.06)' },
  '--dsw-alias-border-l2': { light: '#b8b8b8', dark: '#262626' },
  '--dsw-alias-border-l2-darkmode-thin': { light: 'rgba(0, 0, 0, 0.12)', dark: 'rgba(255, 255, 255, 0.08)' },
  '--dsw-alias-border-l3': { light: '#b8b8b8', dark: '#484848' },
  '--dsw-alias-border-l4': { light: '#9a9a9a', dark: '#606060' },
  '--dsw-alias-label-primary': { light: '#161616', dark: '#eeeeee' },
  '--dsw-alias-label-secondary': { light: '#4b4b4b', dark: '#c8c8c8' },
  '--dsw-alias-label-tertiary': { light: '#6b6b6b', dark: '#a0a0a0' },
  '--dsw-alias-label-caption': { light: '#808080', dark: '#808080' },
  '--dsw-alias-label-dimmed': { light: '#d0d0d0', dark: '#4c4c4c' },
  '--dsw-alias-label-primary-inverted': { light: '#ffffff', dark: '#0a0a0a' },
  '--dsw-alias-label-primary-foreground': { light: '#ffffff', dark: '#0a0a0a' },
  '--dsw-alias-link': { light: '#c2410c', dark: '#fab283' },
  '--dsw-alias-brand-primary': { light: '#c2410c', dark: '#9d7cd8' },
  '--dsw-alias-brand-text': { light: '#161616', dark: '#eeeeee' },
  '--dsw-alias-button-primary-fill': { light: '#c2410c', dark: '#fab283' },
  '--dsw-alias-button-primary-hover': { light: '#9a3412', dark: '#e89b6a' },
  '--dsw-alias-button-info-fill': { light: '#2563eb', dark: '#9d7cd8' },
  '--dsw-alias-button-info-hover': { light: '#1d4ed8', dark: '#8a68c4' },
  '--dsw-alias-markdown-code-block': { light: '#f6f6f6', dark: '#141414' },
  '--dsw-alias-markdown-code-block-banner': { light: '#efefef', dark: '#1e1e1e' },
  '--dsw-alias-markdown-inline-code': { light: '#e7f6ec', dark: '#1e1e1e' },
  '--dsw-alias-markdown-tag': { light: '#efefef', dark: '#1e1e1e' },
  '--dsw-alias-markdown-citation': { light: '#f1f1f1', dark: '#1e1e1e' },
  '--dsw-alias-state-success-primary': { light: '#1e725c', dark: '#7fd88f' },
  '--dsw-alias-state-error-primary': { light: '#c53b53', dark: '#e06c75' },
  '--dsw-alias-state-warn-primary': { light: '#b45309', dark: '#f5a742' },
  '--dsw-alias-state-business-primary': { light: '#7c3aed', dark: '#9d7cd8' },
  '--dsw-alias-code-diff-added': { light: 'rgba(30, 114, 92, 0.12)', dark: 'rgba(79, 214, 190, 0.14)' },
  '--dsw-alias-code-diff-deleted': { light: 'rgba(197, 59, 83, 0.12)', dark: 'rgba(197, 59, 83, 0.16)' },
  '--dsw-alias-file-diff-added-bg': { light: '#e6f4ee', dark: '#20303b' },
  '--dsw-alias-file-diff-added-gutter': { light: '#d9ece3', dark: '#1a2831' },
  '--dsw-alias-file-diff-added-marker': { light: '#1e725c', dark: '#4fd6be' },
  '--dsw-alias-file-diff-deleted-bg': { light: '#fbe9ec', dark: '#37222c' },
  '--dsw-alias-file-diff-deleted-gutter': { light: '#f7dde1', dark: '#2d1c24' },
  '--dsw-alias-file-diff-deleted-marker': { light: '#c53b53', dark: '#c53b53' },
  '--dsw-alias-scrollbar-bg-l1': { light: '#d0d0d0', dark: '#484848' },
  '--dsw-alias-scrollbar-bg-l2': { light: '#d0d0d0', dark: '#484848' },
  '--dsw-alias-scrollbar-hover-l1': { light: '#b8b8b8', dark: '#606060' },
  '--dsw-alias-scrollbar-hover-l2': { light: '#b8b8b8', dark: '#606060' },
  '--dsw-specific-bubble': { light: '#f6f6f6', dark: '#141414' },
  '--dsw-specific-bubble-highlight': { light: '#ececec', dark: '#1e1e1e' },
  '--dsw-specific-input-major': { light: '#ffffff', dark: '#141414' },
  '--dsw-specific-sidebar-fill': { light: '#fafafa', dark: '#0a0a0a' },
  '--dsw-specific-sidebar-nav-item-hover': { light: '#f1f1f1', dark: '#141414' },
  '--dsw-specific-sidebar-nav-item-active': { light: '#e7e7e7', dark: '#1e1e1e' },
  '--dsw-specific-sidebar-nav-item-active-accent': { light: '#fde8d7', dark: '#2b2338' },
  '--dsw-specific-selector': { light: '#f1f1f1', dark: '#1e1e1e' },
  '--dsw-specific-tip': { light: '#f1f1f1', dark: '#1e1e1e' },
});

/**
 * Stack the palette for exactly this client plugin lifetime.
 * @param ctx - client plugin context, which may receive the theme service after it starts.
 */
export function apply(ctx) {
  const install = scope => {
    const theme = scope.get?.('theme') ?? scope.theme;
    if (typeof theme?.overrideTokens !== 'function') return;
    scope.effect(() => theme.overrideTokens(SOURCE, PALETTE), 'aiapi palette layer');
  };
  if (typeof ctx.inject === 'function') ctx.inject(['theme'], install);
  else install(ctx);
}
