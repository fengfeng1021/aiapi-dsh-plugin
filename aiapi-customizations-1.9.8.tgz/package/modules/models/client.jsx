import React, { useEffect, useMemo, useState } from 'react';
import { createPortal } from 'react-dom';
import { isChatModel, requestModelIdForPublicModel } from './discovery.mjs';
import { Logo } from '../../../aiapi-brand/client.jsx';
import { Switch, accountStore, host, installStyle, pluginSettings, useAccount } from '../ui/kit.jsx';
import { LUX_CSS, installRipples } from '../ui/lux.js';

export const name = 'aiapi-models';
export const inject = ['slots', 'remote', 'remote.settings'];
const ns = 'llm-pi-ai';
const unwrap = response => { if (!response.ok) throw new Error(response.error.message); return response.value; };

const MODELS_CSS = `
.aiapi-provider{display:flex;flex-direction:column;gap:10px;margin-top:6px;padding:12px 14px;border-radius:14px}
.aiapi-provider-head{display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap}
.aiapi-provider-who{display:flex;align-items:center;gap:8px;min-width:0;flex-wrap:wrap}
.aiapi-provider-note{color:var(--lux-dim);font-size:12px;line-height:18px}
.aiapi-provider-code{display:flex;align-items:center;gap:10px;flex-wrap:wrap}
.aiapi-cat-overlay{position:fixed;inset:0;z-index:1300;display:flex;align-items:center;justify-content:center;padding:16px;background:rgba(6,5,3,.62);backdrop-filter:blur(6px)}
body:not([data-ds-dark-theme]) .aiapi-cat-overlay{background:rgba(60,40,10,.28)}
.aiapi-cat{box-sizing:border-box;width:min(760px,100%);max-height:86vh;display:flex;flex-direction:column}
.aiapi-cat-head{display:flex;flex-direction:column;gap:12px;padding:18px 22px 12px;border-bottom:1px solid var(--lux-line)}
.aiapi-cat-title-row{display:flex;align-items:center;justify-content:space-between;gap:12px}
.aiapi-cat-title{margin:0;font-size:19px;font-weight:700;letter-spacing:.04em}
.aiapi-cat-x{width:32px;height:32px;display:grid;place-items:center;border:none;border-radius:999px;background:transparent;color:var(--lux-dim);cursor:pointer}
.aiapi-cat-x:hover{color:var(--lux-text);background:rgba(232,187,87,.1)}
.aiapi-cat-auto{display:flex;align-items:center;justify-content:space-between;gap:12px;padding:10px 14px;border-radius:12px}
.aiapi-cat-search{position:relative;display:flex;align-items:center}
.aiapi-cat-search svg{position:absolute;left:14px;color:var(--lux-dim);pointer-events:none}
.aiapi-cat-search input{box-sizing:border-box;width:100%;height:38px;padding:0 14px 0 38px;border-radius:999px;border:1px solid var(--lux-line);background:rgba(232,187,87,.04);color:var(--lux-text);font:inherit;font-size:13px;outline:none;transition:border-color .2s,box-shadow .2s}
.aiapi-cat-search input:focus{border-color:var(--lux-line-strong);box-shadow:0 0 0 3px rgba(232,187,87,.14),0 0 22px -8px rgba(95,243,255,.6)}
.aiapi-cat-tabs{display:flex;gap:4px;padding:4px;border-radius:999px;background:rgba(232,187,87,.06);border:1px solid var(--lux-line);overflow-x:auto}
.aiapi-cat-tab{flex:1 0 auto;height:30px;padding:0 14px;border:none;border-radius:999px;background:transparent;color:var(--lux-dim);font:inherit;font-size:13px;font-weight:550;cursor:pointer;white-space:nowrap}
.aiapi-cat-tab:hover{color:var(--lux-text)}
.aiapi-cat-tab[aria-pressed=true]{color:var(--lux-ink);background:linear-gradient(120deg,var(--lux-gold-deep),var(--lux-gold) 35%,var(--lux-gold-hi) 55%,var(--lux-gold));box-shadow:0 4px 16px -6px rgba(232,187,87,.8)}
.aiapi-cat-body{flex:1 1 auto;min-height:140px;overflow-y:auto;padding:14px 22px;display:flex;flex-direction:column;gap:10px}
.aiapi-cat-empty{padding:40px 0;text-align:center;color:var(--lux-dim)}
.aiapi-cat-group{flex:none;overflow:hidden}
.aiapi-cat-group-head{display:flex;align-items:center;justify-content:space-between;gap:10px;min-height:44px;padding:6px 14px}
.aiapi-cat-group-toggle{display:flex;align-items:center;gap:8px;min-width:0;padding:4px 0;border:none;background:transparent;color:var(--lux-text);font:inherit;cursor:pointer;text-align:left}
.aiapi-cat-chevron{display:flex;color:var(--lux-gold);transition:transform .2s}
.aiapi-cat-chevron[data-collapsed]{transform:rotate(-90deg)}
.aiapi-cat-group-title{font-size:14px;font-weight:650}
.aiapi-cat-group-side{display:flex;align-items:center;gap:10px;flex:none;font-size:12px;color:var(--lux-dim)}
.aiapi-cat-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:6px 12px;padding:10px 12px 12px;border-top:1px solid var(--lux-line)}
.aiapi-cat-item{position:relative;display:flex;align-items:flex-start;gap:10px;min-width:0;padding:8px 10px;border-radius:10px;cursor:pointer;transition:background .2s}
.aiapi-cat-item:hover{background:rgba(232,187,87,.07)}
.aiapi-cat-item input{position:absolute;width:1px;height:1px;opacity:0;pointer-events:none}
.aiapi-cat-check{box-sizing:border-box;display:grid;place-items:center;flex:none;width:20px;height:20px;margin-top:1px;border-radius:50%;border:1.5px solid var(--lux-line-strong);color:var(--lux-ink);transition:all .2s}
.aiapi-cat-check[data-on]{border-color:transparent;background:linear-gradient(135deg,var(--lux-gold-hi),var(--lux-gold),var(--lux-gold-mid));box-shadow:0 0 12px rgba(232,187,87,.75),0 0 2px var(--lux-neon)}
.aiapi-cat-model{display:flex;flex-direction:column;gap:4px;min-width:0}
.aiapi-cat-name{font-size:13px;line-height:18px;color:var(--lux-text);overflow-wrap:anywhere}
.aiapi-cat-id{font-size:11px;color:var(--lux-faint);overflow-wrap:anywhere}
.aiapi-cat-chips{display:flex;gap:4px;flex-wrap:wrap}
.aiapi-cat-foot{display:flex;align-items:center;justify-content:space-between;gap:12px;padding:14px 22px;border-top:1px solid var(--lux-line)}
@media (max-width:560px){.aiapi-cat-grid{grid-template-columns:1fr}}
`;

/** Extend the official provider card; the official Models section remains its owner. */
export function apply(ctx) {
  installStyle(ctx, 'lux', LUX_CSS);
  installStyle(ctx, 'models', MODELS_CSS);
  installRipples(ctx);
  ctx.slots.inject('settings.models.provider-card', () => ctx.slots.register({
    name: 'settings.models.provider-card',
    key: ns,
    inject: () => ({ remote: ctx.remote }),
  }, ProviderCard));
  ctx.effect(() => installDesktopOAuthListener());
}

/**
 * The AIAPI part of the official provider card: who is signed in, the sign-in itself, and the model picker.
 * The account comes from the same store as 「账号与余额」, so both always agree.
 */
function ProviderCard({ remote, provider }) {
  const account = useAccount();
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState('');
  const [catalog, setCatalog] = useState();
  useEffect(() => {
    const onOAuthResult = event => {
      if (event.detail?.status === 'complete') { setMessage(''); void accountStore.refresh(); }
      if (event.detail?.status === 'access_denied') setMessage('你在授權頁拒絕了這次登入。');
      if (event.detail?.status === 'expired') setMessage('登入要求已逾時，請重新開始。');
      if (event.detail?.status === 'error') setMessage('無法完成桌面登入，請重新開始。');
    };
    window.addEventListener('aiapi-desktop-oauth-result', onOAuthResult);
    return () => window.removeEventListener('aiapi-desktop-oauth-result', onOAuthResult);
  }, []);

  if (provider.provider !== 'aiapi') return null;
  const signedIn = account.data !== undefined && (account.phase === 'ok' || account.phase === 'error');
  const pending = account.signIn;
  const settingsCtx = { remote };

  /** Read the account's models (with the platform's capabilities) and open the picker on them. */
  const discover = async () => {
    setBusy(true);
    setMessage('');
    try {
      const described = unwrap(await remote.settings.describe());
      const profile = described.namespaces.find(row => row.ns === ns)?.value?.providers?.aiapi;
      if (!profile) throw new Error('AIAPI 供應商還在註冊中，請稍候再試。');
      const auto = described.namespaces.find(row => row.ns === 'aiapi-customizations')?.value?.autoModels !== false;
      const result = await host('api/aiapi/models', { provider: 'aiapi', enrich: true });
      if (result.models.length === 0) { setMessage(result.warning ?? '這個帳號目前沒有可用的模型。'); return; }
      setCatalog({ models: result.models, selected: Array.isArray(profile.models) ? profile.models : [], auto });
    } catch (error) {
      setMessage(error instanceof Error ? error.message : '模型查詢失敗。');
    } finally {
      setBusy(false);
    }
  };

  /** Automatic: every chat model, kept in step with the account. Manual: exactly the picked list. */
  const save = async ({ auto, models }) => {
    setCatalog(undefined);
    setBusy(true);
    setMessage('');
    try {
      if (auto) {
        await pluginSettings.write(settingsCtx, ['autoModels'], true);
        const result = await host('api/aiapi/provider', {});
        setMessage(`已改為自動同步：帳號能用的 ${result.models ?? ''} 個對話模型都在模型選單裡，之後隨平台更新。`);
      } else {
        const described = unwrap(await remote.settings.describe());
        const section = described.namespaces.find(row => row.ns === ns);
        if (!section?.value?.providers?.aiapi) throw new Error('AIAPI 設定剛被其他地方修改，請重新整理後再試。');
        unwrap(await remote.settings.mutate(ns, [{ op: 'set', path: ['providers', 'aiapi', 'models'], value: models }], section.revision));
        await pluginSettings.write(settingsCtx, ['autoModels'], false);
        setMessage(`已套用，對話中可選用 ${models.length} 個 AIAPI 模型；能力資料仍會隨平台自動更新。`);
      }
    } catch (error) {
      setMessage(error instanceof Error ? error.message : '模型設定儲存失敗。');
    } finally {
      setBusy(false);
    }
  };

  return <div className="aiapi-provider aiapi-lux aiapi-lux-lite" data-aiapi-models-slot>
    <div className="aiapi-provider-head">
      <div className="aiapi-provider-who">
        <Logo size={20} />
        <span className="aiapi-row-title">AIAPI 帳號</span>
        <span className="aiapi-provider-note aiapi-status">
          <span className="aiapi-lux-pulse" data-tone={signedIn ? undefined : account.phase === 'loading' ? 'idle' : 'warn'} />
          {signedIn ? '已登入' : account.phase === 'loading' ? '讀取中' : account.phase === 'invalid-key' ? '登入已失效' : '未登入'}
        </span>
        {signedIn && account.data.group?.name ? <span className="aiapi-lux-chip" data-tone="gold">{account.data.group.name}</span> : null}
      </div>
      <div className="aiapi-row-actions">
        {signedIn
          ? <button type="button" className="aiapi-lux-btn" disabled={busy} onClick={() => { void discover(); }}>{busy ? '讀取中…' : '選擇模型'}</button>
          : pending === undefined
            ? <button type="button" className="aiapi-lux-btn" disabled={account.busy || account.phase === 'loading'} onClick={() => { void accountStore.signIn(); }}>使用 AIAPI 帳號登入</button>
            : null}
      </div>
    </div>
    {pending === undefined ? null : <div className="aiapi-provider-code">
      <span className="aiapi-provider-note">在已開啟的授權頁確認代碼後按「允許這次登入」：</span>
      <span className="aiapi-lux-code aiapi-lux-gold" style={{ fontSize: 18, lineHeight: '26px', padding: '4px 12px' }}>{pending.user_code}</span>
      <button type="button" className="aiapi-lux-btn-line" onClick={() => window.open(pending.verification_uri, '_blank', 'noopener')}>重新開啟授權頁</button>
      <button type="button" className="aiapi-lux-btn-quiet" onClick={() => accountStore.cancelSignIn()}>取消</button>
    </div>}
    {!signedIn && pending === undefined && account.phase !== 'loading'
      ? <span className="aiapi-provider-note">登入後會自動帶入你的帳號能用的模型，不需要自己建立或貼上金鑰。</span>
      : null}
    {message !== '' ? <span className="aiapi-provider-note" role="status">{message}</span>
      : account.error !== '' && pending === undefined && !signedIn ? <span className="aiapi-provider-note aiapi-error-text" role="alert">{account.error}</span> : null}
    {catalog ? createPortal(<Catalog {...catalog} close={() => setCatalog(undefined)} apply={save} />, document.body) : null}
  </div>;
}

function installDesktopOAuthListener() {
  if (!window.__TAURI_INTERNALS__) return () => {};
  let disposed = false;
  let processing = false;
  let retryTimer;
  let activeCallback;
  const completedCallbacks = new Set();
  const attempt = async callback => {
    if (disposed || processing || typeof callback !== 'string') return;
    processing = true;
    try {
      const result = await hostRequest('/api/aiapi/desktop-auth/oauth/callback', { callback });
      if (result.status === 'authorization_pending') {
        retryTimer = window.setTimeout(() => { void attempt(callback); }, 2000);
        return;
      }
      completedCallbacks.add(callback);
      activeCallback = undefined;
      window.dispatchEvent(new CustomEvent('aiapi-desktop-oauth-result', { detail: { status: result.status } }));
      finishDesktopCallback(callback);
    } catch (error) {
      if (error?.status >= 400 && error.status < 500) {
        completedCallbacks.add(callback);
        activeCallback = undefined;
        window.dispatchEvent(new CustomEvent('aiapi-desktop-oauth-result', { detail: { status: 'error' } }));
        finishDesktopCallback(callback);
      } else {
        retryTimer = window.setTimeout(() => { void attempt(callback); }, 5000);
      }
    } finally {
      processing = false;
    }
  };
  const receive = callback => {
    if (disposed || typeof callback !== 'string' || completedCallbacks.has(callback)) return;
    if (activeCallback && activeCallback !== callback) return;
    activeCallback = callback;
    void attempt(callback);
  };
  const onCallback = event => receive(event.detail);
  window.addEventListener('dsh-desktop-oauth-callback', onCallback);
  for (const callback of window.__DSH_DESKTOP_OAUTH_CALLBACKS__ ?? []) receive(callback);
  void hostRequest('/api/aiapi/desktop-auth/oauth/resume', {}).then(result => {
    if (result.status === 'resume' && typeof result.callback === 'string') receive(result.callback);
    if (result.status === 'expired') window.dispatchEvent(new CustomEvent('aiapi-desktop-oauth-result', { detail: { status: 'expired' } }));
  }).catch(() => {});
  return () => {
    disposed = true;
    window.removeEventListener('dsh-desktop-oauth-callback', onCallback);
    window.clearTimeout(retryTimer);
  };
}

function finishDesktopCallback(callback) {
  let state;
  try { state = new URL(callback).searchParams.get('state'); } catch { return; }
  if (!state) return;
  const callbacks = window.__DSH_DESKTOP_OAUTH_CALLBACKS__;
  if (Array.isArray(callbacks)) {
    const index = callbacks.indexOf(callback);
    if (index >= 0) callbacks.splice(index, 1);
  }
  window.location.assign(`dsh-action://oauth-complete?state=${encodeURIComponent(state)}`);
}

async function hostRequest(path, body) {
  const response = await fetch(new URL(path.replace(/^\//, ''), document.baseURI), {
    method: 'POST',
    credentials: 'same-origin',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(body),
    cache: 'no-store',
  });
  const result = await response.json();
  if (!response.ok) {
    const error = new Error(result.error ?? 'AIAPI 授權失敗，請稍後再試。');
    error.status = response.status;
    throw error;
  }
  return result;
}

/** "1M", "256K", "8K" for a context window. */
function shortTokens(value) {
  if (!Number.isFinite(value) || value <= 0) return '';
  if (value >= 1000000) return `${Math.round(value / 104857.6) / 10}M`.replace('.0M', 'M');
  return `${Math.round(value / 1024)}K`;
}

/** What one model can do, as small chips: context, image input, reasoning levels. */
function CapabilityChips({ model }) {
  const levels = model.reasoningEfforts && typeof model.reasoningEfforts === 'object' ? Object.keys(model.reasoningEfforts) : [];
  return <span className="aiapi-cat-chips">
    {model.contextWindow ? <span className="aiapi-lux-chip" title={`上下文 ${model.contextWindow.toLocaleString()} tokens${model.maxTokens ? `，最多輸出 ${model.maxTokens.toLocaleString()}` : ''}`}>{shortTokens(model.contextWindow)}</span> : null}
    {model.input?.includes('image') ? <span className="aiapi-lux-chip" data-tone="neon">圖片</span> : null}
    {levels.length > 0 ? <span className="aiapi-lux-chip" data-tone="gold" title={`可選思考程度：${levels.join('、')}`}>思考 {levels[0]}–{levels[levels.length - 1]}</span> : null}
  </span>;
}

/**
 * Pick which of the account's models DSH offers. Models are grouped by maker in collapsible cards, two columns
 * each; a group's round button picks the whole group, the header picks everything, and the tabs narrow to new
 * models, picked ones, or ones that left the account. 「自動同步」 hands the list to the account instead.
 */
function Catalog({ models, selected, auto: initialAuto, close, apply }) {
  const availableById = useMemo(() => new Map(models.map(model => [model.id, model])), [models]);
  const resolvedSelected = useMemo(() => selected.map(model => {
    const id = requestModelIdForPublicModel(model.id);
    const resolved = { ...model, id, ...availableById.get(id) };
    if (model.input?.length) resolved.input = [...model.input];
    delete resolved.requestModelId;
    return resolved;
  }), [selected, availableById]);
  const isChat = model => model.chat ?? isChatModel(model.id);
  const chatIds = models.filter(isChat).map(model => model.id);
  const existingIds = new Set(resolvedSelected.map(model => model.id));
  const [auto, setAuto] = useState(initialAuto !== false);
  const [query, setQuery] = useState('');
  const [tab, setTab] = useState('all');
  const [collapsed, setCollapsed] = useState(new Set());
  const [checked, setChecked] = useState(() => new Set(initialAuto !== false || selected.length === 0 ? chatIds : existingIds));

  // Image, speech and embedding models are opt-in, so they never count as new.
  const newModels = models.filter(model => isChat(model) && !existingIds.has(model.id));
  const selectedModels = models.filter(model => checked.has(model.id));
  const removedModels = resolvedSelected.filter(model => !availableById.has(model.id));
  const allSelected = chatIds.length > 0 && chatIds.every(id => checked.has(id));
  const candidates = tab === 'new' ? newModels : tab === 'selected' ? selectedModels : tab === 'removed' ? removedModels : models;
  const needle = query.trim().toLowerCase();
  const rows = candidates.filter(model => `${model.id} ${model.name ?? ''}`.toLowerCase().includes(needle));
  const groups = new Map();
  for (const model of rows) {
    const brand = isChat(model) ? categorizeModelId(model.id, model.name) : NON_CHAT_GROUP;
    groups.set(brand, [...groups.get(brand) ?? [], model]);
  }
  const order = brand => { const index = MODEL_BRAND_ORDER.indexOf(brand); return index === -1 ? MODEL_BRAND_ORDER.length - 1 : index; };
  const groupNames = [...groups.keys()].sort((a, b) => order(a) - order(b) || a.localeCompare(b));

  /** Any hand change means a hand-picked list. */
  const edit = change => { setAuto(false); setChecked(previous => change(new Set(previous))); };
  const toggle = id => edit(next => { if (next.has(id)) next.delete(id); else next.add(id); return next; });
  /** 「全選」 picks every chat model; 「取消全選」 clears everything, opt-in models included. */
  const toggleAll = () => edit(next => { if (allSelected) next.clear(); else for (const id of chatIds) next.add(id); return next; });
  const toggleGroup = (brand, event) => {
    event.stopPropagation();
    const group = groups.get(brand) ?? [];
    const all = group.every(model => checked.has(model.id));
    edit(next => { for (const model of group) { if (all) next.delete(model.id); else next.add(model.id); } return next; });
  };
  const setAutomatic = on => { setAuto(on); if (on) setChecked(new Set(chatIds)); };
  const save = () => {
    if (auto) { apply({ auto: true }); return; }
    const existingById = new Map(resolvedSelected.map(model => [model.id, model]));
    const result = [];
    for (const model of models) {
      if (!checked.has(model.id)) continue;
      const existing = existingById.get(model.id);
      const name = cleanModelDisplayName(model.name);
      const candidate = { ...model };
      delete candidate.reasoningSource;
      delete candidate.chat;
      const merged = existing ? { ...existing, ...candidate } : candidate;
      if (name) merged.name = name;
      if (candidate.requestModelId === undefined) delete merged.requestModelId;
      result.push(merged);
      existingById.delete(model.id);
    }
    for (const [id, model] of existingById) if (checked.has(id)) result.push({ ...model });
    apply({ auto: false, models: result });
  };

  return <div className="aiapi-cat-overlay aiapi-lux" role="dialog" aria-modal="true" aria-label="選擇模型" onClick={close}>
    <div className="aiapi-cat aiapi-lux-card aiapi-lux-ripple" onClick={event => event.stopPropagation()}>
      <div className="aiapi-cat-head">
        <div className="aiapi-cat-title-row">
          <h3 className="aiapi-cat-title aiapi-lux-gold">選擇模型</h3>
          <div className="aiapi-row-actions">
            <button type="button" className="aiapi-lux-btn-quiet" onClick={toggleAll}>{allSelected ? '取消全選' : '全選'}</button>
            <button type="button" className="aiapi-cat-x" aria-label="關閉" onClick={close}>
              <svg width="18" height="18" viewBox="0 0 16 16" fill="none" aria-hidden><path d="M4 4L12 12M12 4L4 12" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" /></svg>
            </button>
          </div>
        </div>
        <div className="aiapi-cat-auto aiapi-lux-lite">
          <div className="aiapi-row-copy">
            <span className="aiapi-row-title">自動同步帳號的全部模型</span>
            <span className="aiapi-row-caption">{auto ? '帳號能用的對話模型全部加入；平台新增或下架時自動跟著變' : '只用你勾選的模型；上下文、圖片與思考程度仍會自動更新'}</span>
          </div>
          <Switch checked={auto} label="自動同步帳號的全部模型" onChange={setAutomatic} />
        </div>
        <label className="aiapi-cat-search">
          <svg width="14" height="14" viewBox="0 0 16 16" fill="none" aria-hidden><path d="M7 12C9.76 12 12 9.76 12 7C12 4.24 9.76 2 7 2C4.24 2 2 4.24 2 7C2 9.76 4.24 12 7 12Z" stroke="currentColor" strokeWidth="1.5" /><path d="M11 11L14.5 14.5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" /></svg>
          <input type="search" aria-label="搜尋模型" placeholder="搜尋模型名稱或 ID" value={query} onChange={event => setQuery(event.target.value)} />
        </label>
        <div className="aiapi-cat-tabs" aria-label="模型篩選">
          {[
            ['all', `全部模型（${models.length}）`],
            ['new', `新模型（${newModels.length}）`],
            ['selected', `已選模型（${selectedModels.length}）`],
            ...(removedModels.length ? [['removed', `已下架（${removedModels.length}）`]] : []),
          ].map(([id, label]) => <button type="button" className="aiapi-cat-tab" key={id} aria-pressed={tab === id} onClick={() => setTab(id)}>{label}</button>)}
        </div>
      </div>
      <div className="aiapi-cat-body">
        {groupNames.length === 0
          ? <div className="aiapi-cat-empty">{query ? '沒有符合搜尋條件的模型' : '這裡沒有模型'}</div>
          : groupNames.map(brand => {
            const group = groups.get(brand);
            const open = !collapsed.has(brand);
            const picked = group.filter(model => checked.has(model.id)).length;
            const all = picked === group.length;
            return <section className="aiapi-cat-group aiapi-lux-lite" key={brand}>
              <div className="aiapi-cat-group-head">
                <button type="button" className="aiapi-cat-group-toggle" aria-expanded={open} onClick={() => setCollapsed(previous => { const next = new Set(previous); if (next.has(brand)) next.delete(brand); else next.add(brand); return next; })}>
                  <span className="aiapi-cat-chevron" data-collapsed={open ? undefined : ''}><svg width="14" height="14" viewBox="0 0 16 16" fill="none" aria-hidden><path d="M4 6L8 10L12 6" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" /></svg></span>
                  <span className="aiapi-cat-group-title">{brand}（{group.length}）</span>
                </button>
                <div className="aiapi-cat-group-side">
                  <span>已選 {picked} / {group.length}</span>
                  <button type="button" className="aiapi-cat-group-toggle" aria-label={`${all ? '取消全選' : '全選'}${brand}`} aria-pressed={all} onClick={event => toggleGroup(brand, event)}>
                    <span className="aiapi-cat-check" data-on={all ? '' : undefined}>{all ? <svg width="12" height="12" viewBox="0 0 16 16" fill="none" aria-hidden><path d="M3.5 8.5L6.5 11.5L12.5 4.5" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" /></svg> : null}</span>
                  </button>
                </div>
              </div>
              {open ? <div className="aiapi-cat-grid">{group.map(model => {
                const name = cleanModelDisplayName(model.name);
                const on = checked.has(model.id);
                return <label className="aiapi-cat-item" key={model.id} title={model.id}>
                  <input type="checkbox" checked={on} onChange={() => toggle(model.id)} />
                  <span className="aiapi-cat-check" data-on={on ? '' : undefined}>{on ? <svg width="12" height="12" viewBox="0 0 16 16" fill="none" aria-hidden><path d="M3.5 8.5L6.5 11.5L12.5 4.5" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" /></svg> : null}</span>
                  <span className="aiapi-cat-model">
                    <span className="aiapi-cat-name">{name ?? model.id}</span>
                    {name && name !== model.id ? <span className="aiapi-cat-id">{model.id}</span> : null}
                    <CapabilityChips model={model} />
                  </span>
                </label>;
              })}</div> : null}
            </section>;
          })}
      </div>
      <div className="aiapi-cat-foot">
        <span className="aiapi-row-caption">{auto ? `自動同步 · ${chatIds.length} 個對話模型` : `已選 ${checked.size} 個模型`}</span>
        <div className="aiapi-row-actions">
          <button type="button" className="aiapi-lux-btn-quiet" onClick={close}>取消</button>
          <button type="button" className="aiapi-lux-btn" disabled={!auto && checked.size === 0} onClick={save}>{auto ? '套用自動同步' : '套用所選'}</button>
        </div>
      </div>
    </div>
  </div>;
}

/** Where image, audio and embedding models are listed: last, and off unless picked on purpose. */
const NON_CHAT_GROUP = '圖像、語音與嵌入（不用於對話）';

const MODEL_BRAND_ORDER = [
  'DeepSeek', 'GLM（智譜）', 'Kimi（月之暗面）', 'MiniMax', 'MiMo（小米）',
  'Hunyuan（騰訊混元）', 'Muse（Meta）', 'Qwen（阿里通義）', 'OpenAI',
  'Anthropic', 'Google（Gemini）', 'xAI（Grok）', 'Doubao（豆包）',
  'LongCat（美團）', 'Mistral', 'Other', NON_CHAT_GROUP,
];

function cleanModelDisplayName(name) {
  if (typeof name !== 'string' || name.trim().length === 0) return undefined;
  return name.replace(/^(?:(?:[a-zA-Z0-9\s._-]+):\s+)/, '').trim() || name;
}

function categorizeModelId(id, name) {
  const combined = `${id} ${name ?? ''}`.toLowerCase();
  if (combined.includes('deepseek')) return 'DeepSeek';
  if (['glm', 'chatglm', 'zhipu', 'z.ai'].some(value => combined.includes(value))) return 'GLM（智譜）';
  if (['kimi', 'moonshot'].some(value => combined.includes(value))) return 'Kimi（月之暗面）';
  if (['hunyuan', 'hy4', 'hy3', 'tencent'].some(value => combined.includes(value))) return 'Hunyuan（騰訊混元）';
  if (['minimax', 'abab'].some(value => combined.includes(value))) return 'MiniMax';
  if (['mimo', 'xiaomi'].some(value => combined.includes(value))) return 'MiMo（小米）';
  if (combined.includes('muse')) return 'Muse（Meta）';
  if (['meta', 'llama'].some(value => combined.includes(value))) return 'Meta';
  if (['qwen', 'qwq', 'tongyi', 'alibaba'].some(value => combined.includes(value))) return 'Qwen（阿里通義）';
  if (['claude', 'anthropic'].some(value => combined.includes(value))) return 'Anthropic';
  if (['gpt', 'o1', 'o3', 'o4', 'o5', 'openai', 'chatgpt'].some(value => combined.includes(value))) return 'OpenAI';
  if (['gemini', 'gemma', 'google'].some(value => combined.includes(value))) return 'Google（Gemini）';
  if (['grok', 'xai', 'x-ai'].some(value => combined.includes(value))) return 'xAI（Grok）';
  if (['doubao', 'seedance', 'bytedance', 'volcengine'].some(value => combined.includes(value))) return 'Doubao（豆包）';
  if (['longcat', 'meituan'].some(value => combined.includes(value))) return 'LongCat（美團）';
  if (['mistral', 'codestral', 'pixtral', 'ministral'].some(value => combined.includes(value))) return 'Mistral';
  if (id.includes('/')) return id.split('/')[0].replace(/^./, character => character.toUpperCase());
  return 'Other';
}
