/**
 * The AIAPI look: gilded edges that slowly turn, water ripples under the important cards, gold lettering with a
 * moving sheen, and a cyan neon pulse for "live" states. Everything is scoped under `.aiapi-lux`, so DSH's own
 * screens are untouched; light and dark each get their own palette, and "reduce motion" stills every animation.
 */

export const LUX_CSS = `
@property --aiapi-spin{syntax:'<angle>';inherits:false;initial-value:0deg}
@keyframes aiapi-spin{to{--aiapi-spin:360deg}}
@keyframes aiapi-sheen{from{background-position:0% 50%}to{background-position:220% 50%}}
@keyframes aiapi-ripple{0%{transform:translate(50%,50%) scale(.35);opacity:.0}12%{opacity:.55}100%{transform:translate(50%,50%) scale(1.6);opacity:0}}
@keyframes aiapi-pulse{0%{transform:scale(1);opacity:.7}100%{transform:scale(3.2);opacity:0}}
@keyframes aiapi-wave{from{transform:translate(-50%,-50%) scale(0);opacity:.55}to{transform:translate(-50%,-50%) scale(1);opacity:0}}
@keyframes aiapi-flow{from{background-position:0 0}to{background-position:200% 0}}

.aiapi-lux{
  --lux-text:#f8edd3;--lux-dim:rgba(248,237,211,.62);--lux-faint:rgba(248,237,211,.38);
  --lux-gold-hi:#fff2c6;--lux-gold:#e8bb57;--lux-gold-mid:#c8922c;--lux-gold-deep:#8d5d16;
  --lux-neon:#5ff3ff;--lux-neon-glow:rgba(95,243,255,.55);--lux-rose:#ff7ad9;
  --lux-card:linear-gradient(155deg,rgba(40,30,12,.94) 0%,rgba(17,13,7,.97) 55%,rgba(10,9,7,.98) 100%);
  --lux-card-lite:linear-gradient(160deg,rgba(32,25,12,.72),rgba(14,12,8,.86));
  --lux-line:rgba(232,187,87,.22);--lux-line-strong:rgba(232,187,87,.5);
  --lux-glow:0 0 0 1px rgba(232,187,87,.07),0 18px 48px -18px rgba(232,187,87,.42),inset 0 1px 0 rgba(255,242,198,.10);
  --lux-ink:#241602;
  /* DSH primitives inside the AIAPI surfaces pick up the gold. */
  --dsw-alias-brand-primary:var(--lux-gold);--dsw-alias-button-primary-fill:var(--lux-gold);--dsw-alias-button-primary-hover:var(--lux-gold-hi);
  --dsw-alias-label-primary-foreground:var(--lux-ink);--dsw-alias-button-info-fill:var(--lux-gold);
}
body:not([data-ds-dark-theme]) .aiapi-lux{
  --lux-text:#2a1b04;--lux-dim:rgba(42,27,4,.64);--lux-faint:rgba(42,27,4,.42);
  --lux-gold-hi:#d79b2a;--lux-gold:#b98019;--lux-gold-mid:#9a6a10;--lux-gold-deep:#6f4708;
  --lux-neon:#079fb8;--lux-neon-glow:rgba(7,159,184,.35);--lux-rose:#c2338f;
  --lux-card:linear-gradient(155deg,#fffdf7 0%,#fdf4de 55%,#f8ead0 100%);
  --lux-card-lite:linear-gradient(160deg,rgba(255,252,243,.92),rgba(250,240,216,.92));
  --lux-line:rgba(185,128,25,.24);--lux-line-strong:rgba(185,128,25,.55);
  --lux-glow:0 0 0 1px rgba(185,128,25,.08),0 16px 40px -20px rgba(185,128,25,.45),inset 0 1px 0 rgba(255,255,255,.7);
  --lux-ink:#fffaf0;
}

/* Cards: a gilded edge that slowly turns, over a deep warm glass. */
.aiapi-lux-card{position:relative;isolation:isolate;overflow:hidden;border-radius:16px;border:1px solid transparent;color:var(--lux-text);
  background:var(--lux-card) padding-box,conic-gradient(from var(--aiapi-spin),var(--lux-gold-deep),var(--lux-gold-hi) 12%,var(--lux-gold) 22%,var(--lux-gold-deep) 38%,var(--lux-neon) 50%,var(--lux-gold-deep) 62%,var(--lux-gold) 78%,var(--lux-gold-hi) 88%,var(--lux-gold-deep)) border-box;
  box-shadow:var(--lux-glow);animation:aiapi-spin 9s linear infinite}
.aiapi-lux-lite{position:relative;border-radius:14px;border:1px solid var(--lux-line);background:var(--lux-card-lite);color:var(--lux-text);transition:border-color .25s,box-shadow .25s}
.aiapi-lux-lite:hover{border-color:var(--lux-line-strong);box-shadow:0 0 0 1px rgba(232,187,87,.06),0 10px 30px -18px rgba(232,187,87,.5)}
.aiapi-lux .aiapi-row+.aiapi-row{border-top:1px solid var(--lux-line)}
.aiapi-lux .aiapi-row-caption,.aiapi-lux .aiapi-muted{color:var(--lux-dim)}
.aiapi-lux .aiapi-row-title,.aiapi-lux .aiapi-name{color:var(--lux-text)}

/* Water ripples: two staggered ring sets spreading from the lower right. */
.aiapi-lux-ripple::before,.aiapi-lux-ripple::after{content:'';position:absolute;z-index:-1;right:0;bottom:0;width:520px;height:520px;border-radius:50%;pointer-events:none;
  background:repeating-radial-gradient(circle,transparent 0 22px,rgba(232,187,87,.16) 23px 24px,transparent 25px 46px);
  animation:aiapi-ripple 6.5s cubic-bezier(.2,.6,.3,1) infinite}
.aiapi-lux-ripple::after{animation-delay:3.25s;background:repeating-radial-gradient(circle,transparent 0 30px,rgba(95,243,255,.10) 31px 32px,transparent 33px 60px)}

/* Gold lettering with a slow moving sheen. */
.aiapi-lux-gold{background:linear-gradient(100deg,var(--lux-gold-deep) 0%,var(--lux-gold) 16%,var(--lux-gold-hi) 28%,var(--lux-gold) 42%,var(--lux-gold-mid) 58%,var(--lux-gold-hi) 74%,var(--lux-gold-deep) 100%);
  background-size:220% 100%;-webkit-background-clip:text;background-clip:text;color:transparent;animation:aiapi-sheen 6s linear infinite;
  filter:drop-shadow(0 0 14px rgba(232,187,87,.28))}
.aiapi-lux-eyebrow{font-size:11px;letter-spacing:.18em;text-transform:uppercase;color:var(--lux-gold)}

/* A live state: a neon dot with a ring that keeps spreading. */
.aiapi-lux-pulse{position:relative;display:inline-block;width:8px;height:8px;border-radius:50%;flex:none;background:var(--lux-neon);box-shadow:0 0 10px var(--lux-neon-glow),0 0 2px var(--lux-neon)}
.aiapi-lux-pulse::after{content:'';position:absolute;inset:0;border-radius:50%;border:1px solid var(--lux-neon);animation:aiapi-pulse 2.4s ease-out infinite}
.aiapi-lux-pulse[data-tone=warn]{background:#ffb547;box-shadow:0 0 10px rgba(255,181,71,.6)}
.aiapi-lux-pulse[data-tone=warn]::after{border-color:#ffb547}
.aiapi-lux-pulse[data-tone=error]{background:#ff5d73;box-shadow:0 0 10px rgba(255,93,115,.6)}
.aiapi-lux-pulse[data-tone=error]::after{border-color:#ff5d73}
.aiapi-lux-pulse[data-tone=idle]{background:var(--lux-faint);box-shadow:none}
.aiapi-lux-pulse[data-tone=idle]::after{display:none}

/* Buttons: solid gold and a gilded outline; both answer a press with a ripple from the pointer. */
.aiapi-lux-btn,.aiapi-lux-btn-line{position:relative;overflow:hidden;display:inline-flex;align-items:center;justify-content:center;gap:6px;height:32px;padding:0 14px;border-radius:999px;font:inherit;font-size:13px;font-weight:550;cursor:pointer;white-space:nowrap;transition:transform .15s,box-shadow .25s,filter .2s}
.aiapi-lux-btn{border:none;color:var(--lux-ink);background:linear-gradient(120deg,var(--lux-gold-deep),var(--lux-gold) 30%,var(--lux-gold-hi) 52%,var(--lux-gold) 72%,var(--lux-gold-mid));background-size:200% 100%;
  box-shadow:0 6px 20px -8px rgba(232,187,87,.75),inset 0 1px 0 rgba(255,255,255,.35);animation:aiapi-flow 7s linear infinite}
.aiapi-lux-btn:hover{filter:brightness(1.08);box-shadow:0 8px 26px -8px rgba(232,187,87,.95),0 0 0 1px rgba(255,242,198,.25)}
.aiapi-lux-btn-line{border:1px solid var(--lux-line-strong);color:var(--lux-gold-hi);background:rgba(232,187,87,.06)}
body:not([data-ds-dark-theme]) .aiapi-lux-btn-line{color:var(--lux-gold-mid)}
.aiapi-lux-btn-line:hover{background:rgba(232,187,87,.14);box-shadow:0 0 18px -4px rgba(232,187,87,.6)}
.aiapi-lux-btn:active,.aiapi-lux-btn-line:active{transform:scale(.97)}
.aiapi-lux-btn:disabled,.aiapi-lux-btn-line:disabled{opacity:.45;cursor:default;filter:none;box-shadow:none}
.aiapi-lux-btn-quiet{border:none;background:transparent;color:var(--lux-dim);font:inherit;font-size:13px;cursor:pointer;padding:0 8px;height:32px;border-radius:999px}
.aiapi-lux-btn-quiet:hover{color:var(--lux-text);background:rgba(232,187,87,.08)}
.aiapi-wave{position:absolute;border-radius:50%;pointer-events:none;background:radial-gradient(circle,rgba(255,255,255,.55),rgba(255,242,198,.25) 40%,transparent 70%);animation:aiapi-wave .7s ease-out forwards}

/* A quota bar filled with flowing gold. */
.aiapi-lux-meter{position:relative;width:160px;height:6px;border-radius:999px;background:rgba(232,187,87,.14);overflow:hidden}
.aiapi-lux-meter>span{position:absolute;inset:0 auto 0 0;border-radius:999px;background:linear-gradient(90deg,var(--lux-gold-deep),var(--lux-gold),var(--lux-gold-hi),var(--lux-gold));background-size:200% 100%;animation:aiapi-flow 3s linear infinite;box-shadow:0 0 12px rgba(232,187,87,.6)}
.aiapi-lux-meter[data-level=low]>span{background:linear-gradient(90deg,#a3560d,#ffb547,#ffd58a);background-size:200% 100%}
.aiapi-lux-meter[data-level=empty]>span{background:#ff5d73}

.aiapi-lux-chip{display:inline-flex;align-items:center;gap:4px;height:20px;padding:0 8px;border-radius:999px;font-size:11px;line-height:20px;border:1px solid var(--lux-line);color:var(--lux-dim);background:rgba(232,187,87,.05);white-space:nowrap}
.aiapi-lux-chip[data-tone=gold]{color:var(--lux-gold-hi);border-color:var(--lux-line-strong)}
body:not([data-ds-dark-theme]) .aiapi-lux-chip[data-tone=gold]{color:var(--lux-gold-mid)}
.aiapi-lux-chip[data-tone=neon]{color:var(--lux-neon);border-color:rgba(95,243,255,.35);background:rgba(95,243,255,.06)}

@media (prefers-reduced-motion: reduce){
  .aiapi-lux-card,.aiapi-lux-gold,.aiapi-lux-btn,.aiapi-lux-meter>span,.aiapi-lux-ripple::before,.aiapi-lux-ripple::after,.aiapi-lux-pulse::after{animation:none!important}
  .aiapi-wave{display:none}
}
`;

/**
 * A press on any gilded button sends a ripple out from the pointer. One delegated listener serves every surface.
 * @param ctx - client plugin context; the listener is removed with it.
 */
let rippleUsers = 0;
let removeRipples;

export function installRipples(ctx) {
  ctx.effect(() => {
    rippleUsers += 1;
    if (rippleUsers === 1) removeRipples = listenForPresses();
    return () => {
      rippleUsers -= 1;
      if (rippleUsers === 0) removeRipples?.();
    };
  }, 'aiapi ripples');
}

/** One delegated listener, shared by every surface that uses gilded buttons. */
function listenForPresses() {
  {
    const onPress = event => {
      const button = event.target instanceof Element ? event.target.closest('.aiapi-lux-btn,.aiapi-lux-btn-line') : null;
      if (button === null || button.disabled) return;
      const box = button.getBoundingClientRect();
      const size = Math.max(box.width, box.height) * 2.4;
      const wave = document.createElement('span');
      wave.className = 'aiapi-wave';
      Object.assign(wave.style, { width: `${size}px`, height: `${size}px`, left: `${event.clientX - box.left}px`, top: `${event.clientY - box.top}px` });
      button.append(wave);
      setTimeout(() => wave.remove(), 750);
    };
    document.addEventListener('pointerdown', onPress, true);
    return () => document.removeEventListener('pointerdown', onPress, true);
  }
}
