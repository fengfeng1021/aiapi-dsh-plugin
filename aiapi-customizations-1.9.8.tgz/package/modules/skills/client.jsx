import React, { useEffect, useState } from 'react';
import { showToast } from '../toast.jsx';
import { Button, Input, Modal, SegmentedControl, Switch, host, installStyle } from '../ui/kit.jsx';
import { LUX_CSS, installRipples } from '../ui/lux.js';

const PANEL_ID = 'aiapi-skills';
const SOURCE_LABEL = { 'user-dsh': '全域', 'user-agents': '全域 · .agents', 'project-dsh': '工作區', 'project-agents': '工作區 · .agents', custom: '自訂資料夾', bundled: '插件內建', runtime: '執行中載入' };

const SKILLS_CSS = `
.aiapi-sk{height:100%;overflow:auto;box-sizing:border-box;padding:28px 32px 48px;color:var(--dsw-alias-label-primary);font-size:13px;line-height:20px}
.aiapi-sk-inner{max-width:880px;margin:0 auto;display:flex;flex-direction:column;gap:16px}
.aiapi-sk-head{display:flex;align-items:flex-start;justify-content:space-between;gap:16px;flex-wrap:wrap}
.aiapi-sk-title{font-size:24px;line-height:32px;font-weight:700;margin:0;letter-spacing:.04em}
.aiapi-sk-sub{color:var(--lux-dim);font-size:12px;line-height:18px;margin-top:2px;max-width:560px}
.aiapi-sk-tools{display:flex;align-items:center;gap:10px;flex-wrap:wrap}
.aiapi-sk-tools>:first-child{flex:1;min-width:220px}
.aiapi-sk-list{display:flex;flex-direction:column;gap:8px}
.aiapi-sk-item{padding:12px 16px}
.aiapi-sk-row{display:flex;align-items:flex-start;justify-content:space-between;gap:16px}
.aiapi-sk-name{font-size:14px;font-weight:500;font-family:var(--dsh-font-family-code,ui-monospace,monospace)}
.aiapi-sk-tags{display:inline-flex;gap:6px;flex-wrap:wrap;margin-left:8px;vertical-align:middle}
.aiapi-sk-desc{color:var(--lux-dim);margin-top:4px;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden}
.aiapi-sk-desc[data-open]{-webkit-line-clamp:unset}
.aiapi-sk-meta{display:flex;align-items:center;justify-content:space-between;gap:12px;margin-top:8px;flex-wrap:wrap}
.aiapi-sk-path{color:var(--lux-faint);font-size:11px;line-height:16px;word-break:break-all;min-width:0;flex:1}
.aiapi-sk-actions{display:flex;gap:6px;flex-wrap:wrap}
.aiapi-sk-switch{display:flex;align-items:center;gap:8px;flex:none;color:var(--lux-dim);font-size:12px}
.aiapi-sk-note{color:var(--dsw-alias-state-warn-primary);font-size:12px;margin-top:6px}
.aiapi-sk-empty{padding:40px 0;text-align:center;color:var(--lux-dim)}
.aiapi-sk-plugin-skills{margin-top:10px;display:flex;flex-direction:column;gap:6px;border-top:1px solid var(--lux-line);padding-top:10px}
.aiapi-sk-plugin-skill{display:flex;gap:8px;min-width:0}
.aiapi-sk-plugin-skill .aiapi-sk-name{font-size:12px;flex:none}
.aiapi-sk-plugin-skill .aiapi-sk-desc{margin:0;font-size:12px;-webkit-line-clamp:1}
.aiapi-sk-form{display:flex;flex-direction:column;gap:12px}
.aiapi-sk-versions{display:flex;flex-direction:column;max-height:320px;overflow:auto}
.aiapi-sk-version{display:flex;align-items:center;justify-content:space-between;gap:12px;padding:6px 0;border-bottom:.5px solid var(--dsw-alias-border-l2);font-variant-numeric:tabular-nums}
`;

/**
 * Skills manager page in the sidebar: every discovered skill with its source, whether the AI may use it on its own,
 * its folder, backups and soft removal, plus import from a folder. Owned by the client plugin scope.
 * @param ctx - client plugin context.
 */
export function apply(ctx) {
  installStyle(ctx, 'lux', LUX_CSS);
  installStyle(ctx, 'skills', SKILLS_CSS);
  installRipples(ctx);
  const revealFolder = async path => {
    let result;
    try { result = await ctx.remote.session.openWorkspacePath({ path, action: 'reveal' }); } catch {
      result = undefined; // an unreachable Host fails like a refused path
    }
    if (!result?.ok) showToast('error', `無法開啟資料夾：${path}`);
  };
  ctx.slots.inject('main', () => ctx.slots.register({ name: 'main', key: PANEL_ID, inject: () => ({ revealFolder }) }, SkillsPanel));
  ctx.slots.inject('sidebar.panellist', () => ctx.slots.register({ name: 'sidebar.panellist', id: PANEL_ID, order: 32, label: 'Skills 管理' }, SkillsIcon));
}

function SkillsIcon({ size = 20 }) {
  return <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" aria-hidden="true">
    <path d="M5 4h10l4 4v12H5z" strokeLinejoin="round" /><path d="M15 4v4h4M8 12h8M8 16h6" />
  </svg>;
}

const skillsApi = body => host('api/aiapi/skills', body);

/** Which tab a skill belongs to. */
const kindOf = skill => skill.source?.startsWith('project') ? 'workspace'
  : skill.source?.startsWith('user') || (skill.source === 'custom' && skill.editable) ? 'mine' : 'plugin';

/** One of the user's own skills: what it is, where it lives, and what can be done with it. */
function SkillCard({ skill, shadow, run, revealFolder, openVersions, askRemove }) {
  const [open, setOpen] = useState(false);
  const folder = skill.path ? skill.path.replace(/[\\/]SKILL\.md$/i, '') : null;
  return <div className="aiapi-sk-item aiapi-lux-lite">
    <div className="aiapi-sk-row">
      <div style={{ minWidth: 0 }}>
        <span className="aiapi-sk-name">{skill.name}</span>
        <span className="aiapi-sk-tags">
          <span className="aiapi-lux-chip" data-tone="gold">{SOURCE_LABEL[skill.source] ?? skill.source}{skill.workspace ? ` · ${skill.workspace}` : ''}</span>
          {skill.link ? <span className="aiapi-lux-chip">連結</span> : null}
          {!skill.userInvocable ? <span className="aiapi-lux-chip">不能用 / 叫出</span> : null}
        </span>
        <div className="aiapi-sk-desc" data-open={open ? '' : undefined} onClick={() => setOpen(!open)}>{skill.description}</div>
      </div>
      {skill.editable
        ? <label className="aiapi-sk-switch">AI 自動使用
          <Switch checked={skill.modelInvocable} label={`${skill.name}：AI 自動使用`} onChange={on => run({ action: 'toggle', path: skill.path, modelInvocable: on }, on ? `AI 可以自己使用 ${skill.name} 了` : `${skill.name} 只在你用 / 叫出時使用`)} />
        </label>
        : null}
    </div>
    {shadow ? <div className="aiapi-sk-note">{shadow}</div> : null}
    <div className="aiapi-sk-meta">
      <span className="aiapi-sk-path" title={skill.link ? `經由連結 ${skill.link} 載入` : undefined}>{folder ?? `在輸入框打 /${skill.name} 叫出`}</span>
      <div className="aiapi-sk-actions">
        {folder ? <Button variant="ghost" size="sm" onClick={() => revealFolder(folder)}>開啟資料夾</Button> : null}
        {skill.editable ? <>
          <Button variant="ghost" size="sm" onClick={() => run({ action: 'backup', path: skill.path }, `已備份 ${skill.name}`)}>備份</Button>
          <Button variant="ghost" size="sm" onClick={() => openVersions(skill)}>版本紀錄</Button>
          <Button variant="ghost" size="sm" onClick={() => askRemove(skill)}>{skill.link ? '移除連結' : '移除'}</Button>
        </> : null}
      </div>
    </div>
  </div>;
}

/** All skills one plugin brings, with one switch for whether the AI may use them on its own. */
function PluginCard({ plugin, skills, manual, run }) {
  const [open, setOpen] = useState(false);
  return <div className="aiapi-sk-item aiapi-lux-lite">
    <div className="aiapi-sk-row">
      <div style={{ minWidth: 0 }}>
        <span className="aiapi-sk-name">{plugin}</span>
        <span className="aiapi-sk-tags"><span className="aiapi-lux-chip" data-tone="gold">插件內建 · {skills.length} 個</span></span>
        <div className="aiapi-sk-desc">隨插件更新，不能在這裡修改內容；可以決定 AI 能不能自己使用它們。</div>
      </div>
      <label className="aiapi-sk-switch">AI 自動使用
        <Switch checked={!manual} label={`${plugin}：AI 自動使用`} onChange={on => run({ action: 'manual-only', provider: plugin, manualOnly: !on }, on ? `AI 可以自己使用 ${plugin} 的 skill 了` : `${plugin} 的 skill 只在你用 / 叫出時使用`)} />
      </label>
    </div>
    <div className="aiapi-sk-meta">
      <span className="aiapi-sk-path">{skills.map(skill => `/${skill.name}`).slice(0, 4).join('　')}{skills.length > 4 ? ` 等 ${skills.length} 個` : ''}</span>
      <Button variant="ghost" size="sm" onClick={() => setOpen(!open)}>{open ? '收起' : '查看全部'}</Button>
    </div>
    {open ? <div className="aiapi-sk-plugin-skills">
      {skills.map(skill => <div className="aiapi-sk-plugin-skill" key={`${skill.provider}:${skill.name}`}>
        <span className="aiapi-sk-name">/{skill.name}</span>
        <span className="aiapi-sk-desc" title={skill.description}>{skill.description}</span>
      </div>)}
    </div> : null}
  </div>;
}

/** Import a skill folder into the global folder or into one workspace. */
function ImportDialog({ workspaces, close, run }) {
  const [from, setFrom] = useState('');
  const [scope, setScope] = useState('user');
  const [cwd, setCwd] = useState('');
  const ready = from.trim() !== '' && (scope === 'user' || cwd !== '');
  const submit = async () => {
    if (await run({ action: 'import', from: from.trim(), scope, cwd }, '已匯入')) close();
  };
  return <Modal open title="匯入 skill" description="貼上 skill 資料夾的完整路徑（資料夾裡要有 SKILL.md）。已有同名 skill 時，舊的會先備份。" closeLabel="關閉" onClose={close}
    footer={<div className="aiapi-row-actions"><Button variant="ghost" onClick={close}>取消</Button><Button variant="primary" disabled={!ready} onClick={() => { void submit(); }}>匯入</Button></div>}>
    <div className="aiapi-sk-form">
      <Input aria-label="skill 資料夾路徑" placeholder="/Users/you/skills/my-skill" value={from} onChange={event => setFrom(event.target.value)} />
      <SegmentedControl id="aiapi-sk-scope" label="放到" value={scope} options={[{ value: 'user', label: '全域（所有對話）' }, { value: 'workspace', label: '某個工作區', disabled: workspaces.length === 0 }]} onChange={setScope} />
      {scope === 'workspace'
        ? <select className="aiapi-select" aria-label="工作區" value={cwd} onChange={event => setCwd(event.target.value)}>
          <option value="">選擇工作區</option>
          {workspaces.map(workspace => <option key={workspace.id} value={workspace.cwd}>{workspace.name}</option>)}
        </select>
        : null}
    </div>
  </Modal>;
}

/** Backups of one skill, newest first, each restorable (the current version is backed up first). */
function VersionsDialog({ skill, close, run }) {
  const [versions, setVersions] = useState();
  useEffect(() => {
    void skillsApi({ action: 'backups', name: skill.name }).then(value => setVersions(value.backups ?? []), failure => { showToast('error', failure.message); close(); });
  }, [skill]);
  const label = stamp => stamp.replace(/^(\d{4})(\d{2})(\d{2})-(\d{2})(\d{2})(\d{2})(\d{3})?(.*)$/, '$1/$2/$3 $4:$5:$6');
  return <Modal open title={`${skill.name} 的版本紀錄`} description="還原前，目前的版本也會先備份，所以隨時可以再換回來。" closeLabel="關閉" onClose={close}
    footer={<Button variant="ghost" onClick={close}>關閉</Button>}>
    {versions === undefined ? <div className="aiapi-muted">讀取中…</div>
      : versions.length === 0 ? <div className="aiapi-muted">還沒有備份。每次修改前會自動備份，也可以手動按「備份」。</div>
        : <div className="aiapi-sk-versions">{versions.map(version => <div className="aiapi-sk-version" key={version}>
          <span>{label(version)}</span>
          <Button variant="outline" size="sm" onClick={() => { void run({ action: 'restore', path: skill.path, backup: version }, `已還原 ${skill.name}`).then(done => { if (done) close(); }); }}>還原到這版</Button>
        </div>)}</div>}
  </Modal>;
}

/** Confirmation before moving a skill to the trash folder or dropping its link. */
function RemoveDialog({ skill, trash, close, run }) {
  return <Modal open title={skill.link ? `移除 ${skill.name} 的連結？` : `移除 ${skill.name}？`}
    description={skill.link ? '只移除 skills 資料夾裡的連結，實際的資料夾會留在原處。' : `會移到回收區（${trash}），需要時可以從那裡拿回來。`}
    closeLabel="取消" onClose={close}
    footer={<div className="aiapi-row-actions"><Button variant="ghost" onClick={close}>取消</Button><Button variant="primary" onClick={() => { void run({ action: 'remove', path: skill.path }, skill.link ? '已移除連結' : '已移到回收區').then(close); }}>移除</Button></div>} />;
}

function SkillsPanel({ revealFolder }) {
  const [data, setData] = useState();
  const [error, setError] = useState('');
  const [filter, setFilter] = useState('');
  const [tab, setTab] = useState('mine');
  const [busy, setBusy] = useState(false);
  const [dialog, setDialog] = useState();
  const refresh = async () => {
    try { setData(await skillsApi()); setError(''); }
    catch (failure) { setError(failure instanceof Error ? failure.message : String(failure)); }
  };
  useEffect(() => { void refresh(); }, []);
  /** Show a switch's new position at once; the next listing confirms or corrects it. */
  const optimistic = body => setData(current => current === undefined ? current : {
    ...current,
    skills: body.action === 'toggle' ? current.skills.map(skill => skill.path === body.path ? { ...skill, modelInvocable: body.modelInvocable } : skill) : current.skills,
    manualOnlyProviders: body.action === 'manual-only'
      ? (body.manualOnly ? [...new Set([...current.manualOnlyProviders ?? [], body.provider])] : (current.manualOnlyProviders ?? []).filter(name => name !== body.provider))
      : current.manualOnlyProviders,
  });
  /** Run one change; returns whether it worked. */
  const run = async (body, done) => {
    if (busy) return false;
    setBusy(true);
    const before = data;
    optimistic(body);
    try {
      const value = await skillsApi(body);
      showToast('info', done + (value.previousBackup ? '（原本的版本已備份）' : ''));
      if (body.action !== 'toggle' && body.action !== 'manual-only') await refresh();
      // DSH re-reads skill files on its own schedule; a second listing shortly after picks up the change.
      setTimeout(() => { void refresh(); }, 1500);
      return true;
    } catch (failure) {
      setData(before);
      showToast('error', failure instanceof Error ? failure.message : String(failure));
      return false;
    } finally {
      setBusy(false);
    }
  };
  const query = filter.trim().toLowerCase();
  const matches = skill => query === '' || [skill.name, skill.description, skill.origin, skill.provider, skill.workspace]
    .filter(Boolean).some(value => String(value).toLowerCase().includes(query));
  const all = (data?.skills ?? []).filter(matches);
  const counts = { mine: 0, workspace: 0, plugin: 0 };
  for (const skill of all) counts[kindOf(skill)] += 1;
  const list = all.filter(skill => kindOf(skill) === tab).sort((a, b) => a.name.localeCompare(b.name));
  // A workspace skill replaces the global one with the same name in that workspace's conversations.
  const shadowOf = skill => {
    if (skill.workspace) return data.skills.some(other => other.name === skill.name && !other.workspace) ? '在這個工作區的對話中，會取代同名的全域 skill。' : undefined;
    const places = data.skills.filter(other => other.name === skill.name && other.workspace).map(other => `「${other.workspace}」`);
    return places.length ? `在 ${places.join('、')} 工作區的對話中，會改用該工作區的同名 skill。` : undefined;
  };
  const plugins = new Map();
  if (tab === 'plugin') for (const skill of list) {
    const plugin = skill.origin ?? skill.provider ?? '其他';
    plugins.set(plugin, [...plugins.get(plugin) ?? [], skill]);
  }

  return <div className="aiapi-sk aiapi-lux"><div className="aiapi-sk-inner">
    <div className="aiapi-sk-head">
      <div>
        <h1 className="aiapi-sk-title aiapi-lux-gold">Skills</h1>
        <div className="aiapi-sk-sub">Skill 是給 AI 的工作說明書。開啟「AI 自動使用」時，AI 會在合適的時候自己讀取；關掉後只在你於輸入框打 / 叫出時使用。每次修改前都會自動備份。</div>
      </div>
      <div className="aiapi-row-actions">
        {data ? <button type="button" className="aiapi-lux-btn-line" onClick={() => revealFolder(data.userRoot)}>開啟 skills 資料夾</button> : null}
        <button type="button" className="aiapi-lux-btn" disabled={busy || !data} onClick={() => setDialog({ kind: 'import' })}>匯入 skill</button>
      </div>
    </div>
    <div className="aiapi-sk-tools">
      <Input type="search" aria-label="搜尋 skill" placeholder="搜尋名稱、說明或插件" value={filter} onChange={event => setFilter(event.target.value)} />
      <SegmentedControl id="aiapi-sk-tab" label="分類" value={tab} onChange={setTab} options={[
        { value: 'mine', label: `我的 ${counts.mine}` },
        { value: 'workspace', label: `工作區 ${counts.workspace}` },
        { value: 'plugin', label: `插件 ${counts.plugin}` },
      ]} />
    </div>
    {error !== '' ? <div className="aiapi-error-text" role="alert">{error}</div> : null}
    {data === undefined && error === '' ? <div className="aiapi-sk-empty">讀取中…</div> : null}
    {data !== undefined && list.length === 0
      ? <div className="aiapi-sk-empty">{query !== '' ? `沒有符合「${filter}」的 skill。` : tab === 'mine' ? '還沒有自己的 skill。按「匯入 skill」加入一個。' : tab === 'workspace' ? '工作區裡沒有 skill。' : '沒有插件提供 skill。'}</div>
      : null}
    <div className="aiapi-sk-list">
      {tab === 'plugin'
        ? [...plugins].map(([plugin, skills]) => <PluginCard key={plugin} plugin={plugin} skills={skills} manual={data.manualOnlyProviders?.includes(plugin) ?? false} run={run} />)
        : list.map(skill => <SkillCard key={skill.path ?? `${skill.provider}:${skill.name}`} skill={skill} shadow={shadowOf(skill)} run={run} revealFolder={revealFolder}
          openVersions={target => setDialog({ kind: 'versions', skill: target })} askRemove={target => setDialog({ kind: 'remove', skill: target })} />)}
    </div>
    {dialog?.kind === 'import' ? <ImportDialog workspaces={data?.workspaces ?? []} close={() => setDialog(undefined)} run={run} /> : null}
    {dialog?.kind === 'versions' ? <VersionsDialog skill={dialog.skill} close={() => setDialog(undefined)} run={run} /> : null}
    {dialog?.kind === 'remove' ? <RemoveDialog skill={dialog.skill} trash={data?.trash ?? ''} close={() => setDialog(undefined)} run={run} /> : null}
  </div></div>;
}
