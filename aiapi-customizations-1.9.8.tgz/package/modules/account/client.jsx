/**
 * AIAPI account and balance, inside DSH's own 「账号与余额」 settings page.
 *
 * DSH registers that page (section id `account`) only while a DeepSeek account is signed in. This module
 * registers a section with the same id at a lower priority: with no DeepSeek login it is the page, and once
 * DeepSeek registers its own, that one wins the slot and the AIAPI block is placed inside it instead. Either way
 * there is exactly one 「账号与余额」 entry, never a separate AIAPI page.
 */
import React, { useEffect, useState } from 'react';
import { createRoot } from 'react-dom/client';
import { Logo } from '../../../aiapi-brand/client.jsx';
import { balanceFlag, setBalanceFlag } from '../features/balance-flag.js';
import {
  AIAPI_CONSOLE, KIT_CSS, Switch, Tooltip,
  accountStore, installStyle, money, openSettings, pluginSettings, quotaShare, useAccount,
} from '../ui/kit.jsx';
import { LUX_CSS, installRipples } from '../ui/lux.js';

/** DSH's own label for the page, so the navigation entry reads the same whoever provides it. */
const ACCOUNT_LABEL = '账号与余额';

const ACCOUNT_CSS = `
.aiapi-inline{margin-top:16px}
.aiapi-hero{padding:18px 20px 16px;display:flex;flex-direction:column;gap:14px}
.aiapi-hero-top{display:flex;align-items:center;justify-content:space-between;gap:12px}
.aiapi-hero-mark{display:inline-flex;padding:6px;border-radius:14px;background:radial-gradient(circle at 50% 40%,rgba(232,187,87,.22),transparent 70%);box-shadow:0 0 22px -6px rgba(232,187,87,.6)}
.aiapi-hero-name{font-size:16px;font-weight:650;letter-spacing:.06em}
.aiapi-hero-sub{display:flex;align-items:center;gap:8px;flex-wrap:wrap;font-size:12px;line-height:18px;color:var(--lux-dim)}
.aiapi-hero-balance{display:flex;flex-direction:column;gap:2px}
.aiapi-hero-amount{font-size:38px;line-height:46px;font-weight:700;font-variant-numeric:tabular-nums;letter-spacing:-.01em}
.aiapi-hero[data-compact] .aiapi-hero-amount{font-size:28px;line-height:36px}
.aiapi-hero-note{font-size:12px;color:var(--lux-dim)}
.aiapi-hero-quota{display:flex;align-items:center;gap:12px;flex-wrap:wrap;font-size:12px;color:var(--lux-dim)}
.aiapi-hero-actions{display:flex;justify-content:flex-end;gap:10px;flex-wrap:wrap}
.aiapi-signin-hero{align-items:center;text-align:center;padding:28px 20px 24px}
.aiapi-signin-title{font-size:18px;font-weight:650}
.aiapi-signin-text{font-size:12px;line-height:19px;color:var(--lux-dim);max-width:420px;text-wrap:balance}
.aiapi-lux-code{font:700 26px/34px var(--dsh-font-family-code,ui-monospace,monospace);letter-spacing:.22em;padding:8px 18px;border-radius:12px;border:1px solid var(--lux-line-strong);background:rgba(232,187,87,.06);user-select:all;text-shadow:0 0 18px rgba(95,243,255,.35)}
.aiapi-lux-heading{font-size:11px;letter-spacing:.16em;color:var(--lux-gold);padding:0 4px;margin-bottom:-8px}
.aiapi-bar{position:relative;display:flex;align-items:center;gap:8px;width:100%;height:36px;box-sizing:border-box;padding:0 10px;border:1px solid transparent;border-radius:12px;background:transparent;color:var(--lux-dim);font:inherit;font-size:13px;cursor:pointer;text-align:left;transition:border-color .25s,background .25s,box-shadow .25s}
.aiapi-bar:hover{border-color:var(--lux-line);background:rgba(232,187,87,.06);box-shadow:0 0 22px -10px rgba(232,187,87,.7)}
.aiapi-bar-label{flex:1;min-width:0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;letter-spacing:.06em}
.aiapi-bar-amount{font-weight:650;font-variant-numeric:tabular-nums}
.aiapi-bar[data-state=signed-out] .aiapi-bar-amount{color:var(--lux-faint);font-weight:400}
.aiapi-bar[data-state=low] .aiapi-bar-amount{color:#ffb547;background:none;-webkit-text-fill-color:#ffb547;filter:none}
.aiapi-bar[data-state=empty] .aiapi-bar-amount{color:#ff5d73;background:none;-webkit-text-fill-color:#ff5d73;filter:none}
`;

/** Balance under this many dollars reads as running low. */
const LOW_BALANCE = 1;

/** Time of day for "updated at". */
const clock = at => (at ? new Date(at).toLocaleTimeString('zh-TW', { hour: '2-digit', minute: '2-digit' }) : '');

/** The two plugin switches that live on this page. */
function usePreferences(ctx) {
  const [values, setValues] = useState({ balanceBar: balanceFlag.on, errorReporting: true });
  useEffect(() => {
    let alive = true;
    void pluginSettings.read(ctx).then(view => {
      if (!alive || view === undefined) return;
      setValues({ balanceBar: view.value?.balanceBar === true, errorReporting: view.value?.errorReporting !== false });
    }).catch(() => {});
    return () => { alive = false; };
  }, [ctx]);
  const write = async (key, next) => {
    setValues(current => ({ ...current, [key]: next }));
    if (key === 'balanceBar') setBalanceFlag(next);
    if (key === 'errorReporting') globalThis.__aiapiReportingEnabled = next;
    try {
      await pluginSettings.write(ctx, [key], next);
    } catch (failure) {
      console.warn('[aiapi] 設定寫入失敗:', failure);
      setValues(current => ({ ...current, [key]: !next }));
      if (key === 'balanceBar') setBalanceFlag(!next);
      if (key === 'errorReporting') globalThis.__aiapiReportingEnabled = !next;
    }
  };
  return [values, write];
}

/** Signed out, or the key was rejected: the one thing to do is sign in. */
function SignIn({ account }) {
  const pending = account.signIn;
  return <div className="aiapi-lux-card aiapi-lux-ripple aiapi-hero aiapi-signin-hero">
    <span className="aiapi-hero-mark"><Logo size={40} /></span>
    {pending === undefined ? <>
      <div className="aiapi-signin-title aiapi-lux-gold">{account.phase === 'invalid-key' ? 'AIAPI 登入已失效' : '登入 AIAPI'}</div>
      <div className="aiapi-signin-text">{account.phase === 'invalid-key'
        ? '這台 DSH 保存的 Smart Key 已被停用或刪除，重新登入即可。'
        : '登入後就能在 DSH 使用 AIAPI 的模型，餘額也會顯示在這裡；不需要自己建立或貼上金鑰。'}</div>
      <button type="button" className="aiapi-lux-btn" disabled={account.busy} onClick={() => { void accountStore.signIn(); }}>使用 AIAPI 帳號登入</button>
    </> : <>
      <div className="aiapi-signin-title aiapi-lux-gold">在瀏覽器完成登入</div>
      <div className="aiapi-signin-text">已開啟 AIAPI 授權頁：登入後確認代碼與下方相同，再按「允許這次登入」。</div>
      <span className="aiapi-lux-code aiapi-lux-gold" aria-label="授權代碼">{pending.user_code}</span>
      <div className="aiapi-hero-actions" style={{ justifyContent: 'center' }}>
        <button type="button" className="aiapi-lux-btn-line" onClick={() => window.open(pending.verification_uri, '_blank', 'noopener')}>重新開啟授權頁</button>
        <button type="button" className="aiapi-lux-btn-quiet" onClick={() => accountStore.cancelSignIn()}>取消</button>
      </div>
    </>}
    {account.error !== '' && account.phase !== 'invalid-key' ? <div className="aiapi-signin-text aiapi-error-text" role="alert">{account.error}</div> : null}
  </div>;
}

/** Who is signed in and what is left, on one gilded card. */
function Balance({ account, compact }) {
  const data = account.data ?? {};
  const share = quotaShare(data);
  const group = data.group?.name;
  const multiplier = data.group?.rate_multiplier;
  const level = share === undefined ? 'ok' : share <= 0.02 ? 'empty' : share < 0.2 ? 'low' : 'ok';
  return <div className="aiapi-lux-card aiapi-lux-ripple aiapi-hero" data-compact={compact ? '' : undefined}>
    <div className="aiapi-hero-top">
      <div className="aiapi-identity">
        <span className="aiapi-hero-mark"><Logo size={compact ? 28 : 34} /></span>
        <div>
          <div className="aiapi-hero-name">AIAPI</div>
          <div className="aiapi-hero-sub">
            {account.phase === 'error'
              ? <Tooltip label={account.error} side="top"><span className="aiapi-status"><span className="aiapi-lux-pulse" data-tone="error" />暫時無法更新</span></Tooltip>
              : <span className="aiapi-status"><span className="aiapi-lux-pulse" />已連線</span>}
            {group ? <span className="aiapi-lux-chip" data-tone="gold">{group}{typeof multiplier === 'number' && multiplier !== 1 ? ` ×${multiplier}` : ''}</span> : null}
          </div>
        </div>
      </div>
      {compact ? null : <button type="button" className="aiapi-lux-btn-quiet" disabled={account.busy} onClick={() => { void accountStore.signOut(); }}>登出</button>}
    </div>
    <div className="aiapi-hero-balance">
      <span className="aiapi-lux-eyebrow">平台餘額 · {data.currency ?? 'USD'}</span>
      <span className="aiapi-hero-amount aiapi-lux-gold">{money(data.balance, data.currency)}</span>
      <span className="aiapi-hero-note">
        {typeof data.frozen_balance === 'number' && data.frozen_balance > 0 ? `另有 ${money(data.frozen_balance, data.currency)} 處理中 · ` : ''}
        {account.at ? `更新於 ${clock(account.at)}` : ''}
      </span>
    </div>
    {share === undefined ? null : <div className="aiapi-hero-quota">
      <span>這把 Smart Key 的額度</span>
      <span className="aiapi-lux-meter" data-level={level} role="meter" aria-valuemin={0} aria-valuemax={100} aria-valuenow={Math.round(share * 100)}><span style={{ width: `${Math.max(3, share * 100)}%` }} /></span>
      <span>剩 {money(data.quota.remaining, data.currency)} / {money(data.quota.limit, data.currency)}</span>
    </div>}
    <div className="aiapi-hero-actions">
      <button type="button" className="aiapi-lux-btn-line" disabled={account.busy} onClick={() => { void accountStore.refresh(); }}>重新整理</button>
      <button type="button" className="aiapi-lux-btn" onClick={() => window.open(AIAPI_CONSOLE, '_blank', 'noopener')}>前往 AIAPI 儲值</button>
    </div>
  </div>;
}

/** Account content, for the page itself or for the block inside DeepSeek's page. */
export function AccountPanel({ ctx, inline = false }) {
  const account = useAccount();
  const [preferences, setPreference] = usePreferences(ctx);
  const signedIn = account.phase === 'ok' || (account.phase === 'error' && account.data !== undefined);
  const body = account.phase === 'loading'
    ? <div className="aiapi-lux-card aiapi-hero"><span className="aiapi-hero-note">讀取 AIAPI 帳號…</span></div>
    : signedIn ? <Balance account={account} compact={inline} />
      : account.phase === 'error'
        ? <div className="aiapi-lux-card aiapi-hero">
          <span className="aiapi-hero-note aiapi-error-text" role="alert">無法連到 AIAPI：{account.error}</span>
          <div className="aiapi-hero-actions"><button type="button" className="aiapi-lux-btn-line" onClick={() => { void accountStore.refresh(); }}>重試</button></div>
        </div>
        : <SignIn account={account} />;
  if (inline) {
    return <div className="aiapi-inline aiapi-lux"><div className="aiapi-section" style={{ padding: 0 }}>
      <div className="aiapi-lux-heading">AIAPI</div>
      {body}
    </div></div>;
  }
  return <section className="aiapi-section aiapi-lux" aria-label={ACCOUNT_LABEL}>
    {body}
    <div className="aiapi-lux-heading">偏好</div>
    <div className="aiapi-lux-lite" style={{ padding: '4px 16px' }}>
      <div className="aiapi-row">
        <div className="aiapi-row-copy">
          <span className="aiapi-row-title">在側邊欄顯示餘額</span>
          <span className="aiapi-row-caption">左下角常駐一行 AIAPI 餘額，點一下回到這裡</span>
        </div>
        <Switch checked={preferences.balanceBar} label="在側邊欄顯示餘額" onChange={on => { void setPreference('balanceBar', on); }} />
      </div>
      <div className="aiapi-row">
        <div className="aiapi-row-copy">
          <span className="aiapi-row-title">自動回報介面錯誤</span>
          <span className="aiapi-row-caption">插件畫面出錯時把錯誤訊息與版本送給 AIAPI，不含對話內容或金鑰</span>
        </div>
        <Switch checked={preferences.errorReporting} label="自動回報介面錯誤" onChange={on => { void setPreference('errorReporting', on); }} />
      </div>
    </div>
  </section>;
}

/** The page itself, when no DeepSeek account page is registered. */
function AccountSection({ ctx }) {
  return <AccountPanel ctx={ctx} />;
}

/**
 * Register the page, keep the AIAPI block inside DeepSeek's page when that one is shown, and add the sidebar
 * balance.
 * @param ctx - client plugin context.
 */
export function applyAccount(ctx) {
  installStyle(ctx, 'kit', KIT_CSS);
  installStyle(ctx, 'lux', LUX_CSS);
  installStyle(ctx, 'account', ACCOUNT_CSS);
  installRipples(ctx);
  // The settings navigation lists every registration, not only the one that wins a shared id, so the page is
  // registered only while DeepSeek's own 「账号与余额」 is absent and withdrawn the moment it appears.
  ctx.slots.inject('settings.section', () => {
    let unregister;
    // Registering or withdrawing notifies subscribers; a host that notifies synchronously must not re-enter.
    let reconciling = false;
    const reconcile = () => {
      if (reconciling) return;
      reconciling = true;
      try {
        const official = ctx.slots.entries('settings.section')
          .some(entry => entry.options?.id === 'account' && entry.component !== AccountSection);
        if (official && unregister !== undefined) {
          const dispose = unregister;
          unregister = undefined;
          dispose();
        } else if (!official && unregister === undefined) {
          unregister = ctx.slots.register({
            name: 'settings.section', id: 'account', order: -10, priority: 1000, label: () => ACCOUNT_LABEL,
            inject: () => ({ ctx }),
          }, AccountSection);
        }
      } finally {
        reconciling = false;
      }
    };
    const off = ctx.slots.subscribe('settings.section', reconcile);
    reconcile();
    return () => { off(); unregister?.(); };
  });
  ctx.effect(() => mountInsideDeepSeekPage(ctx), 'aiapi block in the DeepSeek account page');
  ctx.slots.inject('sidebar.footer.action', () => ctx.slots.register({
    name: 'sidebar.footer.action', id: 'aiapi-balance', order: 5,
  }, () => <SidebarBalance ctx={ctx} />));
  void pluginSettings.read(ctx).then(view => setBalanceFlag(view?.value?.balanceBar === true)).catch(() => {});
}

/**
 * Follow DeepSeek's account page: when its balance card is on screen, render the AIAPI block after the page's
 * content; remove it when the page goes away. The page has no slot, so its CSS-module class is the anchor, and a
 * DSH release that renames it only loses the inline block — the page itself still has its normal content.
 * @param ctx - client plugin context.
 * @returns the disposer.
 */
function mountInsideDeepSeekPage(ctx) {
  let host;
  let root;
  const unmount = () => {
    root?.unmount();
    host?.remove();
    root = undefined;
    host = undefined;
  };
  const reconcile = () => {
    const card = document.querySelector('[class*="_balanceCard"]');
    const page = card?.closest('section') ?? card?.parentElement;
    if (page === null || page === undefined) { unmount(); return; }
    if (host !== undefined && host.parentElement === page && page.lastElementChild === host) return;
    if (host === undefined) {
      host = document.createElement('div');
      host.dataset.aiapiAccount = '';
      root = createRoot(host);
      root.render(<AccountPanel ctx={ctx} inline />);
    }
    page.append(host);
  };
  let scheduled = false;
  const observer = new MutationObserver(records => {
    if (scheduled || records.every(record => host?.contains(record.target))) return;
    scheduled = true;
    requestAnimationFrame(() => { scheduled = false; reconcile(); });
  });
  observer.observe(document.body, { childList: true, subtree: true });
  reconcile();
  return () => { observer.disconnect(); unmount(); };
}

/** The sidebar line: the AIAPI mark, the balance, and a click that opens 「账号与余额」. */
function SidebarBalance({ ctx }) {
  const [visible, setVisible] = useState(balanceFlag.on);
  useEffect(() => {
    setVisible(balanceFlag.on);
    balanceFlag.listeners.add(setVisible);
    return () => { balanceFlag.listeners.delete(setVisible); };
  }, []);
  return visible ? <SidebarBalanceLine ctx={ctx} /> : null;
}

function SidebarBalanceLine({ ctx }) {
  const account = useAccount();
  const data = account.data;
  const signedIn = data !== undefined && (account.phase === 'ok' || account.phase === 'error');
  const share = quotaShare(data);
  const state = !signedIn ? 'signed-out'
    : (share !== undefined && share <= 0.02) || data.balance <= 0 ? 'empty'
      : (share !== undefined && share < 0.2) || data.balance < LOW_BALANCE ? 'low' : 'ok';
  const tip = signedIn
    ? `AIAPI 餘額 ${money(data.balance, data.currency)}${data.group?.name ? ` · 分組 ${data.group.name}` : ''}${account.at ? ` · 更新於 ${clock(account.at)}` : ''}`
    : account.phase === 'loading' ? '讀取中' : '尚未登入 AIAPI，點一下前往登入';
  return <Tooltip label={tip} side="top">
    <button type="button" className="aiapi-bar aiapi-lux" data-state={state} onClick={() => { if (!openSettings(ctx)) void accountStore.refresh(); }}>
      <Logo size={16} />
      <span className="aiapi-bar-label">AIAPI</span>
      {signedIn ? <span className="aiapi-lux-pulse" data-tone={state === 'ok' ? undefined : state === 'low' ? 'warn' : 'error'} /> : null}
      <span className={signedIn ? 'aiapi-bar-amount aiapi-lux-gold' : 'aiapi-bar-amount'}>{signedIn ? money(data.balance, data.currency) : account.phase === 'loading' ? '…' : '未登入'}</span>
    </button>
  </Tooltip>;
}
