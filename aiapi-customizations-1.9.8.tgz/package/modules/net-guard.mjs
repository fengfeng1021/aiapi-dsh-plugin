/**
 * Keep one Node bug from taking down every HTTP request in the DSH host.
 *
 * The Node 24.21 runtime inside DeepSeek Harness 0.2.1-rc.2 bundles undici 7.29.1, whose HTTP/1 writer calls
 * `socket.setTypeOfService(request.typeOfService)` (default 0) before every request, with no error handling.
 * On macOS that `setsockopt` can fail with EINVAL, depending on the socket's state. The throw escapes as an
 * "Uncaught Exception: setTypeOfService EINVAL" dialog, and the request it belonged to never settles, which the
 * AIAPI cards then show as a read failure that never clears (reported 2026-10-29).
 *
 * undici 8 treats the marking as best effort and ignores the failure ("QoS marking is best-effort …"). This
 * applies the same rule to the one method, for every caller in the process — DSH's own model requests included —
 * and restores the original when the plugin unloads. Nothing else about the socket changes: a request that was
 * going to work is untouched, and one that hit the bug now proceeds without the marking.
 */
import net from 'node:net';

const GUARD = Symbol.for('aiapi.setTypeOfServiceGuard');

/**
 * Install the guard on `net.Socket.prototype.setTypeOfService`.
 * @param logger - receives one warning the first time a failure is absorbed.
 * @returns the disposer that puts the original method back, or a no-op when there was nothing to guard.
 */
export function guardSocketTypeOfService(logger) {
  const prototype = net.Socket.prototype;
  const original = prototype.setTypeOfService;
  if (typeof original !== 'function' || original[GUARD] === true) return () => {};
  let reported = false;
  const guarded = function setTypeOfService(...args) {
    try {
      return original.apply(this, args);
    } catch (error) {
      if (!reported) {
        reported = true;
        logger?.warn?.(`aiapi: ignored ${error?.code ?? 'error'} from socket.setTypeOfService (best-effort QoS marking; Node undici bug)`);
      }
      return this;
    }
  };
  guarded[GUARD] = true;
  prototype.setTypeOfService = guarded;
  return () => {
    if (prototype.setTypeOfService === guarded) prototype.setTypeOfService = original;
  };
}
