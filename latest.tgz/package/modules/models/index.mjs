import { discover, mergePublicPricingModels, publicModelSourceIds, readJson, parseListing, requestModelIdForPublicModel, enrichModelMetadata, capacityOverrides, unpricedModels, isChatModel, fetchCapabilities, capabilityFields } from './discovery.mjs';
import { createHash, timingSafeEqual } from 'node:crypto';
import { readFileSync } from 'node:fs';
import { mkdir, readdir, readFile, rm, writeFile } from 'node:fs/promises';
import { homedir } from 'node:os';
import { gunzipSync } from 'node:zlib';
import { isDeepStrictEqual } from 'node:util';
import { fileURLToPath } from 'node:url';
import { dirname } from 'node:path';
import { join } from 'node:path';
export const name = 'aiapi-models';
export const inject = ['connection', 'settings', 'credentials'];
const AIAPI_MODEL_ENDPOINT = 'https://aiapi.tw/v1';
const AIAPI_PUBLIC_PRICING_ENDPOINT = 'https://aiapi.tw/api/v1/pricing/public';
const AIAPI_DESKTOP_AUTH_ENDPOINT = 'https://aiapi.tw/api/v1/desktop-auth';
const AIAPI_CREDENTIAL_REF = 'AIAPI_API_KEY';
/** 1.11.0 曾把 Claude 拆到這個供應商；現在只保留它，用來把舊設定清掉。 */
const AIAPI_ANTHROPIC_PROVIDER = 'aiapi-claude';
const AIAPI_PENDING_CREDENTIAL_REF = 'AIAPI_DESKTOP_OAUTH_PENDING';
const AIAPI_DEVICE_CREDENTIAL_REF = 'AIAPI_DEVICE_PENDING';
/** This package's own manifest, read once so the version route and update check cannot drift. */
/**
 * The plugin's own package directory. Found by walking up from this module, so the same file works both in
 * the source tree and inside the installed bundle, and the updater can read the version on disk later.
 * @returns the directory that holds this plugin's package.json.
 */
function findPackageRoot() {
  let dir = dirname(fileURLToPath(import.meta.url));
  for (let depth = 0; depth < 6; depth += 1) {
    try {
      const manifest = JSON.parse(readFileSync(join(dir, 'package.json'), 'utf8'));
      if (manifest.name === '@aiapi/dsh-customizations') return dir;
    } catch { /* keep walking up */ }
    dir = dirname(dir);
  }
  throw new Error('找不到外掛自己的 package.json');
}

const PACKAGE_ROOT = findPackageRoot();
const PACKAGE_INFO = JSON.parse(readFileSync(join(PACKAGE_ROOT, 'package.json'), 'utf8'));

/** The version recorded on disk: after an in-app update it is newer than this running module until restart. */
function readOnDiskVersion() {
  try {
    return JSON.parse(readFileSync(join(PACKAGE_ROOT, 'package.json'), 'utf8')).version ?? '';
  } catch {
    return '';
  }
}

/** Last in-app update attempt; polled by the card because the install outlives its own HTTP request. */
const updateState = { phase: 'idle', version: '', error: '', application: '', restartReason: '', method: '', hostChanged: false, received: 0, total: 0, at: 0 };
/** Release index location used whenever the entry config says nothing (a profile patch may replace the whole config). */
const DEFAULT_UPDATE_MANIFEST = 'https://fengfeng1021.github.io/aiapi-dsh-plugin/index.json';
/** Values that switch the update check off on purpose. */
const UPDATE_MANIFEST_OFF = new Set(['off', 'none', 'disabled']);
const SETTINGS_NAMESPACE = 'llm-pi-ai';

/**
 * Install the authenticated model-discovery route without writing settings during boot.
 * @param ctx - the customization plugin context.
 * @param config - deployment-owned capacity overrides, validated before registration.
 */
export function apply(ctx, config = {}) {
  const limits = capacityOverrides(config.modelCapacityOverrides);
  const lifetime = new AbortController();
  // `autoModels` is volatile: the picker flips it without a restart, and each sync reads the current value.
  const autoModels = () => {
    const raw = config.autoModels;
    const value = raw !== null && typeof raw === 'object' && typeof raw.get === 'function' ? raw.get() : raw;
    return value !== false;
  };
  const register = (options = {}) => ensureProvider(ctx, { limits, signal: lifetime.signal, auto: autoModels(), ...options });
  // The platform's catalog changes without a plugin release: re-sync every six hours while DSH runs.
  ctx.effect(() => {
    const timer = setInterval(() => { void register().catch(() => {}); }, 6 * 3600_000);
    timer.unref?.(); // a background re-sync never keeps the Host process alive on its own
    return () => clearInterval(timer);
  }, 'aiapi model sync');
  // 供應商被使用者層的 llm-pi-ai 設定蓋掉、或缺 apiKeyEnv／思考等級時，啟動時修好一次；不需要 Smart Key，
  // 否則模型頁連「AIAPI」這張卡都不會出現，使用者也就沒地方登入。
  void register().then(
    result => ctx.logger?.info?.(`aiapi provider: ${result.status}`),
    error => ctx.logger?.warn?.(`aiapi provider registration skipped: ${error instanceof Error ? error.message : error}`),
  );
  const pending = new Set();
  let registry;
  let registryAt = 0;
  ctx.effect(() => ctx.connection.fetch.register({ path: '/api/aiapi/models', methods: ['POST'], requestBody: 'buffered', fetch: request => {
    const task = (async () => {
      try {
        const input = await request.json();
        if (!input || input.provider !== 'aiapi' || typeof input.enrich !== 'boolean') throw new Error('模型查詢參數無效');
        const stored = ctx.settings.describe().find(row => row.ns === SETTINGS_NAMESPACE)?.value?.providers?.aiapi;
        const signal = AbortSignal.any([request.signal, lifetime.signal, AbortSignal.timeout(20000)]);
        // The public price list only annotates the picker. A deployment made of exclusive groups publishes no
        // prices at all, and a slow or changed price endpoint must never decide whether models are listed.
        let pricing;
        let pricingError = '';
        try {
          pricing = await readJson(await fetch(AIAPI_PUBLIC_PRICING_ENDPOINT, {
            headers: { accept: 'application/json' }, signal, redirect: 'error', cache: 'no-store',
          }));
        } catch (error) {
          pricingError = error instanceof Error ? error.message : String(error);
        }
        const publicGroups = Array.isArray(pricing?.data?.groups) ? pricing.data.groups : [];
        const pricingEmpty = pricing !== undefined && publicGroups.length === 0;
        let discovered = [];
        let accountListingAvailable = false;
        let discoveryError = '';
        let warning;
        try {
          // The Smart Key lives in the credential store whatever the provider row looks like; a row restored
          // from the user layer may carry neither apiKeyEnv nor the same baseURL, which used to send no key (401).
          const apiKey = await aiapiKey(ctx);
          if (apiKey === undefined) throw new Error('尚未登入 AIAPI：請先按「使用 AIAPI 帳號登入」');
          discovered = await discover({ provider: 'aiapi', api: 'openai-completions', baseURL: AIAPI_MODEL_ENDPOINT, apiKey }, stored, async ref => (await ctx.credentials.resolve(ref))?.value, signal);
          accountListingAvailable = true;
        } catch (error) {
          discoveryError = error instanceof Error ? error.message : String(error);
          warning = `無法向 AIAPI 確認這個 Smart Key 可用的模型：${discoveryError}`;
        }
        let mergedError = '';
        let models = [];
        if (accountListingAvailable) {
          if (!pricingEmpty && pricing !== undefined) {
            try {
              models = mergePublicPricingModels(discovered, pricing);
            } catch (error) {
              mergedError = error instanceof Error ? error.message : String(error);
            }
          }
          if (models.length === 0) {
            // Fall back to the account listing so a price table problem cannot empty the picker.
            models = unpricedModels(discovered);
            if (models.length > 0) {
              warning = pricingEmpty
                ? '這個 AIAPI 站點目前沒有公開價格表（分組都是專屬分組），以下為帳號可直接使用的模型。'
                : `價格表暫時無法比對${mergedError !== '' ? `（${mergedError}）` : pricingError !== '' ? `（${pricingError}）` : ''}，以下為帳號可直接使用的模型。`;
            } else if (pricingError === '') {
              warning = '此 Smart Key 的模型清單是空的：請確認這組 Smart Key 已開通模型權限。';
            }
          }
        }
        const publicSourceIds = publicModelSourceIds(pricing ?? {});
        for (const model of models) {
          if (model.reasoningEfforts !== undefined) model.reasoningSource = 'AIAPI 帳號模型清單';
        }
        if (input.enrich === true && models.length > 0) {
          try {
            if (!registry || Date.now() - registryAt > 3600000) {
              // Public registry receives NO provider key, headers, or model query.
              registry = parseListing(await readJson(await fetch('https://openrouter.ai/api/v1/models', { signal, redirect: 'error' })));
              registryAt = Date.now();
            }
            const exact = new Map(registry.map(model => [model.id, model]));
            for (const model of models) {
              const sourceId = publicSourceIds.get(model.id);
              const match = sourceId ? exact.get(sourceId) : undefined;
              enrichModelMetadata(model, match);
              const publicModelId = sourceId?.slice(sourceId.indexOf('/') + 1);
              const isGatewayAlias = publicModelId !== undefined
                && publicModelId !== model.id
                && requestModelIdForPublicModel(publicModelId) === model.id;
              if (match && (isGatewayAlias || !model.name || model.name === model.id)) {
                model.name = match.name === match.id ? model.id : match.name;
              }
              if (model.reasoningEfforts === undefined && match?.reasoningEfforts !== undefined) {
                model.reasoningEfforts = match.reasoningEfforts;
                model.reasoningSource = `OpenRouter 公開目錄：${sourceId}`;
              }
            }
          } catch { warning = '公開目錄暫時無法讀取，已保留供應商直接回傳的資料。'; }
        }
        // The platform's catalog decides limits, image input and reasoning levels, and which models are chat models.
        if (models.length > 0) {
          const capabilities = await fetchCapabilities(AIAPI_MODEL_ENDPOINT, await aiapiKey(ctx), models.map(model => model.id), signal).catch(() => new Map());
          for (const model of models) {
            Object.assign(model, capabilityFields(capabilities.get(model.id)));
            model.chat = capabilities.get(model.id)?.chat !== false && isChatModel(model.id);
            if (capabilities.get(model.id)?.known === true) model.reasoningSource = 'AIAPI 平台模型目錄';
          }
        }
        for (const model of models) Object.assign(model, limits.get(model.id));
        // A model the platform's catalog does not know falls back to the family default (see
        // defaultReasoningEfforts); without one DSH treats it as "off only" and refuses a configured
        // reasoningEffort locally (2026-10-28: provider "aiapi" … does not support reasoning effort "max").
        for (let index = 0; index < models.length; index += 1) {
          if (models[index].reasoningEfforts !== undefined) continue;
          models[index] = withReasoningEfforts(models[index]);
          models[index].reasoningSource = 'AIAPI 依模型家族的預設等級';
        }
        // Counts let the card explain an empty picker without guessing.
        const detail = {
          accountModels: discovered.length,
          shown: models.length,
          pricingAvailable: pricing !== undefined && !pricingEmpty,
          pricingError: pricingError || mergedError || '',
          discoveryError,
        };
        return Response.json({ models, warning, detail }, { headers: { 'cache-control': 'no-store' } });
      } catch (error) {
        // Fetch errors may include remote details; keys and raw reply bodies are never echoed.
        const failure = error instanceof Error ? error : new Error('Unknown discovery failure');
        const message = failure instanceof SyntaxError ? '供應商回應不是有效 JSON' : failure.name === 'AbortError' || failure.name === 'TimeoutError' ? '查詢已取消或逾時' : /^模型|^供應商|^請填寫/.test(failure.message) ? failure.message : '模型查詢失敗，請檢查位址、金鑰及網路。';
        return Response.json({ error: message }, { status: 400, headers: { 'cache-control': 'no-store' } });
      }
    })();
    pending.add(task);
    void task.finally(() => pending.delete(task));
    return task;
  }}), 'aiapi authenticated discovery');
  ctx.effect(() => ctx.connection.fetch.register({ path: '/api/aiapi/desktop-auth/oauth/start', methods: ['POST'], requestBody: 'buffered', fetch: request => track(pending, startDesktopOAuth(ctx, request, lifetime.signal)) }), 'aiapi desktop authorization start');
  ctx.effect(() => ctx.connection.fetch.register({ path: '/api/aiapi/desktop-auth/oauth/callback', methods: ['POST'], requestBody: 'buffered', fetch: request => track(pending, completeDesktopOAuth(ctx, request, lifetime.signal, register)) }), 'aiapi desktop authorization callback');
  ctx.effect(() => ctx.connection.fetch.register({ path: '/api/aiapi/desktop-auth/oauth/resume', methods: ['POST'], requestBody: 'buffered', fetch: request => track(pending, resumeDesktopOAuth(ctx, request)) }), 'aiapi desktop authorization resume');
  ctx.effect(() => ctx.connection.fetch.register({ path: '/api/aiapi/device-auth/start', methods: ['POST'], requestBody: 'buffered', fetch: request => track(pending, startDeviceAuth(ctx, request, lifetime.signal)) }), 'aiapi device authorization start');
  ctx.effect(() => ctx.connection.fetch.register({ path: '/api/aiapi/device-auth/poll', methods: ['POST'], requestBody: 'buffered', fetch: request => track(pending, pollDeviceAuth(ctx, request, lifetime.signal, register)) }), 'aiapi device authorization poll');
  // A GET route still has to declare `requestBody: 'buffered'`: without it the connection bridge builds a
  // streaming Request, which Fetch refuses for GET ("Request with GET/HEAD method cannot have body"), so every
  // balance read failed before reaching this handler (the account card's 「讀取失敗（回應 400）」).
  ctx.effect(() => ctx.connection.fetch.register({ path: '/api/aiapi/balance', methods: ['GET'], requestBody: 'buffered', fetch: request => track(pending, readBalance(ctx, request, lifetime.signal)) }), 'aiapi balance');
  ctx.effect(() => ctx.connection.fetch.register({ path: '/api/aiapi/report', methods: ['POST'], requestBody: 'buffered', fetch: request => track(pending, forwardReport(ctx, request, lifetime.signal)) }), 'aiapi client report');
  ctx.effect(() => ctx.connection.fetch.register({ path: '/api/aiapi/update', methods: ['GET'], requestBody: 'buffered', fetch: () => Response.json({ name: PACKAGE_INFO.name, version: PACKAGE_INFO.version, onDisk: readOnDiskVersion() }, { headers: { 'cache-control': 'no-store' } }) }), 'aiapi version');
  ctx.effect(() => ctx.connection.fetch.register({ path: '/api/aiapi/update/check', methods: ['POST'], requestBody: 'buffered', fetch: request => track(pending, checkForUpdate(ctx, config, request, lifetime.signal)) }), 'aiapi update check');
  ctx.effect(() => ctx.connection.fetch.register({ path: '/api/aiapi/provider', methods: ['POST'], requestBody: 'buffered', fetch: async () => {
    try {
      return Response.json(await register(), { headers: { 'cache-control': 'no-store' } });
    } catch (error) {
      return Response.json({ status: 'failed', error: error instanceof Error ? error.message : '註冊供應商失敗' }, { status: 500, headers: { 'cache-control': 'no-store' } });
    }
  } }), 'aiapi provider registration');
  ctx.effect(() => ctx.connection.fetch.register({ path: '/api/aiapi/update/status', methods: ['GET'], requestBody: 'buffered', fetch: () => Response.json({ ...updateState, running: PACKAGE_INFO.version, onDisk: readOnDiskVersion() }, { headers: { 'cache-control': 'no-store' } }) }), 'aiapi update status');
  ctx.effect(() => ctx.connection.fetch.register({ path: '/api/aiapi/update/apply', methods: ['POST'], requestBody: 'buffered', fetch: request => track(pending, applyUpdate(ctx, config, request, lifetime.signal)) }), 'aiapi update apply');
  ctx.effect(() => ctx.connection.fetch.register({ path: '/api/aiapi/disconnect', methods: ['POST'], requestBody: 'buffered', fetch: request => track(pending, disconnectAccount(ctx, request)) }), 'aiapi disconnect');
  ctx.effect(() => async () => { lifetime.abort(); await Promise.allSettled(pending); }, 'aiapi discovery cleanup');
}

function track(pending, task) {
  pending.add(task);
  void task.finally(() => pending.delete(task));
  return task;
}

async function startDesktopOAuth(ctx, request, lifetimeSignal) {
  try {
    const signal = AbortSignal.any([request.signal, lifetimeSignal, AbortSignal.timeout(15000)]);
    const input = await request.json();
    if (!input || typeof input.code_verifier !== 'string' || input.code_verifier.length < 43 || input.code_verifier.length > 128 || typeof input.code_challenge !== 'string' || typeof input.state !== 'string' || typeof input.redirect_uri !== 'string') throw new Error('桌面登入資料無效');
    const derived = createHash('sha256').update(input.code_verifier).digest('base64url');
    if (derived !== input.code_challenge || !validRedirectURI(input.redirect_uri)) throw new Error('桌面登入資料無效');
    const grant = await postDesktopAuth('/oauth/request', {
      code_challenge: input.code_challenge,
      state: input.state,
      redirect_uri: input.redirect_uri,
    }, signal);
    if (typeof grant.request_id !== 'string' || grant.request_id.length !== 43 || !Number.isSafeInteger(grant.expires_in)) throw new Error('授權服務回應格式無效');
    await ctx.credentials.set(AIAPI_PENDING_CREDENTIAL_REF, JSON.stringify({
      code_verifier: input.code_verifier,
      state: input.state,
      redirect_uri: input.redirect_uri,
      request_id: grant.request_id,
      expires_at: Date.now() + grant.expires_in * 1000,
    }));
    return Response.json({ authorization_url: `https://aiapi.tw/desktop/authorize?request_id=${encodeURIComponent(grant.request_id)}` }, { headers: { 'cache-control': 'no-store' } });
  } catch (error) {
    return desktopAuthFailure(error, ctx);
  }
}

async function completeDesktopOAuth(ctx, request, lifetimeSignal, register) {
  try {
    const input = await request.json();
    if (!input || typeof input.callback !== 'string' || input.callback.length > 512) throw new Error('桌面授權回呼無效');
    const grant = await ctx.credentials.resolve(AIAPI_PENDING_CREDENTIAL_REF);
    if (!grant?.value) throw new Error('找不到待完成的登入要求，請重新登入。');
    let transaction;
    try { transaction = JSON.parse(grant.value); } catch { throw new Error('桌面登入狀態已損毀，請重新登入。'); }
    if (typeof transaction.state !== 'string' || typeof transaction.code_verifier !== 'string' || typeof transaction.redirect_uri !== 'string' || !Number.isSafeInteger(transaction.expires_at) || transaction.expires_at <= Date.now()) {
      await ctx.credentials.unset(AIAPI_PENDING_CREDENTIAL_REF);
      throw new Error('桌面登入要求已過期，請重新登入。');
    }
    const callback = new URL(input.callback);
    if (`${callback.protocol}//${callback.host}${callback.pathname}` !== transaction.redirect_uri || callback.hash || callback.username || callback.password) throw new Error('桌面授權回呼不符合本機登入要求');
    const states = callback.searchParams.getAll('state');
    const codes = callback.searchParams.getAll('code');
    const errors = callback.searchParams.getAll('error');
    if ([...callback.searchParams.keys()].some(key => !['state', 'code', 'error'].includes(key))) throw new Error('桌面授權回呼無效，請重新登入。');
    const expectedState = Buffer.from(transaction.state);
    const actualState = Buffer.from(states[0] ?? '');
    if (states.length !== 1 || actualState.length !== expectedState.length || !timingSafeEqual(actualState, expectedState)) throw new Error('桌面授權狀態不符，請重新登入。');
    if (transaction.callback && transaction.callback !== input.callback) throw new Error('桌面授權回呼與待完成的登入不符。');
    if (!transaction.callback) {
      transaction.callback = input.callback;
      await ctx.credentials.set(AIAPI_PENDING_CREDENTIAL_REF, JSON.stringify(transaction));
    }
    if (codes.length === 0 && errors.length === 1 && errors[0] === 'access_denied') {
      await ctx.credentials.unset(AIAPI_PENDING_CREDENTIAL_REF);
      return Response.json({ status: 'access_denied' }, { headers: { 'cache-control': 'no-store' } });
    }
    if (codes.length !== 1 || errors.length !== 0 || !/^[A-Za-z0-9_-]{43}$/.test(codes[0])) throw new Error('桌面授權回呼無效，請重新登入。');
    const signal = AbortSignal.any([request.signal, lifetimeSignal, AbortSignal.timeout(15000)]);
    const result = await postDesktopAuth('/oauth/exchange', {
      code: codes[0],
      code_verifier: transaction.code_verifier,
      redirect_uri: transaction.redirect_uri,
    }, signal);
    if (result.status !== 'granted') {
      if (result.status === 'expired' || result.status === 'access_denied') await ctx.credentials.unset(AIAPI_PENDING_CREDENTIAL_REF);
      return Response.json({ status: result.status }, { headers: { 'cache-control': 'no-store' } });
    }
    if (typeof result.api_key !== 'string' || result.api_key.length < 16 || result.api_key.length > 256) throw new Error('授權服務未回傳有效的 Smart Key');
    await ctx.credentials.set(AIAPI_CREDENTIAL_REF, result.api_key);
    try { await postDesktopAuth('/oauth/ack', { code: codes[0] }, signal); } catch { /* The short-lived grant expires automatically. */ }
    await ctx.credentials.unset(AIAPI_PENDING_CREDENTIAL_REF);
    return Response.json({ status: 'complete', provider: await registerAfterSignIn(ctx, register) }, { headers: { 'cache-control': 'no-store' } });
  } catch (error) {
    return desktopAuthFailure(error, ctx);
  }
}

async function resumeDesktopOAuth(ctx, request) {
  try {
    if (request.signal.aborted) throw new Error('桌面登入要求已取消。');
    const grant = await ctx.credentials.resolve(AIAPI_PENDING_CREDENTIAL_REF);
    if (!grant?.value) return Response.json({ status: 'none' }, { headers: { 'cache-control': 'no-store' } });
    let transaction;
    try { transaction = JSON.parse(grant.value); } catch { await ctx.credentials.unset(AIAPI_PENDING_CREDENTIAL_REF); return Response.json({ status: 'expired' }, { headers: { 'cache-control': 'no-store' } }); }
    if (!Number.isSafeInteger(transaction.expires_at) || transaction.expires_at <= Date.now()) {
      await ctx.credentials.unset(AIAPI_PENDING_CREDENTIAL_REF);
      return Response.json({ status: 'expired' }, { headers: { 'cache-control': 'no-store' } });
    }
    if (typeof transaction.callback === 'string') return Response.json({ status: 'resume', callback: transaction.callback }, { headers: { 'cache-control': 'no-store' } });
    return Response.json({ status: 'pending' }, { headers: { 'cache-control': 'no-store' } });
  } catch (error) {
    return desktopAuthFailure(error, ctx);
  }
}


/**
 * Start a device authorization for a browser-only DSH: the account sign-in happens on aiapi.tw, and the
 * Smart Key returns through the Host's poll route instead of a desktop URL scheme callback.
 * @param ctx - unified plugin context, for the pending grant in the credential store.
 * @param request - the page's POST, whose body is unused.
 * @param lifetimeSignal - aborts the attempt when the plugin unloads.
 * @returns the user code and verification page the browser shows, never the device code.
 */
async function startDeviceAuth(ctx, request, lifetimeSignal) {
  try {
    const signal = AbortSignal.any([request.signal, lifetimeSignal, AbortSignal.timeout(15000)]);
    const grant = await postDesktopAuth('/device-code', {}, signal);
    if (typeof grant.device_code !== 'string' || grant.device_code.length < 16 || typeof grant.user_code !== 'string' || !/^[A-Za-z0-9-]{4,32}$/.test(grant.user_code) || typeof grant.verification_uri !== 'string' || !Number.isSafeInteger(grant.expires_in) || grant.expires_in <= 0) throw new Error('授權服務回應格式無效');
    const verification = new URL(grant.verification_uri);
    if (verification.origin !== 'https://aiapi.tw') throw new Error('AIAPI 授權網址無效');
    await ctx.credentials.set(AIAPI_DEVICE_CREDENTIAL_REF, JSON.stringify({
      device_code: grant.device_code,
      expires_at: Date.now() + grant.expires_in * 1000,
    }));
    return Response.json({
      user_code: grant.user_code,
      verification_uri: verification.href,
      expires_in: grant.expires_in,
      interval: Number.isSafeInteger(grant.interval) && grant.interval > 0 ? grant.interval : 5,
    }, { headers: { 'cache-control': 'no-store' } });
  } catch (error) {
    return desktopAuthFailure(error, ctx);
  }
}

/**
 * One poll of a pending device grant. A granted key lands in the same credential the desktop flow uses,
 * so the provider card and the model route read it unchanged.
 * @param ctx - unified plugin context.
 * @param request - the page's POST, whose body is unused.
 * @param lifetimeSignal - aborts the exchange when the plugin unloads.
 * @returns the grant status, and `complete` once the key is stored.
 */
async function pollDeviceAuth(ctx, request, lifetimeSignal, register) {
  try {
    const stored = await ctx.credentials.resolve(AIAPI_DEVICE_CREDENTIAL_REF);
    if (!stored?.value) return Response.json({ status: 'none' }, { headers: { 'cache-control': 'no-store' } });
    let state;
    try { state = JSON.parse(stored.value); } catch {
      await ctx.credentials.unset(AIAPI_DEVICE_CREDENTIAL_REF);
      return Response.json({ status: 'expired' }, { headers: { 'cache-control': 'no-store' } });
    }
    if (typeof state.device_code !== 'string' || !Number.isSafeInteger(state.expires_at) || state.expires_at <= Date.now()) {
      await ctx.credentials.unset(AIAPI_DEVICE_CREDENTIAL_REF);
      return Response.json({ status: 'expired' }, { headers: { 'cache-control': 'no-store' } });
    }
    const signal = AbortSignal.any([request.signal, lifetimeSignal, AbortSignal.timeout(15000)]);
    const result = await postDesktopAuth('/token', { device_code: state.device_code }, signal);
    if (result.status === 'authorization_pending') return Response.json({ status: 'authorization_pending' }, { headers: { 'cache-control': 'no-store' } });
    if (result.status !== 'granted') {
      await ctx.credentials.unset(AIAPI_DEVICE_CREDENTIAL_REF);
      return Response.json({ status: result.status === 'access_denied' ? 'access_denied' : 'expired' }, { headers: { 'cache-control': 'no-store' } });
    }
    if (typeof result.api_key !== 'string' || result.api_key.length < 16 || result.api_key.length > 256) throw new Error('授權服務未回傳有效的 Smart Key');
    await ctx.credentials.set(AIAPI_CREDENTIAL_REF, result.api_key);
    try { await postDesktopAuth('/token/ack', { device_code: state.device_code }, signal); } catch { /* The short-lived grant expires automatically. */ }
    await ctx.credentials.unset(AIAPI_DEVICE_CREDENTIAL_REF);
    return Response.json({ status: 'complete', provider: await registerAfterSignIn(ctx, register) }, { headers: { 'cache-control': 'no-store' } });
  } catch (error) {
    return desktopAuthFailure(error, ctx);
  }
}

/**
 * Bring the provider up to date right after a Smart Key is stored, so the model list matches what that key
 * can use without a second click. A failure here never undoes the sign-in; the next start repairs it.
 * @param ctx - plugin context, for the log.
 * @param register - the entry's {@link ensureProvider} binding.
 * @returns the registration status for the page.
 */
async function registerAfterSignIn(ctx, register) {
  if (typeof register !== 'function') return 'skipped';
  try {
    return (await register()).status;
  } catch (error) {
    ctx.logger?.warn?.(`aiapi provider registration after sign-in failed: ${error instanceof Error ? error.message : error}`);
    return 'failed';
  }
}


/**
 * Compare this package's version with the published release index. The manifest is fetched by the Host,
 * not the page, so it works without CORS on the release host and never exposes the page to that origin.
 * @param ctx - unified plugin context, for the abort signal owner.
 * @param config - deployment config; `updateManifestUrl` may point at another index.
 * @param request - the page's POST, whose body is unused.
 * @param lifetimeSignal - aborts the lookup when the plugin unloads.
 * @returns the current version, the latest published one, and the install spec for it.
 */
/**
 * Order two release versions (`major.minor.patch`, numeric parts; anything after `-` sorts before the release).
 * The update check must only offer a newer build: comparing with `!==` offered 1.9.5 to a running 1.9.6.
 * @param left - one version.
 * @param right - the other.
 * @returns a negative number, zero, or a positive number, like a sort comparator.
 */
export function compareVersions(left, right) {
  const parse = value => {
    const [core, pre] = String(value ?? '').trim().replace(/^v/, '').split('-', 2);
    return { parts: core.split('.').map(part => Number.parseInt(part, 10) || 0), pre: pre ?? '' };
  };
  const a = parse(left);
  const b = parse(right);
  for (let index = 0; index < Math.max(a.parts.length, b.parts.length); index += 1) {
    const difference = (a.parts[index] ?? 0) - (b.parts[index] ?? 0);
    if (difference !== 0) return difference;
  }
  if (a.pre === b.pre) return 0;
  if (a.pre === '') return 1;
  if (b.pre === '') return -1;
  return a.pre < b.pre ? -1 : 1;
}

/**
 * Where this deployment reads its release index. A profile patch replaces an entry's whole config, so an
 * override that only carries `features` must not silently disable updates: the default lives in code and
 * an explicit `off` (or `none` / `disabled`) is the only way to switch the check off.
 * @param config - the plugin config, possibly overridden by the profile patch.
 * @returns the manifest URL, or an empty string when the check was switched off on purpose.
 */
export function resolveUpdateManifest(config) {
  const raw = typeof config?.updateManifestUrl === 'string' ? config.updateManifestUrl.trim() : '';
  if (raw === '') return DEFAULT_UPDATE_MANIFEST;
  return UPDATE_MANIFEST_OFF.has(raw.toLowerCase()) ? '' : raw;
}

async function checkForUpdate(ctx, config, request, lifetimeSignal) {
  const manifestUrl = resolveUpdateManifest(config);
  if (manifestUrl === '') {
    return Response.json({ current: PACKAGE_INFO.version, latest: null, newer: false, unconfigured: true }, { headers: { 'cache-control': 'no-store' } });
  }
  try {
    const signal = AbortSignal.any([request.signal, lifetimeSignal, AbortSignal.timeout(10000)]);
    const response = await fetch(manifestUrl, { headers: { accept: 'application/json', 'cache-control': 'no-store' }, cache: 'no-store', redirect: 'follow', signal });
    if (!response.ok) throw new Error(`更新來源回應 ${response.status}`);
    const text = await response.text();
    let manifest;
    try { manifest = JSON.parse(text); } catch { throw new Error('更新來源不是 JSON：這個網址可能還沒放 index.json'); }
    const latest = manifest?.latest;
    if (latest === undefined || typeof latest.version !== 'string') throw new Error('更新來源格式無效');
    return Response.json({
      current: PACKAGE_INFO.version,
      latest: {
        version: latest.version,
        spec: typeof latest.spec === 'string' ? latest.spec : undefined,
        tarball: typeof latest.tarball === 'string' ? new URL(latest.tarball, manifestUrl).href : undefined,
        sha256: typeof latest.sha256 === 'string' ? latest.sha256 : undefined,
        notes: typeof latest.notes === 'string' ? latest.notes : undefined,
        publishedAt: typeof latest.publishedAt === 'string' ? latest.publishedAt : undefined,
      },
      newer: compareVersions(latest.version, PACKAGE_INFO.version) > 0,
      manifest: manifestUrl,
    }, { headers: { 'cache-control': 'no-store' } });
  } catch (error) {
    return Response.json({
      current: PACKAGE_INFO.version,
      latest: null,
      newer: false,
      manifest: manifestUrl,
      error: error instanceof Error ? error.message : '無法檢查更新',
    }, { headers: { 'cache-control': 'no-store' } });
  }
}


/**
 * One-click update: fetch the published release, verify its checksum, then hand the local file to DSH's
 * own plugin manager. Installation is the manager's operation, and installing another version is a
 * removal plus an installation, so this plugin is stopped while it updates — the page must be reloaded
 * afterwards. Nothing is written into node_modules by this plugin itself.
 * @param ctx - unified plugin context, which also exposes the profile's plugin manager.
 * @param config - deployment config; `updateManifestUrl` may point at another index.
 * @param request - the page's POST, whose body is unused.
 * @param lifetimeSignal - aborts the download when the plugin unloads.
 * @returns `updating` once the manager accepted the file, or a refusal the page can show.
 */
/**
 * Read a .tgz without adding a dependency to a plugin that ships offline.
 * @param buffer - gzip-compressed tarball, as served by the release host.
 * @returns regular files keyed by path, with the tarball's leading `package/` removed.
 */
export function readTarball(buffer) {
  const tar = gunzipSync(buffer);
  const cstr = (block, start, length) => block.subarray(start, start + length).toString('utf8').replace(/\0[\s\S]*$/, '').trim();
  const files = new Map();
  let offset = 0;
  while (offset + 512 <= tar.length) {
    const header = tar.subarray(offset, offset + 512);
    if (header.every(byte => byte === 0)) break;
    let name = cstr(header, 0, 100);
    if (header.subarray(257, 262).toString('utf8') === 'ustar') {
      const prefix = cstr(header, 345, 155);
      if (prefix !== '') name = `${prefix}/${name}`;
    }
    const size = Number.parseInt(cstr(header, 124, 12) || '0', 8);
    const kind = header[156] === 0 ? 48 : header[156];
    const dataStart = offset + 512;
    offset = dataStart + Math.ceil(size / 512) * 512;
    if (kind !== 48) continue;                                  // only regular files carry content
    const path = name.replace(/^package\//, '');
    // Never write outside the package, and never touch installed dependencies.
    if (path === '' || path.startsWith('/') || path.split('/').includes('..') || path.startsWith('node_modules/')) continue;
    files.set(path, tar.subarray(dataStart, dataStart + size));
  }
  return files;
}

/**
 * 列出「只有重啟才能生效」的檔案（host 端）：index.mjs、cordis.patch.yml 與 modules 下的 .mjs。
 * lib/client.js 與 modules/features/*.jsx 是打進前端 bundle 的，重載頁面就會換新，不算 host 變更。
 * @returns 相對路徑 → 內容雜湊。
 */
async function snapshotHostFiles() {
  const out = new Map();
  const walk = async relative => {
    const dir = join(PACKAGE_ROOT, relative);
    let entries;
    try { entries = await readdir(dir, { withFileTypes: true }); }
    catch { return; }
    for (const entry of entries) {
      const next = relative === '' ? entry.name : `${relative}/${entry.name}`;
      if (entry.isDirectory()) {
        if (entry.name === 'node_modules' || entry.name === 'lib' || entry.name === 'locale') continue;
        await walk(next);
        continue;
      }
      const hostFile = next === 'index.mjs' || next === 'cordis.patch.yml'
        || (next.startsWith('modules/') && next.endsWith('.mjs'));
      if (!hostFile) continue;
      try { out.set(next, createHash('sha1').update(await readFile(join(PACKAGE_ROOT, next))).digest('hex')); }
      catch { /* 讀不到就當作沒這個檔 */ }
    }
  };
  await walk('');
  return out;
}

/** 兩份快照是否有差異。 @returns 是否有 host 檔案變更。 */
function hostSnapshotsDiffer(before, after) {
  if (before.size !== after.size) return true;
  for (const [key, value] of before) if (after.get(key) !== value) return true;
  return false;
}

/**
 * Write a release's files over the installed package. Used when the plugin manager cannot swap a `link:`
 * install for a tarball (pnpm leaves a dangling link), and as the verification fallback otherwise.
 * @param files - the extracted tarball contents.
 * @returns how many files were written.
 */
export async function replaceInstalled(files) {
  let written = 0;
  for (const [relative, bytes] of files) {
    const target = join(PACKAGE_ROOT, relative);
    await mkdir(dirname(target), { recursive: true });
    await writeFile(target, bytes);
    written += 1;
  }
  return written;
}

/**
 * Keep only the archive that was just downloaded.
 *
 * The updater writes one tarball per version under ~/.aiapi/updates and never removed the previous ones — by
 * 2026-11-01 that directory held 22 files and 87 MB. Pruning is part of every download rather than a switch:
 * an update that leaves old builds behind is a bug, not a preference. A failed delete is ignored; leftover files
 * are a nuisance, not a reason to fail an update that already succeeded.
 * @param dir - the downloads directory.
 * @param keep - file name of the archive to keep.
 * @returns after the sweep.
 */
async function pruneOlderUpdateFiles(dir, keep) {
  try {
    const entries = await readdir(dir);
    await Promise.all(entries
      .filter(name => name.startsWith('aiapi-customizations-') && name.endsWith('.tgz') && name !== keep)
      .map(name => rm(join(dir, name), { force: true })));
  } catch {
    // Nothing to do: the update itself already succeeded or will report its own failure.
  }
}

/**
 * Start an update: read the manifest, answer at once, then download and install in the background.
 *
 * The download used to run inside the request that started it, so a slow link ended as 「The operation was aborted
 * due to timeout」 and the interface sat on 「更新中」 with nothing to show. The request now reads only the manifest
 * (a few kilobytes) and replies; the archive is fetched afterwards with byte-level progress written to
 * `updateState`, which the card polls for a percentage.
 * @param ctx - plugin context carrying the plugin manager.
 * @param config - plugin config, for the manifest URL.
 * @param request - the POST that starts it.
 * @param lifetimeSignal - aborted when the plugin unloads.
 * @returns the immediate answer: current, updating, unconfigured, unsupported or failed.
 */
async function applyUpdate(ctx, config, request, lifetimeSignal) {
  if (resolveUpdateManifest(config) === '') {
    return Response.json({ status: 'unconfigured', error: '尚未設定更新來源（updateManifestUrl）。' }, { status: 409, headers: { 'cache-control': 'no-store' } });
  }
  const manager = ctx.get?.('pluginManager');
  if (manager === undefined || typeof manager.installBundle !== 'function') {
    return Response.json({ status: 'unsupported', error: '這個 DSH 沒有提供外掛管理服務，請手動貼安裝字串。' }, { status: 501, headers: { 'cache-control': 'no-store' } });
  }
  try {
    const manifestUrl = typeof config?.updateManifestUrl === 'string' && config.updateManifestUrl.trim() !== ''
      ? config.updateManifestUrl.trim()
      : DEFAULT_UPDATE_MANIFEST;
    const manifestSignal = AbortSignal.any([request.signal, lifetimeSignal, AbortSignal.timeout(20000)]);
    const manifestResponse = await fetch(manifestUrl, { headers: { accept: 'application/json', 'cache-control': 'no-store' }, cache: 'no-store', redirect: 'follow', signal: manifestSignal });
    if (!manifestResponse.ok) throw new Error(`更新來源回應 ${manifestResponse.status}`);
    const manifest = await manifestResponse.json();
    const latest = manifest?.latest;
    if (latest === undefined || typeof latest.version !== 'string') throw new Error('更新來源格式無效');
    // Never install the published build over a newer one that is already running.
    if (compareVersions(latest.version, PACKAGE_INFO.version) <= 0) {
      return Response.json({ status: 'current', version: PACKAGE_INFO.version }, { headers: { 'cache-control': 'no-store' } });
    }
    const tarball = new URL(typeof latest.tarball === 'string' ? latest.tarball : `aiapi-customizations-${latest.version}.tgz`, manifestUrl);
    Object.assign(updateState, {
      phase: 'downloading', version: latest.version, error: '', received: 0,
      total: Number(latest.bytes) > 0 ? Number(latest.bytes) : 0, method: '', application: '', restartReason: '', at: Date.now(),
    });
    // The background job belongs to the plugin's lifetime, not to the request that started it.
    void downloadAndInstall(ctx, manager, latest, tarball, lifetimeSignal).catch(error => {
      Object.assign(updateState, { phase: 'failed', error: error instanceof Error ? error.message : '更新失敗', at: Date.now() });
      ctx.logger?.error?.(`aiapi update failed: ${error instanceof Error ? error.message : error}`);
    });
    return Response.json({ status: 'updating', version: latest.version, total: updateState.total }, { headers: { 'cache-control': 'no-store' } });
  } catch (error) {
    return Response.json({ status: 'failed', error: error instanceof Error ? error.message : '更新失敗' }, { status: 400, headers: { 'cache-control': 'no-store' } });
  }
}

/**
 * Fetch the archive with byte-level progress, then install it and sweep the older builds.
 *
 * Pruning happens only after the install succeeds: while pnpm resolves the profile it still reads the archive the
 * profile currently points at, so deleting it first broke the following update.
 * @param ctx - plugin context.
 * @param manager - the plugin manager service.
 * @param latest - the manifest's `latest` entry.
 * @param tarball - resolved archive URL.
 * @param lifetimeSignal - aborted when the plugin unloads.
 * @returns after the version on disk matches the manifest.
 */
async function downloadAndInstall(ctx, manager, latest, tarball, lifetimeSignal) {
  const signal = AbortSignal.any([lifetimeSignal, AbortSignal.timeout(600000)]);
  const response = await fetch(tarball, { cache: 'no-store', redirect: 'follow', signal });
  if (!response.ok) throw new Error(`下載更新檔失敗 ${response.status}`);
  const declared = Number(response.headers.get('content-length') ?? 0);
  if (declared > 0) Object.assign(updateState, { total: declared, at: Date.now() });
  const chunks = [];
  let received = 0;
  if (response.body !== null && typeof response.body?.getReader === 'function') {
    const reader = response.body.getReader();
    for (;;) {
      const { done, value } = await reader.read();
      if (done) break;
      chunks.push(Buffer.from(value));
      received += value.length;
      Object.assign(updateState, { received, at: Date.now() });
    }
  } else {
    const buffer = Buffer.from(await response.arrayBuffer());
    chunks.push(buffer);
    received = buffer.length;
  }
  const bytes = Buffer.concat(chunks);
  Object.assign(updateState, { phase: 'verifying', received: bytes.length, total: bytes.length, at: Date.now() });
  const digest = createHash('sha256').update(bytes).digest('hex');
  if (typeof latest.sha256 === 'string' && latest.sha256.toLowerCase() !== digest) throw new Error('更新檔校驗碼不符，已停止更新');
  const dir = join(homedir(), '.aiapi', 'updates');
  await mkdir(dir, { recursive: true });
  const name = `aiapi-customizations-${latest.version}.tgz`;
  const file = join(dir, name);
  await writeFile(file, bytes);
  Object.assign(updateState, { phase: 'installing', at: Date.now() });
  let managerResult;
  let managerError;
  const hostBefore = await snapshotHostFiles();
  try {
    managerResult = await manager.installBundle(`file:${file}`, { requestId: `aiapi-update-${latest.version}` });
  } catch (error) {
    managerError = error;
  }
  // The manager's word is not enough: read the version it actually left on disk.
  let onDisk = readOnDiskVersion();
  let method = 'manager';
  if (onDisk !== latest.version) {
    // A `link:` install cannot always be replaced by the manager; write the files over it instead.
    const written = await replaceInstalled(readTarball(bytes));
    method = 'copy';
    onDisk = readOnDiskVersion();
    if (onDisk !== latest.version) {
      throw new Error(`安裝後版本仍是 ${onDisk || '讀不到'}（已寫入 ${written} 個檔案）${managerError instanceof Error ? `；管理器：${managerError.message}` : ''}`);
    }
  }
  await pruneOlderUpdateFiles(dir, name);
  const hostChanged = hostSnapshotsDiffer(hostBefore, await snapshotHostFiles());
  const application = method === 'copy'
    ? 'restart-required'
    : (typeof managerResult?.application === 'string' ? managerResult.application : 'restart-required');
  Object.assign(updateState, {
    phase: 'done',
    method,
    application,
    hostChanged,
    restartReason: typeof managerResult?.restartReason === 'string' ? managerResult.restartReason : '',
    at: Date.now(),
  });
  ctx.logger?.info?.(`aiapi update: ${latest.version} via ${method} (${application}, hostChanged=${hostChanged})`);
}

/** The models the provider starts with before the Smart Key's own listing is known; mirrors cordis.patch.yml. */
const AIAPI_DEFAULT_MODELS = Object.freeze([Object.freeze({
  id: 'deepseek-v4.1-flash',
  name: 'DeepSeek V4.1 Flash',
  input: Object.freeze(['text', 'image']),
  contextWindow: 1048576,
  maxTokens: 393216,
})]);

/** Fields of a user's provider row this plugin carries over unchanged when it repairs the row. */
const AIAPI_KEPT_PROVIDER_FIELDS = ['displayName', 'modelOverrides', 'headers', 'compat', 'reasoning', 'thinkingBudgets', 'cacheRetention', 'transport', 'timeoutMs'];

/**
 * DSH only accepts a reasoning effort a model declares: a model without `reasoningEfforts` supports nothing
 * but `off`, and a profile asking for `reasoningEffort: max` is refused locally before any request
 * (2026-10-28：`provider "aiapi" model "deepseek-v4.1-flash" does not support reasoning effort "max"`).
 * AIAPI's /v1/models carries no capability data, so the levels come from the model family:
 * - DeepSeek offers exactly low/high/max (all three verified 200 on the platform for deepseek-v4.1-flash);
 * - other chat models get the OpenAI-compatible low/medium/high, which every upstream behind AIAPI accepts
 *   (`max` would reach an OpenAI or Anthropic upstream as an invalid value);
 * - image, embedding, audio and video models are not reasoning models.
 * `off` is never declared, so the picker shows exactly the levels listed here.
 * @param id - the model id as the gateway routes it.
 * @returns the `reasoningEfforts` value DSH expects.
 */
export function defaultReasoningEfforts(id) {
  const lowered = String(id ?? '').toLowerCase();
  if (!isChatModel(lowered)) return false;
  if (lowered.includes('deepseek')) return { low: 'low', high: 'high', max: 'max' };
  return { low: 'low', medium: 'medium', high: 'high' };
}

/** 替模型補上 reasoning 能力宣告；已宣告過的（含使用者手動調整）不覆蓋。 */
export function withReasoningEfforts(model) {
  if (model === null || typeof model !== 'object') return model;
  if (model.reasoningEfforts !== undefined) return model;
  if (model.reasoning === false) return { ...model, reasoningEfforts: false };
  return { ...model, reasoningEfforts: defaultReasoningEfforts(model.id) };
}

/** The stored Smart Key, or undefined when this profile is not signed in. */
async function aiapiKey(ctx) {
  const value = (await ctx.credentials.resolve(AIAPI_CREDENTIAL_REF))?.value;
  return typeof value === 'string' && value !== '' ? value : undefined;
}

/**
 * The live `llm-pi-ai` settings row. The plugin starts alongside the official entries, so the row may not be
 * configurable yet; waiting matters, because a write made against a missing row would start from nothing.
 * @param ctx - plugin context, owner of the settings service.
 * @param signal - aborts the wait when the plugin unloads.
 * @param timeoutMs - how long to wait for the entry to become configurable.
 * @returns the row, or undefined when it never appears.
 */
async function llmSettingsRow(ctx, signal, timeoutMs = 30000) {
  const deadline = Date.now() + timeoutMs;
  for (;;) {
    signal?.throwIfAborted();
    let row;
    try { row = ctx.settings?.describe?.().find(entry => entry.ns === SETTINGS_NAMESPACE); } catch { /* not ready yet */ }
    if (row !== undefined) return row;
    if (Date.now() >= deadline) return undefined;
    await new Promise(resolve => setTimeout(resolve, 500));
  }
}

const plain = value => value !== null && typeof value === 'object' && !Array.isArray(value);
const usableModel = model => plain(model) && typeof model.id === 'string' && model.id !== '';

/** Registrations run one at a time: start-up repair and a sign-in can otherwise race on the same row. */
let registration = Promise.resolve();

/**
 * Make sure DSH has a working `llm-pi-ai.providers.aiapi` route, written into the profile through the official
 * settings service exactly like a provider added on the Models page.
 *
 * The bundle's cordis.patch.yml declares the route, but a profile patch replaces an entry's whole config: once
 * the user's own `llm-pi-ai` row exists (any provider added by hand), the bundle's AIAPI route is gone and the
 * Models page shows no AIAPI card at all, so there is nowhere to sign in. Registration therefore needs no Smart
 * Key. The route authenticates through `apiKeyEnv: AIAPI_API_KEY` — the credential the sign-in stores; DSH never
 * reads a plaintext `apiKey` field, and a key written there would only leak into cordis.patch.yml.
 *
 * A route that already works is left alone. The model list is only replaced from the Smart Key's own listing
 * when it is missing or still the built-in default, so a hand-picked list survives; otherwise only the
 * reasoning levels DSH needs are filled in.
 * @param ctx - unified plugin context.
 * @param options - `auto` makes the list follow the account (otherwise the user's picked list is kept and only
 *   refreshed); `limits` are the capacity overrides; `signal` stops a pending wait; `waitMs` bounds the wait for
 *   the settings row.
 * @returns what was done, for logs and the /api/aiapi/provider route.
 */
export function ensureProvider(ctx, options = {}) {
  const run = registration.then(() => registerProvider(ctx, options));
  registration = run.catch(() => undefined);
  return run;
}

async function registerProvider(ctx, { limits = new Map(), signal, waitMs, auto = true } = {}) {
  if (typeof ctx.settings?.describe !== 'function' || typeof ctx.settings?.mutate !== 'function') return { status: 'unavailable' };
  const row = await llmSettingsRow(ctx, signal, waitMs);
  if (row === undefined) return { status: 'unavailable' };
  const effective = plain(row.value?.providers?.aiapi) ? row.value.providers.aiapi : undefined;
  const own = plain(row.user?.providers?.aiapi) ? row.user.providers.aiapi : undefined;
  const key = await aiapiKey(ctx);

  let models = Array.isArray(effective?.models) ? effective.models.filter(usableModel) : [];
  const onlyDefaults = models.length === 0
    || (models.length === AIAPI_DEFAULT_MODELS.length && models.every((model, index) => model.id === AIAPI_DEFAULT_MODELS[index].id));
  let synced = false;
  if (key !== undefined) {
    try {
      const timeout = signal === undefined ? AbortSignal.timeout(20000) : AbortSignal.any([signal, AbortSignal.timeout(20000)]);
      const listed = unpricedModels(await discover(
        { provider: 'aiapi', api: 'openai-completions', baseURL: AIAPI_MODEL_ENDPOINT, apiKey: key }, undefined, async () => undefined, timeout,
      ));
      if (listed.length > 0) {
        // The platform's catalog decides limits, image input and reasoning levels; a platform without the
        // endpoint (or an unreachable one) leaves every model as it was.
        const capabilities = await fetchCapabilities(AIAPI_MODEL_ENDPOINT, key, listed.map(model => model.id), timeout).catch(() => new Map());
        const upstream = new Map(listed.map(model => [model.id, { ...model, ...capabilityFields(capabilities.get(model.id)) }]));
        // Either source saying "not a chat model" settles it: the catalog only knows models it prices.
        const chat = model => capabilities.get(model.id)?.chat !== false && isChatModel(model.id);
        const current = new Map(models.map(model => [model.id, model]));
        if (auto || onlyDefaults) {
          // Automatic: the list is every chat model the account can use, in the platform's order.
          models = listed.filter(chat).map(model => ({ ...current.get(model.id), ...upstream.get(model.id), ...(current.get(model.id)?.name ? { name: current.get(model.id).name } : {}) }));
        } else {
          // Hand-picked: keep the user's list, drop what the account no longer offers, refresh what each can do.
          models = models.filter(model => upstream.has(model.id)).map(model => ({ ...model, ...capabilityFields(capabilities.get(model.id)) }));
        }
        synced = true;
      }
    } catch (error) {
      // An unreachable listing must not block the route: the current list keeps the Models page usable.
      ctx.logger?.warn?.(`aiapi model sync failed: ${error instanceof Error ? error.message : error}`);
    }
  }
  if (models.length === 0) models = AIAPI_DEFAULT_MODELS.map(model => ({ ...model, input: [...model.input] }));
  models = models.map(model => withReasoningEfforts({ ...model, ...limits.get(model.id) }));

  // One provider for everything: AIAPI's /v1/chat/completions converts to Anthropic upstream when the
  // routed account is an Anthropic one (`gateway_forward_as_chat_completions.go`: CC → Responses →
  // Anthropic), so Claude models travel down the same OpenAI-compatible route as the rest.
  // The raw profile row is carried over: the effective value has schema defaults filled in
  // (`compat.chatTemplateKwargs: {}` and the like), and writing those back would change requests.
  const kept = Object.fromEntries(AIAPI_KEPT_PROVIDER_FIELDS
    .map(field => [field, own?.[field]])
    .filter(([, value]) => value !== undefined));
  const desired = {
    ...kept,
    displayName: kept.displayName ?? 'AIAPI',
    api: 'openai-completions',
    baseURL: AIAPI_MODEL_ENDPOINT,
    apiKeyEnv: AIAPI_CREDENTIAL_REF,
    models,
  };
  const healthy = effective !== undefined
    && own?.apiKey === undefined
    && effective.api === desired.api
    && effective.baseURL === desired.baseURL
    && effective.apiKeyEnv === desired.apiKeyEnv
    && isDeepStrictEqual(effective.models, desired.models)
    && row.value?.providers?.[AIAPI_ANTHROPIC_PROVIDER] === undefined;
  if (healthy) return { status: 'current', models: models.length, synced };

  // One `set` op replaces the whole route, which also drops a plaintext apiKey an older version wrote.
  const ops = [{ op: 'set', path: ['providers', 'aiapi'], value: desired }];
  // 1.11.0 split Claude onto its own provider; take that card back so the Models page shows one AIAPI only.
  if (row.value?.providers?.[AIAPI_ANTHROPIC_PROVIDER] !== undefined) {
    ops.push({ op: 'unset', path: ['providers', AIAPI_ANTHROPIC_PROVIDER] });
  }
  await ctx.settings.mutate(SETTINGS_NAMESPACE, ops, row.revision);
  return { status: effective === undefined ? 'registered' : 'repaired', models: models.length, synced };
}

/**
 * Forget the AIAPI connection this profile holds: the Smart Key and any half-finished sign-in.
 * The provider entry and the user's own settings are left untouched, so signing in again is one click.
 * @param ctx - unified plugin context, owner of the credential store.
 * @param request - the page's POST, whose body is unused.
 * @returns the state the card should show next.
 */
async function disconnectAccount(ctx, request) {
  try {
    if (request.signal.aborted) throw new Error('已取消');
    await ctx.credentials.unset(AIAPI_CREDENTIAL_REF);
    await ctx.credentials.unset(AIAPI_PENDING_CREDENTIAL_REF);
    await ctx.credentials.unset(AIAPI_DEVICE_CREDENTIAL_REF);
    return Response.json({ status: 'disconnected' }, { headers: { 'cache-control': 'no-store' } });
  } catch (error) {
    return Response.json({ status: 'failed', error: error instanceof Error ? error.message : '無法清除連接' }, { status: 500, headers: { 'cache-control': 'no-store' } });
  }
}


/**
 * 這台 DSH 的 Smart Key 在 AIAPI 平台上還能用多少：帳號餘額、金鑰自己的定額、所屬分組。
 * @param ctx - plugin context（憑證擁有者）。
 * @param request - 頁面的 GET。
 * @param lifetimeSignal - 外掛卸載時中止。
 * @returns 餘額 JSON，或可顯示的錯誤。
 */
async function readBalance(ctx, request, lifetimeSignal) {
  try {
    const credential = await ctx.credentials.resolve(AIAPI_CREDENTIAL_REF);
    const apiKey = credential?.value;
    if (!apiKey) return Response.json({ status: 'unauthenticated' }, { status: 401, headers: { 'cache-control': 'no-store' } });
    const signal = AbortSignal.any([request.signal, lifetimeSignal, AbortSignal.timeout(12000)]);
    const response = await fetch(`${AIAPI_MODEL_ENDPOINT}/balance`, {
      headers: { accept: 'application/json', authorization: `Bearer ${apiKey}`, 'cache-control': 'no-store' },
      cache: 'no-store', redirect: 'error', signal,
    });
    const payload = await response.json().catch(() => undefined);
    if (response.status === 401 || response.status === 403) {
      return Response.json({ status: 'invalid-key', error: 'AIAPI 拒絕了這個 Smart Key（可能已停用或刪除），請重新登入。' }, { status: 401, headers: { 'cache-control': 'no-store' } });
    }
    if (!response.ok) return Response.json({ status: 'failed', error: payload?.error?.message ?? payload?.message ?? `AIAPI 回應 ${response.status}` }, { status: 502, headers: { 'cache-control': 'no-store' } });
    return Response.json({ status: 'ok', ...payload, at: Date.now() }, { headers: { 'cache-control': 'no-store' } });
  } catch (error) {
    return Response.json({ status: 'failed', error: error instanceof Error ? error.message : '無法取得餘額' }, { status: 502, headers: { 'cache-control': 'no-store' } });
  }
}

/**
 * 把使用者端的錯誤回報轉送到平台的 /v1/client-report；沒有金鑰時直接回 204。
 * @param ctx - plugin context。
 * @param request - 頁面送來的 POST。
 * @param lifetimeSignal - 外掛卸載時中止。
 * @returns 204（回報器不該讓使用者看到錯誤）。
 */
async function forwardReport(ctx, request, lifetimeSignal) {
  try {
    const payload = await request.text();
    const credential = await ctx.credentials.resolve(AIAPI_CREDENTIAL_REF);
    const apiKey = credential?.value;
    if (!apiKey) return new Response(null, { status: 204 });
    const signal = AbortSignal.any([request.signal, lifetimeSignal, AbortSignal.timeout(10000)]);
    await fetch(`${AIAPI_MODEL_ENDPOINT}/client-report`, {
      method: 'POST',
      headers: { 'content-type': 'application/json', authorization: `Bearer ${apiKey}` },
      body: payload, redirect: 'error', signal,
    });
    return new Response(null, { status: 204 });
  } catch {
    return new Response(null, { status: 204 });
  }
}

function validRedirectURI(value) {
  return value === 'aiapi-agent://oauth/callback' || value === 'aiapi-agent-preview://oauth/callback';
}

async function postDesktopAuth(path, body, signal) {
  const response = await fetch(`${AIAPI_DESKTOP_AUTH_ENDPOINT}${path}`, {
    method: 'POST',
    headers: { accept: 'application/json', 'content-type': 'application/json', 'cache-control': 'no-store' },
    body: JSON.stringify(body),
    cache: 'no-store',
    redirect: 'error',
    signal,
  });
  let payload;
  try { payload = await response.json(); } catch { throw new Error('AIAPI 授權服務暫時無法使用'); }
  if (!response.ok || payload?.code !== 0) throw new Error('AIAPI 授權服務暫時無法使用');
  return payload.data;
}

function desktopAuthFailure(error, ctx) {
  const failure = error instanceof Error ? error : new Error('Unknown desktop authorization failure');
  // The page gets a plain sentence; the log keeps the real cause, which the generic sentence would otherwise hide.
  ctx?.logger?.warn?.(`aiapi sign-in failed: ${failure.stack ?? failure.message}${failure.cause ? ` (cause: ${failure.cause?.message ?? failure.cause})` : ''}`);
  const message = /^桌面授權|^桌面登入|^找不到待完成|^授權服務/.test(failure.message) ? failure.message : '無法完成 AIAPI 帳號授權，請檢查網路後重試。';
  const status = /^桌面授權|^桌面登入|^找不到待完成/.test(failure.message) ? 400 : 503;
  // `detail` is for diagnosis (devtools, error reports); the page shows only `error`.
  return Response.json({ error: message, detail: `${failure.message}${failure.cause ? ` (${failure.cause?.message ?? failure.cause})` : ''}`.slice(0, 300) }, { status, headers: { 'cache-control': 'no-store' } });
}
