/** Metadata parsing is deliberately independent of model-name heuristics. */
const levels = new Set(['off', 'minimal', 'low', 'medium', 'high', 'xhigh', 'max']);
const object = value => value !== null && typeof value === 'object' && !Array.isArray(value);
const positive = (...values) => values.find(value => Number.isSafeInteger(value) && value > 0);
const publicCatalogNamespaces = new Map([
  ['claude', 'anthropic'],
  ['codex', 'openai'],
  ['deepseek', 'deepseek'],
  ['gemini', 'google'],
]);
const publicModelRequestAliases = new Map([
  ['deepseek-flash', 'deepseek-v4.1-flash'],
]);

/** Ids of image, embedding, audio and video models: listed by the gateway, but not usable in a conversation. */
const NON_CHAT_MODEL = /(?:^|[-_/.])(?:image|images|embed|embedding|embeddings|tts|whisper|transcribe|dall-e|moderation|rerank|seedance|seedream|veo|sora|kling|video|audio)(?:$|[-_/.\d])|^gpt-image|^text-embedding/;

/**
 * Whether a model can hold a conversation (as opposed to generating images, audio or embeddings).
 * @param id - model id as the gateway lists it.
 * @returns false for image, embedding, audio and video models.
 */
export function isChatModel(id) {
  return !NON_CHAT_MODEL.test(String(id ?? '').toLowerCase());
}

/** Resolve a priced catalog ID to the exact model ID accepted by the gateway. */
export function requestModelIdForPublicModel(id) {
  return publicModelRequestAliases.get(id) ?? id;
}

/**
 * Every id that names the same gateway model, including the id itself.
 *
 * A listing and the public price table can disagree for a while after a rename, so routability is
 * decided over the whole group: whichever id the account endpoint lists, the model is available.
 * @param id - any id of the family.
 * @returns the family ids, current name first.
 */
export function modelAliasPeers(id) {
  const peers = [id];
  for (const [retired, current] of publicModelRequestAliases) {
    if (id === retired || id === current) peers.push(retired === id ? current : retired);
  }
  return peers;
}

/**
 * The name to show and to send upstream: the current id, never the retired one.
 * @param id - id from the account listing or the price table.
 * @returns the canonical id.
 */
export function canonicalModelId(id) {
  return publicModelRequestAliases.get(id) ?? id;
}

/** Fill missing capacities and input types from an exact match; gateway values win. */
export function enrichModelMetadata(model, match) {
  for (const field of ['contextWindow', 'maxTokens']) {
    if (model[field] === undefined && match?.[field] !== undefined) model[field] = match[field];
  }
  if (model.input === undefined && match?.input !== undefined) model.input = [...match.input];
}

/** Validate deployment-owned route limits; names alone never imply capacities. */
export function capacityOverrides(value = {}) {
  if (!object(value)) throw new Error('modelCapacityOverrides must be an object');
  const result = new Map();
  for (const [id, row] of Object.entries(value)) {
    if (!id.trim() || !object(row) || Object.keys(row).some(key => !['contextWindow', 'maxTokens'].includes(key))) {
      throw new Error('Invalid modelCapacityOverrides entry');
    }
    for (const number of Object.values(row)) {
      if (!Number.isSafeInteger(number) || number <= 0) throw new Error('Model capacities must be positive integers');
    }
    if (row.contextWindow !== undefined && row.maxTokens !== undefined && row.maxTokens > row.contextWindow) {
      throw new Error('Model output limit cannot exceed its context window');
    }
    result.set(id, row);
  }
  return result;
}

/** Resolve AIAPI's known public groups to exact provider-qualified catalog IDs. */
export function publicModelSourceIds(payload) {
  const result = new Map();
  const seen = new Set();
  const ambiguous = new Set();
  for (const group of payload?.data?.groups ?? []) {
    if (!object(group) || !Array.isArray(group.models)) continue;
    const namespace = publicCatalogNamespaces.get(String(group.name ?? '').trim().toLowerCase());
    for (const row of group.models) {
      if (!object(row) || typeof row.id !== 'string' || !row.id.trim() || row.id.length > 256) continue;
      if (!namespace || row.id.includes('/')) continue;
      const requestIds = new Set([row.id, publicModelRequestAliases.get(row.id)].filter(Boolean));
      for (const requestId of requestIds) {
        if (seen.has(requestId)) {
          result.delete(requestId);
          ambiguous.add(requestId);
          continue;
        }
        seen.add(requestId);
        result.set(requestId, `${namespace}/${row.id}`);
      }
    }
  }
  for (const id of ambiguous) result.delete(id);
  return result;
}

/** Convert explicit endpoint mappings/effort lists to the official pi-ai representation. */
export function reasoningOf(row) {
  if (row.reasoningEfforts === false || row.reasoning === false) return false;
  const source = row.reasoningEfforts ?? row.reasoning?.supported_efforts ?? row.supported_reasoning_efforts ?? row.reasoning_efforts;
  if (source === undefined) return undefined;
  const mapping = {};
  const entries = Array.isArray(source) ? source.map(value => [value, value]) : object(source) ? Object.entries(source) : [];
  for (const [raw, wire] of entries) {
    if (typeof raw !== 'string') continue;
    const level = raw === 'none' ? 'off' : raw === 'ultra' ? 'max' : raw;
    if (!levels.has(level)) continue;
    if (level === 'off') mapping.off = null;
    else if (typeof wire === 'string' && wire.length > 0 && wire.length <= 40) mapping[level] = wire;
  }
  return Object.keys(mapping).length ? mapping : undefined;
}

/** Normalize bounded provider listings; unknown capacities and capabilities stay absent. */
export function parseListing(payload) {
  let rows;
  if (Array.isArray(payload?.data)) rows = payload.data;
  else if (Array.isArray(payload?.models)) rows = payload.models;
  else if (object(payload?.models)) rows = Object.entries(payload.models).filter(([, row]) => object(row)).map(([id, row]) => ({ ...row, id }));
  else throw new Error('供應商沒有回傳可識別的模型清單');
  const found = new Map();
  for (const row of rows.slice(0, 10000)) {
    if (!object(row) || typeof row.id !== 'string' || !row.id.trim() || row.id.length > 256) continue;
    const model = { id: row.id, name: String(row.name ?? row.display_name ?? row.id).slice(0, 256) };
    const context = positive(row.contextWindow, row.context_window, row.context_length, row.limit?.context);
    const output = positive(row.maxTokens, row.max_tokens, row.max_output_tokens, row.top_provider?.max_completion_tokens, row.limit?.output);
    if (context) model.contextWindow = context;
    if (output) model.maxTokens = output;
    const reasoning = reasoningOf(row);
    if (reasoning !== undefined) model.reasoningEfforts = reasoning;
    const input = row.input ?? row.inputModalities ?? row.architecture?.input_modalities;
    if (Array.isArray(input)) {
      const supported = ['text', 'image'].filter(value => input.includes(value));
      if (supported.length) model.input = supported;
    }
    found.set(row.id, model);
  }
  return [...found.values()];
}

/** Keep only priced models the authenticated account listing can route. */
export function mergePublicPricingModels(models, payload) {
  const groups = payload?.code === 0 && Array.isArray(payload.data?.groups) ? payload.data.groups : undefined;
  if (!groups) throw new Error('模型價格清單格式無效');

  const discovered = new Map(models.map(model => [model.id, model]));
  const published = new Map();
  for (const group of groups) {
    if (!object(group) || !Array.isArray(group.models)) throw new Error('模型價格清單格式無效');
    for (const row of group.models) {
      if (object(row) && typeof row.id === 'string' && row.id.trim() && row.id.length <= 256 && !published.has(row.id)) {
        const requestId = requestModelIdForPublicModel(row.id);
        const candidates = [...new Set([...modelAliasPeers(row.id), ...modelAliasPeers(requestId)])];
        const metadata = candidates.map(id => discovered.get(id)).find(Boolean);
        if (!metadata) continue;
        // Emit the current name: a listing that still carries the retired id must not reach the gateway.
        const id = canonicalModelId(metadata.id);
        if (published.has(id)) continue;
        published.set(id, {
          ...metadata,
          id,
          name: id === row.id && metadata.name !== undefined && metadata.name !== metadata.id ? metadata.name : id,
        });
      }
    }
  }
  if (published.size === 0) throw new Error('模型價格清單目前沒有已公布的模型');
  return [...published.values()];
}

/**
 * Models the account listing reported, canonicalised and de-duplicated, for use when the public price list
 * cannot be compared. Keeps a retired alias from reaching the gateway twice under two ids.
 * @param models - the provider's model listing.
 * @returns model entries safe to show and to save into the provider config.
 */
export function unpricedModels(models) {
  const seen = new Map();
  for (const model of Array.isArray(models) ? models : []) {
    if (!object(model) || typeof model.id !== 'string' || model.id === '') continue;
    const id = canonicalModelId(model.id);
    if (seen.has(id)) continue;
    seen.set(id, { ...model, id, name: model.name ?? id });
  }
  return [...seen.values()];
}

/** Enforce limits while streaming, including servers without Content-Length. */
export async function readJson(response, limit = 4 * 1024 * 1024) {
  if (!response.ok) { await response.body?.cancel(); throw new Error(`模型查詢失敗（HTTP ${response.status}）`); }
  const reader = response.body?.getReader();
  if (!reader) throw new Error('模型回應沒有內容');
  let size = 0;
  const parts = [];
  try {
    for (;;) {
      const { done, value } = await reader.read();
      if (done) break;
      size += value.length;
      if (size > limit) throw new Error('模型回應超過大小上限');
      parts.push(value);
    }
  } finally { await reader.cancel(); }
  return JSON.parse(Buffer.concat(parts).toString('utf8'));
}

/** Never forward stored credentials when a draft changes the configured endpoint. */
export function sameEndpoint(left, right) {
  return typeof left === 'string' && typeof right === 'string' && left.replace(/\/+$/, '') === right.replace(/\/+$/, '');
}

/** Fetch a provider listing; redirects cannot forward credentials to a different host. */
export async function discover(request, stored, resolveKey, signal, fetcher = fetch) {
  const url = new URL(request.baseURL);
  if (!['http:', 'https:'].includes(url.protocol) || url.username || url.password || url.search || url.hash) throw new Error('請填寫沒有帳密或查詢參數的 HTTP(S) API 位址');
  const trusted = sameEndpoint(request.baseURL, stored?.baseURL);
  const key = request.apiKey || (trusted && stored?.apiKeyEnv ? await resolveKey(stored.apiKeyEnv) : undefined);
  const headers = new Headers(trusted ? stored?.headers : undefined);
  headers.set('accept', 'application/json');
  if (key) {
    if (request.api === 'anthropic-messages') headers.set('x-api-key', key);
    else headers.set('authorization', `Bearer ${key}`);
  }
  const base = url.href.replace(/\/+$/, '');
  const endpoint = request.api === 'anthropic-messages' ? `${base.replace(/\/v1$/, '')}/v1/models?limit=1000` : `${base}/models`;
  if (request.api === 'anthropic-messages') headers.set('anthropic-version', '2023-06-01');
  return parseListing(await readJson(await fetcher(endpoint, { headers, signal, redirect: 'error' })));
}
