import React, { useEffect, useMemo, useState } from 'react';
import { isChatModel, requestModelIdForPublicModel } from './discovery.mjs';
import { Logo } from '../../../aiapi-brand/client.jsx';
import {
  Button, Checkbox, Input, Modal, SegmentedControl, StateDot, Tag,
  accountStore, installStyle, useAccount,
} from '../ui/kit.jsx';

export const name = 'aiapi-models';
export const inject = ['slots', 'remote', 'remote.settings'];
const ns = 'llm-pi-ai';
const unwrap = response => { if (!response.ok) throw new Error(response.error.message); return response.value; };

const MODELS_CSS = `
.aiapi-provider{display:flex;flex-direction:column;gap:10px;padding:4px 0 2px}
.aiapi-provider-head{display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap}
.aiapi-provider-who{display:flex;align-items:center;gap:8px;min-width:0}
.aiapi-provider-note{color:var(--dsw-alias-label-tertiary);font-size:12px;line-height:18px}
.aiapi-provider-code{display:flex;align-items:center;gap:10px;flex-wrap:wrap}
.aiapi-catalog-tools{display:flex;flex-direction:column;gap:10px;margin-bottom:8px}
.aiapi-catalog-list{max-height:min(52vh,460px);overflow-y:auto;margin:0 -4px;padding:0 4px}
.aiapi-catalog-group{margin-top:12px}
.aiapi-catalog-group:first-child{margin-top:0}
.aiapi-catalog-group-head{display:flex;align-items:center;justify-content:space-between;gap:8px;position:sticky;top:0;z-index:1;padding:6px 0;background:var(--dsw-alias-bg-layer-2);color:var(--dsw-alias-label-secondary);font-size:12px;font-weight:500}
.aiapi-catalog-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:2px 12px}
.aiapi-catalog-item{min-width:0;padding:4px 0}
.aiapi-catalog-id{color:var(--dsw-alias-label-tertiary);font-size:11px;margin-left:4px}
.aiapi-catalog-empty{padding:32px 0;text-align:center;color:var(--dsw-alias-label-tertiary)}
.aiapi-catalog-footer{display:flex;align-items:center;justify-content:space-between;gap:12px;width:100%}
`;

/** Extend the official provider card; the official Models section remains its owner. */
export function apply(ctx) {
  installStyle(ctx, 'models', MODELS_CSS);
  ctx.slots.inject('settings.models.provider-card', () => ctx.slots.register({
    name: 'settings.models.provider-card',
    key: ns,
    inject: () => ({ remote: ctx.remote }),
  }, ProviderCard));
  ctx.effect(() => installDesktopOAuthListener());
}

/**
 * The AIAPI part of the official provider card: who is signed in, the sign-in itself, and the model picker.
 * The account comes from the same store as 「账号与余额」, so both always agree.
 */
function ProviderCard({ remote, provider }) {
  const account = useAccount();
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState('');
  const [catalog, setCatalog] = useState();
  const [selected, setSelected] = useState([]);
  useEffect(() => {
    const onOAuthResult = event => {
      if (event.detail?.status === 'complete') { setMessage(''); void accountStore.refresh(); }
      if (event.detail?.status === 'access_denied') setMessage('你在授權頁拒絕了這次登入。');
      if (event.detail?.status === 'expired') setMessage('登入要求已逾時，請重新開始。');
      if (event.detail?.status === 'error') setMessage('無法完成桌面登入，請重新開始。');
    };
    window.addEventListener('aiapi-desktop-oauth-result', onOAuthResult);
    return () => window.removeEventListener('aiapi-desktop-oauth-result', onOAuthResult);
  }, []);

  if (provider.provider !== 'aiapi') return null;
  const signedIn = account.data !== undefined && (account.phase === 'ok' || account.phase === 'error');
  const pending = account.signIn;

  /** Read the account's listing and open the picker on it. */
  const discover = async () => {
    setBusy(true);
    setMessage('');
    try {
      const described = unwrap(await remote.settings.describe());
      const profile = described.namespaces.find(row => row.ns === ns)?.value?.providers?.aiapi;
      if (!profile) throw new Error('AIAPI 供應商還在註冊中，請稍候再試。');
      const result = await hostRequest('/api/aiapi/models', { provider: 'aiapi', enrich: true });
      setSelected(Array.isArray(profile.models) ? profile.models : []);
      setCatalog(result.models);
      if (result.models.length === 0) setMessage(result.warning ?? '這個帳號目前沒有可用的模型。');
    } catch (error) {
      setMessage(error instanceof Error ? error.message : '模型查詢失敗。');
    } finally {
      setBusy(false);
    }
  };

  /** Save the picked models as the provider's model list. */
  const saveModels = async models => {
    setCatalog(undefined);
    setBusy(true);
    setMessage('');
    try {
      const described = unwrap(await remote.settings.describe());
      const section = described.namespaces.find(row => row.ns === ns);
      if (!section?.value?.providers?.aiapi) throw new Error('AIAPI 設定剛被其他地方修改，請重新整理後再試。');
      unwrap(await remote.settings.mutate(ns, [{ op: 'set', path: ['providers', 'aiapi', 'models'], value: models }], section.revision));
      setMessage(`已更新，對話中可選用 ${models.length} 個 AIAPI 模型。`);
    } catch (error) {
      setMessage(error instanceof Error ? error.message : '模型設定儲存失敗。');
    } finally {
      setBusy(false);
    }
  };

  return <div className="aiapi-provider" data-aiapi-models-slot>
    <div className="aiapi-provider-head">
      <div className="aiapi-provider-who">
        <Logo size={20} />
        <span className="aiapi-row-title">AIAPI 帳號</span>
        <span className="aiapi-row-caption aiapi-status">
          <StateDot state={signedIn ? 'done' : account.phase === 'loading' ? 'idle' : 'warning'} />
          {signedIn ? (account.data.group?.name ? `已登入 · 分組 ${account.data.group.name}` : '已登入')
            : account.phase === 'loading' ? '讀取中' : account.phase === 'invalid-key' ? '登入已失效' : '未登入'}
        </span>
      </div>
      <div className="aiapi-row-actions">
        {signedIn
          ? <Button variant="outline" size="sm" disabled={busy} onClick={() => { void discover(); }}>{busy ? '讀取中…' : '選擇模型'}</Button>
          : pending === undefined
            ? <Button variant="primary" size="sm" disabled={account.busy || account.phase === 'loading'} onClick={() => { void accountStore.signIn(); }}>使用 AIAPI 帳號登入</Button>
            : null}
      </div>
    </div>
    {pending === undefined ? null : <div className="aiapi-provider-code">
      <span className="aiapi-provider-note">在已開啟的授權頁確認代碼後按「允許這次登入」：</span>
      <span className="aiapi-code">{pending.user_code}</span>
      <Button variant="outline" size="sm" onClick={() => window.open(pending.verification_uri, '_blank', 'noopener')}>重新開啟授權頁</Button>
      <Button variant="ghost" size="sm" onClick={() => accountStore.cancelSignIn()}>取消</Button>
    </div>}
    {!signedIn && pending === undefined && account.phase !== 'loading'
      ? <span className="aiapi-provider-note">登入後會自動帶入你的帳號能用的模型，不需要自己建立或貼上金鑰。</span>
      : null}
    {message !== '' ? <span className="aiapi-provider-note" role="status">{message}</span>
      : account.error !== '' && pending === undefined && !signedIn ? <span className="aiapi-provider-note aiapi-error-text" role="alert">{account.error}</span> : null}
    {catalog ? <Catalog models={catalog} selected={selected} close={() => setCatalog(undefined)} apply={saveModels} /> : null}
  </div>;
}

function installDesktopOAuthListener() {
  if (!window.__TAURI_INTERNALS__) return () => {};
  let disposed = false;
  let processing = false;
  let retryTimer;
  let activeCallback;
  const completedCallbacks = new Set();
  const attempt = async callback => {
    if (disposed || processing || typeof callback !== 'string') return;
    processing = true;
    try {
      const result = await hostRequest('/api/aiapi/desktop-auth/oauth/callback', { callback });
      if (result.status === 'authorization_pending') {
        retryTimer = window.setTimeout(() => { void attempt(callback); }, 2000);
        return;
      }
      completedCallbacks.add(callback);
      activeCallback = undefined;
      window.dispatchEvent(new CustomEvent('aiapi-desktop-oauth-result', { detail: { status: result.status } }));
      finishDesktopCallback(callback);
    } catch (error) {
      if (error?.status >= 400 && error.status < 500) {
        completedCallbacks.add(callback);
        activeCallback = undefined;
        window.dispatchEvent(new CustomEvent('aiapi-desktop-oauth-result', { detail: { status: 'error' } }));
        finishDesktopCallback(callback);
      } else {
        retryTimer = window.setTimeout(() => { void attempt(callback); }, 5000);
      }
    } finally {
      processing = false;
    }
  };
  const receive = callback => {
    if (disposed || typeof callback !== 'string' || completedCallbacks.has(callback)) return;
    if (activeCallback && activeCallback !== callback) return;
    activeCallback = callback;
    void attempt(callback);
  };
  const onCallback = event => receive(event.detail);
  window.addEventListener('dsh-desktop-oauth-callback', onCallback);
  for (const callback of window.__DSH_DESKTOP_OAUTH_CALLBACKS__ ?? []) receive(callback);
  void hostRequest('/api/aiapi/desktop-auth/oauth/resume', {}).then(result => {
    if (result.status === 'resume' && typeof result.callback === 'string') receive(result.callback);
    if (result.status === 'expired') window.dispatchEvent(new CustomEvent('aiapi-desktop-oauth-result', { detail: { status: 'expired' } }));
  }).catch(() => {});
  return () => {
    disposed = true;
    window.removeEventListener('dsh-desktop-oauth-callback', onCallback);
    window.clearTimeout(retryTimer);
  };
}

function finishDesktopCallback(callback) {
  let state;
  try { state = new URL(callback).searchParams.get('state'); } catch { return; }
  if (!state) return;
  const callbacks = window.__DSH_DESKTOP_OAUTH_CALLBACKS__;
  if (Array.isArray(callbacks)) {
    const index = callbacks.indexOf(callback);
    if (index >= 0) callbacks.splice(index, 1);
  }
  window.location.assign(`dsh-action://oauth-complete?state=${encodeURIComponent(state)}`);
}

async function hostRequest(path, body) {
  const response = await fetch(new URL(path.replace(/^\//, ''), document.baseURI), {
    method: 'POST',
    credentials: 'same-origin',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(body),
    cache: 'no-store',
  });
  const result = await response.json();
  if (!response.ok) {
    const error = new Error(result.error ?? 'AIAPI 授權失敗，請稍後再試。');
    error.status = response.status;
    throw error;
  }
  return result;
}

/**
 * Pick which of the account's models DSH offers. Models are grouped by maker; the tabs narrow to new ones (not in
 * the current list), picked ones, or ones that left the account.
 */
function Catalog({ models, selected, close, apply }) {
  const availableById = useMemo(() => new Map(models.map(model => [model.id, model])), [models]);
  const resolvedSelected = useMemo(() => selected.map(model => {
    const id = requestModelIdForPublicModel(model.id);
    const resolved = { ...model, id, ...availableById.get(id) };
    if (model.input?.length) resolved.input = [...model.input];
    delete resolved.requestModelId;
    return resolved;
  }), [selected, availableById]);
  const existingIds = new Set(resolvedSelected.map(model => model.id));
  const [query, setQuery] = useState('');
  const [tab, setTab] = useState('all');
  const [checked, setChecked] = useState(() => selected.length ? new Set(existingIds) : new Set(models.filter(model => isChatModel(model.id)).map(model => model.id)));

  const newModels = models.filter(model => !existingIds.has(model.id));
  const removedModels = resolvedSelected.filter(model => !availableById.has(model.id));
  const candidates = tab === 'new' ? newModels
    : tab === 'selected' ? models.filter(model => checked.has(model.id))
      : tab === 'removed' ? removedModels : models;
  const needle = query.trim().toLowerCase();
  const rows = candidates.filter(model => `${model.id} ${model.name ?? ''}`.toLowerCase().includes(needle));
  const groups = new Map();
  for (const model of rows) {
    const brand = isChatModel(model.id) ? categorizeModelId(model.id, model.name) : NON_CHAT_GROUP;
    groups.set(brand, [...groups.get(brand) ?? [], model]);
  }
  const order = brand => { const index = MODEL_BRAND_ORDER.indexOf(brand); return index === -1 ? MODEL_BRAND_ORDER.length : index; };
  const groupNames = [...groups.keys()].sort((a, b) => order(a) - order(b) || a.localeCompare(b));

  const setMany = (ids, on) => setChecked(previous => {
    const next = new Set(previous);
    for (const id of ids) { if (on) next.add(id); else next.delete(id); }
    return next;
  });
  const save = () => {
    const existingById = new Map(resolvedSelected.map(model => [model.id, model]));
    const result = [];
    for (const model of models) {
      if (!checked.has(model.id)) continue;
      const existing = existingById.get(model.id);
      const name = cleanModelDisplayName(model.name);
      const candidate = { ...model };
      if (existing?.input?.length) candidate.input = [...existing.input];
      delete candidate.reasoningSource;
      const merged = existing ? { ...existing, ...candidate } : candidate;
      if (name) merged.name = name;
      if (candidate.requestModelId === undefined) delete merged.requestModelId;
      result.push(merged);
      existingById.delete(model.id);
    }
    for (const [id, model] of existingById) if (checked.has(id)) result.push({ ...model });
    apply(result);
  };
  const tabs = [
    { value: 'all', label: `全部 ${models.length}` },
    { value: 'selected', label: `已選 ${models.filter(model => checked.has(model.id)).length}` },
    { value: 'new', label: `新的 ${newModels.length}`, disabled: newModels.length === 0 },
    ...(removedModels.length ? [{ value: 'removed', label: `已下架 ${removedModels.length}` }] : []),
  ];

  return <Modal
    open
    title="選擇要在 DSH 使用的 AIAPI 模型"
    description="勾選的模型會出現在對話的模型選單；之後隨時可以回來調整。"
    closeLabel="關閉"
    onClose={close}
    footer={<div className="aiapi-catalog-footer">
      <span className="aiapi-row-caption">已選 {checked.size} 個</span>
      <div className="aiapi-row-actions">
        <Button variant="ghost" onClick={close}>取消</Button>
        <Button variant="primary" disabled={checked.size === 0} onClick={save}>套用</Button>
      </div>
    </div>}
  >
    <div className="aiapi-catalog-tools">
      <Input type="search" aria-label="搜尋模型" placeholder="搜尋模型名稱或 ID" value={query} onChange={event => setQuery(event.target.value)} />
      <SegmentedControl id="aiapi-catalog-tab" label="篩選" value={tab} options={tabs} onChange={setTab} />
    </div>
    <div className="aiapi-catalog-list">
      {groupNames.length === 0
        ? <div className="aiapi-catalog-empty">{query ? '沒有符合搜尋的模型' : '這裡沒有模型'}</div>
        : groupNames.map(brand => {
          const group = groups.get(brand);
          const picked = group.filter(model => checked.has(model.id)).length;
          return <div className="aiapi-catalog-group" key={brand}>
            <div className="aiapi-catalog-group-head">
              <span>{brand} <Tag tone="neutral">{picked}/{group.length}</Tag></span>
              <Button variant="ghost" size="sm" onClick={() => setMany(group.map(model => model.id), picked < group.length)}>{picked < group.length ? '全選' : '全不選'}</Button>
            </div>
            <div className="aiapi-catalog-grid">
              {group.map(model => {
                const name = cleanModelDisplayName(model.name);
                return <div className="aiapi-catalog-item" key={model.id} title={model.id}>
                  <Checkbox
                    checked={checked.has(model.id)}
                    label={<>{name ?? model.id}{name && name !== model.id ? <span className="aiapi-catalog-id">{model.id}</span> : null}</>}
                    onChange={on => setMany([model.id], on)}
                  />
                </div>;
              })}
            </div>
          </div>;
        })}
    </div>
  </Modal>;
}

/** Where image, audio and embedding models are listed: last, and off unless picked on purpose. */
const NON_CHAT_GROUP = '圖像、語音與嵌入（不用於對話）';

const MODEL_BRAND_ORDER = [
  'DeepSeek', 'GLM（智譜）', 'Kimi（月之暗面）', 'MiniMax', 'MiMo（小米）',
  'Hunyuan（騰訊混元）', 'Muse（Meta）', 'Qwen（阿里通義）', 'OpenAI',
  'Anthropic', 'Google（Gemini）', 'xAI（Grok）', 'Doubao（豆包）',
  'LongCat（美團）', 'Mistral', 'Other', NON_CHAT_GROUP,
];

function cleanModelDisplayName(name) {
  if (typeof name !== 'string' || name.trim().length === 0) return undefined;
  return name.replace(/^(?:(?:[a-zA-Z0-9\s._-]+):\s+)/, '').trim() || name;
}

function categorizeModelId(id, name) {
  const combined = `${id} ${name ?? ''}`.toLowerCase();
  if (combined.includes('deepseek')) return 'DeepSeek';
  if (['glm', 'chatglm', 'zhipu', 'z.ai'].some(value => combined.includes(value))) return 'GLM（智譜）';
  if (['kimi', 'moonshot'].some(value => combined.includes(value))) return 'Kimi（月之暗面）';
  if (['hunyuan', 'hy4', 'hy3', 'tencent'].some(value => combined.includes(value))) return 'Hunyuan（騰訊混元）';
  if (['minimax', 'abab'].some(value => combined.includes(value))) return 'MiniMax';
  if (['mimo', 'xiaomi'].some(value => combined.includes(value))) return 'MiMo（小米）';
  if (combined.includes('muse')) return 'Muse（Meta）';
  if (['meta', 'llama'].some(value => combined.includes(value))) return 'Meta';
  if (['qwen', 'qwq', 'tongyi', 'alibaba'].some(value => combined.includes(value))) return 'Qwen（阿里通義）';
  if (['claude', 'anthropic'].some(value => combined.includes(value))) return 'Anthropic';
  if (['gpt', 'o1', 'o3', 'o4', 'o5', 'openai', 'chatgpt'].some(value => combined.includes(value))) return 'OpenAI';
  if (['gemini', 'gemma', 'google'].some(value => combined.includes(value))) return 'Google（Gemini）';
  if (['grok', 'xai', 'x-ai'].some(value => combined.includes(value))) return 'xAI（Grok）';
  if (['doubao', 'seedance', 'bytedance', 'volcengine'].some(value => combined.includes(value))) return 'Doubao（豆包）';
  if (['longcat', 'meituan'].some(value => combined.includes(value))) return 'LongCat（美團）';
  if (['mistral', 'codestral', 'pixtral', 'ministral'].some(value => combined.includes(value))) return 'Mistral';
  if (id.includes('/')) return id.split('/')[0].replace(/^./, character => character.toUpperCase());
  return 'Other';
}
