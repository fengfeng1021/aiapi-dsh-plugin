/** Runtime map from subagents to the conversation that started them, kept for the agent-facing context tools that group work by conversation. */

/**
 * Track which agent started each subagent, learned when the subagent starts.
 * The map lives for this plugin activation; subagents started before it stay ungrouped.
 * @param ctx - unified plugin context.
 * @returns `rootOf(agentId)` (the conversation's root agent) and `family(rootId)` (the root plus its known descendants).
 */
export function trackLineage(ctx) {
  const parents = new Map();
  ctx.on('subagent/start', info => {
    const parent = ctx.get('agents')?.currentInitiator?.();
    if (parent && parent.id !== info.id) parents.set(info.id, parent.id);
  });
  const rootOf = id => {
    let current = id;
    const seen = new Set();
    while (parents.has(current) && !seen.has(current)) {
      seen.add(current);
      current = parents.get(current);
    }
    return current;
  };
  const family = root => [root, ...[...parents.keys()].filter(child => rootOf(child) === root)];
  return { rootOf, family, parents };
}
