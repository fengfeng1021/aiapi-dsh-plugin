import React, { useEffect, useRef, useState } from 'react';
import { dispatchDrop, dropNotice, planIntake, prepareDrop, readImage } from './intake.mjs';
import { railOverrideCss } from './rail.mjs';
import { fileTargetFrom } from './file-target.mjs';
import { baseName, resolvePath } from './paths.mjs';
import css from './ui.txt';

/** Mounted main-conversation composers that may receive native drops and resolve relative links. */
const panes = new Set();
/** Opening drafts staged for sessions created by "continue in a new conversation". */
export const stagedDrafts = new Map();
const invokeShell = () => window.__TAURI_INTERNALS__?.invoke;

/**
 * Desktop intake, file-location menu, left turn rail, and conversation handoff.
 * Every listener, element, and stylesheet is owned by this plugin scope and removed when it is disabled.
 * @param ctx - client plugin context.
 */
export function apply(ctx) {
  ctx.effect(() => {
    const style = document.createElement('style');
    style.dataset.aiapiDesktopUi = '';
    style.textContent = css;
    document.head.append(style);
    return () => style.remove();
  });
  ctx.effect(installRailOverride);
  ctx.effect(() => installFileMenu(ctx));
  ctx.effect(installDropRouting);
  ctx.slots.inject('conversation.input.dock', () => ctx.slots.register({
    name: 'conversation.input.dock', id: 'aiapi-desktop-intake',
  }, DesktopIntake));
  ctx.slots.inject('conversation.session.header.actions', () => ctx.slots.register({
    name: 'conversation.session.header.actions', id: 'aiapi-handoff', order: 90,
    inject: () => ({ openSession: id => ctx.get('uiWorkspace')?.openSession(id) }),
  }, HandoffAction));
}

/** Keep the official virtualized rail, restyled from its own CSS-module rules; no transcript DOM is read. */
function installRailOverride() {
  const style = document.createElement('style');
  style.dataset.aiapiTurnRail = 'left';
  document.head.append(style);
  let source;
  const update = () => {
    const tag = document.querySelector('style[data-plugin-css$="/TurnNavigator.module.css"]');
    if (!tag?.sheet || tag === source) return;
    let rules;
    try { rules = tag.sheet.cssRules; } catch { return; } // a sheet still loading has no readable rules yet
    const text = railOverrideCss(rules);
    if (text === undefined) return;
    style.textContent = text;
    source = tag;
  };
  update();
  // Observe stylesheet installation only; transcript rows and geometry are never observed.
  const observer = new window.MutationObserver(update);
  observer.observe(document.head, { childList: true });
  return () => { observer.disconnect(); style.remove(); };
}

let toastTimer;
/**
 * Show one transient status line; a newer message replaces the previous one.
 * @param level - `info` or `error`.
 * @param text - plain-language message.
 */
export function showToast(level, text) {
  let toast = document.querySelector('.aiapi-toast');
  if (!toast) {
    toast = document.createElement('div');
    toast.className = 'aiapi-toast';
    document.body.append(toast);
  }
  toast.dataset.level = level;
  toast.setAttribute('role', level === 'error' ? 'alert' : 'status');
  toast.textContent = text;
  toast.hidden = false;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.remove(), level === 'error' ? 8000 : 4000);
}

const paneContaining = element => (element ? [...panes].find(pane => pane.root()?.contains(element)) : undefined);
const firstPane = () => [...panes].find(pane => pane.root());

function installFileMenu(ctx) {
  const menu = document.createElement('div');
  menu.className = 'aiapi-file-menu';
  menu.setAttribute('role', 'menu');
  menu.hidden = true;
  const reveal = document.createElement('button');
  const copy = document.createElement('button');
  const pathLine = document.createElement('div');
  pathLine.dataset.menuPath = '';
  for (const item of [reveal, copy]) { item.type = 'button'; item.setAttribute('role', 'menuitem'); }
  copy.textContent = '複製完整路徑';
  menu.append(reveal, copy, pathLine);
  document.body.append(menu);
  let current;
  const close = () => { menu.hidden = true; current = undefined; };
  const open = (target, x, y) => {
    current = target;
    reveal.textContent = target.directory ? '開啟資料夾所在位置' : '開啟檔案所在位置';
    pathLine.textContent = target.absolute;
    pathLine.title = target.absolute;
    menu.hidden = false;
    const { width, height } = menu.getBoundingClientRect();
    menu.style.left = `${Math.max(4, Math.min(x, window.innerWidth - width - 4))}px`;
    menu.style.top = `${Math.max(4, Math.min(y, window.innerHeight - height - 4))}px`;
    reveal.focus();
  };
  reveal.addEventListener('click', () => {
    const target = current;
    close();
    if (target) void revealPath(ctx, target.absolute);
  });
  copy.addEventListener('click', () => {
    const target = current;
    close();
    if (!target) return;
    navigator.clipboard.writeText(target.absolute).then(
      () => showToast('info', '已複製完整路徑。'),
      () => showToast('error', '無法寫入剪貼簿，請稍後再試。'),
    );
  });
  const onContextMenu = event => {
    const found = fileTargetFrom(event.target);
    if (!found) { close(); return; }
    event.preventDefault();
    event.stopPropagation();
    const cwd = (paneContaining(found.element) ?? firstPane())?.cwd();
    const absolute = resolvePath(cwd, found.path);
    if (absolute === undefined) {
      showToast('error', `無法判斷「${found.path}」位於哪個工作區，請改用完整路徑。`);
      return;
    }
    open({ absolute, directory: found.directory }, event.clientX, event.clientY);
  };
  const onPointerDown = event => { if (!menu.hidden && !menu.contains(event.target)) close(); };
  const onKeyDown = event => {
    if (menu.hidden) return;
    if (event.key === 'Escape') { event.preventDefault(); event.stopPropagation(); close(); return; }
    if (event.key === 'ArrowDown' || event.key === 'ArrowUp') {
      event.preventDefault();
      (document.activeElement === reveal ? copy : reveal).focus();
    }
  };
  document.addEventListener('contextmenu', onContextMenu, true);
  document.addEventListener('pointerdown', onPointerDown, true);
  document.addEventListener('keydown', onKeyDown, true);
  window.addEventListener('blur', close);
  window.addEventListener('resize', close);
  document.addEventListener('scroll', close, true);
  return () => {
    document.removeEventListener('contextmenu', onContextMenu, true);
    document.removeEventListener('pointerdown', onPointerDown, true);
    document.removeEventListener('keydown', onKeyDown, true);
    window.removeEventListener('blur', close);
    window.removeEventListener('resize', close);
    document.removeEventListener('scroll', close, true);
    menu.remove();
  };
}

/**
 * Select the file in the system file manager through the verified Host path API.
 * A missing file is reported before the Host is asked when the desktop shell can classify it.
 * @param ctx - client context owning the Session Remote.
 * @param absolute - absolute Host path.
 */
async function revealPath(ctx, absolute) {
  const invoke = invokeShell();
  if (invoke) {
    try {
      const [entry] = await invoke('desktop_path_kinds', { paths: [absolute] });
      if (entry?.kind === 'missing') {
        showToast('error', `找不到「${baseName(absolute)}」，可能已被移動、改名或刪除。\n${absolute}`);
        return;
      }
    } catch {
      // Older desktop shells lack path classification; the Host verification below still applies.
    }
  }
  let result;
  try {
    result = await ctx.remote.session.openWorkspacePath({ path: absolute, action: 'reveal' });
  } catch {
    // An unreachable Host fails the gesture like a Host that refused it.
  }
  if (result?.ok) return;
  showToast('error', result?.error?.code === 'gateway/bad-request'
    ? `找不到「${baseName(absolute)}」，可能已被移動、改名或刪除。\n${absolute}`
    : `無法開啟檔案所在位置，請確認檔案仍存在。\n${absolute}`);
}

function installDropRouting() {
  const overlay = document.createElement('div');
  overlay.className = 'aiapi-drop-overlay';
  overlay.hidden = true;
  const card = document.createElement('div');
  card.className = 'aiapi-drop-card';
  const title = document.createElement('strong');
  const detail = document.createElement('span');
  card.append(title, detail);
  overlay.append(card);
  document.body.append(overlay);
  const show = entries => {
    const plan = planIntake(Array.isArray(entries) ? entries : []);
    const count = plan.references.length + plan.images.length;
    if (!firstPane()) {
      title.textContent = '請先開啟或建立對話';
      detail.textContent = '開啟對話後，再把檔案拖進視窗。';
    } else {
      title.textContent = count > 0 ? `放開以加入 ${count} 個項目` : '這些項目無法加入';
      detail.textContent = plan.directories.length > 0
        ? '檔案與資料夾以原始位置引用，不會複製、移動或刪除。'
        : '檔案以原始位置引用，不會複製、移動或刪除；圖片會顯示縮圖。';
    }
    overlay.hidden = false;
  };
  const hide = () => { overlay.hidden = true; };
  const route = async (entries, x, y) => {
    const hit = Number.isFinite(x) && x >= 0 ? document.elementFromPoint(x, y) : null;
    const pane = paneContaining(hit) ?? paneContaining(document.activeElement) ?? firstPane();
    if (!pane) { showToast('error', '請先開啟或建立對話，再把檔案拖進視窗。'); return; }
    await pane.accept(entries);
  };
  const onDrag = event => {
    const value = event.detail;
    if (value?.phase === 'enter') show(value.entries);
    else if (value?.phase === 'leave') hide();
    else if (value?.phase === 'drop') { hide(); void route(Array.isArray(value.entries) ? value.entries : [], value.x, value.y); }
  };
  // Carriers before 0.1.24 dispatched only the dropped path strings.
  const onLegacyDrop = event => {
    if (Array.isArray(event.detail) && event.detail.every(path => typeof path === 'string')) void route(event.detail, -1, -1);
  };
  window.addEventListener('aiapi-desktop-drag', onDrag);
  window.addEventListener('aiapi-desktop-drop', onLegacyDrop);
  return () => {
    window.removeEventListener('aiapi-desktop-drag', onDrag);
    window.removeEventListener('aiapi-desktop-drop', onLegacyDrop);
    overlay.remove();
  };
}

function DesktopIntake({ useInput, inputActions, useSession, useSessions, sessionId }) {
  const state = useInput(value => value);
  const subagent = useSession(value => value.subagent);
  const cwd = useSessions?.(value => value.byId?.[sessionId]?.cwd);
  const latest = useRef(state);
  latest.current = state;
  const cwdRef = useRef(cwd);
  cwdRef.current = cwd;
  const marker = useRef();
  const [notice, setNotice] = useState();
  useEffect(() => {
    if (!notice) return undefined;
    const timer = setTimeout(() => setNotice(undefined), notice.level === 'error' ? 9000 : 5000);
    return () => clearTimeout(timer);
  }, [notice]);
  useEffect(() => {
    const staged = stagedDrafts.get(sessionId);
    if (staged === undefined) return undefined;
    // Let the editor adopt any persisted draft first; never overwrite text the user already has.
    const timer = setTimeout(() => {
      stagedDrafts.delete(sessionId);
      if (latest.current.draft !== '' || latest.current.phase !== 'plain') return;
      // The handoff file rides as plain text; DSH 0.2.1 has no reference API to call here.
      inputActions.setDraft(staged.references.length === 0
        ? staged.text : `${staged.text}（交接檔：${staged.references.map(reference => reference.path).join('、')}）`);
    }, 300);
    return () => clearTimeout(timer);
  }, [sessionId, inputActions]);
  useEffect(() => {
    if (subagent) return undefined;
    let active = true;
    let pending = false;
    const root = () => marker.current?.closest('[data-conversation-content]');
    const accept = async entries => {
      if (!active) return;
      if (pending) { setNotice({ level: 'error', text: '上一批檔案仍在加入，請稍候再拖入。' }); return; }
      const invoke = invokeShell();
      if (!invoke) { setNotice({ level: 'error', text: '桌面外殼無法使用，請重新開啟應用程式。' }); return; }
      pending = true;
      try {
        const drop = await prepareDrop(entries, {
          read: path => readImage(invoke, path),
          isActive: () => active,
          phase: () => latest.current.phase,
        });
        if (!active) return;
        const unhandled = !drop.cancelled && drop.files.length > 0 && !dispatchDrop(drop, document);
        setNotice(dropNotice({ ...drop, unhandled }));
      } catch {
        if (active) setNotice({ level: 'error', text: '加入檔案失敗，請確認檔案仍存在。圖片支援 PNG、JPEG、WebP、GIF，大小依附件設定限制。' });
      } finally { pending = false; }
    };
    const pane = { root, accept, cwd: () => cwdRef.current };
    panes.add(pane);
    return () => {
      active = false;
      panes.delete(pane);
    };
  }, [subagent]);
  return <div ref={marker} data-aiapi-desktop-intake="" data-level={notice?.level}
    hidden={!notice} role={notice?.level === 'error' ? 'alert' : 'status'}>{notice?.text}</div>;
}

function HandoffAction({ sessionId, useSession, openSession }) {
  const subagent = useSession(value => value.subagent);
  const running = useSession(value => value.running);
  const [busy, setBusy] = useState(false);
  if (subagent) return null;
  const run = async () => {
    setBusy(true);
    try {
      const response = await fetch(new URL('api/aiapi/handoff', document.baseURI), {
        method: 'POST', credentials: 'same-origin',
        headers: { 'content-type': 'application/json' }, body: JSON.stringify({ sessionId }),
      });
      const value = await response.json().catch(() => ({}));
      if (!response.ok || typeof value.sessionId !== 'string') throw new Error(value.error || '服務沒有回應');
      if (typeof value.draft === 'string') {
        stagedDrafts.set(value.sessionId, { text: value.draft, references: typeof value.path === 'string' ? [{ path: value.path }] : [] });
      }
      openSession(value.sessionId);
      showToast('info', value.summary || '已建立續做對話，交接內容會隨第一則訊息送出。');
    } catch (error) {
      showToast('error', `無法建立續做對話：${error instanceof Error ? error.message : String(error)}`);
    } finally { setBusy(false); }
  };
  return <button type="button" className="aiapi-handoff" disabled={busy || running} onClick={run}
    title={running ? '請先等目前的工作完成或停止，再到新對話續做。' : '建立新對話並自動帶入工作區、需求、成果與待辦，接著繼續未完成的工作'}>
    {busy ? '整理交接中…' : '在新對話續做'}
  </button>;
}
