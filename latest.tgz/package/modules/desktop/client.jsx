import React, { useEffect, useRef, useState } from 'react';
import { dispatchDrop, dropNotice, planIntake, prepareDrop, readImage } from './intake.mjs';
import { baseName, resolvePath } from './paths.mjs';
import css from './ui.txt';

/** Mounted main-conversation composers that may receive native drops and resolve relative links. */
const panes = new Set();
/** Opening drafts staged for sessions created by "continue in a new conversation". */
export const stagedDrafts = new Map();
const invokeShell = () => window.__TAURI_INTERNALS__?.invoke;

/**
 * Desktop intake, file-location menu, left turn rail, and conversation handoff.
 * Every listener, element, and stylesheet is owned by this plugin scope and removed when it is disabled.
 * @param ctx - client plugin context.
 */
export function apply(ctx) {
  ctx.effect(() => {
    const style = document.createElement('style');
    style.dataset.aiapiDesktopUi = '';
    style.textContent = css;
    document.head.append(style);
    return () => style.remove();
  });
  ctx.effect(installDropRouting);
  ctx.slots.inject('conversation.input.dock', () => ctx.slots.register({
    name: 'conversation.input.dock', id: 'aiapi-desktop-intake',
  }, DesktopIntake));
  ctx.slots.inject('conversation.session.header.actions', () => ctx.slots.register({
    name: 'conversation.session.header.actions', id: 'aiapi-handoff', order: 90,
    inject: () => ({ openSession: id => ctx.get('uiWorkspace')?.openSession(id) }),
  }, HandoffAction));
}

export function showToast(level, text) {
  let toast = document.querySelector('.aiapi-toast');
  if (!toast) {
    toast = document.createElement('div');
    toast.className = 'aiapi-toast';
    document.body.append(toast);
  }
  toast.dataset.level = level;
  toast.setAttribute('role', level === 'error' ? 'alert' : 'status');
  toast.textContent = text;
  toast.hidden = false;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.remove(), level === 'error' ? 8000 : 4000);
}

const paneContaining = element => (element ? [...panes].find(pane => pane.root()?.contains(element)) : undefined);
const firstPane = () => [...panes].find(pane => pane.root());

function installDropRouting() {
  const overlay = document.createElement('div');
  overlay.className = 'aiapi-drop-overlay';
  overlay.hidden = true;
  const card = document.createElement('div');
  card.className = 'aiapi-drop-card';
  const title = document.createElement('strong');
  const detail = document.createElement('span');
  card.append(title, detail);
  overlay.append(card);
  document.body.append(overlay);
  const show = entries => {
    const plan = planIntake(Array.isArray(entries) ? entries : []);
    const count = plan.references.length + plan.images.length;
    if (!firstPane()) {
      title.textContent = '請先開啟或建立對話';
      detail.textContent = '開啟對話後，再把檔案拖進視窗。';
    } else {
      title.textContent = count > 0 ? `放開以加入 ${count} 個項目` : '這些項目無法加入';
      detail.textContent = plan.directories.length > 0
        ? '檔案與資料夾以原始位置引用，不會複製、移動或刪除。'
        : '檔案以原始位置引用，不會複製、移動或刪除；圖片會顯示縮圖。';
    }
    overlay.hidden = false;
  };
  const hide = () => { overlay.hidden = true; };
  const route = async (entries, x, y) => {
    const hit = Number.isFinite(x) && x >= 0 ? document.elementFromPoint(x, y) : null;
    const pane = paneContaining(hit) ?? paneContaining(document.activeElement) ?? firstPane();
    if (!pane) { showToast('error', '請先開啟或建立對話，再把檔案拖進視窗。'); return; }
    await pane.accept(entries);
  };
  const onDrag = event => {
    const value = event.detail;
    if (value?.phase === 'enter') show(value.entries);
    else if (value?.phase === 'leave') hide();
    else if (value?.phase === 'drop') { hide(); void route(Array.isArray(value.entries) ? value.entries : [], value.x, value.y); }
  };
  // Carriers before 0.1.24 dispatched only the dropped path strings.
  const onLegacyDrop = event => {
    if (Array.isArray(event.detail) && event.detail.every(path => typeof path === 'string')) void route(event.detail, -1, -1);
  };
  window.addEventListener('aiapi-desktop-drag', onDrag);
  window.addEventListener('aiapi-desktop-drop', onLegacyDrop);
  return () => {
    window.removeEventListener('aiapi-desktop-drag', onDrag);
    window.removeEventListener('aiapi-desktop-drop', onLegacyDrop);
    overlay.remove();
  };
}

function DesktopIntake({ useInput, inputActions, useSession, useSessions, sessionId }) {
  const state = useInput(value => value);
  const subagent = useSession(value => value.subagent);
  const cwd = useSessions?.(value => value.byId?.[sessionId]?.cwd);
  const latest = useRef(state);
  latest.current = state;
  const cwdRef = useRef(cwd);
  cwdRef.current = cwd;
  const marker = useRef();
  const [notice, setNotice] = useState();
  useEffect(() => {
    if (!notice) return undefined;
    const timer = setTimeout(() => setNotice(undefined), notice.level === 'error' ? 9000 : 5000);
    return () => clearTimeout(timer);
  }, [notice]);
  useEffect(() => {
    const staged = stagedDrafts.get(sessionId);
    if (staged === undefined) return undefined;
    // Let the editor adopt any persisted draft first; never overwrite text the user already has.
    const timer = setTimeout(() => {
      stagedDrafts.delete(sessionId);
      if (latest.current.draft !== '' || latest.current.phase !== 'plain') return;
      // The handoff file rides as plain text; DSH 0.2.1 has no reference API to call here.
      inputActions.setDraft(staged.references.length === 0
        ? staged.text : `${staged.text}（交接檔：${staged.references.map(reference => reference.path).join('、')}）`);
    }, 300);
    return () => clearTimeout(timer);
  }, [sessionId, inputActions]);
  useEffect(() => {
    if (subagent) return undefined;
    let active = true;
    let pending = false;
    const root = () => marker.current?.closest('[data-conversation-content]');
    const accept = async entries => {
      if (!active) return;
      if (pending) { setNotice({ level: 'error', text: '上一批檔案仍在加入，請稍候再拖入。' }); return; }
      const invoke = invokeShell();
      if (!invoke) { setNotice({ level: 'error', text: '桌面外殼無法使用，請重新開啟應用程式。' }); return; }
      pending = true;
      try {
        const drop = await prepareDrop(entries, {
          read: path => readImage(invoke, path),
          isActive: () => active,
          phase: () => latest.current.phase,
        });
        if (!active) return;
        const unhandled = !drop.cancelled && drop.files.length > 0 && !dispatchDrop(drop, document);
        setNotice(dropNotice({ ...drop, unhandled }));
      } catch {
        if (active) setNotice({ level: 'error', text: '加入檔案失敗，請確認檔案仍存在。圖片支援 PNG、JPEG、WebP、GIF，大小依附件設定限制。' });
      } finally { pending = false; }
    };
    const pane = { root, accept, cwd: () => cwdRef.current };
    panes.add(pane);
    return () => {
      active = false;
      panes.delete(pane);
    };
  }, [subagent]);
  return <div ref={marker} data-aiapi-desktop-intake="" data-level={notice?.level}
    hidden={!notice} role={notice?.level === 'error' ? 'alert' : 'status'}>{notice?.text}</div>;
}

function HandoffAction({ sessionId, useSession, openSession }) {
  const subagent = useSession(value => value.subagent);
  const running = useSession(value => value.running);
  const [busy, setBusy] = useState(false);
  if (subagent) return null;
  const run = async () => {
    setBusy(true);
    try {
      const response = await fetch(new URL('api/aiapi/handoff', document.baseURI), {
        method: 'POST', credentials: 'same-origin',
        headers: { 'content-type': 'application/json' }, body: JSON.stringify({ sessionId }),
      });
      const value = await response.json().catch(() => ({}));
      if (!response.ok || typeof value.sessionId !== 'string') throw new Error(value.error || '服務沒有回應');
      if (typeof value.draft === 'string') {
        stagedDrafts.set(value.sessionId, { text: value.draft, references: typeof value.path === 'string' ? [{ path: value.path }] : [] });
      }
      openSession(value.sessionId);
      showToast('info', value.summary || '已建立續做對話，交接內容會隨第一則訊息送出。');
    } catch (error) {
      showToast('error', `無法建立續做對話：${error instanceof Error ? error.message : String(error)}`);
    } finally { setBusy(false); }
  };
  return <button type="button" className="aiapi-handoff" disabled={busy || running} onClick={run}
    title={running ? '請先等目前的工作完成或停止，再到新對話續做。' : '建立新對話並自動帶入工作區、需求、成果與待辦，接著繼續未完成的工作'}>
    {busy ? '整理交接中…' : '在新對話續做'}
  </button>;
}
