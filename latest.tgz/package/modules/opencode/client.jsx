import React, { useEffect, useState } from 'react';

/**
 * OpenCode-inspired color theme for the DSH Web UI.
 *
 * The palette follows opencode's v2 tokens (MIT, https://github.com/anomalyco/opencode):
 * near-black page, raised panels, muted grey text, purple headings and orange links/interactive
 * accents, plus green inline code and teal/red diff pairs. DSH exposes the same layers as
 * `--dsw-alias-*` tokens on `body`, so the theme overrides those tokens instead of any hashed
 * component class; the Web markup can change without breaking it.
 */

const STORAGE_KEY = 'aiapi.opencode-theme';
const ATTRIBUTE = 'data-aiapi-opencode';

const CSS = `
html[${ATTRIBUTE}] body {
  --dsw-alias-bg-base: #ffffff;
  --dsw-alias-bg-layer-1: #ffffff;
  --dsw-alias-bg-layer-2: #f6f6f6;
  --dsw-alias-bg-layer-3: #ffffff;
  --dsw-alias-bg-module-platform: #f1f1f1;
  --dsw-alias-bg-multi-select: #f1f1f1;
  --dsw-alias-bg-overlay: #f6f6f6;
  --dsw-alias-bg-skeleton: rgba(0, 0, 0, 0.05);
  --dsw-alias-border-l1: rgba(0, 0, 0, 0.06);
  --dsw-alias-border-l2: #b8b8b8;
  --dsw-alias-border-l2-darkmode-thin: rgba(0, 0, 0, 0.12);
  --dsw-alias-border-l3: #b8b8b8;
  --dsw-alias-border-l4: #9a9a9a;
  --dsw-alias-label-primary: #161616;
  --dsw-alias-label-secondary: #4b4b4b;
  --dsw-alias-label-tertiary: #6b6b6b;
  --dsw-alias-label-caption: #808080;
  --dsw-alias-label-dimmed: #d0d0d0;
  --dsw-alias-label-primary-inverted: #ffffff;
  --dsw-alias-label-primary-foreground: #ffffff;
  --dsw-alias-link: #c2410c;
  --dsw-alias-brand-primary: #c2410c;
  --dsw-alias-brand-text: #161616;
  --dsw-alias-button-primary-fill: #c2410c;
  --dsw-alias-button-primary-hover: #9a3412;
  --dsw-alias-button-info-fill: #2563eb;
  --dsw-alias-button-info-hover: #1d4ed8;
  --dsw-alias-markdown-code-block: #f6f6f6;
  --dsw-alias-markdown-code-block-banner: #efefef;
  --dsw-alias-markdown-inline-code: #e7f6ec;
  --dsw-alias-markdown-tag: #efefef;
  --dsw-alias-markdown-citation: #f1f1f1;
  --dsw-alias-state-success-primary: #1e725c;
  --dsw-alias-state-error-primary: #c53b53;
  --dsw-alias-state-warn-primary: #b45309;
  --dsw-alias-state-business-primary: #7c3aed;
  --dsw-alias-code-diff-added: rgba(30, 114, 92, 0.12);
  --dsw-alias-code-diff-deleted: rgba(197, 59, 83, 0.12);
  --dsw-alias-file-diff-added-bg: #e6f4ee;
  --dsw-alias-file-diff-added-gutter: #d9ece3;
  --dsw-alias-file-diff-added-marker: #1e725c;
  --dsw-alias-file-diff-deleted-bg: #fbe9ec;
  --dsw-alias-file-diff-deleted-gutter: #f7dde1;
  --dsw-alias-file-diff-deleted-marker: #c53b53;
  --dsw-alias-scrollbar-bg-l1: #d0d0d0;
  --dsw-alias-scrollbar-bg-l2: #d0d0d0;
  --dsw-alias-scrollbar-hover-l1: #b8b8b8;
  --dsw-alias-scrollbar-hover-l2: #b8b8b8;
  --dsw-specific-bubble: #f6f6f6;
  --dsw-specific-bubble-highlight: #ececec;
  --dsw-specific-input-major: #ffffff;
  --dsw-specific-sidebar-fill: #fafafa;
  --dsw-specific-sidebar-nav-item-hover: #f1f1f1;
  --dsw-specific-sidebar-nav-item-active: #e7e7e7;
  --dsw-specific-sidebar-nav-item-active-accent: #fde8d7;
  --dsw-specific-selector: #f1f1f1;
  --dsw-specific-tip: #f1f1f1;
}

html[${ATTRIBUTE}] body[data-ds-dark-theme] {
  --dsw-alias-bg-base: #0a0a0a;
  --dsw-alias-bg-layer-1: #0a0a0a;
  --dsw-alias-bg-layer-2: #141414;
  --dsw-alias-bg-layer-3: #1e1e1e;
  --dsw-alias-bg-module-platform: #141414;
  --dsw-alias-bg-multi-select: #141414;
  --dsw-alias-bg-overlay: #1e1e1e;
  --dsw-alias-bg-skeleton: rgba(255, 255, 255, 0.06);
  --dsw-alias-border-l1: rgba(255, 255, 255, 0.06);
  --dsw-alias-border-l2: #262626;
  --dsw-alias-border-l2-darkmode-thin: rgba(255, 255, 255, 0.08);
  --dsw-alias-border-l3: #484848;
  --dsw-alias-border-l4: #606060;
  --dsw-alias-label-primary: #eeeeee;
  --dsw-alias-label-secondary: #c8c8c8;
  --dsw-alias-label-tertiary: #a0a0a0;
  --dsw-alias-label-caption: #808080;
  --dsw-alias-label-dimmed: #4c4c4c;
  --dsw-alias-label-primary-inverted: #0a0a0a;
  --dsw-alias-label-primary-foreground: #0a0a0a;
  --dsw-alias-link: #fab283;
  --dsw-alias-brand-primary: #9d7cd8;
  --dsw-alias-brand-text: #eeeeee;
  --dsw-alias-button-primary-fill: #fab283;
  --dsw-alias-button-primary-hover: #e89b6a;
  --dsw-alias-button-info-fill: #9d7cd8;
  --dsw-alias-button-info-hover: #8a68c4;
  --dsw-alias-markdown-code-block: #141414;
  --dsw-alias-markdown-code-block-banner: #1e1e1e;
  --dsw-alias-markdown-inline-code: #1e1e1e;
  --dsw-alias-markdown-tag: #1e1e1e;
  --dsw-alias-markdown-citation: #1e1e1e;
  --dsw-alias-state-success-primary: #7fd88f;
  --dsw-alias-state-error-primary: #e06c75;
  --dsw-alias-state-warn-primary: #f5a742;
  --dsw-alias-state-business-primary: #9d7cd8;
  --dsw-alias-code-diff-added: rgba(79, 214, 190, 0.14);
  --dsw-alias-code-diff-deleted: rgba(197, 59, 83, 0.16);
  --dsw-alias-file-diff-added-bg: #20303b;
  --dsw-alias-file-diff-added-gutter: #1a2831;
  --dsw-alias-file-diff-added-marker: #4fd6be;
  --dsw-alias-file-diff-deleted-bg: #37222c;
  --dsw-alias-file-diff-deleted-gutter: #2d1c24;
  --dsw-alias-file-diff-deleted-marker: #c53b53;
  --dsw-alias-scrollbar-bg-l1: #484848;
  --dsw-alias-scrollbar-bg-l2: #484848;
  --dsw-alias-scrollbar-hover-l1: #606060;
  --dsw-alias-scrollbar-hover-l2: #606060;
  --dsw-specific-bubble: #141414;
  --dsw-specific-bubble-highlight: #1e1e1e;
  --dsw-specific-input-major: #141414;
  --dsw-specific-sidebar-fill: #0a0a0a;
  --dsw-specific-sidebar-nav-item-hover: #141414;
  --dsw-specific-sidebar-nav-item-active: #1e1e1e;
  --dsw-specific-sidebar-nav-item-active-accent: #2b2338;
  --dsw-specific-selector: #1e1e1e;
  --dsw-specific-tip: #1e1e1e;
}

.aiapi-opencode-row {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 16px;
  padding: 12px 0;
  border-bottom: 1px solid var(--dsw-alias-border-l2);
}
.aiapi-opencode-text { display: flex; flex-direction: column; gap: 2px; }
.aiapi-opencode-title { color: var(--dsw-alias-label-primary); font-size: 14px; }
.aiapi-opencode-desc { color: var(--dsw-alias-label-tertiary); font-size: 12px; }
.aiapi-opencode-switch {
  appearance: none;
  width: 34px;
  height: 20px;
  border-radius: 999px;
  border: 1px solid var(--dsw-alias-border-l3);
  background: var(--dsw-alias-bg-layer-2);
  position: relative;
  cursor: pointer;
  transition: background 120ms ease, border-color 120ms ease;
}
.aiapi-opencode-switch::after {
  content: '';
  position: absolute;
  top: 2px;
  left: 2px;
  width: 14px;
  height: 14px;
  border-radius: 50%;
  background: var(--dsw-alias-label-tertiary);
  transition: transform 120ms ease, background 120ms ease;
}
.aiapi-opencode-switch:checked {
  background: var(--dsw-alias-link);
  border-color: var(--dsw-alias-link);
}
.aiapi-opencode-switch:checked::after {
  transform: translateX(14px);
  background: var(--dsw-alias-label-primary-inverted);
}
`;

const readEnabled = () => {
  try {
    return window.localStorage.getItem(STORAGE_KEY) !== 'off';
  } catch {
    return true;
  }
};

const writeEnabled = enabled => {
  try {
    window.localStorage.setItem(STORAGE_KEY, enabled ? 'on' : 'off');
  } catch {
    // The theme still applies for this page view when storage is unavailable.
  }
};

/** Settings → General row that turns the palette on or off; the default is on. */
function OpenCodeRow() {
  const [enabled, setEnabled] = useState(readEnabled);
  useEffect(() => {
    writeEnabled(enabled);
    document.documentElement.toggleAttribute(ATTRIBUTE, enabled);
  }, [enabled]);
  return (
    <label className="aiapi-opencode-row">
      <span className="aiapi-opencode-text">
        <span className="aiapi-opencode-title">智能配色</span>
        <span className="aiapi-opencode-desc">紫／橙／綠的標注色與近黑底，只影響介面配色</span>
      </span>
      <input
        type="checkbox"
        className="aiapi-opencode-switch"
        aria-label="智能配色"
        checked={enabled}
        onChange={event => setEnabled(event.target.checked)}
      />
    </label>
  );
}

/**
 * Install the palette and its settings row for exactly this client plugin lifetime.
 * @param ctx - client plugin context.
 */
export function apply(ctx) {
  ctx.effect(() => {
    const style = document.createElement('style');
    style.dataset.aiapiOpencode = '';
    style.textContent = CSS;
    document.head.append(style);
    return () => style.remove();
  });
  ctx.effect(() => {
    const enabled = readEnabled();
    document.documentElement.toggleAttribute(ATTRIBUTE, enabled);
    return () => document.documentElement.removeAttribute(ATTRIBUTE);
  });
  ctx.slots.inject('settings.general.item', () => ctx.slots.register({
    name: 'settings.general.item', id: 'aiapi-opencode', order: 12,
  }, OpenCodeRow));
}
