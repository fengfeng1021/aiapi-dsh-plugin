import React, { useEffect, useState } from 'react';

const CSS = `.aiapi-subagent-model{display:inline-flex;align-items:center;gap:4px;font-size:12px;color:var(--dsw-alias-label-secondary,#646a73)}
.aiapi-subagent-model select{font:inherit;max-width:180px;padding:2px 6px;border-radius:6px;border:1px solid var(--dsw-alias-border-l3,#d0d3d6);background:var(--dsw-alias-bg-base,#fff);color:var(--dsw-alias-label-primary,#1f2329)}
.aiapi-subagent-model select:disabled{opacity:.55}`;

/**
 * Conversation header picker for the subagent model of this conversation. Disabled with an explanation
 * when the conversation was created before the official model selection was turned on.
 * @param ctx - client plugin context.
 * @returns nothing.
 */
export function apply(ctx) {
  ctx.effect(() => {
    const style = document.createElement('style');
    style.dataset.aiapiSubagentModel = '';
    style.textContent = CSS;
    document.head.append(style);
    return () => style.remove();
  });
  ctx.slots.inject('conversation.session.header.actions', () => ctx.slots.register({
    name: 'conversation.session.header.actions', id: 'aiapi-subagent-model', order: 80,
  }, SubagentModelPicker));
}

const routeKey = route => `${route.provider}\u0000${route.model}`;

function SubagentModelPicker({ sessionId, useSession }) {
  const subagent = useSession(value => value.subagent);
  const [state, setState] = useState();
  const [error, setError] = useState();
  useEffect(() => {
    if (subagent || !sessionId) return undefined;
    let stopped = false;
    void (async () => {
      try {
        const response = await fetch(new URL(`api/aiapi/subagent-model?session=${encodeURIComponent(sessionId)}`, document.baseURI), { credentials: 'same-origin', cache: 'no-store' });
        const value = await response.json();
        if (!stopped) setState(response.ok ? value : undefined);
      } catch {
        if (!stopped) setState(undefined); // a new, still unsaved conversation has no log to inspect yet
      }
    })();
    return () => { stopped = true; };
  }, [sessionId, subagent]);
  if (subagent || !state) return null;
  const change = async event => {
    const route = state.allowed.find(entry => routeKey(entry) === event.target.value);
    setError(undefined);
    try {
      const response = await fetch(new URL('api/aiapi/subagent-model', document.baseURI), {
        method: 'POST', credentials: 'same-origin', headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ session: sessionId, ...route }),
      });
      const value = await response.json();
      if (!response.ok) throw new Error(value.error || `HTTP ${response.status}`);
      setState(value);
    } catch (failure) {
      setError(failure instanceof Error ? failure.message : String(failure));
    }
  };
  const title = state.enabled
    ? '這個對話的子代理一律使用所選模型；選「跟隨主模型」則由 AI 決定或沿用主對話的模型。'
    : '這個對話建立時還沒開啟子代理模型選擇。到「插件 → 子智能體 → 模型選擇」開啟並勾選模型後，新建的對話才能指定。';
  return <label className="aiapi-subagent-model" title={error ?? title}>
    子代理
    <select value={state.selected ? routeKey(state.selected) : ''} disabled={!state.enabled} onChange={change}>
      <option value="">跟隨主模型</option>
      {state.allowed.map(route => <option key={routeKey(route)} value={routeKey(route)}>{route.model}</option>)}
    </select>
    {error && <span style={{ color: 'var(--dsw-alias-state-error-primary,#d93d42)' }}>!</span>}
  </label>;
}
