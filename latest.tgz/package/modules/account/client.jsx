/**
 * AIAPI account and balance, inside DSH's own 「账号与余额」 settings page.
 *
 * DSH registers that page (section id `account`) only while a DeepSeek account is signed in. This module
 * registers a section with the same id at a lower priority: with no DeepSeek login it is the page, and once
 * DeepSeek registers its own, that one wins the slot and the AIAPI block is placed inside it instead. Either way
 * there is exactly one 「账号与余额」 entry, never a separate AIAPI page.
 */
import React, { useEffect, useState } from 'react';
import { createRoot } from 'react-dom/client';
import { Logo } from '../../../aiapi-brand/client.jsx';
import { balanceFlag, setBalanceFlag } from '../features/balance-flag.js';
import {
  AIAPI_CONSOLE, Button, KIT_CSS, Meter, StateDot, Switch, Tooltip,
  accountStore, installStyle, money, openSettings, pluginSettings, quotaShare, useAccount,
} from '../ui/kit.jsx';

/** DSH's own label for the page, so the navigation entry reads the same whoever provides it. */
const ACCOUNT_LABEL = '账号与余额';

const ACCOUNT_CSS = `
.aiapi-inline{margin-top:16px}
.aiapi-inline-title{display:flex;align-items:center;gap:8px;margin:0 0 8px;color:var(--dsw-alias-label-secondary);font-size:13px;font-weight:500}
.aiapi-signin{display:flex;flex-direction:column;align-items:center;gap:10px}
.aiapi-bar{display:flex;align-items:center;gap:8px;width:100%;height:36px;box-sizing:border-box;padding:0 10px;border:none;border-radius:var(--dsw-radius-md);background:transparent;color:var(--dsw-alias-label-secondary);font:inherit;font-size:13px;cursor:pointer;text-align:left}
.aiapi-bar:hover{background:var(--dsw-specific-sidebar-nav-item-hover,var(--dsw-alias-interactive-bg-hover))}
.aiapi-bar-label{flex:1;min-width:0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.aiapi-bar-amount{color:var(--dsw-alias-label-primary);font-weight:500;font-variant-numeric:tabular-nums}
.aiapi-bar[data-state=low] .aiapi-bar-amount{color:var(--dsw-alias-state-warn-primary)}
.aiapi-bar[data-state=empty] .aiapi-bar-amount{color:var(--dsw-alias-state-error-primary)}
.aiapi-bar[data-state=signed-out] .aiapi-bar-amount{color:var(--dsw-alias-label-tertiary);font-weight:400}
`;

/** Balance under this many dollars reads as running low. */
const LOW_BALANCE = 1;

/** Time of day for "updated at". */
const clock = at => (at ? new Date(at).toLocaleTimeString('zh-TW', { hour: '2-digit', minute: '2-digit' }) : '');

/** The two plugin switches that live on this page. */
function usePreferences(ctx) {
  const [values, setValues] = useState({ balanceBar: balanceFlag.on, errorReporting: true });
  useEffect(() => {
    let alive = true;
    void pluginSettings.read(ctx).then(view => {
      if (!alive || view === undefined) return;
      setValues({ balanceBar: view.value?.balanceBar === true, errorReporting: view.value?.errorReporting !== false });
    }).catch(() => {});
    return () => { alive = false; };
  }, [ctx]);
  const write = async (key, next) => {
    setValues(current => ({ ...current, [key]: next }));
    if (key === 'balanceBar') setBalanceFlag(next);
    if (key === 'errorReporting') globalThis.__aiapiReportingEnabled = next;
    try {
      await pluginSettings.write(ctx, [key], next);
    } catch (failure) {
      console.warn('[aiapi] 設定寫入失敗:', failure);
      setValues(current => ({ ...current, [key]: !next }));
      if (key === 'balanceBar') setBalanceFlag(!next);
      if (key === 'errorReporting') globalThis.__aiapiReportingEnabled = !next;
    }
  };
  return [values, write];
}

/** Signed out, or the key was rejected: the one thing to do is sign in. */
function SignIn({ account }) {
  const pending = account.signIn;
  return <div className="aiapi-card">
    <div className="aiapi-empty">
      <Logo size={32} className="aiapi-mark" />
      {pending === undefined ? <>
        <div>
          <div className="aiapi-empty-title">{account.phase === 'invalid-key' ? 'AIAPI 登入已失效' : '登入 AIAPI'}</div>
          <div className="aiapi-empty-text">{account.phase === 'invalid-key'
            ? '這台 DSH 保存的 Smart Key 已被停用或刪除，重新登入即可。'
            : '登入後就能在 DSH 使用 AIAPI 的模型，餘額也會顯示在這裡；不需要自己建立或貼上金鑰。'}</div>
        </div>
        <Button variant="primary" disabled={account.busy} onClick={() => { void accountStore.signIn(); }}>使用 AIAPI 帳號登入</Button>
      </> : <>
        <div>
          <div className="aiapi-empty-title">在瀏覽器完成登入</div>
          <div className="aiapi-empty-text">已開啟 AIAPI 授權頁：登入後確認代碼與下方相同，再按「允許這次登入」。</div>
        </div>
        <div className="aiapi-signin">
          <span className="aiapi-code" aria-label="授權代碼">{pending.user_code}</span>
          <div className="aiapi-row-actions">
            <Button variant="outline" size="sm" onClick={() => window.open(pending.verification_uri, '_blank', 'noopener')}>重新開啟授權頁</Button>
            <Button variant="ghost" size="sm" onClick={() => accountStore.cancelSignIn()}>取消</Button>
          </div>
        </div>
      </>}
      {account.error !== '' && account.phase !== 'invalid-key' ? <div className="aiapi-row-caption aiapi-error-text" role="alert">{account.error}</div> : null}
    </div>
  </div>;
}

/** Who is signed in and what is left: the identity card and the balance card. */
function Balance({ account, compact }) {
  const data = account.data ?? {};
  const share = quotaShare(data);
  const group = data.group?.name;
  const multiplier = data.group?.rate_multiplier;
  return <>
    <div className="aiapi-card">
      <div className="aiapi-row">
        <div className="aiapi-identity">
          <Logo size={32} className="aiapi-mark" />
          <div className="aiapi-row-copy">
            <span className="aiapi-name">AIAPI</span>
            <span className="aiapi-row-caption">
              {group ? `分組 ${group}${typeof multiplier === 'number' && multiplier !== 1 ? ` · 倍率 ×${multiplier}` : ''}` : '已登入'}
            </span>
          </div>
        </div>
        <div className="aiapi-row-actions">
          {account.phase === 'error'
            ? <Tooltip label={account.error} side="top"><span className="aiapi-row-caption aiapi-status aiapi-error-text"><StateDot state="error" />暫時無法更新</span></Tooltip>
            : <span className="aiapi-row-caption aiapi-status"><StateDot state="done" />已連線</span>}
          {compact ? null : <Button variant="ghost" size="sm" disabled={account.busy} onClick={() => { void accountStore.signOut(); }}>登出</Button>}
        </div>
      </div>
    </div>
    <div className="aiapi-card">
      <div className="aiapi-row">
        <div className="aiapi-row-copy">
          <span className="aiapi-row-title">平台餘額</span>
          {typeof data.frozen_balance === 'number' && data.frozen_balance > 0
            ? <span className="aiapi-row-caption">另有 {money(data.frozen_balance, data.currency)} 處理中</span>
            : null}
        </div>
        <span className="aiapi-amount">{money(data.balance, data.currency)}</span>
      </div>
      {share === undefined ? null : <div className="aiapi-row">
        <div className="aiapi-row-copy">
          <span className="aiapi-row-title">這把 Smart Key 的額度</span>
          <span className="aiapi-row-caption">剩 {money(data.quota.remaining, data.currency)}，共 {money(data.quota.limit, data.currency)}</span>
        </div>
        <Meter share={share} label="Smart Key 額度剩餘比例" />
      </div>}
      <div className="aiapi-row">
        <span className="aiapi-row-caption">{account.at ? `更新於 ${clock(account.at)}` : ''}</span>
        <div className="aiapi-row-actions">
          <Button variant="outline" size="sm" disabled={account.busy} onClick={() => { void accountStore.refresh(); }}>重新整理</Button>
          <Button variant="outline" size="sm" onClick={() => window.open(AIAPI_CONSOLE, '_blank', 'noopener')}>前往 AIAPI 儲值</Button>
        </div>
      </div>
    </div>
  </>;
}

/** Account content, for the page itself or for the block inside DeepSeek's page. */
export function AccountPanel({ ctx, inline = false }) {
  const account = useAccount();
  const [preferences, setPreference] = usePreferences(ctx);
  const signedIn = account.phase === 'ok' || (account.phase === 'error' && account.data !== undefined);
  const body = account.phase === 'loading'
    ? <div className="aiapi-card"><div className="aiapi-row"><span className="aiapi-muted">讀取 AIAPI 帳號…</span></div></div>
    : signedIn ? <Balance account={account} compact={inline} />
      : account.phase === 'error'
        ? <div className="aiapi-card"><div className="aiapi-row">
          <span className="aiapi-row-caption aiapi-error-text" role="alert">無法連到 AIAPI：{account.error}</span>
          <Button variant="outline" size="sm" onClick={() => { void accountStore.refresh(); }}>重試</Button>
        </div></div>
        : <SignIn account={account} />;
  if (inline) {
    return <div className="aiapi-inline"><div className="aiapi-section" style={{ padding: 0 }}>
      <div className="aiapi-heading">AIAPI</div>
      {body}
    </div></div>;
  }
  return <section className="aiapi-section" aria-label={ACCOUNT_LABEL}>
    {body}
    <div className="aiapi-heading">偏好</div>
    <div className="aiapi-card">
      <div className="aiapi-row">
        <div className="aiapi-row-copy">
          <span className="aiapi-row-title">在側邊欄顯示餘額</span>
          <span className="aiapi-row-caption">左下角常駐一行 AIAPI 餘額，點一下回到這裡</span>
        </div>
        <Switch checked={preferences.balanceBar} label="在側邊欄顯示餘額" onChange={on => { void setPreference('balanceBar', on); }} />
      </div>
      <div className="aiapi-row">
        <div className="aiapi-row-copy">
          <span className="aiapi-row-title">自動回報介面錯誤</span>
          <span className="aiapi-row-caption">插件畫面出錯時把錯誤訊息與版本送給 AIAPI，不含對話內容或金鑰</span>
        </div>
        <Switch checked={preferences.errorReporting} label="自動回報介面錯誤" onChange={on => { void setPreference('errorReporting', on); }} />
      </div>
    </div>
  </section>;
}

/**
 * Register the page, keep the AIAPI block inside DeepSeek's page when that one is shown, and add the sidebar
 * balance.
 * @param ctx - client plugin context.
 */
export function applyAccount(ctx) {
  installStyle(ctx, 'kit', KIT_CSS);
  installStyle(ctx, 'account', ACCOUNT_CSS);
  // Priority: the lowest number wins a shared id; DeepSeek's own page registers at 0 and takes over when present.
  ctx.slots.inject('settings.section', () => ctx.slots.register({
    name: 'settings.section', id: 'account', order: -10, priority: 1000, label: () => ACCOUNT_LABEL,
  }, () => <AccountPanel ctx={ctx} />));
  ctx.effect(() => mountInsideDeepSeekPage(ctx), 'aiapi block in the DeepSeek account page');
  ctx.slots.inject('sidebar.footer.action', () => ctx.slots.register({
    name: 'sidebar.footer.action', id: 'aiapi-balance', order: 5,
  }, () => <SidebarBalance ctx={ctx} />));
  void pluginSettings.read(ctx).then(view => setBalanceFlag(view?.value?.balanceBar === true)).catch(() => {});
}

/**
 * Follow DeepSeek's account page: when its balance card is on screen, render the AIAPI block after the page's
 * content; remove it when the page goes away. The page has no slot, so its CSS-module class is the anchor, and a
 * DSH release that renames it only loses the inline block — the page itself still has its normal content.
 * @param ctx - client plugin context.
 * @returns the disposer.
 */
function mountInsideDeepSeekPage(ctx) {
  let host;
  let root;
  const unmount = () => {
    root?.unmount();
    host?.remove();
    root = undefined;
    host = undefined;
  };
  const reconcile = () => {
    const card = document.querySelector('[class*="_balanceCard"]');
    const page = card?.closest('section') ?? card?.parentElement;
    if (page === null || page === undefined) { unmount(); return; }
    if (host !== undefined && host.parentElement === page && page.lastElementChild === host) return;
    if (host === undefined) {
      host = document.createElement('div');
      host.dataset.aiapiAccount = '';
      root = createRoot(host);
      root.render(<AccountPanel ctx={ctx} inline />);
    }
    page.append(host);
  };
  let scheduled = false;
  const observer = new MutationObserver(records => {
    if (scheduled || records.every(record => host?.contains(record.target))) return;
    scheduled = true;
    requestAnimationFrame(() => { scheduled = false; reconcile(); });
  });
  observer.observe(document.body, { childList: true, subtree: true });
  reconcile();
  return () => { observer.disconnect(); unmount(); };
}

/** The sidebar line: the AIAPI mark, the balance, and a click that opens 「账号与余额」. */
function SidebarBalance({ ctx }) {
  const [visible, setVisible] = useState(balanceFlag.on);
  useEffect(() => {
    setVisible(balanceFlag.on);
    balanceFlag.listeners.add(setVisible);
    return () => { balanceFlag.listeners.delete(setVisible); };
  }, []);
  return visible ? <SidebarBalanceLine ctx={ctx} /> : null;
}

function SidebarBalanceLine({ ctx }) {
  const account = useAccount();
  const data = account.data;
  const signedIn = data !== undefined && (account.phase === 'ok' || account.phase === 'error');
  const share = quotaShare(data);
  const state = !signedIn ? 'signed-out'
    : (share !== undefined && share <= 0.02) || data.balance <= 0 ? 'empty'
      : (share !== undefined && share < 0.2) || data.balance < LOW_BALANCE ? 'low' : 'ok';
  const tip = signedIn
    ? `AIAPI 餘額 ${money(data.balance, data.currency)}${data.group?.name ? ` · 分組 ${data.group.name}` : ''}${account.at ? ` · 更新於 ${clock(account.at)}` : ''}`
    : account.phase === 'loading' ? '讀取中' : '尚未登入 AIAPI，點一下前往登入';
  return <Tooltip label={tip} side="top">
    <button type="button" className="aiapi-bar" data-state={state} onClick={() => { if (!openSettings(ctx)) void accountStore.refresh(); }}>
      <Logo size={16} />
      <span className="aiapi-bar-label">AIAPI</span>
      <span className="aiapi-bar-amount">{signedIn ? money(data.balance, data.currency) : account.phase === 'loading' ? '…' : '未登入'}</span>
    </button>
  </Tooltip>;
}
