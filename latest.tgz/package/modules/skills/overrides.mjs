/**
 * Manual-only plugin skills. For each plugin the user switches to manual use, a provider re-lists that plugin's
 * skills ranked ahead of the originals with model invocation off: the model no longer sees or loads them, while the
 * user can still call them with "/". The plugin and its files stay untouched; switching back drops the shadows.
 */
import { AsyncLocalStorage } from 'node:async_hooks';
import { mkdir, readFile, rename, stat, writeFile } from 'node:fs/promises';
import { dirname, join } from 'node:path';

/** Provider name that owns the shadow entries. */
export const MANUAL_ONLY_PROVIDER = 'aiapi-manual-only';
// Ahead of every rank providers use (the lowest in use is 0), so a shadow wins within the shared global layer.
const SHADOW_RANK = -1;

/** Persisted names of the plugins (skill providers) whose skills are manual-only. */
export class ManualOnlyStore {
  /** @param file - JSON file `{ "manualOnlyProviders": [...] }`. */
  constructor(file) {
    this.file = file;
    this.providers = undefined;
  }

  /** @returns the manual-only provider names; a missing or unreadable file means none. */
  async list() {
    this.providers ??= await readFile(this.file, 'utf8')
      .then(text => new Set(JSON.parse(text).manualOnlyProviders ?? []), () => new Set());
    return this.providers;
  }

  /**
   * Switch one plugin's skills to manual use or back.
   * @param provider - skill provider name.
   * @param manualOnly - whether its skills become manual-only.
   */
  async set(provider, manualOnly) {
    const providers = new Set(await this.list());
    if (manualOnly) providers.add(provider); else providers.delete(provider);
    await mkdir(dirname(this.file), { recursive: true });
    const temp = `${this.file}.${process.pid}.tmp`;
    await writeFile(temp, `${JSON.stringify({ manualOnlyProviders: [...providers].sort() }, null, 2)}\n`, 'utf8');
    await rename(temp, this.file);
    this.providers = providers;
  }
}

/**
 * Create the shadow provider.
 * @param registry - skill registry the original entries are read from.
 * @param store - manual-only plugin list.
 * @returns `{ provider, origins }`; `origins` maps a shadowed skill name to the plugin it came from.
 */
export function createManualOnlyProvider(registry, store) {
  const inner = new AsyncLocalStorage();
  const origins = new Map();
  const shadow = (skill, origin, file) => ({
    name: skill.name, description: skill.description,
    ...skill.whenToUse === undefined ? {} : { whenToUse: skill.whenToUse },
    invocation: { modelInvocable: false, userInvocable: skill.invocation?.userInvocable !== false },
    source: skill.source, provider: MANUAL_ONLY_PROVIDER, resourceBase: skill.resourceBase,
    rank: SHADOW_RANK, locator: { origin, file },
  });
  const provider = {
    name: MANUAL_ONLY_PROVIDER,
    async list(options = {}) {
      // The inner read must neither see these shadows nor be cached as a complete catalog.
      if (inner.getStore()) return { candidates: [], complete: false };
      const manual = await store.list();
      if (manual.size === 0) return [];
      const entries = await inner.run(true, () => registry.list(options));
      const candidates = [];
      for (const skill of entries) {
        // A concurrent read may already have cached a catalog that holds this provider's own shadows.
        const origin = skill.provider === MANUAL_ONLY_PROVIDER ? origins.get(skill.name) : skill.provider;
        if (!manual.has(origin) || skill.resourceBase?.kind !== 'directory') continue;
        const file = join(skill.resourceBase.path, 'SKILL.md');
        if (!await stat(file).then(info => info.isFile(), () => false)) continue;
        origins.set(skill.name, origin);
        candidates.push(shadow(skill, origin, file));
      }
      return candidates;
    },
    async get(candidate) {
      const text = await readFile(candidate.locator.file, 'utf8');
      return {
        name: candidate.name, description: candidate.description,
        ...candidate.whenToUse === undefined ? {} : { whenToUse: candidate.whenToUse },
        invocation: candidate.invocation, source: candidate.source, provider: MANUAL_ONLY_PROVIDER,
        resourceBase: candidate.resourceBase,
        content: text.replace(/^﻿/, '').replace(/^---\r?\n[\s\S]*?\r?\n---[^\n]*(?:\n|$)/, ''),
      };
    },
  };
  return { provider, origins };
}
