import React, { useEffect, useState } from 'react';
import { showToast } from '../desktop/client.jsx';

const PANEL_ID = 'aiapi-skills';
const SOURCE_LABEL = { 'user-dsh': '全域', 'user-agents': '全域（.agents）', 'project-dsh': '工作區', 'project-agents': '工作區（.agents）', custom: '自訂資料夾', bundled: '插件內建', runtime: '執行中載入' };
const CSS = `.aiapi-sk{height:100%;overflow:auto;padding:24px 28px 40px;box-sizing:border-box;color:var(--dsw-alias-label-primary,#1f2329);font-size:13px;line-height:1.5}
.aiapi-sk h1{font-size:20px;margin:0 0 4px;font-weight:600}
.aiapi-sk h2{font-size:15px;margin:22px 0 8px;font-weight:600}
.aiapi-sk .muted{color:var(--dsw-alias-label-tertiary,#8f959e)}
.aiapi-sk .row{display:flex;flex-wrap:wrap;gap:8px;align-items:center}
.aiapi-sk .item{border:1px solid var(--dsw-alias-border-l2,#dee0e3);border-radius:10px;padding:10px 14px;margin-top:10px;background:var(--dsw-alias-bg-layer-1,#fff)}
.aiapi-sk .item b{font-size:14px}
.aiapi-sk .badge{display:inline-block;margin-left:6px;padding:0 6px;border-radius:8px;font-size:11px;background:var(--dsw-alias-bg-layer-2,#f2f3f5);font-weight:400}
.aiapi-sk .badge.off{color:var(--dsw-alias-state-warn-primary,#de7802)}
.aiapi-sk .path{font-size:12px;color:var(--dsw-alias-label-tertiary,#8f959e);word-break:break-all}
.aiapi-sk button{font:inherit;padding:3px 10px;border-radius:8px;border:1px solid var(--dsw-alias-border-l3,#d0d3d6);background:var(--dsw-alias-bg-layer-1,#fff);color:inherit;cursor:pointer}
.aiapi-sk button:hover{background:var(--dsw-alias-interactive-bg-hover,#f2f3f5)}
.aiapi-sk button.primary{background:var(--dsw-alias-button-primary-fill,#1f2329);color:var(--dsw-alias-label-primary-foreground,#fff);border-color:transparent}
.aiapi-sk button.danger{color:var(--dsw-alias-state-error-primary,#d93d42)}
.aiapi-sk input,.aiapi-sk select{font:inherit;padding:4px 8px;border-radius:8px;border:1px solid var(--dsw-alias-border-l3,#d0d3d6);background:var(--dsw-alias-bg-base,#fff);color:inherit}
.aiapi-sk .error{color:var(--dsw-alias-state-error-primary,#d93d42)}
.aiapi-sk .warn{font-size:12px;color:var(--dsw-alias-state-warn-primary,#de7802)}
.aiapi-sk summary{cursor:pointer;margin-top:6px}`;

/**
 * Skills manager page in the sidebar: every discovered skill with its source, invocation switch,
 * folder, backups and soft removal, plus import from a folder. Owned by the client plugin scope.
 * @param ctx - client plugin context.
 * @returns nothing.
 */
export function apply(ctx) {
  ctx.effect(() => {
    const style = document.createElement('style');
    style.dataset.aiapiSkills = '';
    style.textContent = CSS;
    document.head.append(style);
    return () => style.remove();
  });
  const revealFolder = async path => {
    let result;
    try { result = await ctx.remote.session.openWorkspacePath({ path, action: 'reveal' }); } catch {
      result = undefined; // an unreachable Host fails like a refused path
    }
    if (!result?.ok) showToast('error', `無法開啟資料夾，路徑：\n${path}`);
  };
  ctx.slots.inject('main', () => ctx.slots.register({ name: 'main', key: PANEL_ID, inject: () => ({ revealFolder }) }, SkillsPanel));
  ctx.slots.inject('sidebar.panellist', () => ctx.slots.register({ name: 'sidebar.panellist', id: PANEL_ID, order: 32, label: 'Skills 管理' }, SkillsIcon));
}

function SkillsIcon({ size = 20 }) {
  return <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" aria-hidden="true">
    <path d="M5 4h10l4 4v12H5z" strokeLinejoin="round" /><path d="M15 4v4h4M8 12h8M8 16h6" />
  </svg>;
}

const request = async (method, body) => {
  const response = await fetch(new URL('api/aiapi/skills', document.baseURI), {
    method, credentials: 'same-origin', cache: 'no-store',
    ...(body ? { headers: { 'content-type': 'application/json' }, body: JSON.stringify(body) } : {}),
  });
  const value = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(value.error || `HTTP ${response.status}`);
  return value;
};

function SkillItem({ skill, shadow, run, revealFolder }) {
  const [versions, setVersions] = useState();
  const [confirming, setConfirming] = useState(false);
  const folder = skill.path ? skill.path.replace(/[\\/]SKILL\.md$/i, '') : null;
  return <div className="item">
    <div><b>{skill.name}</b>
      <span className="badge">{skill.source === 'custom' && !skill.editable ? '插件提供' : SOURCE_LABEL[skill.source] ?? skill.source}{skill.workspace ? `：${skill.workspace}` : ''}</span>
      {!skill.modelInvocable && <span className="badge off">AI 不會自動使用</span>}
      {!skill.userInvocable && <span className="badge off">不能用 / 叫出</span>}
    </div>
    <div style={{ margin: '4px 0' }}>{skill.description}</div>
    {skill.path && <div className="path">{skill.path}</div>}
    {skill.link && <div className="path">經由連結 {skill.link} 載入；修改會直接改到上面這個資料夾，「移除連結」只移除連結。</div>}
    {shadow && <div className="warn">{shadow}</div>}
    <div className="row" style={{ marginTop: 8 }}>
      <span className="muted">在輸入框打 /{skill.name} 叫出</span>
      {folder && <button type="button" onClick={() => revealFolder(folder)}>開啟資料夾</button>}
      {skill.editable && <>
        <button type="button" onClick={() => run({ action: 'toggle', path: skill.path, modelInvocable: !skill.modelInvocable }, skill.modelInvocable ? '已設為只能手動叫出' : '已允許 AI 自動使用')}>
          {skill.modelInvocable ? '改成只能手動叫出' : '允許 AI 自動使用'}
        </button>
        <button type="button" onClick={() => run({ action: 'backup', path: skill.path }, '已備份')}>備份</button>
        <button type="button" onClick={async () => { try { setVersions((await request('POST', { action: 'backups', name: skill.name })).backups); } catch (failure) { showToast('error', failure instanceof Error ? failure.message : String(failure)); } }}>版本紀錄</button>
        {confirming
          ? <><span className="error">{skill.link ? '確定移除連結？實際資料夾會保留。' : '確定移到回收區？'}</span><button type="button" className="danger" onClick={() => run({ action: 'remove', path: skill.path }, skill.link ? '已移除連結，實際資料夾保留' : '已移到回收區')}>確定</button><button type="button" onClick={() => setConfirming(false)}>取消</button></>
          : <button type="button" className="danger" onClick={() => setConfirming(true)}>{skill.link ? '移除連結' : '移到回收區'}</button>}
      </>}
      {!skill.editable && <span className="muted">（{skill.source === 'bundled' || skill.source === 'custom' ? '插件內建，隨插件更新' : '無法在這裡修改'}）</span>}
    </div>
    {versions && <div style={{ marginTop: 8 }}>
      {versions.length === 0 ? <span className="muted">還沒有備份。</span> : versions.map(version => <div className="row" key={version}>
        <span className="muted">{version}</span>
        <button type="button" onClick={() => run({ action: 'restore', path: skill.path, backup: version }, `已還原到 ${version}（還原前的版本也已備份）`)}>還原到這版</button>
      </div>)}
    </div>}
  </div>;
}

function SkillsPanel({ revealFolder }) {
  const [data, setData] = useState();
  const [error, setError] = useState();
  const [form, setForm] = useState({ from: '', scope: 'user', cwd: '' });
  const [filter, setFilter] = useState('');
  const [busy, setBusy] = useState(false);
  const refresh = async () => {
    try { setData(await request('GET')); setError(undefined); } catch (failure) {
      setError(failure instanceof Error ? failure.message : String(failure));
    }
  };
  useEffect(() => { void refresh(); }, []);
  const run = async (body, done) => {
    if (busy) return;
    setBusy(true);
    try {
      const value = await request('POST', body);
      showToast('info', done + (value.previousBackup ? `（原本的版本已備份到 ${value.previousBackup}）` : ''));
      await refresh();
    } catch (failure) {
      showToast('error', failure instanceof Error ? failure.message : String(failure));
    } finally {
      setBusy(false);
    }
  };
  const query = filter.trim().toLowerCase();
  /** One row survives the search when its name, description, source or plugin matches. */
  const matches = skill => query === ''
    || [skill.name, skill.description, skill.source, skill.origin, skill.provider]
      .filter(Boolean).some(value => String(value).toLowerCase().includes(query));
  const byName = (left, right) => String(left.name).localeCompare(String(right.name), 'zh-Hant');
  const groups = [
    ['全域 skills（所有對話都能用）', skill => skill.source?.startsWith('user') || (skill.source === 'custom' && skill.editable)],
    ['工作區 skills（只在該工作區的對話出現）', skill => skill.source?.startsWith('project')],
    ['插件內建', skill => !skill.source?.startsWith('user') && !(skill.source === 'custom' && skill.editable) && !skill.source?.startsWith('project'), 'collapsed'],
  ];
  // A workspace skill replaces the global one with the same name in that workspace's conversations.
  const shadowOf = skill => {
    if (!data) return undefined;
    if (skill.workspace) return data.skills.some(other => other.name === skill.name && !other.workspace) ? '在這個工作區的對話中，會取代同名的全域 skill。' : undefined;
    const places = data.skills.filter(other => other.name === skill.name && other.workspace).map(other => `「${other.workspace}」`);
    return places.length ? `在 ${places.join('、')} 工作區的對話中，會改用該工作區的同名 skill，而不是這一份。` : undefined;
  };
  return <div className="aiapi-sk">
    <h1>Skills 管理</h1>
    <div className="muted">skill 是給 AI 的工作說明書。放在 skills 資料夾的 skill 會自動出現在 AI 的清單裡，也能在輸入框用 / 叫出。每次修改前都會自動備份。</div>
    <div className="row" style={{ marginTop: 12 }}>
      <input style={{ minWidth: 260 }} placeholder="搜尋名稱、說明或來源…" value={filter} onChange={event => setFilter(event.target.value)} />
      {filter !== '' && <button type="button" onClick={() => setFilter('')}>清除</button>}
      <button type="button" onClick={() => { void refresh(); }} disabled={busy}>{busy ? '處理中…' : '重新整理'}</button>
      {data && <span className="muted">共 {data.skills.filter(matches).length} / {data.skills.length} 個</span>}
    </div>
    {error && <div className="error" role="alert">{error}</div>}
    <h2>匯入 skill</h2>
    <form className="row" onSubmit={event => { event.preventDefault(); void run({ action: 'import', from: form.from.trim(), scope: form.scope, cwd: form.cwd }, '已匯入').then(() => setForm({ ...form, from: '' })); }}>
      <input style={{ minWidth: 340 }} placeholder="skill 資料夾的完整路徑（裡面要有 SKILL.md）" value={form.from} onChange={event => setForm({ ...form, from: event.target.value })} />
      <select value={form.scope} onChange={event => setForm({ ...form, scope: event.target.value })}>
        <option value="user">放到全域</option>
        <option value="workspace">放到某個工作區</option>
      </select>
      {form.scope === 'workspace' && <select value={form.cwd} onChange={event => setForm({ ...form, cwd: event.target.value })}>
        <option value="">選擇工作區</option>
        {data?.workspaces.map(workspace => <option key={workspace.id} value={workspace.cwd}>{workspace.name}</option>)}
      </select>}
      <button type="submit" className="primary" disabled={busy || !form.from.trim() || (form.scope === 'workspace' && !form.cwd)}>{busy ? '處理中…' : '匯入'}</button>
    </form>
    {data && <div className="row" style={{ marginTop: 6 }}>
      <span className="muted">全域資料夾：{data.userRoot}</span>
      <button type="button" onClick={() => revealFolder(data.userRoot)}>開啟</button>
      <span className="muted">回收區：{data.trash}</span>
    </div>}
    {data && query !== '' && data.skills.filter(matches).length === 0
      ? <div className="muted" style={{ marginTop: 16 }}>沒有符合「{filter}」的 skill。清掉搜尋即可看全部。</div>
      : null}
    {data && groups.map(([title, test, collapsed]) => {
      const list = data.skills.filter(skill => test(skill) && matches(skill)).sort(byName);
      const items = list.map(skill => <SkillItem key={skill.path ?? `${skill.provider}:${skill.name}`} skill={skill} shadow={shadowOf(skill)} run={run} revealFolder={revealFolder} />);
      if (list.length === 0) return null;
      if (!collapsed) return <div key={title}><h2>{title}（{list.length}）</h2>{items}</div>;
      // Plugin skills are grouped by the plugin they come from; a shadowed skill keeps its origin.
      const plugins = new Map();
      for (const skill of list) {
        const plugin = skill.origin ?? skill.provider ?? '其他';
        plugins.set(plugin, [...plugins.get(plugin) ?? [], skill]);
      }
      return <div key={title}>
        <h2>{title}（{list.length}）</h2>
        <div className="muted">設成「只能手動叫出」的插件，AI 不會自己載入它的 skill，也看不到它們；你仍可在輸入框用 / 叫出。插件本身不會被修改。</div>
        {[...plugins].map(([plugin, skills]) => {
          const manual = data.manualOnlyProviders?.includes(plugin) ?? false;
          return <div className="item" key={plugin}>
            <div className="row">
              <b>{plugin}</b><span className="muted">{skills.length} 個 skill</span>
              {manual ? <span className="badge off">只能手動叫出</span> : <span className="badge">AI 可自動使用</span>}
              <button type="button" onClick={() => run({ action: 'manual-only', provider: plugin, manualOnly: !manual }, manual ? `已恢復讓 AI 自動使用 ${plugin} 的 skill` : `${plugin} 的 skill 已改成只能手動叫出`)}>
                {manual ? '恢復讓 AI 自動使用' : '改成只能手動叫出'}
              </button>
            </div>
            <details><summary className="muted">查看這個插件的 skill</summary>
              {skills.map(skill => <SkillItem key={`${skill.provider}:${skill.name}`} skill={skill} shadow={shadowOf(skill)} run={run} revealFolder={revealFolder} />)}
            </details>
          </div>;
        })}
      </div>;
    })}
  </div>;
}
