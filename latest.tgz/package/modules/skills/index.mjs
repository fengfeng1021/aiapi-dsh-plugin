/**
 * Skills manager routes: list every skill the registry discovers (global, per workspace, plugin-bundled),
 * import a skill folder, switch model invocation on or off, back up, restore, and move a skill to a trash folder.
 * Only skills stored in skill folders on disk (global `$DSH_HOME/skills` or a workspace's `.dsh/skills` /
 * `.agents/skills`, or a configured custom folder outside `node_modules`) can be changed; every change first copies
 * the current folder to a timestamped backup. The filesystem provider is mounted inside the agent preset, so listing
 * borrows the default preset's scope the way the official session skill catalog does for a cold session.
 * A whole plugin's skills can be switched to manual use (see `overrides.mjs`) without touching the plugin.
 */
import { cp, lstat, mkdir, readdir, readFile, realpath, rename, rm, stat, unlink, writeFile } from 'node:fs/promises';
import { homedir } from 'node:os';
import { basename, dirname, isAbsolute, join, relative, resolve } from 'node:path';
import { createManualOnlyProvider, MANUAL_ONLY_PROVIDER, ManualOnlyStore } from './overrides.mjs';
import { realLocation } from '../paths.mjs';

const EDITABLE_SOURCES = new Set(['user-dsh', 'user-agents', 'project-dsh', 'project-agents', 'custom']);
let lastStamp = '';
/** Taiwan-time stamp with milliseconds, unique within this process, naming backup and trash folders. */
const stamp = () => {
  let value = new Date(Date.now() + 8 * 3600_000).toISOString().slice(0, 23).replace(/[-:.]/g, '').replace('T', '-');
  if (value <= lastStamp) value = `${lastStamp}-1`;
  lastStamp = value;
  return value;
};

/**
 * Parse the YAML front matter fields a skill needs (`name`, `description`).
 * @param text - SKILL.md text.
 * @returns `{ name, description }`, or undefined when the front matter is missing either.
 */
export function skillHeader(text) {
  const match = String(text).match(/^---\r?\n([\s\S]*?)\r?\n---/);
  if (!match) return undefined;
  const field = key => match[1].match(new RegExp(`^${key}:\\s*(.+)$`, 'm'))?.[1].trim().replace(/^["']|["']$/g, '');
  const name = field('name');
  const description = field('description');
  return name && description ? { name, description } : undefined;
}

/**
 * Set `disable-model-invocation` in a skill's front matter, keeping every other line.
 * @param text - SKILL.md text.
 * @param modelInvocable - whether the model may load the skill on its own.
 * @returns the updated text.
 */
export function setModelInvocation(text, modelInvocable) {
  const match = String(text).match(/^---(\r?\n)([\s\S]*?)\r?\n---/);
  if (!match) throw new Error('SKILL.md 沒有開頭的 --- 區塊');
  const newline = match[1];
  const lines = match[2].split(/\r?\n/).filter(line => !/^disable-model-invocation\s*:/.test(line));
  if (!modelInvocable) lines.push('disable-model-invocation: true');
  return `---${newline}${lines.join(newline)}${newline}---${text.slice(match[0].length)}`;
}

/**
 * The folder that holds a skill: its bundle directory, or the flat file itself.
 * @param path - SKILL.md or `<name>.md` path.
 * @returns folder or file path to copy as a unit.
 */
export function skillUnit(path) {
  return basename(path).toLowerCase() === 'skill.md' ? dirname(path) : path;
}

/**
 * Register the skills-manager routes.
 * @param ctx - unified plugin context.
 * @returns nothing; routes are effects of `ctx`.
 */
export function apply(ctx) {
  const home = process.env.DSH_HOME || join(homedir(), '.dsh');
  const userRoot = join(home, 'skills');
  const agentsRoot = join(process.env.DSH_AGENTS_HOME || join(homedir(), '.agents'), 'skills');
  const backups = join(home, 'aiapi-skill-backups');
  const trash = join(home, 'aiapi-skill-trash');
  const json = (value, status = 200) => Response.json(value, { status, headers: { 'cache-control': 'no-store' } });
  const manualOnly = new ManualOnlyStore(join(home, 'aiapi-skill-overrides.json'));
  let shadowsControl;
  let origins = new Map();

  ctx.inject(['skills'], scope => {
    const shadows = createManualOnlyProvider(scope.skills, manualOnly);
    origins = shadows.origins;
    scope.effect(() => scope.skills.registerProvider(control => {
      shadowsControl = control;
      return shadows.provider;
    }), 'aiapi manual-only plugin skills');
  });

  ctx.inject(['connection', 'skills'], scope => {
    const workspaces = () => {
      try { return (ctx.get('workspaceRegistry')?.list() ?? []).map(workspace => ({ id: workspace.id, name: workspace.title || basename(workspace.path ?? ''), cwd: workspace.path })).filter(workspace => workspace.cwd); } catch {
        return []; // the Web registry is absent in headless profiles
      }
    };
    const catalog = async () => {
      const entries = new Map();
      const add = (skill, workspace) => {
        const key = skill.path ?? `${skill.provider}:${skill.name}`;
        if (entries.has(key)) return;
        entries.set(key, {
          name: skill.name, description: skill.description, source: skill.source, provider: skill.provider, path: skill.path ?? null,
          modelInvocable: skill.invocation?.modelInvocable !== false, userInvocable: skill.invocation?.userInvocable !== false,
          editable: Boolean(skill.path) && EDITABLE_SOURCES.has(skill.source) && !/[\\/]node_modules[\\/]/.test(skill.path),
          workspace: workspace?.name ?? null, cwd: workspace?.cwd ?? null, link: null, linkTarget: null,
          origin: skill.provider === MANUAL_ONLY_PROVIDER ? origins.get(skill.name) ?? null : null,
        });
      };
      // Without a preset scope only host-level providers answer; the filesystem roots register inside the preset.
      const lease = await ctx.get('agentPresets')?.acquireScope().catch(() => undefined);
      try {
        const view = options => scope.skills.list({ ...options, scope: lease?.key });
        for (const skill of await view()) if (!String(skill.source).startsWith('project')) add(skill);
        for (const workspace of workspaces()) {
          for (const skill of await view({ cwd: workspace.cwd }).catch(() => [])) if (String(skill.source).startsWith('project')) add(skill, workspace);
        }
      } finally {
        await lease?.[Symbol.asyncDispose]();
      }
      // The registry reports a skill's real folder. A folder outside its skills root was reached through a link
      // (junction) in that root: removal drops only the link, and other changes land in the linked folder.
      const inside = (root, path) => {
        const rel = relative(root, path);
        return rel !== '' && !rel.startsWith('..') && !isAbsolute(rel);
      };
      for (const entry of entries.values()) {
        if (!entry.editable) continue;
        const unit = skillUnit(entry.path);
        const real = await realpath(unit).catch(() => unit);
        if (await lstat(unit).then(info => info.isSymbolicLink(), () => false)) {
          Object.assign(entry, { link: unit, linkTarget: real });
          continue;
        }
        const leaf = entry.source.endsWith('agents') ? ['.agents', 'skills'] : ['.dsh', 'skills'];
        const roots = [];
        if (entry.source.startsWith('project')) {
          // The project root is the workspace folder or one of its ancestors (the nearest one with `.git`).
          for (let dir = entry.cwd; dir; dir = dirname(dir) === dir ? undefined : dirname(dir)) roots.push(join(dir, ...leaf));
        } else roots.push(entry.source === 'user-dsh' ? userRoot : entry.source === 'user-agents' ? agentsRoot : dirname(unit));
        let placed = false;
        for (const root of roots) {
          const realRoot = await realpath(root).catch(() => undefined);
          if (realRoot === undefined) continue;
          if (inside(root, unit) || inside(realRoot, real)) { placed = true; break; }
          for (const name of await readdir(root).catch(() => [])) {
            const candidate = join(root, name);
            if (!await lstat(candidate).then(info => info.isSymbolicLink(), () => false)) continue;
            if (await realpath(candidate).catch(() => undefined) !== real) continue;
            Object.assign(entry, { link: candidate, linkTarget: real });
            placed = true;
            break;
          }
          if (placed) break;
        }
        // A folder whose place in a skills root cannot be found is left alone rather than guessed at.
        if (!placed) entry.editable = false;
      }
      return [...entries.values()].sort((a, b) => a.name.localeCompare(b.name));
    };
    const editable = async path => {
      const skill = (await catalog()).find(entry => entry.path === path);
      if (!skill?.editable) throw new Error('只能修改放在 skills 資料夾裡的 skill（插件內建的不行）');
      return skill;
    };
    const backup = async (path, name) => {
      const unit = skillUnit(path);
      // Copy the content, not the link: a copied junction would point back at the folder being changed.
      const source = await realpath(unit);
      const target = join(backups, name, stamp());
      if (unit === path) {
        await mkdir(target, { recursive: true });
        await cp(source, join(target, basename(unit)));
      } else {
        await mkdir(dirname(target), { recursive: true });
        await cp(source, target, { recursive: true });
      }
      return target;
    };

    scope.effect(() => scope.connection.fetch.register({
      path: '/api/aiapi/skills', methods: ['GET', 'POST'], requestBody: 'buffered',
      fetch: async request => {
        try {
          if (request.method === 'GET') {
            // Folders are shown where they really are, e.g. on another drive behind a linked data folder.
            return json({
              userRoot: await realLocation(userRoot), backups: await realLocation(backups), trash: await realLocation(trash),
              workspaces: workspaces(), skills: await catalog(), manualOnlyProviders: [...await manualOnly.list()].sort(),
            });
          }
          const body = await request.json().catch(() => ({}));
          switch (body?.action) {
            case 'import': {
              const from = String(body.from ?? '');
              if (!isAbsolute(from)) return json({ error: '請貼上 skill 資料夾的完整路徑' }, 400);
              const header = skillHeader(await readFile(join(from, 'SKILL.md'), 'utf8').catch(() => ''));
              if (!header) return json({ error: '這個資料夾沒有有效的 SKILL.md（開頭需要 name 與 description）' }, 400);
              if (!/^[a-z0-9][a-z0-9-]{0,63}$/.test(header.name)) return json({ error: `skill 名稱「${header.name}」需為小寫英數與連字號` }, 400);
              const workspace = body.scope === 'workspace' ? workspaces().find(entry => entry.cwd === body.cwd) : undefined;
              if (body.scope === 'workspace' && !workspace) return json({ error: '找不到這個工作區' }, 400);
              const root = workspace ? join(workspace.cwd, '.dsh', 'skills') : userRoot;
              const destination = join(root, header.name);
              if (resolve(destination) === resolve(from)) return json({ error: '這個 skill 已經在這個位置' }, 400);
              let previous;
              if (await stat(join(destination, 'SKILL.md')).then(() => true, () => false)) previous = await backup(join(destination, 'SKILL.md'), header.name);
              await mkdir(root, { recursive: true });
              // Removing a linked destination drops only the link; copying from the real folder imports content, not a link.
              const content = await realpath(from);
              await rm(destination, { recursive: true, force: true });
              await cp(content, destination, { recursive: true });
              return json({ ok: true, path: join(destination, 'SKILL.md'), previousBackup: previous ?? null });
            }
            case 'toggle': {
              const skill = await editable(String(body.path));
              await backup(skill.path, skill.name);
              await writeFile(skill.path, setModelInvocation(await readFile(skill.path, 'utf8'), body.modelInvocable === true), 'utf8');
              return json({ ok: true });
            }
            case 'backup': {
              const skill = await editable(String(body.path));
              return json({ ok: true, backup: await backup(skill.path, skill.name) });
            }
            case 'backups': {
              const name = String(body.name ?? '');
              if (!/^[\w.-]{1,64}$/.test(name)) return json({ error: '名稱無效' }, 400);
              const list = await readdir(join(backups, name)).catch(() => []);
              return json({ backups: list.sort().reverse() });
            }
            case 'restore': {
              const skill = await editable(String(body.path));
              const from = join(backups, skill.name, String(body.backup ?? ''));
              if (relative(join(backups, skill.name), from).startsWith('..') || from === join(backups, skill.name)) return json({ error: '備份名稱無效' }, 400);
              if (!await stat(from).then(() => true, () => false)) return json({ error: '找不到這個備份' }, 404);
              await backup(skill.path, skill.name);
              const unit = skillUnit(skill.path);
              // Restore into the folder a link points to, so the link and the user's folder layout stay as they were.
              const real = await realpath(unit);
              await rm(real, { recursive: true, force: true });
              await cp(unit === skill.path ? join(from, basename(unit)) : from, real, { recursive: true });
              return json({ ok: true });
            }
            case 'manual-only': {
              const provider = String(body.provider ?? '');
              if (!/^[\w@./:-]{1,120}$/.test(provider) || provider === MANUAL_ONLY_PROVIDER) return json({ error: '插件名稱無效' }, 400);
              // The user's own skills live in the preset layer, where a shadow would not win; they use the per-skill switch.
              if (provider === 'filesystem') return json({ error: '自己的 skill 請用各自的「改成只能手動叫出」' }, 400);
              await manualOnly.set(provider, body.manualOnly === true);
              shadowsControl?.invalidate();
              return json({ ok: true });
            }
            case 'remove': {
              const skill = await editable(String(body.path));
              const unit = skillUnit(skill.path);
              await mkdir(trash, { recursive: true });
              if (skill.link) {
                // Only the link goes; the folder it points to stays where the user keeps it, recorded in the trash.
                const note = join(trash, `${skill.name}-${stamp()}.link.json`);
                await writeFile(note, `${JSON.stringify({ link: skill.link, target: skill.linkTarget }, null, 2)}\n`, 'utf8');
                await unlink(skill.link);
                return json({ ok: true, trash: note, linkOnly: true });
              }
              const target = join(trash, `${skill.name}-${stamp()}`);
              await rename(unit, target).catch(async () => { await cp(unit, target, { recursive: true }); await rm(unit, { recursive: true, force: true }); });
              return json({ ok: true, trash: target });
            }
            default:
              return json({ error: '未知的操作' }, 400);
          }
        } catch (error) {
          return json({ error: error instanceof Error ? error.message : String(error) }, 500);
        }
      },
    }), 'aiapi skills manager');
  });
}

