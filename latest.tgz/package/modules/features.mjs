/**
 * Every feature this bundle contributes, one switch each.
 *
 * The manifest is shared by the Host entry, the browser entry and the settings row, so a feature's
 * identity and default exist in exactly one place. A Host module or browser module listed here is
 * mounted only while its switch is on; turning it off disposes just that contribution and leaves
 * history, credentials and other features untouched.
 */

/**
 * One feature: its stable id, which halves contribute it, and its row text.
 * @typedef {object} Feature
 * @property {string} id - config key under `features`.
 * @property {boolean} [defaultOn] - false for a feature that ships switched off (opt-in).
 * @property {boolean} [fixed] - always on; shown without a switch because the product depends on it.
 * @property {boolean} host - the Host entry mounts a module for it.
 * @property {boolean} client - the browser entry mounts a module for it.
 * @property {string} zh - Traditional Chinese row label.
 * @property {string} en - English row label.
 * @property {string} zhDetail - Traditional Chinese one-line description.
 * @property {string} enDetail - English one-line description.
 */

/** @type {readonly Feature[]} */
export const FEATURES = Object.freeze([
  {
    id: 'brand',
    fixed: true,
    host: false,
    client: true,
    zh: '品牌外觀',
    en: 'Brand',
    zhDetail: '側邊欄標誌、名稱與新對話字標',
    enDetail: 'Sidebar logo, name and new-conversation wordmark',
  },
  {
    id: 'models',
    fixed: true,
    host: true,
    client: true,
    zh: '模型與提供者',
    en: 'Models and provider',
    zhDetail: 'Aiapi 提供者預設、模型挑選、能力清單與額度覆寫',
    enDetail: 'Aiapi provider default, model picker, discovery and capacity overrides',
  },
  {
    id: 'engineering',
    host: true,
    client: false,
    zh: '工程審查包',
    en: 'Engineering review pack',
    zhDetail: '只有一個引導 skill；六份審查文件放在包裡，對話中叫它才讀（不自動注入、不改提示）',
    enDetail: 'One guide skill; six review documents are read from the pack on demand (no injection, no prompt change)',
  },
  {
    id: 'communication',
    host: true,
    client: false,
    zh: '白話進度與結論優先回覆',
    en: 'Plain progress, outcome-first answers',
    zhDetail: '白話進度與結論優先回覆',
    enDetail: 'Plain-language progress and outcome-first answers',
  },
  {
    id: 'context',
    host: true,
    client: false,
    zh: '任務狀態與原話查找',
    en: 'Task state and recall',
    zhDetail: 'task_state 目標帳本與 context_recall 原話回查',
    enDetail: 'Durable task ledger and original-log recall',
  },
  {
    id: 'desktop',
    host: false,
    client: true,
    zh: '拖放參照與對話交接',
    en: 'Drop references and handoff',
    zhDetail: '原生拖放變成 @ 參照、在對話間續做（檔案位置與回合導覽交給官方）',
    enDetail: 'Native drops become @ references, plus continue-in-a-new-conversation',
  },
  {
    id: 'opencode',
    host: false,
    client: true,
    zh: '智能配色',
    en: 'Smart palette',
    zhDetail: '設定 → 一般 的智能配色開關',
    enDetail: 'The smart palette switch in Settings → General',
  },
  {
    id: 'fonts',
    host: false,
    client: true,
    zh: '字型設定',
    en: 'Fonts',
    zhDetail: '拉丁與中文字型、字重與對話字級',
    enDetail: 'Latin and Chinese families, weights and conversation text size',
  },
  {
    id: 'skills',
    host: true,
    client: true,
    zh: 'Skills 管理',
    en: 'Skills manager',
    zhDetail: '側邊欄 Skills 管理頁、匯入、備份與整包手動化',
    enDetail: 'Sidebar skills page, import, backup and whole-plugin manual use',
  },
]);

/** Stable ids in manifest order. */
export const FEATURE_IDS = Object.freeze(FEATURES.map(feature => feature.id));

/**
 * Read one switch, accepting both a plain value and a volatile config reference.
 * @param candidate - stored value, `Volatile` reference, or `undefined`.
 * @returns the boolean, or `undefined` when the switch was never set.
 */
function unwrap(candidate) {
  if (candidate !== null && typeof candidate === 'object' && typeof candidate.get === 'function') {
    return candidate.get();
  }
  return candidate;
}

/**
 * Resolve every switch for a plugin config, filling defaults for anything absent.
 *
 * Missing `features` (an older entry) means every feature stays on, which is the behaviour before
 * per-feature switches existed.
 * @param config - the plugin config, whose `features` may hold volatile references.
 * @returns a complete `{ [featureId]: boolean }` record.
 */
export function readFeatures(config) {
  // A 1.3.x patch may still carry features.browser; it no longer has an entry here and is ignored.
  const raw = unwrap(config?.features);
  const stored = raw !== null && typeof raw === 'object' ? raw : {};
  /** @type {Record<string, boolean>} */
  const values = {};
  for (const feature of FEATURES) {
    // A fixed feature backs the product itself (brand, provider), so its switch is read-only.
    if (feature.fixed === true) { values[feature.id] = true; continue; }
    values[feature.id] = unwrap(stored[feature.id]) === undefined ? feature.defaultOn !== false : unwrap(stored[feature.id]) !== false;
  }
  return values;
}

/**
 * Whether one feature is on.
 * @param config - the plugin config.
 * @param id - feature id.
 * @returns true unless the switch is explicitly off.
 */
export function featureEnabled(config, id) {
  return readFeatures(config)[id] === true;
}
