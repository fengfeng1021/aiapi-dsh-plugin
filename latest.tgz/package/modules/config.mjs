/** Settings schema of the unified customization plugin; each module reads its own fields. */
import z from '@deepseek-ai/schemastery';
import { FEATURES } from './features.mjs';

/**
 * One live switch per feature. `volatile()` keeps the loader from remounting the entry when a
 * switch changes: it commits the value into the running reference and emits
 * `loader/volatile-update`, so the Host entry mounts or disposes a single feature in place.
 * @param feature - manifest entry the switch belongs to.
 * @returns the boolean schema for that feature.
 */
function switchOf(feature) {
  return z.boolean().default(feature.defaultOn !== false).volatile().description(`${feature.zh}／${feature.en}：${feature.zhDetail}`);
}

const switches = Object.fromEntries(FEATURES.map(feature => [feature.id, switchOf(feature)]));

/**
 * Ordinary fields kept in this plugin's entry. Subagent and tool-call concurrency are the official
 * `@deepseek-ai/dsh-subagent` and `@deepseek-ai/dsh-agent-loop` settings; older entries that still carry
 * this plugin's former limit fields load unchanged and those fields are ignored.
 *
 * `features` is the only section a settings form edits: every field under it is live, so the Plugins
 * page and the plugin's own settings row can flip one feature without restarting the host or the
 * browser page.
 */
export const Config = z.object({
  features: z.object(switches).description('逐項功能開關；關閉即收回該功能的宿主與介面貢獻，不影響歷史、憑證或其他功能'),
  updateManifestUrl: z.string().description('版本檢查用的發佈索引網址；留空則用內建的 AIAPI 發佈位置'),
  /**
   * Removed with the system-browser feature. Kept as an accepted legacy field so a profile patch
   * written for 1.3.x still loads; the value is ignored.
   */
  browser: z.any(),
  /** Legacy switch of the removed browser feature; ignored, and no longer listed in the switches row. */
  modelCapacityOverrides: z.any(),
  progressIntervalSeconds: z.number().step(1).min(15).max(300).default(45),
});
