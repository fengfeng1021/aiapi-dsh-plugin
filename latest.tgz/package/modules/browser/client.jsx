import React, { useEffect, useState } from 'react';

const PANEL_ID = 'aiapi-browser-tabs';
const CSS = `[data-aiapi-browser-attention]{display:flex;flex-wrap:wrap;align-items:center;gap:8px;padding:0 12px 6px;font-size:12px;line-height:1.5;color:#b25e09}
[data-aiapi-browser-attention] button{font:inherit;padding:2px 10px;border-radius:6px;border:1px solid currentColor;background:transparent;color:inherit;cursor:pointer}
.aiapi-bt{height:100%;overflow:auto;padding:24px 28px 40px;box-sizing:border-box;color:var(--dsw-alias-label-primary,#1f2329);font-size:13px;line-height:1.5}
.aiapi-bt h1{font-size:20px;margin:0 0 4px;font-weight:600}
.aiapi-bt .muted{color:var(--dsw-alias-label-tertiary,#8f959e)}
.aiapi-bt .group{border:1px solid var(--dsw-alias-border-l2,#dee0e3);border-radius:10px;padding:10px 14px;margin-top:14px;background:var(--dsw-alias-bg-layer-1,#fff)}
.aiapi-bt .head{display:flex;justify-content:space-between;align-items:center;gap:8px;font-weight:600}
.aiapi-bt .tab{display:flex;justify-content:space-between;align-items:center;gap:10px;padding:6px 0;border-top:1px solid var(--dsw-alias-border-l1,#eff0f1)}
.aiapi-bt .tab:first-of-type{border-top:none}
.aiapi-bt .url{color:var(--dsw-alias-label-tertiary,#8f959e);word-break:break-all;font-size:12px}
.aiapi-bt .badge{display:inline-block;margin-left:6px;padding:0 6px;border-radius:8px;font-size:11px;background:var(--dsw-alias-bg-layer-2,#f2f3f5)}
.aiapi-bt .badge.warn{color:var(--dsw-alias-state-warn-primary,#de7802)}
.aiapi-bt button{font:inherit;padding:3px 10px;border-radius:8px;border:1px solid var(--dsw-alias-border-l3,#d0d3d6);background:var(--dsw-alias-bg-layer-1,#fff);color:inherit;cursor:pointer;white-space:nowrap}
.aiapi-bt button:hover{background:var(--dsw-alias-interactive-bg-hover,#f2f3f5)}
.aiapi-bt .error{color:var(--dsw-alias-state-error-primary,#d93d42)}`;

const call = async (path, init) => {
  const response = await fetch(new URL(path, document.baseURI), { credentials: 'same-origin', cache: 'no-store', ...init });
  const value = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(value.error || `HTTP ${response.status}`);
  return value;
};
const act = body => call('api/aiapi/browser/tab', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(body) });
const hostOf = url => { try { return new URL(url).hostname; } catch { return url; } };

/**
 * Browser tab UI: a sidebar page listing every tab by conversation, and a composer notice when one of
 * this conversation's tabs waits for login or verification. Owned by the client plugin scope.
 * @param ctx - client plugin context.
 * @returns nothing.
 */
export function apply(ctx) {
  ctx.effect(() => {
    const style = document.createElement('style');
    style.dataset.aiapiBrowserTabs = '';
    style.textContent = CSS;
    document.head.append(style);
    return () => style.remove();
  });
  ctx.slots.inject('conversation.input.dock', () => ctx.slots.register({ name: 'conversation.input.dock', id: 'aiapi-browser-attention' }, BrowserAttentionNotice));
  ctx.slots.inject('main', () => ctx.slots.register({ name: 'main', key: PANEL_ID }, BrowserTabsPanel));
  ctx.slots.inject('sidebar.panellist', () => ctx.slots.register({ name: 'sidebar.panellist', id: PANEL_ID, order: 31, label: '瀏覽器分頁' }, BrowserTabsIcon));
}

function BrowserTabsIcon({ size = 20 }) {
  return <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" aria-hidden="true">
    <rect x="3" y="5" width="18" height="14" rx="2" /><path d="M3 9h18M8 5v4" />
  </svg>;
}

function BrowserAttentionNotice({ sessionId, useSession }) {
  const subagent = useSession(value => value.subagent);
  const [attention, setAttention] = useState([]);
  const [error, setError] = useState();
  useEffect(() => {
    if (subagent || !sessionId) return undefined;
    let stopped = false;
    const poll = async () => {
      if (document.visibilityState !== 'visible') return;
      try {
        const value = await call(`api/aiapi/browser/tabs?session=${encodeURIComponent(sessionId)}`);
        if (!stopped) setAttention(value.attention ?? []);
      } catch {
        if (!stopped) setAttention([]); // the browser route is absent while the plugin reloads or the browser bundle is off
      }
    };
    void poll();
    const timer = setInterval(poll, 5000);
    return () => { stopped = true; clearInterval(timer); };
  }, [sessionId, subagent]);
  if (subagent || attention.length === 0) return null;
  const [first] = attention;
  const show = async () => {
    setError(undefined);
    try { await act({ action: 'reveal', tabId: first.tabId }); } catch (failure) {
      setError(failure instanceof Error ? failure.message : String(failure));
    }
  };
  return <div data-aiapi-browser-attention="" role="status">
    <span>這個對話的瀏覽器分頁可能在等你登入或驗證：{first.title || hostOf(first.url)}（{hostOf(first.url)}）{attention.length > 1 ? `，另有 ${attention.length - 1} 個` : ''}</span>
    <button type="button" onClick={show}>顯示這個分頁</button>
    {error && <span>（{error}）</span>}
  </div>;
}

function BrowserTabsPanel() {
  const [groups, setGroups] = useState();
  const [error, setError] = useState();
  const refresh = async () => {
    try { setGroups((await call('api/aiapi/browser/tabs')).groups); setError(undefined); } catch (failure) {
      setError(failure instanceof Error ? failure.message : String(failure));
    }
  };
  useEffect(() => {
    void refresh();
    const timer = setInterval(() => { if (document.visibilityState === 'visible') void refresh(); }, 4000);
    return () => clearInterval(timer);
  }, []);
  const run = async body => {
    try { await act(body); await refresh(); } catch (failure) {
      setError(failure instanceof Error ? failure.message : String(failure));
    }
  };
  return <div className="aiapi-bt">
    <h1>瀏覽器分頁</h1>
    <div className="muted">AI 共用的瀏覽器裡目前開著的分頁，依對話分組。每個 AI 最多保留少數分頁，子代理結束會自動關閉它的分頁。需要你登入或驗證時，按「顯示」把那個分頁帶到前面。</div>
    {error && <div className="error" role="alert">{error}</div>}
    {groups && groups.length === 0 && <div className="muted" style={{ marginTop: 16 }}>目前沒有開啟的分頁。</div>}
    {groups?.map(group => <div className="group" key={group.root}>
      <div className="head">
        <span>{group.title || (group.root === 'user' ? '你自己開的分頁' : `對話 ${group.root.slice(0, 16)}…`)}</span>
        {group.root !== 'user' && <button type="button" onClick={() => run({ action: 'close-group', root: group.root })}>關閉這個對話的分頁</button>}
      </div>
      {group.tabs.map(tab => <div className="tab" key={tab.tabId}>
        <div>
          <div>{tab.title || '（無標題）'}{tab.needsUser && <span className="badge warn">可能在等登入或驗證</span>}{tab.subagent && <span className="badge">子代理</span>}</div>
          <div className="url">{tab.url}</div>
        </div>
        <div style={{ display: 'flex', gap: 6 }}>
          <button type="button" onClick={() => run({ action: 'reveal', tabId: tab.tabId })}>顯示</button>
          <button type="button" onClick={() => run({ action: 'close', tabId: tab.tabId })}>關閉</button>
        </div>
      </div>)}
    </div>)}
  </div>;
}
