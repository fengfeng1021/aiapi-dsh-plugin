---
name: aiapi-code-review
description: 對代碼變更做最終審查、修復後複審與驗證；從 Codex review skills 適配到 DSH。
---

閱讀實際 diff、受影響呼叫端及倉庫規範，再載入 aiapi-review-breaking-changes、aiapi-review-context、aiapi-review-testing、aiapi-review-change-size。

有可用且已獲授權的子代理工作流時，可按檢查面分派獨立審查；否則依序完成全部檢查面。不要要求 DSH 不具備的 Codex 模型或工具參數。

每項確實可重現或有充分證據的問題須包含嚴重性、檔案和行號、觸發條件與影響。不要只報第一項；不為增加數量捏造問題。修復前確認任務包含修復授權；純 review 任務只報告。修復後重新閱讀最終 diff，重跑能證明原問題已解決的測試，再檢查修復是否引入其他問題；沒有新變更或未解疑點時不要無限複審。

除非使用者要求，不在 GitHub 發留言、改標籤或提交變更。結論區分通過的證據、發現的問題及未測範圍。此版調整了原 Codex orchestrator 的工具依賴與外部寫入行為；原文隨套件保留。
