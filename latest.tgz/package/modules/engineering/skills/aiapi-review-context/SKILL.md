---
name: aiapi-review-context
description: 審查模型可見上下文的大小、穩定性與日誌重建。
---

檢查上下文是否增量累積、不重寫歷史，避免頻繁改動前綴造成快取失效。注入內容與外部結果必須有硬上限；單項不得超過 10,000 tokens，新增超過約 1,000 tokens 的片段需額外人工審視並在報告標出。DSH 使用 systemPrompt/context 等官方可記錄接口，不需要 Codex core/context 的 Rust trait。確認停用插件撤回未來貢獻，保留已記錄的歷史，且金鑰不進入上下文。
