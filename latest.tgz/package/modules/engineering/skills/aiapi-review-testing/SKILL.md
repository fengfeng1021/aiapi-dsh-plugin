---
name: aiapi-review-testing
description: 審查 agent 行為、插件整合及使用者可见變更的驗證是否充分。
---

列出主要邏輯變更與使用者可見行為，逐項對照測試。agent 邏輯優先用整合測試；DSH 需從真實 Loader/打包入口驗證，模型輸出需可重播的會話證據，UI 需渲染證據。插件包含停用、重新啟用、取消與清理。單元測試集中在獨立測試檔，使用既有 helpers，避免為測試添加生產專用接口。只在 Codex Rust 倉庫使用 test_codex 與其 just test 命令，DSH 使用自身測試工具。說明測試缺口，不把沒有跑過的檢查宣稱通過。
