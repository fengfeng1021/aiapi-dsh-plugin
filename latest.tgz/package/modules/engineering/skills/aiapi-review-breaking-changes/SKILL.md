---
name: aiapi-review-breaking-changes
description: 審查外部整合、設定與既有會話的相容性。
---

檢查 API/RPC 方法與欄位、事件、CLI 參數、設定載入、插件 exports、停用恢復、以及既有會話恢復。追蹤受影響的呼叫端和持久化資料，不只查新程式是否編譯。DSH 中須同時考慮 Host/Client 接口及模型可見日誌；修改 Codex 時才檢查其 app-server 與 rawResponseItem 事件。列出所有有證據的相容性問題。
