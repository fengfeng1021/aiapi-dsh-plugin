import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';

export const name = 'aiapi-engineering';
export const inject = ['skills'];

/** The one skill this feature exposes; every other file in the pack is read on demand. */
const GUIDE = 'aiapi-engineering-review';

/**
 * Register a single guide skill for the engineering review pack. The six review documents stay as plain
 * files inside the bundle: they are never registered, never injected into the prompt, and never appear in
 * the model's skill catalog — a conversation has to call the guide (by name or `/`) and the guide then
 * points at the file to read.
 * @param ctx - customization plugin context.
 * @returns nothing; the registration belongs to this plugin fiber.
 */
export function apply(ctx) {
  const skillsRoot = new URL('./skills/', import.meta.url);
  const url = new URL(`${GUIDE}/SKILL.md`, skillsRoot);
  const raw = readFileSync(url, 'utf8');
  const match = /^---\r?\nname: ([^\r\n]+)\r?\ndescription: ([^\r\n]+)\r?\n---\r?\n([\s\S]*)$/.exec(raw);
  if (!match) throw new Error(`Invalid packaged skill: ${GUIDE}`);
  ctx.skills.register({
    name: match[1],
    description: match[2],
    content: match[3],
    source: 'bundled',
    provider: 'aiapi-engineering',
    path: fileURLToPath(url),
    // The pack root, so the guide's relative paths resolve for the file tools it tells you to use.
    resourceBase: { kind: 'directory', path: fileURLToPath(skillsRoot) },
  });
}
