/**
 * Per-feature switches: one browser-side store every feature module reads, and the settings row that
 * flips them.
 *
 * The switch values are the plugin config's `features` object. The Host half reads the same values
 * through volatile references, so a change written here reaches both halves: the Host entry mounts or
 * disposes a feature on `loader/volatile-update`, and this page re-gates its own modules through
 * {@link subscribeFeatures} without a reload.
 */
import React, { useEffect, useState } from 'react';
import { FEATURES, readFeatures } from '../features.mjs';

/** Entry id this bundle is normally mounted under; used when the schema cannot identify the namespace. */
const DEFAULT_NS = 'aiapi-customizations';

/** Package name the bundle page keys its own configuration slot by. */
const PACKAGE_NAME = '@aiapi/dsh-customizations';

/** Same-origin JSON call to the Host routes this bundle registered. */
async function readJson(path, init) {
  const response = await fetch(new URL(path.replace(/^\//, ''), document.baseURI), {
    credentials: 'same-origin', cache: 'no-store', ...init,
  });
  const body = await response.json();
  if (!response.ok) throw new Error(body?.error ?? `回應 ${response.status}`);
  return body;
}

const CSS = `.aiapi-fe{padding:2px 0 6px}
.aiapi-fe .head{display:flex;align-items:baseline;gap:8px;flex-wrap:wrap}
.aiapi-fe .title{font-weight:600}
.aiapi-fe .hint{font-size:12px;color:var(--dsw-alias-label-tertiary,#8f959e)}
.aiapi-fe .grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(190px,1fr));gap:2px 14px;margin-top:8px}
.aiapi-fe label{display:flex;align-items:center;gap:6px;padding:2px 0;cursor:pointer;font-size:13px}
.aiapi-fe label input{margin:0}
.aiapi-fe .detail{font-size:11px;color:var(--dsw-alias-label-tertiary,#8f959e);margin-left:22px;line-height:1.35}
.aiapi-fe .state{margin-top:6px;font-size:12px}
.aiapi-fe .state.error{color:var(--dsw-alias-state-error-primary,#d93d42)}
.aiapi-fe-fixed{display:inline-flex;align-items:center;gap:6px;font-weight:500}
.aiapi-fe-lock{font-size:11px;padding:0 6px;border-radius:999px;background:rgba(127,127,127,.16);color:inherit;opacity:.8}
.aiapi-fe .state.ok{color:var(--dsw-alias-label-tertiary,#8f959e)}
.aiapi-up{display:flex;gap:10px;flex-wrap:wrap;align-items:center;font-size:12px;color:var(--dsw-alias-label-tertiary,#8f959e)}
.aiapi-up button{font:inherit;font-size:12px;padding:2px 8px;border-radius:7px;border:1px solid var(--dsw-alias-border-l3,#d0d3d6);background:var(--dsw-alias-bg-layer-1,#fff);color:inherit;cursor:pointer}
.aiapi-up button:hover{background:var(--dsw-alias-interactive-bg-hover,#f2f3f5)}
.aiapi-up .newer{color:var(--dsw-alias-state-warn-primary,#de7802)}
.aiapi-up code{font-size:11px;user-select:all}
.aiapi-fe-section{margin-top:18px;padding-top:14px;border-top:1px solid var(--dsw-alias-border-l2,#dee0e3)}`;

/** Listeners re-gated by a switch change; module scope keeps them across page remounts. */
const listeners = new Set();

/** Last known complete set of switches. */
let current = null;

/**
 * Publish a complete switch set to the feature mounters.
 * @param values - `{ [featureId]: boolean }`.
 * @returns nothing.
 */
export function setFeatureValues(values) {
  current = { ...values };
  for (const listener of listeners) listener(current);
}

/**
 * Read the last published switches.
 * @returns the current record, or an empty object before the first publish.
 */
export function getFeatureValues() {
  return current ?? {};
}

/**
 * Follow switch changes, so a feature can unmount itself without a page reload.
 * @param listener - called with the complete record after every change.
 * @returns the unsubscribe function.
 */
export function subscribeFeatures(listener) {
  listeners.add(listener);
  return () => listeners.delete(listener);
}

/**
 * Pick this plugin's namespace out of a describe response: the entry whose resolved value carries a
 * `features` object, preferring the default entry id when several match.
 * @param namespaces - namespace views from `settings.describe()`.
 * @returns the matching view, or undefined.
 */
function pickNamespace(namespaces) {
  const holders = (namespaces ?? []).filter(view => view?.value !== null && typeof view?.value === 'object' && view.value.features !== undefined);
  return holders.find(view => view.ns === DEFAULT_NS) ?? holders[0];
}

/**
 * Read the settings view this row writes into.
 * @param ctx - client plugin context.
 * @returns the settings describe value.
 */
async function describe(ctx) {
  const response = await ctx.remote.settings.describe();
  if (response?.ok === false) throw new Error(response.error?.message ?? '無法讀取設定');
  return response?.value ?? response;
}

/**
 * Write the complete switch set through the settings service, which validates the plugin's Config
 * before persisting and applies a volatile-only change in place.
 * @param ctx - client plugin context.
 * @param values - complete switch set to persist.
 * @returns the namespace written.
 */
async function persist(ctx, values) {
  const view = pickNamespace((await describe(ctx)).namespaces);
  if (view === undefined) throw new Error('找不到本插件的設定命名空間');
  const operations = FEATURES.map(feature => ({ op: 'set', path: ['features', feature.id], value: values[feature.id] !== false }));
  const response = await ctx.remote.settings.mutate(view.ns, operations, view.revision);
  if (response?.ok === false) throw new Error(response.error?.message ?? '寫入被拒絕');
  return view.ns;
}

/** One switch row: the label, its description, and the checkbox that flips it. */
function SwitchRow({ feature, on, busy, onToggle }) {
  const [zh, en] = [feature.zh, feature.en];
  const fixed = feature.fixed === true;
  return (
    <div>
      <label title={fixed ? `${zh}／${en}（固定啟用）` : `${zh}／${en}`}>
        {fixed
          ? <span className="aiapi-fe-fixed">{zh}<span className="aiapi-fe-lock">固定啟用</span></span>
          : (
            <>
              <input type="checkbox" checked={on} disabled={busy} onChange={event => onToggle(feature.id, event.target.checked)} />
              {zh}
            </>
          )}
      </label>
      <div className="detail">{feature.zhDetail}</div>
    </div>
  );
}

/**
 * The 功能開關 row in Settings → General: every feature of this bundle with its own switch.
 * @param props - client plugin context injected by the slot.
 * @returns the row element.
 */
function FeatureRow({ ctx }) {
  const [values, setValues] = useState(() => getFeatureValues());
  const [status, setStatus] = useState({ kind: 'idle', message: '' });
  const [busy, setBusy] = useState(false);

  useEffect(() => subscribeFeatures(next => setValues(next)), []);

  // The Host is the source of truth after a restart or another client's edit.
  useEffect(() => {
    let alive = true;
    describe(ctx)
      .then(view => {
        if (!alive) return;
        const namespace = pickNamespace(view.namespaces);
        if (namespace === undefined) return;
        const next = readFeatures({ features: namespace.value?.features });
        setFeatureValues(next);
        setValues(next);
      })
      .catch(error => { if (alive) setStatus({ kind: 'error', message: error?.message ?? String(error) }) });
    return () => { alive = false };
  }, [ctx]);

  const toggle = async (id, on) => {
    const previous = values;
    const next = { ...values, [id]: on };
    setValues(next);
    setFeatureValues(next);
    setBusy(true);
    try {
      await persist(ctx, next);
      setStatus({ kind: 'ok', message: '已套用' });
    } catch (error) {
      setValues(previous);
      setFeatureValues(previous);
      setStatus({ kind: 'error', message: error?.message ?? String(error) });
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="aiapi-fe">
      <div className="head">
        <span className="title">功能開關</span>
        <span className="hint">逐項啟用或停用；關閉會立即收回該功能，歷史與憑證不受影響</span>
      </div>
      <div className="grid">
        {FEATURES.map(feature => (
          <SwitchRow
            key={feature.id}
            feature={feature}
            on={values[feature.id] !== false}
            busy={busy}
            onToggle={toggle}
          />
        ))}
      </div>
      {status.message === '' ? null : <div className={`state ${status.kind}`}>{status.message}</div>}
    </div>
  );
}

/**
 * Register the switches row and its stylesheet in the client plugin's disposal scope.
 * @param ctx - client plugin context.
 * @returns nothing; every contribution is disposed with the plugin.
 */
export function applyFeaturesRow(ctx) {
  ctx.effect(() => {
    const style = document.createElement('style');
    style.dataset.aiapiFeatures = '';
    style.textContent = CSS;
    document.head.append(style);
    return () => style.remove();
  });
  ctx.slots.inject('settings.general.item', () => ctx.slots.register({
    name: 'settings.general.item', id: 'aiapi-features', order: 13,
  }, () => <FeatureRow ctx={ctx} />));
}

/**
 * Register the same switches on the plugin's own page in Plugins, so every feature is reachable from
 * the entry itself and not only from Settings → General.
 *
 * The detail section is the slot the manager documents for a bundle that has something to say about
 * its own page: it is dispatched for every open detail page, so this entry renders null unless the
 * subject is this package.
 * @param ctx - client plugin context.
 * @returns nothing; the registration lives in the plugin's disposal scope.
 */
export function applyPluginPageRow(ctx) {
  ctx.slots.inject('plugins.detail.section', () => ctx.slots.register({
    name: 'plugins.detail.section', id: 'aiapi-features',
  }, ({ subject }) => {
    const name = subject?.kind === 'bundle' || subject?.kind === 'row' ? subject.pkg?.name : undefined;
    if (name !== PACKAGE_NAME) return null;
    return <section className="aiapi-fe-section" data-aiapi-features-section><UpdateCard ctx={ctx} /><FeatureRow ctx={ctx} /></section>;
  }));
}

/**
 * Version and update card: shows this build next to the published release, and hands over the install
 * spec for a newer one. Installing is DSH's own operation — the plugin only reports and prepares it.
 * @param props - client plugin context injected by the slot.
 * @returns the card element.
 */
function UpdateCard({ ctx }) {
  const [current, setCurrent] = useState('');
  const [latest, setLatest] = useState(null);
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const [applying, setApplying] = useState('');
  const [needsReload, setNeedsReload] = useState(false);

  const check = async () => {
    setBusy(true);
    setError('');
    try {
      const info = await readJson('api/aiapi/update');
      setCurrent(info.version);
      const result = await readJson('api/aiapi/update/check', {
        method: 'POST', headers: { 'content-type': 'application/json' }, body: '{}',
      });
      if (result.unconfigured === true) setError('尚未設定更新來源：在 profile patch 的 aiapi-customizations config 加上 updateManifestUrl。');
      else if (result.error !== undefined) setError(`${result.error}${result.manifest === undefined ? '' : `（${result.manifest}）`}`);
      setLatest(result.latest ?? null);
    } catch (failure) {
      setError(failure instanceof Error ? failure.message : '無法檢查更新');
    } finally {
      setBusy(false);
    }
  };

  /** Ask the Host to install the published release through DSH's plugin manager. */
  const apply = async () => {
    setApplying('正在下載並校驗更新檔…');
    setError('');
    try {
      const result = await readJson('api/aiapi/update/apply', {
        method: 'POST', headers: { 'content-type': 'application/json' }, body: '{}',
      });
      if (result.status === 'current') { setApplying('已是最新版本。'); return; }
      if (result.status !== 'updating') throw new Error(result.error ?? '更新未被接受');
      setNeedsReload(true);
      setApplying(`正在安裝 ${result.version}；這個外掛會被重新載入，完成後請按「重新載入頁面」。`);
    } catch (failure) {
      const message = failure instanceof Error ? failure.message : '更新失敗';
      setApplying('');
      if (message.includes('尚未設定更新來源')) setError('尚未設定更新來源（updateManifestUrl）。');
      else if (message.includes('沒有提供外掛管理服務')) setError(message);
      else setError(message);
    }
  };

  useEffect(() => { void check(); }, []);

  const spec = latest?.spec ?? latest?.tarball;
  // The published version and this build must differ; the presence of an install spec means nothing.
  const newer = latest !== null && current !== '' && latest.version !== current;
  return (
    <div className="aiapi-up">
      <span>版本 {current === '' ? '讀取中…' : current}</span>
      <button type="button" disabled={busy} onClick={() => { void check(); }}>{busy ? '檢查中…' : '檢查更新'}</button>
      {latest === null
        ? null
        : newer
          ? <span className="newer">有新版本 {latest.version}</span>
          : <span>已是最新（{latest.version}）</span>}
      {newer && applying === ''
        ? <button type="button" disabled={busy} onClick={() => { void apply(); }}>立即更新</button>
        : null}
      {applying === '' ? null : <span>{applying}{needsReload ? <button type="button" onClick={() => window.location.reload()}>重新載入頁面</button> : null}</span>}
      {newer && applying === '' && error !== '' && spec !== undefined ? <span>或手動貼：<code>{spec}</code></span> : null}
      {error === '' ? null : <span>{error}</span>}
    </div>
  );
}

/**
 * Offer the update on every DSH start while this build is behind the published one — once per page load,
 * so a dismissed dialog is not reopened by navigation. The dialog is plain DOM: it must work before any
 * page-level React surface exists, and it is removed with the plugin's disposal scope.
 * @param ctx - client plugin context.
 * @returns nothing.
 */
export function applyUpdateNotice(ctx) {
  ctx.effect(() => {
    let disposed = false;
    let root;
    let reloadNeeded = false;
    const close = () => { root?.remove(); root = undefined };

    const render = (current, latest) => {
      root = document.createElement('div');
      root.dataset.aiapiUpdateNotice = '';
      Object.assign(root.style, {
        position: 'fixed', right: '18px', bottom: '18px', zIndex: '9999', maxWidth: '360px',
        padding: '14px 16px', borderRadius: '12px', background: '#1f2329', color: '#fff',
        boxShadow: '0 12px 32px rgba(0,0,0,.35)', font: '13px/1.55 -apple-system,"Segoe UI",system-ui,sans-serif',
      });

      const title = document.createElement('div');
      title.style.fontWeight = '600';
      title.style.marginBottom = '4px';
      title.textContent = `Aiapi 插件有新版本 ${latest.version}`;
      const body = document.createElement('div');
      body.style.opacity = '.85';
      body.textContent = latest.notes ? `${latest.notes}（目前 ${current}）` : `目前 ${current}，可更新到 ${latest.version}。`;

      const row = document.createElement('div');
      row.style.display = 'flex';
      row.style.gap = '8px';
      row.style.marginTop = '10px';
      const update = document.createElement('button');
      update.type = 'button';
      update.textContent = '立即更新';
      Object.assign(update.style, { padding: '5px 12px', borderRadius: '8px', border: '0', background: '#1f6feb', color: '#fff', cursor: 'pointer', font: 'inherit' });
      const later = document.createElement('button');
      later.type = 'button';
      later.textContent = '稍後';
      Object.assign(later.style, { padding: '5px 12px', borderRadius: '8px', border: '1px solid rgba(255,255,255,.35)', background: 'transparent', color: '#fff', cursor: 'pointer', font: 'inherit' });

      update.addEventListener('click', async () => {
        update.disabled = true;
        update.textContent = '處理中…';
        try {
          const result = await readJson('api/aiapi/update/apply', { method: 'POST', headers: { 'content-type': 'application/json' }, body: '{}' });
          if (result.status === 'current') { body.textContent = '已是最新版本。'; update.remove(); return; }
          if (result.status !== 'updating') throw new Error(result.error ?? '更新未被接受');
          reloadNeeded = true;
          body.textContent = `正在安裝 ${result.version}；這個外掛會被重新載入，完成後請按「重新載入頁面」。`;
          update.textContent = '重新載入頁面';
          update.disabled = false;
          update.addEventListener('click', () => window.location.reload(), { once: true });
        } catch (error) {
          body.textContent = error instanceof Error ? error.message : '更新失敗';
          update.disabled = false;
          update.textContent = '立即更新';
        }
      });
      later.addEventListener('click', close);

      row.append(update, later);
      root.append(title, body, row);
      document.body.append(root);
    };

    void (async () => {
      try {
        const info = await readJson('api/aiapi/update');
        const result = await readJson('api/aiapi/update/check', { method: 'POST', headers: { 'content-type': 'application/json' }, body: '{}' });
        if (disposed || !result.newer || result.latest === null || result.latest === undefined) return;
        if (root !== undefined || reloadNeeded) return;
        render(info.version, result.latest);
      } catch {
        // An unreachable release host must never produce a startup error for the user.
      }
    })();

    return () => { disposed = true; close() };
  }, 'aiapi update notice');
}
