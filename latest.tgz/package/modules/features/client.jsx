/**
 * Per-feature switches: one browser-side store every feature module reads, and the settings row that
 * flips them.
 *
 * The switch values are the plugin config's `features` object. The Host half reads the same values
 * through volatile references, so a change written here reaches both halves: the Host entry mounts or
 * disposes a feature on `loader/volatile-update`, and this page re-gates its own modules through
 * {@link subscribeFeatures} without a reload.
 */
import React, { useEffect, useState } from 'react';
import { BalanceBar, BalanceCard, BalancePage } from './balance.jsx';
import { FEATURES, readFeatures } from '../features.mjs';

/** Entry id this bundle is normally mounted under; used when the schema cannot identify the namespace. */
const DEFAULT_NS = 'aiapi-customizations';

/** Package name the bundle page keys its own configuration slot by. */
const PACKAGE_NAME = '@aiapi/dsh-customizations';

/** One shared record of what the release host offers, so the card and the popup cannot disagree. */
export const updateStore = {
  state: { current: '', latest: undefined, installed: '', newer: false },
  listeners: new Set(),
  publish(patch) {
    this.state = { ...this.state, ...patch };
    for (const listener of this.listeners) listener(this.state);
  },
  subscribe(listener) {
    this.listeners.add(listener);
    listener(this.state);
    return () => { this.listeners.delete(listener); };
  },
};

/**
 * Restart the desktop shell. DSH runs inside different carriers, so every relaunch command a Tauri shell
 * may expose is tried in turn; when none is available the caller must offer the manual step instead of
 * pretending the click worked.
 * @returns whether a restart was actually requested.
 */
async function restartDsh() {
  const tauri = window.__TAURI_INTERNALS__;
  const invoke = tauri?.invoke;
  if (typeof invoke !== 'function') return false;
  for (const command of ['plugin:process|restart', 'plugin:process|relaunch', 'plugin:app|restart', 'restart_app']) {
    try {
      await invoke(command, {});
      return true;
    } catch { /* try the next name; the shell may not expose this plugin */ }
  }
  return false;
}

/** Same-origin JSON call to the Host routes this bundle registered. */
async function readJson(path, init) {
  // 桌面殼的 document.baseURI 不一定是 http(s)（可能是 tauri:// 或帶路徑），
  // 這裡一律從站點根組出絕對路徑，避免解析到殼自己的 origin 而 404。
  const origin = /^https?:/i.test(location.origin) ? location.origin : document.baseURI;
  const url = new URL(`/${path.replace(/^\//, '')}`, origin);
  const response = await fetch(url, { credentials: 'same-origin', cache: 'no-store', ...init });
  if (!response.ok) {
    const body = await response.json().catch(() => undefined);
    console.warn('[aiapi] 請求失敗', url.href, response.status, body);
    throw new Error(body?.error ?? `回應 ${response.status}`);
  }
  return response.json();
}

const CSS = `.aiapi-fe{padding:2px 0 6px}
.aiapi-fe .head{display:flex;align-items:baseline;gap:8px;flex-wrap:wrap}
.aiapi-fe .title{font-weight:600}
.aiapi-fe .hint{font-size:12px;color:var(--dsw-alias-label-tertiary,#8f959e)}
.aiapi-fe .grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(190px,1fr));gap:2px 14px;margin-top:8px}
.aiapi-fe label{display:flex;align-items:center;gap:6px;padding:2px 0;cursor:pointer;font-size:13px}
.aiapi-fe label input{margin:0}
.aiapi-fe .detail{font-size:11px;color:var(--dsw-alias-label-tertiary,#8f959e);margin-left:22px;line-height:1.35}
.aiapi-fe .state{margin-top:6px;font-size:12px}
.aiapi-fe .state.error{color:var(--dsw-alias-state-error-primary,#d93d42)}
.aiapi-bal{display:flex;align-items:center;gap:8px;width:100%;padding:5px 8px;border-radius:9px;border:1px solid rgba(127,127,127,.22);background:rgba(127,127,127,.08);font:inherit;color:inherit;cursor:pointer;overflow:hidden}
.aiapi-bal:hover{background:rgba(127,127,127,.14)}
.aiapi-bal-off{opacity:.6;cursor:default;font-size:12px}
.aiapi-bal-dot{width:7px;height:7px;border-radius:50%;flex:none;animation:aiapi-bal-pulse 2.4s ease-in-out infinite}
@keyframes aiapi-bal-pulse{0%,100%{opacity:.55;transform:scale(.9)}50%{opacity:1;transform:scale(1.15)}}
.aiapi-bal-amount{font-variant-numeric:tabular-nums;font-weight:600;font-size:12px;flex:none}
.aiapi-bal-track{position:relative;flex:1;height:4px;border-radius:999px;background:rgba(127,127,127,.25);overflow:hidden;min-width:36px}
.aiapi-bal-fill{position:absolute;inset:0 auto 0 0;border-radius:999px;transition:width .6s ease, background .6s ease;background-size:200% 100%;animation:aiapi-bal-flow 6s linear infinite}
@keyframes aiapi-bal-flow{0%{background-position:0 0}100%{background-position:200% 0}}
.aiapi-fe-error{margin:8px 0;padding:8px 10px;border-radius:8px;background:rgba(220,80,80,.12);color:inherit;font-size:12px}
.aiapi-balance-page{padding:4px 0 8px;max-width:640px}
.aiapi-balance-title{margin:0 0 4px;font-size:15px;font-weight:650}
.aiapi-balance-hint{margin:0 0 12px;font-size:12px;color:var(--dsw-alias-label-tertiary,#8f959e)}
.aiapi-balance-figures{display:grid;grid-template-columns:repeat(auto-fit,minmax(120px,1fr));gap:10px;margin-bottom:14px}
.aiapi-balance-figure-block{display:flex;flex-direction:column;gap:2px;padding:10px 12px;border:1px solid rgba(127,127,127,.22);border-radius:10px;background:rgba(127,127,127,.06)}
.aiapi-balance-figure-label{font-size:11px;color:var(--dsw-alias-label-tertiary,#8f959e)}
.aiapi-balance-figure{font-size:18px;font-weight:650;font-variant-numeric:tabular-nums}
.aiapi-balance-figure small{font-size:12px;font-weight:400;opacity:.75}
.aiapi-balance-version{margin:0 0 10px;font-size:11px;color:var(--dsw-alias-label-tertiary,#8f959e)}
.aiapi-balance-version code{font-size:11px}
.aiapi-balance-actions{display:flex;align-items:center;gap:12px;flex-wrap:wrap}
.aiapi-balance-toggle{display:inline-flex;align-items:center;gap:6px;font-size:12px}
.aiapi-balance-card{padding:6px 0 2px}
.aiapi-balance-figure{font-size:20px;font-weight:650;font-variant-numeric:tabular-nums}
.aiapi-fe-fixed{display:inline-flex;align-items:center;gap:6px;font-weight:500}
.aiapi-fe-lock{font-size:11px;padding:0 6px;border-radius:999px;background:rgba(127,127,127,.16);color:inherit;opacity:.8}
.aiapi-fe .state.ok{color:var(--dsw-alias-label-tertiary,#8f959e)}
.aiapi-up{display:flex;gap:10px;flex-wrap:wrap;align-items:center;font-size:12px;color:var(--dsw-alias-label-tertiary,#8f959e)}
.aiapi-up button{font:inherit;font-size:12px;padding:2px 8px;border-radius:7px;border:1px solid var(--dsw-alias-border-l3,#d0d3d6);background:var(--dsw-alias-bg-layer-1,#fff);color:inherit;cursor:pointer}
.aiapi-up button:hover{background:var(--dsw-alias-interactive-bg-hover,#f2f3f5)}
.aiapi-up .newer{color:var(--dsw-alias-state-warn-primary,#de7802)}
.aiapi-up code{font-size:11px;user-select:all}
.aiapi-fe-section{margin-top:18px;padding-top:14px;border-top:1px solid var(--dsw-alias-border-l2,#dee0e3)}`;

/** Listeners re-gated by a switch change; module scope keeps them across page remounts. */
const listeners = new Set();

/** Last known complete set of switches. */
let current = null;

/**
 * Publish a complete switch set to the feature mounters.
 * @param values - `{ [featureId]: boolean }`.
 * @returns nothing.
 */
export function setFeatureValues(values) {
  current = { ...values };
  for (const listener of listeners) listener(current);
}

/**
 * Read the last published switches.
 * @returns the current record, or an empty object before the first publish.
 */
export function getFeatureValues() {
  return current ?? {};
}

/**
 * Follow switch changes, so a feature can unmount itself without a page reload.
 * @param listener - called with the complete record after every change.
 * @returns the unsubscribe function.
 */
export function subscribeFeatures(listener) {
  listeners.add(listener);
  return () => listeners.delete(listener);
}

/**
 * Pick this plugin's namespace out of a describe response: the entry whose resolved value carries a
 * `features` object, preferring the default entry id when several match.
 * @param namespaces - namespace views from `settings.describe()`.
 * @returns the matching view, or undefined.
 */
function pickNamespace(namespaces) {
  const holders = (namespaces ?? []).filter(view => view?.value !== null && typeof view?.value === 'object' && view.value.features !== undefined);
  return holders.find(view => view.ns === DEFAULT_NS) ?? holders[0];
}

/**
 * Read the settings view this row writes into.
 * @param ctx - client plugin context.
 * @returns the settings describe value.
 */
async function describe(ctx) {
  const response = await ctx.remote.settings.describe();
  if (response?.ok === false) throw new Error(response.error?.message ?? '無法讀取設定');
  return response?.value ?? response;
}

/**
 * Write the complete switch set through the settings service, which validates the plugin's Config
 * before persisting and applies a volatile-only change in place.
 * @param ctx - client plugin context.
 * @param values - complete switch set to persist.
 * @returns the namespace written.
 */
async function persist(ctx, values) {
  const view = pickNamespace((await describe(ctx)).namespaces);
  if (view === undefined) throw new Error('找不到本插件的設定命名空間');
  const operations = FEATURES.map(feature => ({ op: 'set', path: ['features', feature.id], value: values[feature.id] !== false }));
  const response = await ctx.remote.settings.mutate(view.ns, operations, view.revision);
  if (response?.ok === false) throw new Error(response.error?.message ?? '寫入被拒絕');
  return view.ns;
}

/** One switch row: the label, its description, and the checkbox that flips it. */
function SwitchRow({ feature, on, busy, onToggle }) {
  const [zh, en] = [feature.zh, feature.en];
  const fixed = feature.fixed === true;
  return (
    <div>
      <label title={fixed ? `${zh}／${en}（固定啟用）` : `${zh}／${en}`}>
        {fixed
          ? <span className="aiapi-fe-fixed">{zh}<span className="aiapi-fe-lock">固定啟用</span></span>
          : (
            <>
              <input type="checkbox" checked={on} disabled={busy} onChange={event => onToggle(feature.id, event.target.checked)} />
              {zh}
            </>
          )}
      </label>
      <div className="detail">{feature.zhDetail}</div>
    </div>
  );
}

/**
 * The 功能開關 row in Settings → General: every feature of this bundle with its own switch.
 * @param props - client plugin context injected by the slot.
 * @returns the row element.
 */
function FeatureRow({ ctx }) {
  const [values, setValues] = useState(() => getFeatureValues());
  const [status, setStatus] = useState({ kind: 'idle', message: '' });
  const [busy, setBusy] = useState(false);

  useEffect(() => subscribeFeatures(next => setValues(next)), []);

  // The Host is the source of truth after a restart or another client's edit.
  useEffect(() => {
    let alive = true;
    describe(ctx)
      .then(view => {
        if (!alive) return;
        const namespace = pickNamespace(view.namespaces);
        if (namespace === undefined) return;
        const next = readFeatures({ features: namespace.value?.features });
        setFeatureValues(next);
        setValues(next);
      })
      .catch(error => { if (alive) setStatus({ kind: 'error', message: error?.message ?? String(error) }) });
    return () => { alive = false };
  }, [ctx]);

  const toggle = async (id, on) => {
    const previous = values;
    const next = { ...values, [id]: on };
    setValues(next);
    setFeatureValues(next);
    setBusy(true);
    try {
      await persist(ctx, next);
      setStatus({ kind: 'ok', message: '已套用' });
    } catch (error) {
      setValues(previous);
      setFeatureValues(previous);
      setStatus({ kind: 'error', message: error?.message ?? String(error) });
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="aiapi-fe">
      <div className="head">
        <span className="title">功能開關</span>
        <span className="hint">逐項啟用或停用；關閉會立即收回該功能，歷史與憑證不受影響</span>
      </div>
      <div className="grid">
        {FEATURES.map(feature => (
          <SwitchRow
            key={feature.id}
            feature={feature}
            on={values[feature.id] !== false}
            busy={busy}
            onToggle={toggle}
          />
        ))}
      </div>
      {status.message === '' ? null : <div className={`state ${status.kind}`}>{status.message}</div>}
    </div>
  );
}

/**
 * Register the switches row and its stylesheet in the client plugin's disposal scope.
 * @param ctx - client plugin context.
 * @returns nothing; every contribution is disposed with the plugin.
 */
export function applyFeaturesRow(ctx) {
  ctx.effect(() => {
    const style = document.createElement('style');
    style.dataset.aiapiFeatures = '';
    style.textContent = CSS;
    document.head.append(style);
    return () => style.remove();
  });
  ctx.slots.inject('settings.general.item', () => ctx.slots.register({
    name: 'settings.general.item', id: 'aiapi-features', order: 13,
  }, () => <FeatureRow ctx={ctx} />));
}

/**
 * Register the same switches on the plugin's own page in Plugins, so every feature is reachable from
 * the entry itself and not only from Settings → General.
 *
 * The detail section is the slot the manager documents for a bundle that has something to say about
 * its own page: it is dispatched for every open detail page, so this entry renders null unless the
 * subject is this package.
 * @param ctx - client plugin context.
 * @returns nothing; the registration lives in the plugin's disposal scope.
 */
export function applyPluginPageRow(ctx) {
  ctx.slots.inject('plugins.detail.section', () => ctx.slots.register({
    name: 'plugins.detail.section', id: 'aiapi-features',
  }, ({ subject }) => {
    const name = subject?.kind === 'bundle' || subject?.kind === 'row' ? subject.pkg?.name : undefined;
    if (name !== PACKAGE_NAME) return null;
    return <section className="aiapi-fe-section" data-aiapi-features-section><CardBoundary label="update"><UpdateCard ctx={ctx} /></CardBoundary><CardBoundary label="balance"><BalanceRow ctx={ctx} /></CardBoundary><CardBoundary label="features"><FeatureRow ctx={ctx} /></CardBoundary></section>;
  }));
}

/**
 * Version and update card: shows this build next to the published release, and hands over the install
 * spec for a newer one. Installing is DSH's own operation — the plugin only reports and prepares it.
 * @param props - client plugin context injected by the slot.
 * @returns the card element.
 */
function UpdateCard({ ctx }) {
  const [current, setCurrent] = useState('');
  const [latest, setLatest] = useState(null);
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const [applying, setApplying] = useState('');
  const [needsReload, setNeedsReload] = useState(false);
  const [restartNeeded, setRestartNeeded] = useState(false);
  const [onDisk, setOnDisk] = useState('');

  const check = async () => {
    setBusy(true);
    setError('');
    try {
      const info = await readJson('api/aiapi/update');
      setCurrent(info.version);
      setOnDisk(typeof info.onDisk === 'string' ? info.onDisk : '');
      const result = await readJson('api/aiapi/update/check', {
        method: 'POST', headers: { 'content-type': 'application/json' }, body: '{}',
      });
      if (result.unconfigured === true) setError('尚未設定更新來源：在 profile patch 的 aiapi-customizations config 加上 updateManifestUrl。');
      else if (result.error !== undefined) setError(`${result.error}${result.manifest === undefined ? '' : `（${result.manifest}）`}`);
      setLatest(result.latest ?? null);
      updateStore.publish({ current: info.version, latest: result.latest ?? undefined, installed: info.onDisk ?? '', newer: result.newer === true });
    } catch (failure) {
      setError(failure instanceof Error ? failure.message : '無法檢查更新');
    } finally {
      setBusy(false);
    }
  };

  /** Ask the Host to install the published release through DSH's plugin manager. */
  const apply = async () => {
    setApplying('正在下載並校驗更新檔…');
    setError('');
    try {
      const result = await readJson('api/aiapi/update/apply', {
        method: 'POST', headers: { 'content-type': 'application/json' }, body: '{}',
      });
      if (result.status === 'current') { setApplying('已是最新版本。'); return; }
      if (result.status !== 'updating') throw new Error(result.error ?? '更新未被接受');
      setApplying(`正在安裝 ${result.version}…`);
      // The install outlives this request: the manager's own outcome decides the next step.
      for (let attempt = 0; attempt < 120; attempt += 1) {
        await new Promise(resolve => setTimeout(resolve, 1000));
        const state = await readJson('api/aiapi/update/status').catch(() => undefined);
        if (state === undefined) continue;
        if (typeof state.onDisk === 'string' && state.onDisk !== '') setOnDisk(state.onDisk);
        if (state.phase === 'failed') { setApplying(''); throw new Error(state.error || '安裝失敗'); }
        if (state.phase !== 'done') continue;
        if (state.application === 'restart-required' || state.method === 'copy') {
          setNeedsReload(false);
          setRestartNeeded(true);
          setApplying(`已安裝 ${state.version}。需要重新啟動 DSH 才會生效（目前執行 ${state.running ?? current}）。`);
          return;
        }
        setNeedsReload(true);
        setApplying(`已安裝 ${state.version}；請按「重新載入頁面」。`);
        return;
      }
      setApplying(`下載與安裝已送出，但 2 分鐘內沒有結果。請完全結束 DSH 再開，或手動安裝 ${result.file ?? '更新檔'}。`);
    } catch (failure) {
      const message = failure instanceof Error ? failure.message : '更新失敗';
      setApplying('');
      if (message.includes('尚未設定更新來源')) setError('尚未設定更新來源（updateManifestUrl）。');
      else if (message.includes('沒有提供外掛管理服務')) setError(message);
      else setError(message);
    }
  };

  useEffect(() => { void check(); }, []);

  const spec = latest?.spec ?? latest?.tarball;
  // The published version and this build must differ; the presence of an install spec means nothing.
  const newer = latest !== null && current !== '' && latest.version !== current;
  return (
    <div className="aiapi-up">
      <span>版本 {current === '' ? '讀取中…' : current}</span>
      <button type="button" disabled={busy} onClick={() => { void check(); }}>{busy ? '檢查中…' : '檢查更新'}</button>
      {onDisk !== '' && current !== '' && onDisk !== current
        ? <span className="newer">磁碟上已是 {onDisk}（執行中 {current}）→ 請完全結束 DSH 再開</span>
        : null}
      {latest === null
        ? null
        : newer
          ? <span className="newer">有新版本 {latest.version}</span>
          : <span>已是最新（{latest.version}）</span>}
      {newer && applying === ''
        ? <button type="button" disabled={busy} onClick={() => { void apply(); }}>立即更新</button>
        : null}
      {applying === '' ? null : (
        <span>
          {applying}
          {restartNeeded
            ? <button type="button" onClick={async () => {
                setApplying('正在重新啟動 DSH…');
                if (await restartDsh()) return;
                setApplying('這個 DSH 不支援自動重啟。請完全結束 DSH（⌘Q）再重新開啟。');
              }}>重新啟動 DSH</button>
            : needsReload
              ? <button type="button" onClick={() => window.location.reload()}>重新載入頁面</button>
              : null}
        </span>
      )}
      {newer && applying === '' && error !== '' && spec !== undefined ? <span>或手動貼：<code>{spec}</code></span> : null}
      {error === '' ? null : <span>{error}</span>}
    </div>
  );
}

/**
 * Offer the update on every DSH start while this build is behind the published one — once per page load,
 * so a dismissed dialog is not reopened by navigation. The dialog is plain DOM: it must work before any
 * page-level React surface exists, and it is removed with the plugin's disposal scope.
 * @param ctx - client plugin context.
 * @returns nothing.
 */
export function applyUpdateNotice(ctx) {
  ctx.effect(() => {
    let disposed = false;
    let root;
    let settled = false;
    const timers = new Set();
    const close = () => { root?.remove(); root = undefined };

    const offerRestart = async (latest, current) => {
      const primary = root?.querySelector('[data-aiapi-primary]');
      const body = root?.querySelector('[data-aiapi-body]');
      if (primary !== null && primary !== undefined) { primary.disabled = true; primary.textContent = '正在重新啟動…'; }
      if (await restartDsh()) return;
      if (body !== null && body !== undefined) {
        body.textContent = `已安裝 ${latest.version}。這個 DSH 不支援自動重啟，請完全結束 DSH（⌘Q）再重新開啟，版本才會變成 ${latest.version}。`;
      }
      if (primary !== null && primary !== undefined) { primary.remove(); }
    };

    const render = (latest, current, needsRestart) => {
      root = document.createElement('div');
      root.dataset.aiapiUpdateNotice = '';
      Object.assign(root.style, {
        position: 'fixed', right: '18px', bottom: '18px', zIndex: '9999', maxWidth: '380px',
        padding: '14px 16px', borderRadius: '12px', background: '#1f2329', color: '#fff',
        boxShadow: '0 12px 32px rgba(0,0,0,.35)', font: '13px/1.55 -apple-system,"Segoe UI",system-ui,sans-serif',
      });

      const title = document.createElement('div');
      title.style.fontWeight = '600';
      title.style.marginBottom = '4px';
      title.textContent = needsRestart ? `Aiapi 插件 ${latest.version} 已安裝` : `Aiapi 插件有新版本 ${latest.version}`;

      const body = document.createElement('div');
      body.dataset.aiapiBody = '';
      body.style.opacity = '.85';
      body.textContent = needsRestart
        ? `需要重新啟動 DSH 才會生效（目前執行 ${current}）。`
        : latest.notes ? `${latest.notes}（目前 ${current}）` : `目前 ${current}，可更新到 ${latest.version}。`;

      const row = document.createElement('div');
      row.style.display = 'flex';
      row.style.gap = '8px';
      row.style.marginTop = '10px';
      const primary = document.createElement('button');
      primary.type = 'button';
      primary.dataset.aiapiPrimary = '';
      primary.textContent = needsRestart ? '重新啟動 DSH' : '立即更新';
      Object.assign(primary.style, { padding: '5px 12px', borderRadius: '8px', border: '0', background: '#1f6feb', color: '#fff', cursor: 'pointer', font: 'inherit' });
      const secondary = document.createElement('button');
      secondary.type = 'button';
      secondary.textContent = '稍後';
      Object.assign(secondary.style, { padding: '5px 12px', borderRadius: '8px', border: '1px solid rgba(255,255,255,.35)', background: 'transparent', color: '#fff', cursor: 'pointer', font: 'inherit' });

      primary.addEventListener('click', async () => {
        if (needsRestart) { await offerRestart(latest, current); return; }
        primary.disabled = true;
        primary.textContent = '處理中…';
        try {
          const result = await readJson('api/aiapi/update/apply', { method: 'POST', headers: { 'content-type': 'application/json' }, body: '{}' });
          if (result.status === 'current') { body.textContent = '已是最新版本。'; primary.remove(); return; }
          if (result.status !== 'updating') throw new Error(result.error ?? '更新未被接受');
          settled = true;
          body.textContent = `正在安裝 ${result.version}…`;
          for (let attempt = 0; attempt < 120; attempt += 1) {
            await new Promise(resolve => setTimeout(resolve, 1000));
            const state = await readJson('api/aiapi/update/status').catch(() => undefined);
            if (state === undefined) continue;
            if (state.phase === 'failed') throw new Error(state.error || '安裝失敗');
            if (state.phase !== 'done') continue;
            body.textContent = `已安裝 ${state.version}；需要重新啟動 DSH 才會生效。`;
            primary.textContent = '重新啟動 DSH';
            primary.disabled = false;
            primary.onclick = () => { void offerRestart(state, current); };
            return;
          }
          body.textContent = '已送出安裝，但 2 分鐘內沒有結果；請完全結束 DSH 再開。';
          primary.remove();
        } catch (error) {
          body.textContent = error instanceof Error ? error.message : '更新失敗';
          primary.disabled = false;
          primary.textContent = '立即更新';
        }
      });
      secondary.addEventListener('click', close);

      row.append(primary, secondary);
      root.append(title, body, row);
      document.body.append(root);
    };

    /** Ask the Host what it knows; a failure is retried, never surfaced. */
    const check = async () => {
      if (disposed || settled) return true;
      try {
        const info = await readJson('api/aiapi/update');
        const installed = typeof info.onDisk === 'string' ? info.onDisk : '';
        if (installed !== '' && installed !== info.version) {
          updateStore.publish({ current: info.version, installed, newer: false });
          return true;
        }
        const result = await readJson('api/aiapi/update/check', { method: 'POST', headers: { 'content-type': 'application/json' }, body: '{}' });
        if (disposed) return true;
        updateStore.publish({ current: info.version, latest: result.latest ?? undefined, installed, newer: result.newer === true });
        console.info('[aiapi] 更新檢查:', { current: info.version, latest: result.latest?.version, newer: result.newer === true, installed });
        return true;
      } catch (failure) {
        console.warn('[aiapi] 更新檢查失敗:', failure);
        return false;
      }
    };

    // Render from the shared record, so a check made on the plugin page also raises the popup.
    const unsubscribe = updateStore.subscribe(state => {
      if (disposed || settled || root !== undefined) return;
      const needsRestart = state.installed !== '' && state.current !== '' && state.installed !== state.current;
      if (needsRestart) { render({ version: state.installed, notes: '' }, state.current, true); return; }
      if (state.newer && state.latest !== undefined && state.current !== '') render(state.latest, state.current, false);
    });

    let attempt = 0;
    const schedule = () => {
      const delays = [0, 4000, 12000, 30000, 90000];
      const delay = attempt < delays.length ? delays[attempt] : 600000;
      attempt += 1;
      const timer = setTimeout(async () => {
        timers.delete(timer);
        if (disposed) return;
        const finished = await check();
        if (!finished || root === undefined) schedule();
      }, delay);
      timers.add(timer);
    };
    const onVisible = () => { if (document.visibilityState === 'visible' && root === undefined) void check(); };
    document.addEventListener('visibilitychange', onVisible);
    schedule();

    return () => {
      disposed = true;
      unsubscribe();
      document.removeEventListener('visibilitychange', onVisible);
      for (const timer of timers) clearTimeout(timer);
      close();
    };
  }, 'aiapi update notice');
}

/**
 * Balance card with the switch that owns the sidebar bar. The switch is volatile, so flipping it never
 * remounts the plugin: the bar is mounted or disposed on its own.
 * @param props - client plugin context injected by the slot.
 * @returns the card element.
 */
function BalanceRow({ ctx }) {
  const [enabled, setEnabled] = useState(() => balanceFlag.on);
  useEffect(() => {
    let alive = true;
    void (async () => {
      try {
        const view = pickNamespace((await describe(ctx)).namespaces);
        if (alive && view?.value?.balanceBar === true) { setEnabled(true); setBalanceFlag(true); }
      } catch { /* keep the current state when the settings view is unavailable */ }
    })();
    return () => { alive = false; };
  }, []);
  const toggle = async (next) => {
    setEnabled(next);
    setBalanceFlag(next);
    try {
      const view = pickNamespace((await describe(ctx)).namespaces);
      if (view === undefined) throw new Error('找不到設定命名空間');
      const response = await ctx.remote.settings.mutate(view.ns, [{ op: 'set', path: 'balanceBar', value: next }], view.revision);
      if (response?.ok === false) throw new Error(response.error?.message ?? '寫入被拒絕');
    } catch {
      setEnabled(!next);
      setBalanceFlag(!next);
    }
  };
  return <BalanceCard enabled={enabled} onToggle={toggle} />;
}

/** The sidebar bar follows the stored switch: mounted once, it renders nothing while the switch is off. */
function BalanceFooterBar() {
  const [on, setOn] = useState(balanceFlag.on);
  useEffect(() => {
    setOn(balanceFlag.on);
    balanceFlag.listeners.add(setOn);
    return () => { balanceFlag.listeners.delete(setOn); };
  }, []);
  return on ? <BalanceBar /> : null;
}

/**
 * Register the sidebar balance bar once; it hides itself when the switch is off.
 * @param ctx - client plugin context.
 * @returns nothing; the registration lives in the plugin's disposal scope.
 */
export function applyBalanceBar(ctx) {
  // 讀一次設定：條子是否顯示不該取決於「插件頁有沒有被打開過」。
  void (async () => {
    try {
      const view = pickNamespace((await describe(ctx)).namespaces);
      const stored = view?.value?.balanceBar === true;
      setBalanceFlag(stored);
      console.info('[aiapi] balanceBar 設定讀取:', stored);
    } catch (failure) {
      console.warn('[aiapi] balanceBar 設定讀取失敗:', failure);
    }
  })();
  try {
    ctx.slots.inject('sidebar.footer.action', () => ctx.slots.register({
      name: 'sidebar.footer.action', id: 'aiapi-balance', order: 5,
    }, () => <BalanceFooterBar />));
    console.info('[aiapi] 已註冊 sidebar.footer.action 餘額條');
  } catch (failure) {
    console.warn('[aiapi] sidebar.footer.action 註冊失敗:', failure);
  }
}

/**
 * 在 DSH 設定裡註冊「AIAPI 帳號」區塊（就放在「帳號」同一層），顯示登入狀態、平台餘額與常駐餘額條開關。
 * @param ctx - client plugin context.
 */
export function applyBalanceSection(ctx) {
  try {
    ctx.slots.inject('settings.section', () => ctx.slots.register({
      name: 'settings.section', id: 'aiapi-account', order: 45, label: () => 'AIAPI 帳號',
    }, () => <BalancePage ctx={ctx} />));
    console.info('[aiapi] 已註冊 settings.section「AIAPI 帳號」');
  } catch (failure) {
    console.warn('[aiapi] settings.section 註冊失敗:', failure);
  }
}

/**
 * 單張卡片的最小錯誤邊界：卡片內部出錯時只顯示一行提示，不影響同一頁其他內容。
 */
class CardBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { error: undefined };
  }
  static getDerivedStateFromError(error) {
    return { error };
  }
  componentDidCatch(error) {
    console.warn('[aiapi] 卡片渲染失敗:', this.props?.label ?? '', error);
  }
  render() {
    if (this.state.error !== undefined) {
      return <div className="aiapi-fe-error">這個區塊載入失敗：{String(this.state.error?.message ?? this.state.error)}</div>;
    }
    return this.props.children;
  }
}
