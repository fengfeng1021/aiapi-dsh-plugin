/**
 * Font-family and weight model ported from the Aiapi desktop theme settings.
 *
 * Windows Terminal parity: one Latin/digit family and one Chinese family form
 * each stack; the body weight follows the Chinese family, the code weight
 * follows the Latin family. Only variable/bundled families expose a slider;
 * fixed system families render 400 while their stored value stays as memory.
 */

/** Font families accepted for Latin letters and digits. */
export const LATIN_FONTS = ['Cascadia Mono', 'Noto Sans Mono'];

/** Font families accepted for Chinese characters. */
export const CJK_FONTS = [
  'Microsoft YaHei UI', 'Microsoft YaHei', 'Microsoft JhengHei UI', 'Microsoft JhengHei', 'Maple Mono CN',
];

/** Stored defaults; the first entries are the Windows Terminal pairing. */
export const DEFAULT_FONTS = Object.freeze({
  latin: 'Cascadia Mono',
  cjk: 'Microsoft YaHei UI',
  latinWeight: 400,
  cjkWeight: 500,
  size: 14,
});

/** Smallest and largest conversation text size the official theme service accepts. */
export const SIZE_MIN = 10;
export const SIZE_MAX = 22;

/**
 * Adjustable weight window of one Latin family.
 * @param family - selected Latin family.
 * @returns the slider window, or null for a fixed-weight family.
 */
export function latinWeightSpec(family) {
  return family === 'Noto Sans Mono' ? { min: 100, max: 900, step: 10, default: 400 } : null;
}

/**
 * Adjustable weight window of one Chinese family.
 * @param family - selected Chinese family.
 * @returns the slider window, or null for a fixed-weight family.
 */
export function cjkWeightSpec(family) {
  return family === 'Maple Mono CN' ? { min: 400, max: 700, step: 50, default: 500 } : null;
}

const clamp = (spec, raw) => Math.min(spec.max, Math.max(spec.min, Math.round(raw)));

/**
 * Weight a family actually renders; fixed families ignore the stored value.
 * @param family - selected family.
 * @param raw - stored weight.
 * @param spec - family window from {@link latinWeightSpec} or {@link cjkWeightSpec}.
 * @returns the rendered weight.
 */
export function effectiveWeight(family, raw, spec) {
  if (spec === null) return 400;
  const value = Number.isFinite(raw) ? raw : spec.default;
  return clamp(spec, value);
}

/**
 * Build the interface and code stacks for one Latin/Chinese pairing.
 * @param latin - Latin/digit family.
 * @param cjk - Chinese family.
 * @returns ui and code CSS font-family lists.
 */
export function fontStacks(latin, cjk) {
  const latinFamily = `'${latin}'`;
  const chinese = [cjk, ...CJK_FONTS.filter(family => family !== cjk)].map(family => `'${family}'`).join(', ');
  return {
    ui: `${latinFamily}, ${chinese}, -apple-system, BlinkMacSystemFont, 'Segoe UI', 'PingFang SC', 'Hiragino Sans GB', 'Helvetica Neue', Helvetica, Arial, sans-serif`,
    code: `${latinFamily}, ${chinese}, Consolas, 'Liberation Mono', Menlo, Courier, 'PingFang SC'`,
  };
}

/**
 * Read the stored selection, rejecting values this build no longer offers.
 * @param storage - localStorage-like object, or null when unavailable.
 * @returns the complete selection with defaults filled in.
 */
export function readFontSettings(storage) {
  let stored = {};
  try {
    stored = JSON.parse(storage?.getItem('aiapi.fonts') ?? '{}') ?? {};
  } catch {
    stored = {};
  }
  return {
    latin: LATIN_FONTS.includes(stored.latin) ? stored.latin : DEFAULT_FONTS.latin,
    cjk: CJK_FONTS.includes(stored.cjk) ? stored.cjk : DEFAULT_FONTS.cjk,
    latinWeight: Number.isInteger(stored.latinWeight) ? stored.latinWeight : DEFAULT_FONTS.latinWeight,
    cjkWeight: Number.isInteger(stored.cjkWeight) ? stored.cjkWeight : DEFAULT_FONTS.cjkWeight,
    size: Number.isInteger(stored.size) && stored.size >= SIZE_MIN && stored.size <= SIZE_MAX ? stored.size : DEFAULT_FONTS.size,
  };
}

/**
 * Persist a selection; a storage failure only loses the preference for later launches.
 * @param storage - localStorage-like object, or null when unavailable.
 * @param settings - complete selection to store.
 */
export function writeFontSettings(storage, settings) {
  try {
    storage?.setItem('aiapi.fonts', JSON.stringify(settings));
  } catch {
    // The current page keeps the applied selection.
  }
}
