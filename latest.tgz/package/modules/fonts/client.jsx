import React, { useEffect, useState } from 'react';
import {
  CJK_FONTS, LATIN_FONTS, SIZE_MAX, SIZE_MIN,
  cjkWeightSpec, effectiveWeight, fontStacks, latinWeightSpec, readFontSettings, writeFontSettings,
} from './settings.mjs';

/**
 * Font section: Latin and Chinese family pickers with live previews, weight
 * sliders for the families that ship adjustable weights, and the conversation
 * text size. It shadows the official `font-size` row at a lower priority, so
 * the General page shows this control instead of the plain size stepper.
 *
 * Families and sizes are written through the official `theme` service
 * (`setFontFamily`, `setFontSize`), so they persist in the user settings
 * document and follow the official presenter. Weights have no official API;
 * they ride two scoped CSS variables on the document root.
 */

const STORAGE_KEY = 'aiapi.fonts';
const ATTRIBUTE = 'data-aiapi-fonts';
const UI_FONT_VARIABLE = '--dsh-font-family-text';
const CODE_FONT_VARIABLE = '--dsh-font-family-code';
const SIZE_VARIABLE = '--dsh-content-font-size';

const CSS = `
@font-face {
  font-family: 'Noto Sans Mono';
  font-style: normal;
  font-weight: 100 900;
  font-display: swap;
  src: url('fonts/noto-sans-mono-latin-ext.woff2') format('woff2');
  unicode-range: U+0100-02BA, U+02BD-02C5, U+02C7-02CC, U+02CE-02D7, U+02DD-02FF, U+0304, U+0308, U+0329, U+1D00-1DBF, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20C0, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
@font-face {
  font-family: 'Noto Sans Mono';
  font-style: normal;
  font-weight: 100 900;
  font-display: swap;
  src: url('fonts/noto-sans-mono-latin.woff2') format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
${[400, 500, 600, 700].map(weight => `@font-face {
  font-family: 'Maple Mono CN';
  font-style: normal;
  font-weight: ${weight};
  font-display: swap;
  src: url('fonts/maple-mono-cn-${weight}.woff2') format('woff2');
  unicode-range: U+2E80-2EFF, U+2F00-2FDF, U+3000-303F, U+3040-309F, U+30A0-30FF, U+3100-312F, U+3130-318F, U+3190-319F, U+31A0-31FF, U+3200-32FF, U+3300-33FF, U+3400-4DBF, U+4E00-9FFF, U+A000-A48F, U+A490-A4CF, U+AC00-D7AF, U+D7B0-D7FF, U+F900-FAFF, U+FE10-FE1F, U+FE30-FE4F, U+FF00-FF60, U+FFE0-FFE6, U+20000-2EBEF, U+2F800-2FA1F, U+30000-323AF;
}`).join('\n')}
html[${ATTRIBUTE}] body { font-weight: var(--aiapi-body-weight, 400); }
html[${ATTRIBUTE}] code, html[${ATTRIBUTE}] pre, html[${ATTRIBUTE}] kbd, html[${ATTRIBUTE}] samp {
  font-weight: var(--aiapi-code-weight, 400);
}

.aiapi-font-block { display: flex; flex-direction: column; gap: 14px; padding: 12px 0; border-bottom: 1px solid var(--dsw-alias-border-l2); }
.aiapi-font-head { display: flex; flex-direction: column; gap: 2px; }
.aiapi-font-title { color: var(--dsw-alias-label-primary); font-size: 14px; }
.aiapi-font-desc { color: var(--dsw-alias-label-tertiary); font-size: 12px; }
.aiapi-font-group { display: flex; flex-direction: column; gap: 6px; }
.aiapi-font-label { color: var(--dsw-alias-label-primary); font-size: 13px; }
.aiapi-font-hint { color: var(--dsw-alias-label-tertiary); font-size: 12px; }
.aiapi-font-select {
  min-width: 220px; max-width: 100%; padding: 6px 8px; border-radius: 8px;
  border: 1px solid var(--dsw-alias-border-l2); background: var(--dsw-alias-bg-layer-2);
  color: var(--dsw-alias-label-primary); font-size: 13px;
}
.aiapi-font-preview { color: var(--dsw-alias-label-secondary); font-size: 13px; padding: 6px 8px; border-radius: 8px; background: var(--dsw-alias-bg-layer-2); }
.aiapi-font-weight { display: flex; align-items: center; gap: 10px; }
.aiapi-font-weight input[type='range'] { flex: 1; min-width: 120px; accent-color: var(--dsw-alias-link); }
.aiapi-font-weight-value { color: var(--dsw-alias-label-secondary); font-size: 12px; font-variant-numeric: tabular-nums; min-width: 32px; text-align: right; }
.aiapi-font-size { display: flex; align-items: center; gap: 8px; }
.aiapi-font-size button {
  width: 26px; height: 26px; border-radius: 999px; border: 1px solid var(--dsw-alias-border-l2);
  background: var(--dsw-alias-bg-layer-2); color: var(--dsw-alias-label-primary); font: inherit; cursor: pointer;
}
.aiapi-font-size button:disabled { opacity: 0.4; cursor: default; }
.aiapi-font-size-value { min-width: 40px; text-align: center; color: var(--dsw-alias-label-primary); font-variant-numeric: tabular-nums; }
.aiapi-font-note { color: var(--dsw-alias-label-tertiary); font-size: 12px; }
`;

const getTheme = ctx => {
  try {
    return ctx.get('theme');
  } catch {
    return undefined;
  }
};

const readPickerState = ctx => {
  let storage;
  try {
    storage = window.localStorage;
  } catch {
    storage = null;
  }
  const settings = readFontSettings(storage);
  const existing = storage?.getItem(STORAGE_KEY);
  if (existing === null || existing === undefined) {
    const current = getTheme(ctx)?.getTheme?.()?.fontSizes?.text;
    if (Number.isInteger(current)) settings.size = current;
  }
  return { storage, settings };
};

const applyFonts = (ctx, settings) => {
  if (typeof document === 'undefined') return;
  const root = document.documentElement;
  const stacks = fontStacks(settings.latin, settings.cjk);
  const latinSpec = latinWeightSpec(settings.latin);
  const cjkSpec = cjkWeightSpec(settings.cjk);
  const bodyWeight = effectiveWeight(settings.cjk, settings.cjkWeight, cjkSpec);
  const codeWeight = effectiveWeight(settings.latin, settings.latinWeight, latinSpec);
  root.setAttribute(ATTRIBUTE, '');
  root.style.setProperty('--aiapi-body-weight', String(bodyWeight));
  root.style.setProperty('--aiapi-code-weight', String(codeWeight));
  const theme = getTheme(ctx);
  try {
    if (typeof theme?.setFontFamily === 'function') {
      theme.setFontFamily('text', stacks.ui);
      theme.setFontFamily('code', stacks.code);
    } else if (document.body) {
      document.body.style.setProperty(UI_FONT_VARIABLE, stacks.ui);
      document.body.style.setProperty(CODE_FONT_VARIABLE, stacks.code);
    }
    if (typeof theme?.setFontSize === 'function') theme.setFontSize('text', settings.size);
    else document.body?.style.setProperty(SIZE_VARIABLE, `${settings.size}px`);
  } catch {
    // A late or read-only theme service still gets the stacks through the variables.
    document.body?.style.setProperty(UI_FONT_VARIABLE, stacks.ui);
    document.body?.style.setProperty(CODE_FONT_VARIABLE, stacks.code);
    document.body?.style.setProperty(SIZE_VARIABLE, `${settings.size}px`);
  }
};

/** One font group: label, picker, live preview, and an optional weight slider. */
function FontGroup({ title, hint, value, options, weight, spec, preview, onChange, onWeight }) {
  return (
    <div className="aiapi-font-group">
      <span className="aiapi-font-label">{title}</span>
      <span className="aiapi-font-hint">{hint}</span>
      <select
        className="aiapi-font-select"
        aria-label={title}
        value={value}
        onChange={event => onChange(event.target.value)}
      >
        {options.map(option => <option key={option} value={option}>{option}</option>)}
      </select>
      <div className="aiapi-font-preview" style={{ fontFamily: `'${value}'`, fontWeight: weight }}>{preview}</div>
      {spec !== null && (
        <label className="aiapi-font-weight">
          <input
            type="range"
            min={spec.min}
            max={spec.max}
            step={spec.step}
            value={weight}
            aria-label={`${title} 字重`}
            onChange={event => onWeight(Number(event.target.value))}
          />
          <span className="aiapi-font-weight-value">{weight}</span>
        </label>
      )}
    </div>
  );
}

/**
 * General-settings row replacing the official size control.
 * @param props - slot props plus the client context; this row owns its state.
 */
function FontRow({ context }) {
  const [state, setState] = useState(() => readPickerState(context));
  useEffect(() => {
    setState(readPickerState(context));
  }, [context]);
  useEffect(() => {
    applyFonts(context, state.settings);
    writeFontSettings(state.storage, state.settings);
  }, [context, state]);
  const settings = state.settings;
  const update = patch => setState(current => ({ ...current, settings: { ...current.settings, ...patch } }));
  const latinSpec = latinWeightSpec(settings.latin);
  const cjkSpec = cjkWeightSpec(settings.cjk);
  const latinWeight = effectiveWeight(settings.latin, settings.latinWeight, latinSpec);
  const cjkWeight = effectiveWeight(settings.cjk, settings.cjkWeight, cjkSpec);
  return (
    <div className="aiapi-font-block">
      <div className="aiapi-font-head">
        <span className="aiapi-font-title">字體</span>
        <span className="aiapi-font-desc">英文與數字、中文各用一款字體；可調字重與會話字級</span>
      </div>
      <FontGroup
        title="英文與數字"
        hint="程式碼、指令與英文內容所用的字體"
        value={settings.latin}
        options={LATIN_FONTS}
        weight={latinWeight}
        spec={latinSpec}
        preview="git pull --ff-only · 0123456789 · AaBbCcDdEe"
        onChange={latin => update({ latin, latinWeight: effectiveWeight(latin, settings.latinWeight, latinWeightSpec(latin)) })}
        onWeight={latinWeightValue => update({ latinWeight: latinWeightValue })}
      />
      <FontGroup
        title="中文"
        hint="中文內容所用的字體"
        value={settings.cjk}
        options={CJK_FONTS}
        weight={cjkWeight}
        spec={cjkSpec}
        preview="中文等寬預覽 0123456789 AaBb · 繁體測試 · 简体测试"
        onChange={cjk => update({ cjk, cjkWeight: effectiveWeight(cjk, settings.cjkWeight, cjkWeightSpec(cjk)) })}
        onWeight={cjkWeightValue => update({ cjkWeight: cjkWeightValue })}
      />
      <div className="aiapi-font-size">
        <span className="aiapi-font-label">會話字級</span>
        <button type="button" aria-label="減小字級" disabled={settings.size <= SIZE_MIN} onClick={() => update({ size: settings.size - 1 })}>−</button>
        <span className="aiapi-font-size-value">{settings.size} px</span>
        <button type="button" aria-label="增大字級" disabled={settings.size >= SIZE_MAX} onClick={() => update({ size: settings.size + 1 })}>＋</button>
      </div>
      <span className="aiapi-font-note">正文粗細跟隨中文，程式碼粗細跟隨英文與數字</span>
    </div>
  );
}

/**
 * Install the font styles and the replacement General-settings row.
 * @param ctx - client plugin context.
 */
export function apply(ctx) {
  ctx.effect(() => {
    const style = document.createElement('style');
    style.dataset.aiapiFonts = '';
    style.textContent = CSS;
    document.head.append(style);
    return () => style.remove();
  });
  ctx.effect(() => {
    const { storage, settings } = readPickerState(ctx);
    writeFontSettings(storage, settings);
    applyFonts(ctx, settings);
    // The client theme service may register after this plugin; reapply once it exists.
    const fiber = typeof ctx.inject === 'function' ? ctx.inject(['theme'], () => applyFonts(ctx, settings)) : undefined;
    return () => {
      void fiber?.dispose?.();
      document.documentElement.removeAttribute(ATTRIBUTE);
      document.documentElement.style.removeProperty('--aiapi-body-weight');
      document.documentElement.style.removeProperty('--aiapi-code-weight');
    };
  });
  // Lowest priority renders; the official row registers at 0, so this shadows it.
  ctx.slots.inject('settings.general.item', () => ctx.slots.register(
    { name: 'settings.general.item', id: 'font-size', priority: -1, order: 11 },
    () => React.createElement(FontRow, { context: ctx }),
  ));
}
