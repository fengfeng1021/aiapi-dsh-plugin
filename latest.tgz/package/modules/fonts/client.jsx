/**
 * Fonts in Settings → General: for conversation text, code and the terminal, pick a family this computer actually
 * has and set the size.
 *
 * The row takes the place of DSH's own font group (same id, lower priority) and writes through the same official
 * theme service (`setFontFamily`, `setFontSize`), so values persist in the user's settings exactly as DSH's own
 * fields would and switching the feature off brings DSH's group back with the same values. Nothing is applied on
 * load: the theme service already owns that. Families are offered only when the browser can render them, and a
 * chosen family is placed ahead of DSH's built-in stack, so Chinese text still falls back to the system's Chinese
 * fonts.
 */
import React, { useEffect, useMemo, useState } from 'react';
import { installStyle } from '../ui/kit.jsx';

/** Roles, their size ranges (DSH's own) and the families worth offering for each. */
const ROLES = [
  {
    id: 'text', title: '對話與介面', min: 10, max: 22, fallback: 14,
    sample: 'Aiapi 字型預覽 · 繁體 简体 0123',
    families: ['PingFang TC', 'PingFang SC', 'PingFang HK', 'Hiragino Sans', 'Hiragino Sans GB', 'Noto Sans TC', 'Noto Sans SC', 'Noto Sans CJK TC', 'Source Han Sans TC', 'Source Han Sans SC', 'Microsoft JhengHei UI', 'Microsoft JhengHei', 'Microsoft YaHei UI', 'Microsoft YaHei', 'LXGW WenKai TC', 'LXGW WenKai', 'Sarasa Gothic TC', 'Inter', 'Helvetica Neue', 'Segoe UI', 'Roboto', 'Maple Mono CN', 'Maple Mono NF CN', 'Cascadia Mono', 'JetBrains Mono'],
  },
  {
    id: 'code', title: '程式碼', min: 10, max: 16, fallback: 11,
    sample: 'const ok = 0x1F; // 程式碼 0Oo1lI',
    families: ['SF Mono', 'Menlo', 'Monaco', 'JetBrains Mono', 'Fira Code', 'Cascadia Code', 'Cascadia Mono', 'Consolas', 'Source Code Pro', 'IBM Plex Mono', 'Roboto Mono', 'Noto Sans Mono', 'Maple Mono', 'Maple Mono CN', 'Maple Mono NF CN', 'Sarasa Mono TC', 'Sarasa Mono SC', 'Hack', 'Iosevka', 'Ubuntu Mono', 'Courier New'],
  },
  {
    id: 'terminal', title: '終端機', min: 10, max: 20, fallback: 13,
    sample: '$ git status  # 終端機 0123',
    families: ['SF Mono', 'Menlo', 'Monaco', 'JetBrains Mono', 'Fira Code', 'Cascadia Code', 'Cascadia Mono', 'Consolas', 'Source Code Pro', 'IBM Plex Mono', 'Roboto Mono', 'Noto Sans Mono', 'Maple Mono', 'Maple Mono CN', 'Maple Mono NF CN', 'Sarasa Mono TC', 'Hack', 'Iosevka', 'Ubuntu Mono'],
  },
];

const FONTS_CSS = `
.aiapi-fonts{padding:16px 0;border-bottom:.5px solid var(--dsw-alias-border-l2)}
.aiapi-fonts-head{margin-bottom:12px}
.aiapi-fonts .aiapi-card{padding:4px 16px}
.aiapi-fonts .aiapi-row{min-height:56px}
.aiapi-fonts .aiapi-row-copy{flex:1 1 auto;min-width:0}
.aiapi-fonts-sample{font-size:12px;line-height:18px;color:var(--dsw-alias-label-tertiary);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.aiapi-fonts .aiapi-select{min-width:180px;width:180px}
.aiapi-stepper{display:inline-flex;align-items:center;border:.5px solid var(--dsw-alias-border-l3);border-radius:var(--dsw-radius-md);height:32px;overflow:hidden}
.aiapi-stepper button{width:30px;height:100%;border:none;background:transparent;color:var(--dsw-alias-label-primary);font:inherit;font-size:15px;cursor:pointer}
.aiapi-stepper button:hover:not(:disabled){background:var(--dsw-alias-interactive-bg-hover)}
.aiapi-stepper button:disabled{color:var(--dsw-alias-label-dimmed);cursor:default}
.aiapi-stepper span{min-width:44px;text-align:center;font-size:13px;font-variant-numeric:tabular-nums}
`;

/**
 * Whether the browser renders a family: text measured in it differs from the generic fallback it names.
 * @param family - family name.
 * @returns true when installed (or otherwise available to the page).
 */
function renders(family) {
  const canvas = renders.canvas ??= document.createElement('canvas');
  const context = canvas.getContext('2d');
  if (context === null) return true;
  const sample = 'mmmmmmmmmmlli1WW@# 中文字型 0123';
  return ['monospace', 'sans-serif', 'serif'].some(base => {
    context.font = `48px ${base}`;
    const fallback = context.measureText(sample).width;
    context.font = `48px "${family}", ${base}`;
    return context.measureText(sample).width !== fallback;
  });
}

/** The first family of a stored list, unquoted; '' for DSH's built-in stack. */
const leadFamily = list => String(list ?? '').split(',')[0]?.trim().replace(/^["']|["']$/g, '') ?? '';

/** Read DSH's theme service, which may start after this plugin. */
const themeOf = ctx => { try { return ctx.get('theme'); } catch { return undefined; } };

/** The theme snapshot, re-read whenever the theme publishes. */
function useThemeSnapshot(ctx) {
  const [snapshot, setSnapshot] = useState(() => themeOf(ctx)?.getTheme?.());
  useEffect(() => {
    const read = () => setSnapshot(themeOf(ctx)?.getTheme?.());
    read();
    const off = typeof ctx.on === 'function' ? ctx.on('theme/change', read) : undefined;
    const timer = setInterval(read, 1500);
    return () => { off?.(); clearInterval(timer); };
  }, [ctx]);
  return snapshot;
}

/** One role: family picker with a live sample, and the size stepper. */
function RoleRow({ ctx, role, snapshot }) {
  const available = useMemo(() => role.families.filter(renders), [role]);
  const stored = snapshot?.fontFamilies?.[role.id] ?? '';
  const current = leadFamily(stored);
  const size = snapshot?.fontSizes?.[role.id] ?? role.fallback;
  const [error, setError] = useState('');
  const run = action => {
    try { action(themeOf(ctx)); setError(''); }
    catch (failure) { setError(failure?.message ?? String(failure)); }
  };
  const options = current !== '' && !available.includes(current) ? [current, ...available] : available;
  return <div className="aiapi-row">
    <div className="aiapi-row-copy">
      <span className="aiapi-row-title">{role.title}</span>
      <span className="aiapi-fonts-sample" style={{ fontFamily: stored || undefined }}>{role.sample}</span>
      {error === '' ? null : <span className="aiapi-row-caption aiapi-error-text">{error}</span>}
    </div>
    <div className="aiapi-row-actions">
      <select className="aiapi-select" aria-label={`${role.title}字型`} value={current} onChange={event => run(theme => theme.setFontFamily(role.id, event.target.value))}>
        <option value="">系統預設</option>
        {options.map(family => <option key={family} value={family} style={{ fontFamily: `"${family}"` }}>{family}{available.includes(family) ? '' : '（未安裝）'}</option>)}
      </select>
      <span className="aiapi-stepper" role="group" aria-label={`${role.title}字級`}>
        <button type="button" aria-label="縮小" disabled={size <= role.min} onClick={() => run(theme => theme.setFontSize(role.id, size - 1))}>−</button>
        <span>{size} px</span>
        <button type="button" aria-label="放大" disabled={size >= role.max} onClick={() => run(theme => theme.setFontSize(role.id, size + 1))}>＋</button>
      </span>
    </div>
  </div>;
}

/** The whole group that takes the place of DSH's font settings. */
function FontSettings({ ctx }) {
  const snapshot = useThemeSnapshot(ctx);
  if (themeOf(ctx) === undefined) return null;
  return <div className="aiapi-fonts">
    <div className="aiapi-fonts-head">
      <div className="aiapi-general-title">字型與字級</div>
      <div className="aiapi-general-description">只列出這台電腦已安裝的字型；選英文字型時，中文會自動接上系統的中文字型</div>
    </div>
    <div className="aiapi-card">
      {ROLES.map(role => <RoleRow key={role.id} ctx={ctx} role={role} snapshot={snapshot} />)}
    </div>
  </div>;
}

/**
 * Show the font group in place of DSH's own for this client plugin lifetime.
 * @param ctx - client plugin context.
 */
export function apply(ctx) {
  installStyle(ctx, 'fonts', FONTS_CSS);
  // A shared id: the lowest priority renders, and DSH's own font group registers at 0.
  ctx.slots.inject('settings.general.item', () => ctx.slots.register(
    { name: 'settings.general.item', id: 'font-size', priority: -1, order: 11 },
    () => <FontSettings ctx={ctx} />,
  ));
}
