/**
 * What the workspace-order feature is actually doing, for the Plugins page to show.
 *
 * The feature can only work when three things line up: the build exposes the workspace remote, the conversation list
 * can be read, and the sidebar renders the row of the conversation that just changed. When one of them is missing the
 * feature stays silent by design — which also makes it invisible, so it reports the first obstacle it hit instead of
 * leaving the user guessing.
 */
export const workspaceOrderStatus = {
  /** True once every ingredient was found at least once. */
  available: false,
  /** Why it is not running, in the user's words. */
  reason: '',
  /** Last successful reorder, as a short human sentence. */
  lastAction: '',
  /** When `lastAction` happened. */
  lastAt: 0,
  /** How many workspace rows the sidebar showed on the last tick. */
  workspaces: 0,
  /** Whether the remote was found at mount time. */
  hasRemote: false,
};

/**
 * Record an obstacle.
 * @param reason - one short sentence, already worded for the page.
 */
export function noteBlocked(reason) {
  if (workspaceOrderStatus.reason === reason) return;
  workspaceOrderStatus.reason = reason;
  workspaceOrderStatus.available = false;
}

/**
 * Record a successful reorder.
 * @param text - what was moved, in the user's words.
 * @param workspaces - how many workspace rows were visible.
 */
export function noteReorder(text, workspaces) {
  workspaceOrderStatus.available = true;
  workspaceOrderStatus.reason = '';
  workspaceOrderStatus.lastAction = text;
  workspaceOrderStatus.lastAt = Date.now();
  workspaceOrderStatus.workspaces = workspaces;
}
