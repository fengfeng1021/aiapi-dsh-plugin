/**
 * Workspace order follows activity: the workspace with the newest change floats to the top.
 *
 * DSH keeps the sidebar's workspace order as a manual list, so a folder you used five minutes ago can sit below one
 * you have not touched in a week. The registry exposes what is needed — `list()` returns each workspace with its
 * `updatedAt`, and `insertBefore({ workspaceId, beforeWorkspaceId })` rewrites the stored order — so this module
 * promotes the newest workspace to the front whenever that timestamp moves.
 *
 * It polls rather than subscribing: the workspace feed pushes increments for sessions and titles, but the ordering
 * decision here only needs the timestamp, and a three-second poll cannot race the user's own drag-to-reorder (the
 * stored order is compared, not assumed).
 */

/** How often the stored order and timestamps are compared. */
const INTERVAL_MS = 3000;

/**
 * Read a timestamp that may be a number or an ISO string.
 * @param value - the stored `updatedAt`.
 * @returns milliseconds since the epoch, or 0 when unreadable.
 */
function stampOf(value) {
  if (typeof value === 'number' && Number.isFinite(value)) return value;
  const parsed = Date.parse(String(value ?? ''));
  return Number.isFinite(parsed) ? parsed : 0;
}

/**
 * Promote the most recently updated workspace to the front.
 * @param ctx - client plugin context carrying `remote.workspaceController`.
 */
export function apply(ctx) {
  const controller = ctx?.remote?.workspaceController;
  if (controller?.list === undefined || controller?.insertBefore === undefined) return;
  /** The newest timestamp already acted on, so one change promotes once rather than every tick. */
  let handled = 0;
  const tick = async () => {
    const view = await controller.list();
    const items = Array.isArray(view?.items) ? view.items : [];
    if (items.length < 2) return;
    let newest = items[0];
    let newestAt = stampOf(items[0]?.updatedAt);
    for (const item of items.slice(1)) {
      const at = stampOf(item?.updatedAt);
      if (at > newestAt) { newest = item; newestAt = at; }
    }
    if (newestAt === 0 || newestAt <= handled) return;
    handled = newestAt;
    if (items[0]?.workspaceId === newest?.workspaceId) return;
    await controller.insertBefore({ workspaceId: newest.workspaceId, beforeWorkspaceId: items[0].workspaceId });
  };
  ctx.effect(() => {
    const timer = setInterval(() => { void tick().catch(() => {}); }, INTERVAL_MS);
    return () => clearInterval(timer);
  }, 'aiapi workspace order');
}
