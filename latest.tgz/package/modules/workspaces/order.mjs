/**
 * Workspace order follows activity: the workspace you just talked in moves to the top.
 *
 * DSH stores the sidebar order as a manual list and only reorders it when the user drags. Two official remotes are
 * enough to do better without touching the stored order by hand:
 *
 * - `session.list()` returns the visible conversations already ordered by activity, so the first row is the one that
 *   just changed.
 * - `workspace.insertBefore({ workspaceId, beforeWorkspaceId })` rewrites the stored order.
 *
 * The conversation row in the sidebar carries `data-row-key="session:<id>"` and sits inside its workspace's
 * `data-row-key="workspace:<id>"` row, which is how a session is mapped back to the workspace that owns it. Nothing
 * is cached locally: every tick reads the row order the sidebar is showing, so a user drag stays authoritative.
 */

import { noteBlocked, noteReorder, workspaceOrderStatus } from './status.js';

/** How often the newest conversation is checked. */
const INTERVAL_MS = 2500;

/**
 * Read the workspace id that owns a rendered row.
 * @param row - an element from the sidebar.
 * @returns the workspace id, or undefined when the row is not inside one.
 */
function workspaceOf(row) {
  const owner = row?.closest?.('[data-row-key^="workspace:"]');
  const key = owner?.getAttribute?.('data-row-key') ?? '';
  return key.startsWith('workspace:') ? key.slice('workspace:'.length) : undefined;
}

/**
 * Keep the most recently active workspace at the top.
 * @param ctx - client plugin context carrying `remote.workspace` and `remote.session`.
 */
export function apply(ctx) {
  const workspace = ctx?.remote?.workspace;
  const session = ctx?.remote?.session;
  workspaceOrderStatus.hasRemote = typeof workspace?.insertBefore === 'function';
  if (typeof workspace?.insertBefore !== 'function') { noteBlocked('這個版本沒有開放工作區排序介面'); return; }
  if (typeof session?.list !== 'function') { noteBlocked('這個版本沒有開放對話清單介面'); return; }
  if (typeof document === 'undefined') { noteBlocked('不在瀏覽器環境中'); return; }
  /** Last conversation acted on, so one change reorders once instead of every tick. */
  let handled = '';
  const tick = async () => {
    let view;
    try {
      view = await session.list({});
    } catch (error) {
      noteBlocked(`讀不到對話清單：${error?.message ?? error}`);
      return;
    }
    const newest = Array.isArray(view?.items) ? view.items[0] : undefined;
    const sessionId = newest?.sessionId;
    if (typeof sessionId !== 'string' || sessionId === '') { noteBlocked('對話清單是空的'); return; }
    const workspaceRows = [...document.querySelectorAll('[data-row-key^="workspace:"]')];
    workspaceOrderStatus.workspaces = workspaceRows.length;
    if (workspaceRows.length < 2) { noteBlocked(`側邊欄只有 ${workspaceRows.length} 個工作區，不需要排序`); return; }
    if (sessionId === handled) { workspaceOrderStatus.available = true; workspaceOrderStatus.reason = ''; return; }
    const rows = [...document.querySelectorAll('[data-row-key^="session:"]')];
    const row = rows.find(element => element.getAttribute('data-row-key') === `session:${sessionId}`);
    if (row === undefined) { noteBlocked('最新的對話在收合的工作區裡，看不到位置'); return; }
    handled = sessionId;
    const ownId = workspaceOf(row);
    const firstKey = workspaceRows[0].getAttribute('data-row-key') ?? '';
    const firstId = firstKey.startsWith('workspace:') ? firstKey.slice('workspace:'.length) : undefined;
    if (ownId === undefined || firstId === undefined) { noteBlocked('對不到工作區的識別碼'); return; }
    if (ownId === firstId) { noteReorder('已是最新，不需要移動', workspaceRows.length); return; }
    try {
      await workspace.insertBefore({ workspaceId: ownId, beforeWorkspaceId: firstId });
      noteReorder('已把最近有動靜的工作區移到最上面', workspaceRows.length);
    } catch (error) {
      noteBlocked(`排序被拒絕：${error?.message ?? error}`);
    }
  };
  ctx.effect(() => {
    const timer = setInterval(() => { void tick().catch(() => {}); }, INTERVAL_MS);
    return () => clearInterval(timer);
  }, 'aiapi workspace order');
}
