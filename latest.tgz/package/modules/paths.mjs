/** Where a folder shown to the user really lives once links, such as a data folder moved to another drive, are followed. */
import { realpath } from 'node:fs/promises';
import { basename, dirname, join } from 'node:path';

/**
 * Resolve links in the longest existing part of a path and keep the rest as written.
 * @param path - absolute path that may not exist yet.
 * @returns the real location, or the path itself when no part of it resolves.
 */
export async function realLocation(path) {
  const rest = [];
  for (let current = path; ; current = dirname(current)) {
    const real = await realpath(current).catch(() => undefined);
    if (real !== undefined) return join(real, ...rest.reverse());
    if (dirname(current) === current) return path;
    rest.push(basename(current));
  }
}
