/** One transient notice for the whole bundle, owned by the document and replaced on every call. */
let toastTimer;

/**
 * Show a short message in the bottom of the window.
 * @param level - `info` for normal results, `error` for failures (stays longer and is announced).
 * @param text - the message; kept short because it is overwritten by the next call.
 * @returns nothing.
 */
export function showToast(level, text) {
  let toast = document.querySelector('.aiapi-toast');
  if (!toast) {
    toast = document.createElement('div');
    toast.className = 'aiapi-toast';
    document.body.append(toast);
  }
  toast.dataset.level = level;
  toast.setAttribute('role', level === 'error' ? 'alert' : 'status');
  toast.textContent = text;
  toast.hidden = false;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.remove(), level === 'error' ? 8000 : 4000);
}
