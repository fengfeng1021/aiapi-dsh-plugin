/**
 * Shared pieces for every AIAPI surface: the host's own primitives, one stylesheet built only from DSH design
 * tokens, Host request helpers, and the single account store the sidebar, the account page and the plugin page
 * all read. One store means one balance request per refresh, however many surfaces are open.
 */
import React, { useSyncExternalStore } from 'react';
import * as primitives from '@deepseek-ai/dsh-client-ui-primitives';

export const { Button, Switch, Tag, StateDot, Tooltip, Modal, Input, Checkbox, SegmentedControl } = primitives;

/** Same-origin URL of one of this bundle's Host routes; relative, so a path-prefixed app still works. */
export const hostUrl = path => new URL(path.replace(/^\//, ''), document.baseURI);

/**
 * Call a Host route and decode its JSON.
 * @param path - route such as `api/aiapi/balance`.
 * @param body - JSON body for a POST; omitted for a GET.
 * @returns the decoded reply.
 * @throws an Error carrying `status` and the Host's `code` (`status` field) when the reply is not 2xx.
 */
export async function host(path, body) {
  const response = await fetch(hostUrl(path), body === undefined
    ? { credentials: 'same-origin', cache: 'no-store' }
    : { method: 'POST', credentials: 'same-origin', cache: 'no-store', headers: { 'content-type': 'application/json' }, body: JSON.stringify(body) });
  const text = await response.text();
  let value;
  try { value = text === '' ? {} : JSON.parse(text); } catch { value = undefined; }
  if (!response.ok) {
    const failure = new Error(value?.error ?? `回應 ${response.status}`);
    failure.status = response.status;
    failure.code = value?.status;
    throw failure;
  }
  return value ?? {};
}

/** Money the way the platform bills it. */
export function money(value, currency = 'USD') {
  if (typeof value !== 'number' || !Number.isFinite(value)) return '—';
  const symbol = currency === 'CNY' ? '¥' : currency === 'TWD' ? 'NT$' : '$';
  const digits = Math.abs(value) >= 1000 ? 0 : 2;
  return `${symbol}${value.toLocaleString('en-US', { minimumFractionDigits: digits, maximumFractionDigits: digits })}`;
}

/** Where the AIAPI web console lives; every "open AIAPI" link goes here. */
export const AIAPI_CONSOLE = 'https://aiapi.tw/';

/**
 * Add a stylesheet for the lifetime of a client plugin context.
 * @param ctx - client plugin context.
 * @param id - stable data attribute value, so a reload replaces instead of duplicating.
 * @param css - the rules.
 */
export function installStyle(ctx, id, css) {
  ctx.effect(() => {
    document.querySelector(`style[data-aiapi-style="${id}"]`)?.remove();
    const style = document.createElement('style');
    style.dataset.aiapiStyle = id;
    style.textContent = css;
    document.head.append(style);
    return () => style.remove();
  }, `aiapi style ${id}`);
}

/**
 * Layout shared by the settings surfaces, mirroring DSH's own settings sheets: cards on the settings-card fill
 * with a half-pixel stroke, 40px rows, 13/22 body text, tertiary captions. Only design tokens are used, so light,
 * dark and any theme layer apply without extra rules.
 */
export const KIT_CSS = `
.aiapi-section{display:flex;flex-direction:column;gap:16px;padding:8px 0;color:var(--dsw-alias-label-primary);font-size:13px;line-height:22px}
.aiapi-card{border:.5px solid var(--dsw-alias-settings-card-stroke);border-radius:var(--dsw-radius-xl);background:var(--dsw-alias-settings-card-fill);padding:4px 16px}
.aiapi-card>.aiapi-row+.aiapi-row{border-top:.5px solid var(--dsw-alias-border-l2)}
.aiapi-row{display:flex;align-items:center;justify-content:space-between;gap:16px;min-height:44px;padding:8px 0;box-sizing:border-box}
.aiapi-row-copy{display:flex;flex-direction:column;min-width:0}
.aiapi-row-title{font-size:13px;line-height:22px}
.aiapi-row-caption{color:var(--dsw-alias-label-tertiary);font-size:12px;line-height:18px}
.aiapi-row-actions{display:flex;align-items:center;justify-content:flex-end;gap:8px;flex:none;flex-wrap:wrap}
.aiapi-identity{display:flex;align-items:center;gap:10px;min-width:0}
.aiapi-mark{flex:none}
.aiapi-status{display:inline-flex;align-items:center;gap:6px}
.aiapi-name{font-size:14px;font-weight:500;line-height:22px}
.aiapi-amount{font-size:18px;font-weight:510;line-height:28px;font-variant-numeric:tabular-nums}
.aiapi-amount-sub{color:var(--dsw-alias-label-tertiary);font-size:12px;font-variant-numeric:tabular-nums}
.aiapi-meter{position:relative;width:140px;height:4px;border-radius:999px;background:var(--dsw-alias-border-l2);overflow:hidden}
.aiapi-meter>span{position:absolute;inset:0 auto 0 0;border-radius:999px;background:var(--dsw-alias-state-success-primary)}
.aiapi-meter[data-level=low]>span{background:var(--dsw-alias-state-warn-primary)}
.aiapi-meter[data-level=empty]>span{background:var(--dsw-alias-state-error-primary)}
.aiapi-link{color:var(--dsw-alias-label-primary);text-decoration:none;display:inline-flex;align-items:center;gap:2px}
.aiapi-link:hover{text-decoration:underline;text-underline-offset:3px}
.aiapi-muted{color:var(--dsw-alias-label-tertiary)}
.aiapi-error-text{color:var(--dsw-alias-state-error-primary)}
.aiapi-empty{display:flex;flex-direction:column;align-items:center;justify-content:center;gap:16px;padding:28px 12px;text-align:center}
.aiapi-empty-title{font-size:14px;line-height:22px}
.aiapi-empty-text{color:var(--dsw-alias-label-tertiary);font-size:12px;line-height:18px;max-width:440px;text-wrap:balance}
.aiapi-empty-title{text-wrap:balance}
.aiapi-code{font:600 22px/30px var(--dsh-font-family-code,ui-monospace,monospace);letter-spacing:.12em;padding:6px 14px;border-radius:var(--dsw-radius-md);background:var(--dsw-alias-bg-layer-1);border:.5px solid var(--dsw-alias-border-l2);user-select:all}
.aiapi-heading{font-size:13px;font-weight:500;color:var(--dsw-alias-label-secondary);padding:0 4px;margin-bottom:-8px}
.aiapi-general-row{display:flex;align-items:center;justify-content:space-between;gap:24px;padding:16px 0;border-bottom:.5px solid var(--dsw-alias-border-l2)}
.aiapi-general-title{font-size:14px;line-height:20px;color:var(--dsw-alias-label-primary)}
.aiapi-general-description{margin-top:4px;font-size:12px;line-height:18px;color:var(--dsw-alias-label-secondary)}
.aiapi-toast{position:fixed;left:50%;bottom:28px;transform:translateX(-50%);z-index:10000;max-width:min(560px,calc(100vw - 48px));box-sizing:border-box;padding:9px 16px;border-radius:var(--dsw-radius-xl);border:.5px solid var(--dsw-alias-border-l2);background:var(--dsw-alias-bg-overlay,var(--dsw-alias-bg-layer-2));color:var(--dsw-alias-label-primary);box-shadow:0 8px 24px rgba(0,0,0,.16);font-size:13px;line-height:20px;white-space:pre-line}
.aiapi-toast[data-level=error]{color:var(--dsw-alias-state-error-primary)}
.aiapi-select{box-sizing:border-box;height:32px;min-width:200px;max-width:100%;padding:0 10px;border-radius:var(--dsw-radius-md);border:.5px solid var(--dsw-alias-border-l3);background:var(--dsw-alias-bg-layer-1);color:var(--dsw-alias-label-primary);font:inherit;font-size:13px}
`;

/**
 * The account as every surface sees it, plus the actions that change it.
 *
 * `phase` is `loading` before the first answer, then `ok`, `signed-out` (no Smart Key), `invalid-key` (AIAPI
 * rejected it) or `error` (network or platform failure; the previous figures stay visible with the message).
 */
function createAccountStore() {
  let state = { phase: 'loading', data: undefined, error: '', at: 0, signIn: undefined, busy: false };
  const listeners = new Set();
  let inflight;
  let timer;
  const set = patch => {
    state = { ...state, ...patch };
    for (const listener of listeners) listener();
  };
  const refresh = () => {
    inflight ??= host('api/aiapi/balance')
      .then(data => set({ phase: 'ok', data, error: '', at: Date.now() }))
      .catch(failure => {
        if (failure?.status === 401) set({ phase: failure.code === 'invalid-key' ? 'invalid-key' : 'signed-out', data: undefined, error: '', at: Date.now() });
        else set({ phase: 'error', error: failure?.message ?? String(failure), at: Date.now() });
      })
      .finally(() => { inflight = undefined; });
    return inflight;
  };
  // Fresh while someone is looking: every two minutes, and on return to the window after a minute away.
  const schedule = () => {
    clearInterval(timer);
    timer = listeners.size > 0 ? setInterval(() => { if (document.visibilityState === 'visible') void refresh(); }, 120000) : undefined;
  };
  const onVisible = () => {
    if (document.visibilityState === 'visible' && listeners.size > 0 && Date.now() - state.at > 60000) void refresh();
  };
  return {
    get: () => state,
    subscribe(listener) {
      listeners.add(listener);
      if (listeners.size === 1) {
        document.addEventListener('visibilitychange', onVisible);
        if (state.phase === 'loading' || Date.now() - state.at > 60000) void refresh();
      }
      schedule();
      return () => {
        listeners.delete(listener);
        if (listeners.size === 0) document.removeEventListener('visibilitychange', onVisible);
        schedule();
      };
    },
    refresh,
    /** Device-code sign-in: the account login and approval happen on aiapi.tw; the Host stores the key. */
    async signIn() {
      if (state.busy) return;
      set({ busy: true, error: '' });
      try {
        const grant = await host('api/aiapi/device-auth/start', {});
        set({ signIn: grant });
        window.open(grant.verification_uri, '_blank', 'noopener');
        const interval = Math.max(3, Number.isFinite(grant.interval) ? grant.interval : 5) * 1000;
        const deadline = Date.now() + (Number.isFinite(grant.expires_in) ? grant.expires_in : 600) * 1000;
        while (Date.now() < deadline && state.signIn === grant) {
          await new Promise(resolve => setTimeout(resolve, interval));
          if (state.signIn !== grant) return;
          const result = await host('api/aiapi/device-auth/poll', {});
          if (result.status === 'authorization_pending') continue;
          if (result.status === 'complete') { set({ signIn: undefined }); await refresh(); return; }
          throw new Error(result.status === 'access_denied' ? '你在授權頁拒絕了這次登入。' : '授權已逾時，請重新登入。');
        }
        if (state.signIn === grant) throw new Error('授權已逾時，請重新登入。');
      } catch (failure) {
        set({ signIn: undefined, error: failure?.message ?? String(failure) });
      } finally {
        set({ busy: false });
      }
    },
    cancelSignIn() { set({ signIn: undefined, busy: false }); },
    async signOut() {
      set({ busy: true });
      try { await host('api/aiapi/disconnect', {}); }
      catch (failure) { set({ error: failure?.message ?? String(failure) }); }
      finally { set({ busy: false }); await refresh(); }
    },
  };
}

export const accountStore = createAccountStore();

/** The account state, re-rendering on every change. */
export function useAccount() {
  return useSyncExternalStore(accountStore.subscribe, accountStore.get);
}

/** Share of a key quota still available, or undefined when the key has no quota. */
export function quotaShare(data) {
  const limit = data?.quota?.limit;
  if (typeof limit !== 'number' || limit <= 0) return undefined;
  return Math.max(0, Math.min(1, (data.quota.remaining ?? 0) / limit));
}

/** A thin meter for a 0–1 share, coloured by what is left. */
export function Meter({ share, label }) {
  const level = share <= 0.02 ? 'empty' : share < 0.2 ? 'low' : 'ok';
  return <span className="aiapi-meter" data-level={level} role="meter" aria-label={label} aria-valuemin={0} aria-valuemax={100} aria-valuenow={Math.round(share * 100)}>
    <span style={{ width: `${Math.max(3, share * 100)}%` }} />
  </span>;
}

/**
 * This plugin's own settings namespace (switches like the sidebar balance), read and written through the
 * official settings service. Writes use list paths; a bare string would be split into characters.
 */
export const pluginSettings = {
  async read(ctx) {
    const response = await ctx.remote.settings.describe();
    if (response?.ok === false) throw new Error(response.error?.message ?? '無法讀取設定');
    const namespaces = (response?.value ?? response)?.namespaces ?? [];
    return namespaces.find(row => row?.ns === 'aiapi-customizations');
  },
  async write(ctx, path, value) {
    const view = await pluginSettings.read(ctx);
    if (view === undefined) throw new Error('找不到 Aiapi 插件的設定');
    const response = await ctx.remote.settings.mutate(view.ns, [{ op: 'set', path, value }], view.revision);
    if (response?.ok === false) throw new Error(response.error?.message ?? '設定寫入被拒絕');
  },
};

/**
 * Open DSH's Settings window. Its first section is 「账号与余额」, so this is how the sidebar balance takes the
 * user to the AIAPI account.
 * @param ctx - client plugin context.
 * @returns whether the command was available.
 */
export function openSettings(ctx) {
  try {
    const shortcuts = ctx.get?.('shortcuts');
    if (typeof shortcuts?.invoke !== 'function') return false;
    shortcuts.invoke('settings.open', { modal: null });
    return true;
  } catch {
    return false;
  }
}
